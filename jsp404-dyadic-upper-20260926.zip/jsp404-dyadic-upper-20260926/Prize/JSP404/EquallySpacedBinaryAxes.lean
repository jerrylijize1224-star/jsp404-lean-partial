import Prize.JSP404.BinaryScaleConstruction

/-! Equally spaced axes discharge the binary construction hypotheses at every
finite level count at least two. This is a general upper-bound construction;
it does not supply the universal lower bound or the full Sendov classification. -/

namespace Prize.JSP404

open scoped RealInnerProductSpace

noncomputable def circleDirection (a : ℝ) : Plane := !₂[Real.cos a, Real.sin a]

theorem circleDirection_norm (a : ℝ) : ‖circleDirection a‖ = 1 := by
  simp [circleDirection, EuclideanSpace.norm_eq, Fin.sum_univ_two,
    Real.cos_sq_add_sin_sq]

theorem circleDirection_nonzero (a : ℝ) : circleDirection a ≠ 0 := by
  intro h
  have hn := circleDirection_norm a
  rw [h, norm_zero] at hn
  norm_num at hn

theorem circleDirection_inner (a b : ℝ) :
    ⟪circleDirection a, circleDirection b⟫ = Real.cos (b - a) := by
  simp [circleDirection, PiLp.inner_apply, Fin.sum_univ_two, Real.cos_sub]

theorem circleDirection_angle {a b : ℝ} (hab : a ≤ b) (hba : b - a ≤ Real.pi) :
    InnerProductGeometry.angle (circleDirection a) (circleDirection b) = b - a := by
  rw [InnerProductGeometry.angle, circleDirection_norm, circleDirection_norm,
    circleDirection_inner, one_mul, div_one, Real.arccos_cos (sub_nonneg.mpr hab) hba]

noncomputable def equallySpacedBinaryAxes (n : ℕ) (r : Fin n) : Plane :=
  circleDirection ((r.val : ℝ) * (Real.pi / (n : ℝ)))

theorem equallySpacedBinaryAxes_nonzero {n : ℕ} (r : Fin n) :
    equallySpacedBinaryAxes n r ≠ 0 := circleDirection_nonzero _

theorem equallySpacedBinaryAxes_angle_of_lt {n : ℕ} (hn : 2 ≤ n)
    (r s : Fin n) (hrs : r < s) :
    InnerProductGeometry.angle (equallySpacedBinaryAxes n r) (equallySpacedBinaryAxes n s) =
      ((s.val : ℝ) - (r.val : ℝ)) * (Real.pi / (n : ℝ)) := by
  have hn0 : (0 : ℝ) < n := by exact_mod_cast (show 0 < n by omega)
  have hd : 0 < Real.pi / (n : ℝ) := div_pos Real.pi_pos hn0
  have hrsR : (r.val : ℝ) < s.val := by exact_mod_cast hrs
  have hsR : (s.val : ℝ) < n := by exact_mod_cast s.isLt
  have hr0 : (0 : ℝ) ≤ r.val := Nat.cast_nonneg _
  have hunit : (n : ℝ) * (Real.pi / (n : ℝ)) = Real.pi := by
    field_simp
  unfold equallySpacedBinaryAxes
  rw [circleDirection_angle (by nlinarith) (by nlinarith)]
  ring

/-- The unsigned angle between two distinct equally spaced axes is separated
from both zero and pi by at least pi/n. -/
theorem equallySpacedBinaryAxes_angle_bounds {n : ℕ} (hn : 2 ≤ n)
    (r s : Fin n) (hrs : r ≠ s) :
    Real.pi / (n : ℝ) ≤
        InnerProductGeometry.angle (equallySpacedBinaryAxes n r) (equallySpacedBinaryAxes n s) ∧
      InnerProductGeometry.angle (equallySpacedBinaryAxes n r) (equallySpacedBinaryAxes n s) ≤
        Real.pi - Real.pi / (n : ℝ) := by
  have ordered (r s : Fin n) (hrs : r < s) :
      Real.pi / (n : ℝ) ≤
          InnerProductGeometry.angle (equallySpacedBinaryAxes n r) (equallySpacedBinaryAxes n s) ∧
        InnerProductGeometry.angle (equallySpacedBinaryAxes n r) (equallySpacedBinaryAxes n s) ≤
          Real.pi - Real.pi / (n : ℝ) := by
    rw [equallySpacedBinaryAxes_angle_of_lt hn r s hrs]
    have hn0 : (0 : ℝ) < n := by exact_mod_cast (show 0 < n by omega)
    have hd : 0 < Real.pi / (n : ℝ) := div_pos Real.pi_pos hn0
    have hlow : (r.val : ℝ) + 1 ≤ s.val := by exact_mod_cast (show r.val + 1 ≤ s.val from hrs)
    have hhigh : (s.val : ℝ) + 1 ≤ n := by exact_mod_cast s.isLt
    have hr0 : (0 : ℝ) ≤ r.val := Nat.cast_nonneg _
    have hunit : (n : ℝ) * (Real.pi / (n : ℝ)) = Real.pi := by field_simp
    constructor <;> nlinarith
  rcases lt_or_gt_of_ne hrs with h | h
  · exact ordered r s h
  · rw [InnerProductGeometry.angle_comm]
    exact ordered s r h

theorem equallySpacedBinaryAxes_signed_angle {n : ℕ} (hn : 2 ≤ n)
    (r s : Fin n) (hrs : r ≠ s) (b c : Bool) :
    InnerProductGeometry.angle (signedBinaryAxis (equallySpacedBinaryAxes n r) b)
      (signedBinaryAxis (equallySpacedBinaryAxes n s) c) ≤ (1 - 1 / (n : ℝ)) * Real.pi := by
  obtain ⟨hl, hu⟩ := equallySpacedBinaryAxes_angle_bounds hn r s hrs
  have he : (1 - 1 / (n : ℝ)) * Real.pi = Real.pi - Real.pi / (n : ℝ) := by ring
  rw [he]
  cases b <;> cases c <;> simp only [signedBinaryAxis, Bool.false_eq_true, ↓reduceIte,
    InnerProductGeometry.angle_neg_left, InnerProductGeometry.angle_neg_right] <;> linarith

theorem exists_dyadic_counterexample {n : ℕ} (hn : 2 ≤ n) {ε : ℝ} (hε : 0 < ε) :
    ∃ s : Finset Plane, s.card = 2 ^ n ∧
      ¬ HasLargeAngle s ((1 - 1 / (n : ℝ)) * Real.pi + ε) := by
  apply exists_binaryScale_counterexample equallySpacedBinaryAxes_nonzero
    ?_ (equallySpacedBinaryAxes_signed_angle hn) hε
  have hnR : (1 : ℝ) ≤ n := by exact_mod_cast (show 1 ≤ n by omega)
  have : 1 / (n : ℝ) ≤ 1 := (div_le_one (by positivity)).mpr hnR
  positivity

theorem dyadic_alpha_upper {n m : ℕ} (hn : 2 ≤ n) (hm : 3 ≤ m) (hmn : m ≤ 2 ^ n) :
    alpha m ≤ (1 - 1 / (n : ℝ)) * Real.pi := by
  apply alpha_le_of_large_approximation hm
  intro ε hε
  obtain ⟨s, hs, hbad⟩ := exists_dyadic_counterexample hn hε
  exact ⟨s, by omega, hbad⟩

/-- Strictly larger angles fail to be guaranteed, even without restricting b
in advance to [0, pi]. Subsets provide every cardinality up to 2^n. -/
theorem dyadic_not_guaranteed {n m : ℕ} (hn : 2 ≤ n) (hmn : m ≤ 2 ^ n)
    {b : ℝ} (hb : (1 - 1 / (n : ℝ)) * Real.pi < b) : ¬ GuaranteedAngle m b := by
  obtain ⟨s, hs, hbad⟩ := exists_dyadic_counterexample hn (sub_pos.mpr hb)
  rw [show (1 - 1 / (n : ℝ)) * Real.pi +
    (b - (1 - 1 / (n : ℝ)) * Real.pi) = b by ring] at hbad
  exact not_guaranteedAngle_of_large_counterexample (by omega) hbad

/-- The upper-bound direction of the second band in SendovClaim, with exactly
the original range of cardinalities. This is not an IsSharpBound theorem. -/
theorem sendov_high_band_upper {k N : ℕ} (hk : 2 ≤ k)
    (hlo : 2 ^ k + 2 ^ (k - 2) < N) (hhi : N ≤ 2 ^ (k + 1)) :
    alpha N ≤ (1 - 1 / ((k : ℝ) + 1)) * Real.pi := by
  have hfour : 4 ≤ (2 : ℕ) ^ k := by
    calc
      4 = (2 : ℕ) ^ 2 := by norm_num
      _ ≤ 2 ^ k := pow_le_pow_right₀ (by decide) hk
  have hpow : 2 ^ k < N := lt_of_le_of_lt (Nat.le_add_right _ _) hlo
  have hN : 3 ≤ N := (by decide : 3 ≤ 4).trans (hfour.trans (Nat.le_of_lt hpow))
  simpa only [Nat.cast_add, Nat.cast_one] using
    dyadic_alpha_upper (show 2 ≤ k + 1 by omega) hN hhi

end Prize.JSP404
