# 25 点精确值为 144°

2026-11-05。Lean 已证明 `alpha 25 = 4*Real.pi/5` 和 25～32 点完整 `IsSharpBound`。
整库构建 3292 项、公理审计 4276 项全部成功，其中 4 项不依赖公理。
其余项只使用 `propext`、`Classical.choice`、`Quot.sound`。

连续模型使用已有的二十种规范类型。若存在 16 行三弧，则缺少四个类型。
`ThreeArcOrderModelFour.lean` 将缺失类型排成递增四元组。
`ThreeArcOrder16Checks.lean` 核验 167 份矛盾证书，每份证书只需要一部分类型。
`ThreeArcOrder16Coverage.lean` 证明每个递增缺失四元组都避开至少一份证书需要的类型，
共 4845 种情况。按前两个缺失编号分组，一共核验 190 组。
`ThreeArcOrderCoreHelpers.lean` 把相容模型限制到该证书需要的类型上，导出矛盾。

`ThreeArcFifteen.lean` 因此得到三弧上限 15。加上单弧上限 9，所有角小于 144° 的配置
至多有 24 个点。`TwentyfiveExact.lean` 用已有的二进制构造匹配上界。
精确值适用于任意有限平面点集。21～24 点仍为 [140°,144°]，任意点数主命题仍未完成。

证书共 9453 个节点，单份最多 124 个节点。以下命令从保存的具体证书重建数据、
检查声明及覆盖表。复现核对见 `logs/jsp404-order-certificate-16-reproduction-20261105.json`。

```sh
python3 scripts/export_three_arc_order16_certificate.py --library research/jsp404-order16-certificate-input.json --out /tmp/jsp404-order16-reproduced
python3 scripts/export_three_arc_order16_coverage.py --library research/jsp404-order16-certificate-input.json --output /tmp/jsp404-order16-reproduced/ThreeArcOrder16Coverage.lean
```

证书的搜索和生成属于形式化过程。数值目标来自 Sendov 的论文 *Minimax of the angles in a plane configuration of points*，
Acta Mathematica Hungarica 69 (1995), 27–46。[原论文 DOI](https://doi.org/10.1007/BF01874605)
本轮检索范围是有限模型的证书搜索。文献核对和优先权检索的既有范围见 `jsp404-english-source.md` 与 `jsp404-proof-map.md`。
