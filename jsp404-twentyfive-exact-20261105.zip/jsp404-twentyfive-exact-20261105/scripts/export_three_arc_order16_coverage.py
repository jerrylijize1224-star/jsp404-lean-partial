#!/usr/bin/env python3
"""Export the explicit witness table for the sixteen-label coverage proof."""

import argparse
from itertools import combinations
import json
from pathlib import Path


def export_coverage(records):
    supports = [frozenset(record['core']) for record in records]
    if not supports or any(not support <= set(range(20)) for support in supports):
        raise ValueError('expected nonempty library of supports on labels 0..19')

    lines = [
        'import Prize.JSP404.ThreeArcOrder16Data',
        'import Mathlib.Tactic.FinCases',
        '',
        '/-! Explicit core witnesses and their finite coverage checks. The rank',
        'calculation is checked through the selected witness for every increasing',
        'quadruple. Its injectivity is not needed in the coverage proof. -/',
        'namespace Prize.JSP404.ThreeArcOrder16Coverage',
        'open ThreeArcOrderCertificate ThreeArcOrder16Data',
        '',
        'def witnessRow (a b : Label) : Array Index :=',
        '  match a.val, b.val with',
    ]
    covered = 0
    for a, b in combinations(range(20), 2):
        witnesses = []
        for d in range(b + 2, 20):
            for c in range(b + 1, d):
                missing = {a, b, c, d}
                index = next((i for i, support in enumerate(supports)
                              if support.isdisjoint(missing)), None)
                if index is None:
                    raise ValueError(f'no core for missing labels {sorted(missing)}')
                witnesses.append(str(index))
        if witnesses:
            lines.append(f'  | {a}, {b} => #[{", ".join(witnesses)}]')
        covered += len(witnesses)
    if covered != 4845:
        raise ValueError(f'expected 4845 increasing quadruples, found {covered}')

    lines.extend('''  | _, _ => #[]

def witness (a b c d : Label) : Index :=
  let c' := c.val - (b.val + 1)
  let d' := d.val - (b.val + 1)
  (witnessRow a b)[d' * (d' - 1) / 2 + c']?.getD 0

def avoids (i : Index) (a b c d : Label) : Bool :=
  (coreList i).all (fun x => decide (x ≠ a ∧ x ≠ b ∧ x ≠ c ∧ x ≠ d))

def pairChecked (a b : Label) : Bool :=
  (List.finRange 20).all (fun c =>
    (List.finRange 20).all (fun d =>
      if b < c ∧ c < d then avoids (witness a b c d) a b c d else true))

set_option maxRecDepth 4096
set_option maxHeartbeats 1000000
'''.splitlines())

    for a, b in combinations(range(20), 2):
        lines.extend([
            '',
            f'theorem checked{a:02d}_{b:02d} : pairChecked {a} {b} = true := by',
            '  decide +kernel',
        ])
    for a in range(20):
        lines.extend([
            '',
            f'theorem row{a:02d}_checked (b : Label) (hab : {a} < b) :',
            f'    pairChecked {a} b = true := by',
            '  fin_cases b',
        ])
        for b in range(20):
            tactic = 'norm_num at hab' if b <= a else f'exact checked{a:02d}_{b:02d}'
            lines.append(f'  · {tactic}')

    lines.extend([
        '',
        'theorem all_pairs_checked (a b : Label) (hab : a < b) :',
        '    pairChecked a b = true := by',
        '  fin_cases a',
    ])
    lines.extend(f'  · exact row{a:02d}_checked b hab' for a in range(20))

    lines.extend('''

theorem all_covered (a b c d : Label) (hab : a < b) (hbc : b < c) (hcd : c < d) :
    ∃ i : Index, core i ⊆ (((Finset.univ.erase a).erase b).erase c).erase d := by
  have h := all_pairs_checked a b hab
  unfold pairChecked at h
  have hc := List.all_eq_true.mp h c (List.mem_finRange c)
  have hd := List.all_eq_true.mp hc d (List.mem_finRange d)
  have havoid : avoids (witness a b c d) a b c d = true := by
    simpa only [if_pos (show b < c ∧ c < d from ⟨hbc, hcd⟩)] using hd
  refine ⟨witness a b c d, ?_⟩
  intro x hx
  have hx' : x ∈ coreList (witness a b c d) := List.mem_toFinset.mp hx
  unfold avoids at havoid
  have hne : x ≠ a ∧ x ≠ b ∧ x ≠ c ∧ x ≠ d :=
    of_decide_eq_true (List.all_eq_true.mp havoid x hx')
  obtain ⟨ha, hb, hc', hd'⟩ := hne
  exact Finset.mem_erase.mpr ⟨hd', Finset.mem_erase.mpr ⟨hc',
    Finset.mem_erase.mpr ⟨hb, Finset.mem_erase.mpr ⟨ha, Finset.mem_univ x⟩⟩⟩⟩

end Prize.JSP404.ThreeArcOrder16Coverage
'''.splitlines())
    return '\n'.join(lines) + '\n'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--library', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    data = json.loads(args.library.read_text())
    records = data['greedy'] if isinstance(data, dict) else data
    args.output.write_text(export_coverage(records))


if __name__ == '__main__':
    main()
