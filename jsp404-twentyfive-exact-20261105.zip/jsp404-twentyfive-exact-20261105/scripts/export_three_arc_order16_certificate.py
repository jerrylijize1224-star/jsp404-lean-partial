"""Render fixed exploratory core data as Lean source for kernel validation.

The input JSON contains a `greedy` array of concrete cores. Its array order
defines the indices shared with the finite coverage file. Python replay checks
generation. The emitted Lean theorems check certificate acceptance in the kernel.
"""

import argparse
import hashlib
from itertools import combinations
import json
from pathlib import Path
import runpy


def lean_list(values):
    return '[' + ', '.join(map(str, values)) + ']'


def validate(rows, options, widths):
    """Replay every certificate and check the selected library covers all omissions."""
    assert len(rows) == 167, 'The selected core index has changed'
    for row in rows:
        core = frozenset(row['core'])
        assert sorted(core) == row['core']
        assert all(0 <= label < 20 for label in core)
        assert row['core_mask'] == sum(1 << label for label in core)
        nodes = row['nodes']
        assert row['root'] == len(nodes) - 1

        def replay(index, edges):
            node = nodes[index]
            if 'cycle' in node:
                path = node['cycle']
                assert len(path) >= 2 and path[0] == path[-1]
                assert all(0 <= v < 60 for v in path)
                assert all(edge in edges for edge in zip(path, path[1:]))
                return 1
            i, j = node['pair']
            children = node['children']
            assert i < j and i in core and j in core
            assert len(children) == len(options[i, j])
            assert all(0 <= child < index for child in children)
            return 1 + sum(
                replay(child, edges | frozenset(choice))
                for choice, child in zip(options[i, j], children)
            )

        initial = frozenset(edge for i in core for edge in widths[i])
        assert replay(row['root'], initial) == row['expanded_visits']

    for missing in combinations(range(20), 4):
        omitted = set(missing)
        assert any(omitted.isdisjoint(row['core']) for row in rows), missing


def render_data(rows, options):
    lines = [
        'import Prize.JSP404.ThreeArcOrderData',
        'import Mathlib.Data.Finset.Dedup',
        '',
        '/-! Concrete order contradiction cores, to be checked by the Lean kernel. -/',
        'namespace Prize.JSP404.ThreeArcOrder16Data',
        'open ThreeArcOrderCertificate',
        '',
        f'abbrev Index := Fin {len(rows)}',
        'abbrev spec : Spec := ThreeArcOrderData.spec',
        '',
        'def coreList (i : Index) : List Label :=',
        '  match i.val with',
    ]
    for i, row in enumerate(rows):
        lines.append(f'  | {i} => {lean_list(row["core"])}')
    lines += [
        '  | _ => []',
        '',
        'def core (i : Index) : Finset Label := (coreList i).toFinset',
        '',
    ]
    for i, row in enumerate(rows):
        lines.append(f'private def certificate_{i:03d} : Array Node := #[')
        nodes = row['nodes']
        for index, node in enumerate(nodes):
            if 'cycle' in node:
                term = f'.cycle {lean_list(node["cycle"])}'
            else:
                a, b = node['pair']
                children = []
                for choice, child in zip(options[a, b], node['children']):
                    edges = lean_list(f'({u}, {v})' for u, v in choice)
                    children.append(f'({edges}, {child})')
                term = f'.branch {a} {b} {lean_list(children)}'
            comma = ',' if index + 1 < len(nodes) else ''
            lines.append(f'  {term}{comma}')
        lines += [']', '']
    lines += ['def certificate (i : Index) : Array Node :=', '  match i.val with']
    lines += [f'  | {i} => certificate_{i:03d}' for i in range(len(rows))]
    lines += ['  | _ => #[]', '', 'end Prize.JSP404.ThreeArcOrder16Data', '']
    return '\n'.join(lines)


def render_checks(count):
    lines = [
        'import Prize.JSP404.ThreeArcOrder16Data',
        'import Mathlib.Tactic.FinCases',
        '',
        '/-! Each concrete core certificate is checked by kernel reduction. -/',
        'namespace Prize.JSP404.ThreeArcOrder16Data',
        'open ThreeArcOrderCertificate',
        '',
    ]
    for i in range(count):
        lines += [
            'set_option maxHeartbeats 1000000 in',
            f'theorem accepted_{i:03d} : accepted spec (core {i}) (certificate {i}) = true := by',
            '  decide +kernel',
            '',
        ]
    lines += [
        'set_option maxHeartbeats 1000000 in',
        'theorem all_accepted (i : Index) : accepted spec (core i) (certificate i) = true := by',
        '  fin_cases i',
    ]
    lines += [f'  · exact accepted_{i:03d}' for i in range(count)]
    lines += ['', 'end Prize.JSP404.ThreeArcOrder16Data', '']
    return '\n'.join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path.cwd())
    parser.add_argument('--library', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--selected-library', type=Path)
    args = parser.parse_args()

    rows = json.loads(args.library.read_text())['greedy']
    exporter = runpy.run_path(str(args.root / 'scripts/export_three_arc_order17_certificate.py'))
    options, widths = exporter['prepare'](args.root)
    validate(rows, options, widths)

    args.out.mkdir(parents=True, exist_ok=True)
    outputs = {
        'ThreeArcOrder16Data.lean': render_data(rows, options),
        'ThreeArcOrder16Checks.lean': render_checks(len(rows)),
    }
    hashes = {}
    for name, source in outputs.items():
        content = source.encode('utf-8')
        (args.out / name).write_bytes(content)
        hashes[name] = {'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()}

    if args.selected_library:
        selected = {'greedy': rows}
        args.selected_library.write_text(json.dumps(selected, separators=(',', ':')) + '\n')

    summary = {
        'scope': 'Untrusted concrete certificates, pending Lean kernel verification',
        'cores': len(rows),
        'nodes': sum(len(row['nodes']) for row in rows),
        'expanded_visits': sum(row['expanded_visits'] for row in rows),
        'max_nodes': max(len(row['nodes']) for row in rows),
        'checked_omissions_in_python': 4845,
        'outputs': hashes,
    }
    (args.out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
