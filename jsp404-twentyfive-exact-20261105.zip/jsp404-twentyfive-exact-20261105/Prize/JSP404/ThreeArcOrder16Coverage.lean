import Prize.JSP404.ThreeArcOrder16Data
import Mathlib.Tactic.FinCases

/-! Explicit core witnesses and their finite coverage checks. The rank
calculation is checked through the selected witness for every increasing
quadruple. Its injectivity is not needed in the coverage proof. -/
namespace Prize.JSP404.ThreeArcOrder16Coverage
open ThreeArcOrderCertificate ThreeArcOrder16Data

def witnessRow (a b : Label) : Array Index :=
  match a.val, b.val with
  | 0, 1 => #[0, 0, 0, 0, 0, 0, 3, 3, 1, 8, 3, 3, 1, 8, 1, 5, 5, 1, 24, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 6, 6, 1, 32, 1, 1, 1, 1, 1, 3, 3, 1, 8, 1, 1, 1, 1, 1, 1, 3, 3, 1, 8, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 15, 76, 31, 0, 0, 143, 66, 31, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 3, 3, 5, 0, 0, 6, 3, 3, 0, 0, 0, 0, 0, 0, 3, 3, 5, 0, 0, 6, 3, 3, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0]
  | 0, 2 => #[0, 0, 0, 3, 3, 2, 3, 3, 2, 2, 5, 12, 2, 2, 2, 0, 0, 0, 2, 2, 2, 0, 0, 0, 2, 2, 2, 0, 6, 6, 2, 2, 2, 2, 2, 2, 3, 3, 2, 2, 2, 2, 2, 2, 2, 3, 3, 2, 2, 2, 2, 2, 2, 2, 2, 0, 0, 0, 2, 2, 2, 0, 0, 2, 2, 2, 0, 0, 0, 3, 3, 5, 0, 0, 10, 3, 3, 0, 0, 0, 0, 3, 3, 5, 0, 0, 6, 3, 3, 0, 0, 0, 0, 0, 2, 2, 2, 0, 0, 2, 2, 2, 0, 0, 0, 0, 0, 0, 3, 3, 5, 0, 0, 6, 3, 3, 0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 0, 0, 2, 2, 2, 0, 0, 0, 0, 0]
  | 0, 3 => #[0, 3, 14, 3, 14, 3, 9, 19, 9, 9, 0, 0, 6, 9, 9, 0, 0, 9, 9, 5, 0, 6, 21, 6, 9, 9, 6, 9, 3, 34, 3, 3, 9, 9, 9, 9, 3, 19, 3, 3, 5, 16, 5, 52, 3, 0, 0, 14, 14, 19, 0, 0, 101, 142, 19, 0, 0, 3, 3, 5, 0, 0, 37, 3, 3, 0, 0, 0, 3, 3, 5, 0, 0, 6, 3, 3, 0, 0, 0, 0, 3, 3, 5, 0, 0, 6, 3, 3, 0, 0, 0, 0, 0, 3, 3, 5, 0, 0, 6, 3, 3, 0, 0, 0, 0, 0, 0, 3, 3, 5, 0, 0, 6, 3, 3, 0, 0, 0, 0, 0]
  | 0, 4 => #[8, 8, 1, 12, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 12, 1, 1, 1, 1, 1, 8, 1, 1, 1, 1, 1, 1, 8, 1, 1, 1, 1, 1, 1, 1, 0, 12, 14, 12, 0, 0, 12, 59, 12, 0, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 3, 3, 19, 0, 0, 6, 3, 3, 0, 0, 0, 3, 3, 9, 0, 0, 6, 3, 3, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0]
  | 0, 5 => #[2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 0, 2, 2, 2, 8, 8, 17, 0, 0, 17, 8, 8, 0, 14, 14, 19, 0, 0, 38, 38, 19, 0, 0, 2, 2, 2, 0, 0, 2, 2, 2, 0, 0, 0, 8, 8, 12, 0, 0, 12, 8, 8, 0, 0, 0, 0, 2, 2, 2, 0, 0, 2, 2, 2, 0, 0, 0, 0, 0]
  | 0, 6 => #[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 14, 3, 58, 6, 14, 6, 3, 3, 14, 3, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 1, 1, 1, 1, 1, 1, 1, 12, 1, 3, 3, 1, 1, 1, 1, 1, 1, 1, 2, 1, 3, 2, 1]
  | 0, 7 => #[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 14, 10, 10, 10, 10, 3, 3, 14, 3, 2, 2, 2, 2, 2, 2, 2, 3, 3, 1, 1, 1, 1, 1, 1, 27, 1, 3, 3, 1, 1, 1, 1, 1, 1, 2, 1, 3, 2, 1]
  | 0, 8 => #[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 19, 10, 5, 10, 10, 5, 19, 5, 2, 2, 2, 2, 2, 2, 5, 5, 1, 1, 1, 1, 1, 12, 1, 5, 5, 1, 1, 1, 1, 1, 2, 1, 5, 2, 1]
  | 0, 9 => #[1, 1, 1, 1, 1, 1, 0, 2, 2, 2, 0, 1, 1, 1, 0, 0, 6, 10, 10, 0, 0, 0, 2, 2, 2, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0]
  | 0, 10 => #[1, 1, 1, 2, 2, 2, 1, 1, 1, 0, 10, 10, 5, 0, 0, 2, 2, 2, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0]
  | 0, 11 => #[1, 2, 2, 1, 1, 62, 10, 10, 29, 10, 2, 2, 2, 17, 6, 1, 1, 12, 1, 6, 6, 1, 1, 2, 1, 6, 2, 1]
  | 0, 12 => #[2, 1, 35, 3, 35, 3, 2, 2, 3, 3, 1, 59, 1, 3, 3, 1, 2, 1, 3, 2, 1]
  | 0, 13 => #[19, 19, 3, 2, 3, 3, 12, 1, 3, 3, 2, 1, 3, 2, 1]
  | 0, 14 => #[0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
  | 0, 15 => #[0, 0, 0, 0, 0, 0]
  | 0, 16 => #[0, 0, 0]
  | 0, 17 => #[0]
  | 1, 2 => #[0, 0, 0, 3, 3, 11, 3, 3, 149, 3, 5, 45, 11, 11, 105, 0, 0, 0, 6, 63, 45, 0, 0, 0, 7, 7, 5, 0, 6, 6, 11, 6, 23, 11, 6, 11, 3, 3, 33, 3, 3, 20, 16, 7, 25, 3, 3, 11, 3, 3, 5, 16, 5, 11, 3, 0, 0, 0, 7, 7, 11, 0, 0, 11, 7, 7, 0, 0, 0, 3, 3, 5, 0, 0, 11, 3, 3, 0, 0, 0, 0, 3, 3, 5, 0, 0, 6, 3, 3, 0, 0, 0, 0, 0, 3, 3, 5, 0, 0, 6, 3, 3, 0, 0, 0, 0, 0, 0, 3, 3, 5, 0, 0, 6, 3, 3, 0, 0, 0, 0, 0, 0, 0, 3, 3, 5, 0, 0, 6, 3, 3, 0, 0, 0, 0, 0]
  | 1, 3 => #[0, 3, 24, 3, 68, 3, 56, 24, 24, 163, 0, 0, 6, 109, 146, 0, 0, 15, 49, 5, 0, 6, 99, 6, 74, 118, 6, 25, 3, 114, 3, 3, 97, 16, 25, 25, 3, 24, 3, 3, 5, 16, 5, 145, 3, 0, 0, 15, 158, 56, 0, 0, 165, 72, 103, 0, 0, 3, 3, 5, 0, 0, 74, 3, 3, 0, 0, 0, 3, 3, 5, 0, 0, 6, 3, 3, 0, 0, 0, 0, 3, 3, 5, 0, 0, 6, 3, 3, 0, 0, 0, 0, 0, 3, 3, 5, 0, 0, 6, 3, 3, 0, 0, 0, 0, 0, 0, 3, 3, 5, 0, 0, 6, 3, 3, 0, 0, 0, 0, 0]
  | 1, 4 => #[8, 8, 1, 148, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 32, 1, 1, 1, 1, 1, 8, 1, 1, 1, 1, 1, 1, 8, 1, 1, 1, 1, 1, 1, 1, 0, 7, 7, 56, 0, 0, 23, 7, 7, 0, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 3, 3, 45, 0, 0, 6, 3, 3, 0, 0, 0, 3, 3, 48, 0, 0, 6, 3, 3, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0]
  | 1, 5 => #[8, 11, 166, 8, 8, 73, 11, 26, 11, 0, 11, 98, 11, 32, 11, 8, 8, 87, 8, 33, 111, 8, 8, 11, 8, 11, 11, 8, 11, 125, 11, 0, 0, 11, 33, 11, 8, 8, 11, 0, 0, 11, 8, 8, 0, 26, 26, 73, 0, 0, 113, 86, 26, 0, 0, 8, 8, 11, 0, 0, 11, 8, 8, 0, 0, 0, 8, 8, 119, 0, 0, 32, 8, 8, 0, 0, 0, 0, 11, 68, 11, 0, 0, 11, 33, 11, 0, 0, 0, 0, 0]
  | 1, 6 => #[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 7, 11, 53, 7, 11, 7, 7, 1, 1, 1, 1, 1, 1, 1, 7, 3, 36, 6, 15, 6, 3, 3, 15, 3, 3, 11, 6, 11, 6, 3, 3, 11, 3, 3, 1, 1, 1, 1, 1, 1, 1, 7, 1, 3, 3, 1, 1, 1, 1, 1, 1, 1, 7, 1, 3, 3, 1]
  | 1, 7 => #[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 76, 144, 7, 23, 7, 7, 1, 1, 1, 1, 1, 1, 7, 155, 26, 26, 63, 3, 3, 85, 3, 48, 8, 23, 23, 3, 3, 23, 3, 3, 1, 1, 1, 1, 1, 1, 7, 1, 3, 3, 1, 1, 1, 1, 1, 1, 7, 1, 3, 3, 1]
  | 1, 8 => #[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 129, 11, 11, 20, 11, 1, 1, 1, 1, 1, 11, 45, 5, 36, 20, 5, 20, 5, 48, 5, 11, 77, 5, 11, 5, 5, 1, 1, 1, 1, 1, 31, 1, 5, 5, 1, 1, 1, 1, 1, 11, 1, 5, 5, 1]
  | 1, 9 => #[1, 1, 1, 1, 1, 1, 0, 53, 66, 53, 0, 1, 1, 1, 0, 0, 6, 16, 16, 0, 0, 0, 6, 8, 8, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0]
  | 1, 10 => #[1, 1, 1, 11, 7, 7, 1, 1, 1, 0, 36, 20, 5, 0, 0, 11, 25, 5, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0]
  | 1, 11 => #[1, 156, 11, 1, 1, 11, 95, 36, 92, 36, 25, 11, 11, 11, 6, 1, 1, 122, 1, 6, 6, 1, 1, 11, 1, 6, 6, 1]
  | 1, 12 => #[7, 1, 7, 3, 20, 3, 3, 33, 3, 3, 1, 7, 1, 3, 3, 1, 7, 1, 3, 3, 1]
  | 1, 13 => #[7, 20, 3, 11, 3, 3, 7, 1, 3, 3, 7, 1, 3, 3, 1]
  | 1, 14 => #[0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
  | 1, 15 => #[0, 0, 0, 0, 0, 0]
  | 1, 16 => #[0, 0, 0]
  | 1, 17 => #[0]
  | 2, 3 => #[0, 3, 4, 3, 128, 3, 4, 4, 4, 147, 0, 0, 4, 46, 4, 0, 0, 4, 49, 4, 0, 4, 4, 4, 46, 4, 4, 4, 3, 13, 3, 3, 28, 13, 13, 25, 3, 4, 3, 3, 4, 4, 4, 4, 3, 0, 0, 4, 75, 4, 0, 0, 4, 13, 4, 0, 0, 3, 3, 4, 0, 0, 4, 3, 3, 0, 0, 0, 3, 3, 4, 0, 0, 4, 3, 3, 0, 0, 0, 0, 3, 3, 4, 0, 0, 4, 3, 3, 0, 0, 0, 0, 0, 3, 3, 5, 0, 0, 6, 3, 3, 0, 0, 0, 0, 0, 0, 3, 3, 5, 0, 0, 6, 3, 3, 0, 0, 0, 0, 0]
  | 2, 4 => #[4, 27, 3, 4, 4, 42, 0, 4, 27, 4, 0, 4, 7, 4, 0, 4, 4, 23, 4, 4, 4, 13, 3, 3, 18, 13, 7, 18, 4, 3, 3, 4, 4, 4, 4, 3, 0, 4, 7, 4, 0, 0, 4, 7, 4, 0, 3, 3, 4, 0, 0, 4, 3, 3, 0, 0, 3, 3, 4, 0, 0, 4, 3, 3, 0, 0, 0, 3, 3, 4, 0, 0, 4, 3, 3, 0, 0, 0, 0, 3, 3, 12, 0, 0, 6, 3, 3, 0, 0, 0, 0, 0, 3, 3, 18, 0, 0, 6, 3, 3, 0, 0, 0, 0, 0]
  | 2, 5 => #[2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 0, 2, 2, 2, 4, 60, 4, 0, 0, 4, 13, 4, 0, 4, 60, 4, 0, 0, 4, 13, 4, 0, 0, 2, 2, 2, 0, 0, 2, 2, 2, 0, 0, 0, 12, 27, 12, 0, 0, 12, 50, 12, 0, 0, 0, 0, 2, 2, 2, 0, 0, 2, 2, 2, 0, 0, 0, 0, 0]
  | 2, 6 => #[2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 4, 4, 4, 4, 3, 3, 4, 3, 4, 4, 4, 4, 3, 3, 4, 3, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 12, 6, 7, 6, 3, 3, 7, 3, 3, 3, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 2, 3]
  | 2, 7 => #[2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 10, 10, 7, 10, 3, 3, 7, 10, 10, 10, 10, 3, 3, 35, 3, 2, 2, 2, 2, 2, 2, 2, 3, 3, 22, 22, 7, 42, 3, 3, 7, 3, 3, 3, 2, 2, 2, 2, 2, 2, 2, 3, 3, 2, 3]
  | 2, 8 => #[2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 4, 4, 4, 10, 4, 4, 4, 4, 4, 10, 4, 4, 4, 2, 2, 2, 2, 2, 2, 4, 4, 12, 5, 12, 28, 5, 12, 5, 5, 5, 2, 2, 2, 2, 2, 2, 5, 5, 2, 5]
  | 2, 9 => #[2, 2, 2, 2, 2, 2, 0, 2, 2, 2, 0, 4, 10, 4, 0, 0, 4, 10, 4, 0, 0, 0, 2, 2, 2, 0, 0, 0, 0, 6, 16, 12, 0, 0, 0, 0, 0, 2, 2, 2, 0, 0, 0, 0, 0]
  | 2, 10 => #[2, 2, 2, 2, 2, 2, 4, 7, 4, 0, 4, 10, 4, 0, 0, 2, 2, 2, 0, 0, 0, 42, 7, 5, 0, 0, 0, 0, 2, 2, 2, 0, 0, 0, 0, 0]
  | 2, 11 => #[2, 2, 2, 10, 4, 4, 10, 4, 4, 4, 2, 2, 2, 4, 4, 42, 12, 12, 51, 6, 6, 2, 2, 2, 10, 6, 2, 6]
  | 2, 12 => #[2, 3, 7, 3, 13, 3, 2, 2, 3, 3, 3, 7, 3, 3, 3, 2, 2, 3, 3, 2, 3]
  | 2, 13 => #[4, 4, 3, 2, 3, 3, 7, 3, 3, 3, 2, 3, 3, 2, 3]
  | 2, 14 => #[0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
  | 2, 15 => #[0, 0, 0, 0, 0, 0]
  | 2, 16 => #[0, 0, 0]
  | 2, 17 => #[0]
  | 3, 4 => #[4, 14, 3, 4, 4, 9, 0, 4, 9, 4, 0, 4, 9, 4, 0, 4, 4, 9, 4, 4, 4, 13, 3, 3, 9, 9, 9, 9, 4, 3, 3, 4, 4, 4, 4, 3, 0, 4, 14, 4, 0, 0, 4, 13, 4, 0, 3, 3, 4, 0, 0, 4, 3, 3, 0, 0, 3, 3, 4, 0, 0, 4, 3, 3, 0, 0, 0, 3, 3, 4, 0, 0, 4, 3, 3, 0, 0, 0, 0, 3, 3, 28, 0, 0, 6, 3, 3, 0, 0, 0, 0, 0, 3, 3, 9, 0, 0, 6, 3, 3, 0, 0, 0, 0, 0]
  | 3, 5 => #[14, 4, 57, 4, 14, 4, 4, 14, 4, 0, 4, 21, 4, 4, 4, 34, 34, 112, 13, 13, 94, 4, 57, 4, 4, 4, 4, 13, 4, 14, 4, 0, 0, 4, 13, 4, 4, 14, 4, 0, 0, 4, 13, 4, 0, 4, 14, 4, 0, 0, 4, 13, 4, 0, 0, 4, 14, 4, 0, 0, 4, 34, 4, 0, 0, 0, 21, 21, 91, 0, 0, 21, 89, 78, 0, 0, 0, 0, 24, 34, 24, 0, 0, 43, 13, 13, 0, 0, 0, 0, 0]
  | 3, 6 => #[9, 9, 4, 9, 4, 4, 9, 4, 4, 4, 3, 9, 9, 9, 9, 3, 4, 4, 4, 4, 3, 14, 4, 4, 4, 4, 41, 4, 3, 4, 4, 4, 4, 3, 3, 4, 3, 4, 4, 4, 4, 3, 3, 4, 3, 3, 4, 4, 4, 4, 3, 3, 4, 3, 3, 3, 40, 6, 15, 6, 3, 3, 15, 3, 3, 3, 3, 9, 6, 9, 6, 3, 3, 15, 3, 3, 3, 3]
  | 3, 7 => #[9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 57, 46, 49, 46, 3, 30, 14, 14, 75, 126, 141, 30, 14, 14, 37, 3, 3, 14, 124, 14, 14, 37, 3, 3, 14, 3, 9, 9, 9, 9, 3, 3, 14, 3, 3, 83, 21, 79, 21, 3, 3, 88, 3, 3, 3, 9, 9, 9, 9, 3, 3, 30, 3, 3, 3, 3]
  | 3, 8 => #[4, 4, 4, 9, 9, 9, 4, 4, 4, 39, 4, 4, 4, 96, 4, 4, 4, 4, 39, 4, 4, 4, 4, 4, 39, 4, 4, 4, 4, 4, 4, 9, 4, 4, 4, 4, 40, 5, 40, 28, 5, 110, 5, 5, 5, 9, 5, 9, 9, 5, 30, 5, 5, 5, 5]
  | 3, 9 => #[4, 9, 9, 4, 4, 13, 0, 4, 13, 4, 0, 4, 13, 4, 0, 0, 4, 13, 4, 0, 0, 0, 4, 9, 4, 0, 0, 0, 0, 6, 16, 16, 0, 0, 0, 0, 0, 6, 9, 13, 0, 0, 0, 0, 0]
  | 3, 10 => #[9, 4, 13, 4, 13, 4, 4, 13, 4, 0, 4, 13, 4, 0, 0, 4, 9, 4, 0, 0, 0, 40, 28, 5, 0, 0, 0, 0, 9, 9, 5, 0, 0, 0, 0, 0]
  | 3, 11 => #[52, 164, 4, 140, 4, 4, 117, 4, 4, 4, 9, 4, 4, 4, 4, 153, 65, 70, 65, 6, 6, 9, 52, 43, 43, 6, 6, 6]
  | 3, 12 => #[13, 3, 13, 3, 13, 3, 3, 72, 3, 3, 3, 41, 3, 3, 3, 3, 13, 3, 3, 3, 3]
  | 3, 13 => #[4, 4, 3, 4, 3, 3, 41, 3, 3, 3, 13, 3, 3, 3, 3]
  | 3, 14 => #[0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
  | 3, 15 => #[0, 0, 0, 0, 0, 0]
  | 3, 16 => #[0, 0, 0]
  | 3, 17 => #[0]
  | 4, 5 => #[8, 4, 108, 4, 8, 4, 4, 14, 4, 0, 4, 21, 4, 4, 4, 8, 8, 18, 8, 13, 18, 4, 8, 4, 4, 4, 4, 8, 4, 14, 4, 0, 0, 4, 13, 4, 4, 8, 4, 0, 0, 4, 8, 4, 0, 4, 14, 4, 0, 0, 4, 13, 4, 0, 0, 4, 8, 4, 0, 0, 4, 8, 4, 0, 0, 0, 8, 8, 12, 0, 0, 12, 8, 8, 0, 0, 0, 0, 18, 34, 18, 0, 0, 18, 13, 13, 0, 0, 0, 0, 0]
  | 4, 6 => #[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 7, 4, 4, 4, 4, 7, 4, 1, 1, 1, 1, 1, 1, 1, 4, 3, 4, 4, 4, 4, 3, 3, 4, 3, 3, 4, 4, 4, 4, 3, 3, 4, 3, 3, 1, 1, 1, 1, 1, 1, 1, 7, 1, 3, 3, 1, 1, 1, 1, 1, 1, 1, 7, 1, 3, 3, 1]
  | 4, 7 => #[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 30, 14, 7, 23, 7, 7, 1, 1, 1, 1, 1, 1, 7, 139, 14, 14, 37, 3, 3, 14, 3, 9, 8, 9, 9, 3, 3, 14, 3, 3, 1, 1, 1, 1, 1, 1, 7, 1, 3, 3, 1, 1, 1, 1, 1, 1, 7, 1, 3, 3, 1]
  | 4, 8 => #[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 4, 4, 4, 18, 4, 1, 1, 1, 1, 1, 4, 4, 4, 4, 39, 4, 4, 4, 4, 4, 4, 9, 4, 4, 4, 4, 1, 1, 1, 1, 1, 12, 1, 69, 12, 1, 1, 1, 1, 1, 18, 1, 39, 9, 1]
  | 4, 9 => #[1, 1, 1, 1, 1, 1, 0, 4, 13, 4, 0, 1, 1, 1, 0, 0, 4, 13, 4, 0, 0, 0, 4, 8, 4, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0]
  | 4, 10 => #[1, 1, 1, 4, 7, 4, 1, 1, 1, 0, 4, 13, 4, 0, 0, 4, 9, 4, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0]
  | 4, 11 => #[1, 18, 4, 1, 1, 4, 38, 4, 4, 4, 9, 4, 4, 4, 4, 1, 1, 12, 1, 6, 6, 1, 1, 18, 1, 6, 6, 1]
  | 4, 12 => #[7, 1, 7, 3, 13, 3, 3, 18, 3, 3, 1, 7, 1, 3, 3, 1, 7, 1, 3, 3, 1]
  | 4, 13 => #[4, 4, 3, 4, 3, 3, 7, 1, 3, 3, 7, 1, 3, 3, 1]
  | 4, 14 => #[0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
  | 4, 15 => #[0, 0, 0, 0, 0, 0]
  | 4, 16 => #[0, 0, 0]
  | 4, 17 => #[0]
  | 5, 6 => #[2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 8, 4, 4, 4, 4, 8, 4, 4, 14, 4, 4, 4, 4, 138, 4, 4, 4, 2, 2, 2, 2, 2, 2, 2, 2, 4, 4, 8, 12, 8, 54, 12, 8, 8, 12, 8, 106, 8, 2, 2, 2, 2, 2, 2, 2, 2, 11, 43, 2, 32]
  | 5, 7 => #[2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 17, 8, 14, 17, 8, 8, 14, 162, 14, 14, 93, 123, 26, 14, 14, 2, 2, 2, 2, 2, 2, 2, 8, 14, 71, 8, 54, 21, 8, 8, 27, 8, 152, 8, 2, 2, 2, 2, 2, 2, 2, 17, 131, 2, 54]
  | 5, 8 => #[2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 4, 4, 4, 17, 4, 4, 4, 4, 4, 55, 4, 4, 4, 2, 2, 2, 2, 2, 2, 4, 4, 12, 71, 12, 50, 12, 12, 50, 159, 12, 2, 2, 2, 2, 2, 2, 11, 100, 2, 130]
  | 5, 9 => #[2, 2, 2, 2, 2, 2, 0, 2, 2, 2, 0, 4, 8, 4, 0, 0, 4, 13, 4, 0, 0, 0, 2, 2, 2, 0, 0, 0, 0, 12, 8, 8, 0, 0, 0, 0, 0, 2, 2, 2, 0, 0, 0, 0, 0]
  | 5, 10 => #[2, 2, 2, 2, 2, 2, 4, 13, 4, 0, 4, 13, 4, 0, 0, 2, 2, 2, 0, 0, 0, 64, 136, 47, 0, 0, 0, 0, 2, 2, 2, 0, 0, 0, 0, 0]
  | 5, 11 => #[2, 2, 2, 17, 4, 4, 38, 4, 4, 4, 2, 2, 2, 4, 4, 67, 12, 12, 64, 150, 12, 2, 2, 2, 11, 38, 2, 32]
  | 5, 12 => #[2, 8, 13, 13, 13, 13, 2, 2, 8, 55, 8, 121, 8, 161, 8, 2, 2, 13, 13, 2, 67]
  | 5, 13 => #[4, 4, 4, 2, 4, 4, 12, 8, 47, 8, 2, 11, 13, 2, 47]
  | 5, 14 => #[0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
  | 5, 15 => #[0, 0, 0, 0, 0, 0]
  | 5, 16 => #[0, 0, 0]
  | 5, 17 => #[0]
  | 6, 7 => #[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 7, 58, 14, 14, 37, 3, 3, 14, 3, 2, 2, 2, 2, 2, 2, 2, 3, 3, 1, 1, 1, 1, 1, 1, 7, 1, 3, 3, 1, 1, 1, 1, 1, 1, 2, 1, 3, 2, 1]
  | 6, 8 => #[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 4, 4, 4, 4, 127, 4, 4, 4, 2, 2, 2, 2, 2, 2, 4, 4, 1, 1, 1, 1, 1, 12, 1, 134, 12, 1, 1, 1, 1, 1, 2, 1, 36, 2, 1]
  | 6, 9 => #[1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 1, 1, 1, 1, 4, 4, 4, 61, 4, 4, 4, 2, 2, 2, 2, 2, 4, 4, 1, 1, 1, 1, 12, 1, 6, 6, 1, 1, 1, 1, 2, 1, 6, 2, 1]
  | 6, 10 => #[1, 1, 1, 2, 2, 2, 1, 1, 1, 4, 4, 44, 4, 4, 4, 2, 2, 2, 2, 4, 4, 1, 1, 1, 7, 1, 15, 15, 1, 1, 1, 2, 1, 15, 2, 1]
  | 6, 11 => #[1, 2, 2, 1, 1, 4, 61, 4, 4, 4, 2, 2, 2, 4, 4, 1, 1, 12, 1, 6, 6, 1, 1, 2, 1, 6, 2, 1]
  | 6, 12 => #[2, 1, 7, 3, 44, 3, 2, 2, 3, 3, 1, 7, 1, 3, 3, 1, 2, 1, 3, 2, 1]
  | 6, 13 => #[4, 4, 3, 2, 3, 3, 7, 1, 3, 3, 2, 1, 3, 2, 1]
  | 6, 14 => #[4, 4, 4, 7, 15, 12, 7, 15, 2, 7]
  | 6, 15 => #[3, 3, 3, 3, 3, 1]
  | 6, 16 => #[3, 3, 3]
  | 6, 17 => #[3]
  | 7, 8 => #[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 30, 10, 10, 10, 10, 10, 84, 10, 2, 2, 2, 2, 2, 2, 17, 22, 1, 1, 1, 1, 1, 115, 1, 22, 22, 1, 1, 1, 1, 1, 2, 1, 10, 2, 1]
  | 7, 9 => #[1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 1, 1, 1, 1, 14, 10, 10, 10, 10, 14, 10, 2, 2, 2, 2, 2, 8, 14, 1, 1, 1, 1, 27, 1, 22, 8, 1, 1, 1, 1, 2, 1, 10, 2, 1]
  | 7, 10 => #[1, 1, 1, 2, 2, 2, 1, 1, 1, 7, 10, 10, 10, 14, 10, 2, 2, 2, 2, 14, 14, 1, 1, 1, 7, 1, 22, 22, 1, 1, 1, 2, 1, 10, 2, 1]
  | 7, 11 => #[1, 2, 2, 1, 1, 23, 10, 10, 62, 10, 2, 2, 2, 17, 37, 1, 1, 90, 1, 81, 21, 1, 1, 2, 1, 10, 2, 1]
  | 7, 12 => #[2, 1, 7, 3, 35, 3, 2, 2, 3, 3, 1, 7, 1, 3, 3, 1, 2, 1, 3, 2, 1]
  | 7, 13 => #[7, 35, 3, 2, 3, 3, 7, 1, 3, 3, 2, 1, 3, 2, 1]
  | 7, 14 => #[14, 14, 14, 7, 116, 27, 7, 35, 2, 7]
  | 7, 15 => #[3, 3, 3, 3, 3, 1]
  | 7, 16 => #[3, 3, 3]
  | 7, 17 => #[3]
  | 8, 9 => #[1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 1, 1, 1, 1, 4, 4, 4, 10, 4, 4, 4, 2, 2, 2, 2, 2, 4, 4, 1, 1, 1, 1, 12, 1, 22, 12, 1, 1, 1, 1, 2, 1, 10, 2, 1]
  | 8, 10 => #[1, 1, 1, 2, 2, 2, 1, 1, 1, 4, 4, 10, 4, 4, 4, 2, 2, 2, 2, 4, 4, 1, 1, 1, 31, 1, 5, 5, 1, 1, 1, 2, 1, 5, 2, 1]
  | 8, 11 => #[1, 2, 2, 1, 1, 4, 10, 4, 4, 4, 2, 2, 2, 4, 4, 1, 1, 12, 1, 120, 12, 1, 1, 2, 1, 10, 2, 1]
  | 8, 12 => #[2, 1, 20, 10, 20, 10, 2, 2, 17, 55, 1, 82, 1, 69, 28, 1, 2, 1, 10, 2, 1]
  | 8, 13 => #[4, 4, 4, 2, 4, 4, 12, 1, 5, 5, 2, 1, 5, 2, 1]
  | 8, 14 => #[4, 4, 4, 31, 80, 12, 11, 20, 2, 31]
  | 8, 15 => #[4, 5, 5, 5, 5, 1]
  | 8, 16 => #[5, 5, 5]
  | 8, 17 => #[5]
  | 9, 10 => #[1, 1, 1, 2, 2, 2, 1, 1, 1, 0, 4, 10, 4, 0, 0, 2, 2, 2, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0]
  | 9, 11 => #[1, 2, 2, 1, 1, 4, 10, 4, 4, 4, 2, 2, 2, 4, 4, 1, 1, 12, 1, 6, 6, 1, 1, 2, 1, 6, 2, 1]
  | 9, 12 => #[2, 1, 13, 10, 13, 10, 2, 2, 8, 16, 1, 41, 1, 16, 8, 1, 2, 1, 10, 2, 1]
  | 9, 13 => #[4, 4, 4, 2, 4, 4, 12, 1, 16, 8, 2, 1, 10, 2, 1]
  | 9, 14 => #[0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
  | 9, 15 => #[0, 0, 0, 0, 0, 0]
  | 9, 16 => #[0, 0, 0]
  | 9, 17 => #[0]
  | 10, 11 => #[1, 2, 2, 1, 1, 4, 10, 4, 4, 4, 2, 2, 2, 4, 4, 1, 1, 70, 1, 133, 40, 1, 1, 2, 1, 10, 2, 1]
  | 10, 12 => #[2, 1, 7, 10, 13, 10, 2, 2, 17, 44, 1, 7, 1, 107, 28, 1, 2, 1, 10, 2, 1]
  | 10, 13 => #[4, 4, 4, 2, 4, 4, 7, 1, 5, 5, 2, 1, 5, 2, 1]
  | 10, 14 => #[0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
  | 10, 15 => #[0, 0, 0, 0, 0, 0]
  | 10, 16 => #[0, 0, 0]
  | 10, 17 => #[0]
  | 11, 12 => #[2, 1, 102, 10, 154, 10, 2, 2, 17, 137, 1, 157, 1, 160, 104, 1, 2, 1, 10, 2, 1]
  | 11, 13 => #[4, 4, 4, 2, 4, 4, 12, 1, 29, 12, 2, 1, 10, 2, 1]
  | 11, 14 => #[4, 4, 4, 135, 29, 12, 11, 29, 2, 29]
  | 11, 15 => #[4, 51, 51, 10, 11, 1]
  | 11, 16 => #[6, 6, 6]
  | 11, 17 => #[6]
  | 12, 13 => #[7, 13, 3, 2, 3, 3, 7, 1, 3, 3, 2, 1, 3, 2, 1]
  | 12, 14 => #[13, 33, 44, 7, 151, 132, 7, 13, 2, 7]
  | 12, 15 => #[3, 3, 3, 3, 3, 1]
  | 12, 16 => #[3, 3, 3]
  | 12, 17 => #[3]
  | 13, 14 => #[4, 4, 4, 7, 29, 12, 7, 13, 2, 7]
  | 13, 15 => #[3, 3, 3, 3, 3, 1]
  | 13, 16 => #[3, 3, 3]
  | 13, 17 => #[3]
  | 14, 15 => #[0, 0, 0, 0, 0, 0]
  | 14, 16 => #[0, 0, 0]
  | 14, 17 => #[0]
  | 15, 16 => #[0, 0, 0]
  | 15, 17 => #[0]
  | 16, 17 => #[0]
  | _, _ => #[]

def witness (a b c d : Label) : Index :=
  let c' := c.val - (b.val + 1)
  let d' := d.val - (b.val + 1)
  (witnessRow a b)[d' * (d' - 1) / 2 + c']?.getD 0

def avoids (i : Index) (a b c d : Label) : Bool :=
  (coreList i).all (fun x => decide (x ≠ a ∧ x ≠ b ∧ x ≠ c ∧ x ≠ d))

def pairChecked (a b : Label) : Bool :=
  (List.finRange 20).all (fun c =>
    (List.finRange 20).all (fun d =>
      if b < c ∧ c < d then avoids (witness a b c d) a b c d else true))

set_option maxRecDepth 4096
set_option maxHeartbeats 1000000

theorem checked00_01 : pairChecked 0 1 = true := by
  decide +kernel

theorem checked00_02 : pairChecked 0 2 = true := by
  decide +kernel

theorem checked00_03 : pairChecked 0 3 = true := by
  decide +kernel

theorem checked00_04 : pairChecked 0 4 = true := by
  decide +kernel

theorem checked00_05 : pairChecked 0 5 = true := by
  decide +kernel

theorem checked00_06 : pairChecked 0 6 = true := by
  decide +kernel

theorem checked00_07 : pairChecked 0 7 = true := by
  decide +kernel

theorem checked00_08 : pairChecked 0 8 = true := by
  decide +kernel

theorem checked00_09 : pairChecked 0 9 = true := by
  decide +kernel

theorem checked00_10 : pairChecked 0 10 = true := by
  decide +kernel

theorem checked00_11 : pairChecked 0 11 = true := by
  decide +kernel

theorem checked00_12 : pairChecked 0 12 = true := by
  decide +kernel

theorem checked00_13 : pairChecked 0 13 = true := by
  decide +kernel

theorem checked00_14 : pairChecked 0 14 = true := by
  decide +kernel

theorem checked00_15 : pairChecked 0 15 = true := by
  decide +kernel

theorem checked00_16 : pairChecked 0 16 = true := by
  decide +kernel

theorem checked00_17 : pairChecked 0 17 = true := by
  decide +kernel

theorem checked00_18 : pairChecked 0 18 = true := by
  decide +kernel

theorem checked00_19 : pairChecked 0 19 = true := by
  decide +kernel

theorem checked01_02 : pairChecked 1 2 = true := by
  decide +kernel

theorem checked01_03 : pairChecked 1 3 = true := by
  decide +kernel

theorem checked01_04 : pairChecked 1 4 = true := by
  decide +kernel

theorem checked01_05 : pairChecked 1 5 = true := by
  decide +kernel

theorem checked01_06 : pairChecked 1 6 = true := by
  decide +kernel

theorem checked01_07 : pairChecked 1 7 = true := by
  decide +kernel

theorem checked01_08 : pairChecked 1 8 = true := by
  decide +kernel

theorem checked01_09 : pairChecked 1 9 = true := by
  decide +kernel

theorem checked01_10 : pairChecked 1 10 = true := by
  decide +kernel

theorem checked01_11 : pairChecked 1 11 = true := by
  decide +kernel

theorem checked01_12 : pairChecked 1 12 = true := by
  decide +kernel

theorem checked01_13 : pairChecked 1 13 = true := by
  decide +kernel

theorem checked01_14 : pairChecked 1 14 = true := by
  decide +kernel

theorem checked01_15 : pairChecked 1 15 = true := by
  decide +kernel

theorem checked01_16 : pairChecked 1 16 = true := by
  decide +kernel

theorem checked01_17 : pairChecked 1 17 = true := by
  decide +kernel

theorem checked01_18 : pairChecked 1 18 = true := by
  decide +kernel

theorem checked01_19 : pairChecked 1 19 = true := by
  decide +kernel

theorem checked02_03 : pairChecked 2 3 = true := by
  decide +kernel

theorem checked02_04 : pairChecked 2 4 = true := by
  decide +kernel

theorem checked02_05 : pairChecked 2 5 = true := by
  decide +kernel

theorem checked02_06 : pairChecked 2 6 = true := by
  decide +kernel

theorem checked02_07 : pairChecked 2 7 = true := by
  decide +kernel

theorem checked02_08 : pairChecked 2 8 = true := by
  decide +kernel

theorem checked02_09 : pairChecked 2 9 = true := by
  decide +kernel

theorem checked02_10 : pairChecked 2 10 = true := by
  decide +kernel

theorem checked02_11 : pairChecked 2 11 = true := by
  decide +kernel

theorem checked02_12 : pairChecked 2 12 = true := by
  decide +kernel

theorem checked02_13 : pairChecked 2 13 = true := by
  decide +kernel

theorem checked02_14 : pairChecked 2 14 = true := by
  decide +kernel

theorem checked02_15 : pairChecked 2 15 = true := by
  decide +kernel

theorem checked02_16 : pairChecked 2 16 = true := by
  decide +kernel

theorem checked02_17 : pairChecked 2 17 = true := by
  decide +kernel

theorem checked02_18 : pairChecked 2 18 = true := by
  decide +kernel

theorem checked02_19 : pairChecked 2 19 = true := by
  decide +kernel

theorem checked03_04 : pairChecked 3 4 = true := by
  decide +kernel

theorem checked03_05 : pairChecked 3 5 = true := by
  decide +kernel

theorem checked03_06 : pairChecked 3 6 = true := by
  decide +kernel

theorem checked03_07 : pairChecked 3 7 = true := by
  decide +kernel

theorem checked03_08 : pairChecked 3 8 = true := by
  decide +kernel

theorem checked03_09 : pairChecked 3 9 = true := by
  decide +kernel

theorem checked03_10 : pairChecked 3 10 = true := by
  decide +kernel

theorem checked03_11 : pairChecked 3 11 = true := by
  decide +kernel

theorem checked03_12 : pairChecked 3 12 = true := by
  decide +kernel

theorem checked03_13 : pairChecked 3 13 = true := by
  decide +kernel

theorem checked03_14 : pairChecked 3 14 = true := by
  decide +kernel

theorem checked03_15 : pairChecked 3 15 = true := by
  decide +kernel

theorem checked03_16 : pairChecked 3 16 = true := by
  decide +kernel

theorem checked03_17 : pairChecked 3 17 = true := by
  decide +kernel

theorem checked03_18 : pairChecked 3 18 = true := by
  decide +kernel

theorem checked03_19 : pairChecked 3 19 = true := by
  decide +kernel

theorem checked04_05 : pairChecked 4 5 = true := by
  decide +kernel

theorem checked04_06 : pairChecked 4 6 = true := by
  decide +kernel

theorem checked04_07 : pairChecked 4 7 = true := by
  decide +kernel

theorem checked04_08 : pairChecked 4 8 = true := by
  decide +kernel

theorem checked04_09 : pairChecked 4 9 = true := by
  decide +kernel

theorem checked04_10 : pairChecked 4 10 = true := by
  decide +kernel

theorem checked04_11 : pairChecked 4 11 = true := by
  decide +kernel

theorem checked04_12 : pairChecked 4 12 = true := by
  decide +kernel

theorem checked04_13 : pairChecked 4 13 = true := by
  decide +kernel

theorem checked04_14 : pairChecked 4 14 = true := by
  decide +kernel

theorem checked04_15 : pairChecked 4 15 = true := by
  decide +kernel

theorem checked04_16 : pairChecked 4 16 = true := by
  decide +kernel

theorem checked04_17 : pairChecked 4 17 = true := by
  decide +kernel

theorem checked04_18 : pairChecked 4 18 = true := by
  decide +kernel

theorem checked04_19 : pairChecked 4 19 = true := by
  decide +kernel

theorem checked05_06 : pairChecked 5 6 = true := by
  decide +kernel

theorem checked05_07 : pairChecked 5 7 = true := by
  decide +kernel

theorem checked05_08 : pairChecked 5 8 = true := by
  decide +kernel

theorem checked05_09 : pairChecked 5 9 = true := by
  decide +kernel

theorem checked05_10 : pairChecked 5 10 = true := by
  decide +kernel

theorem checked05_11 : pairChecked 5 11 = true := by
  decide +kernel

theorem checked05_12 : pairChecked 5 12 = true := by
  decide +kernel

theorem checked05_13 : pairChecked 5 13 = true := by
  decide +kernel

theorem checked05_14 : pairChecked 5 14 = true := by
  decide +kernel

theorem checked05_15 : pairChecked 5 15 = true := by
  decide +kernel

theorem checked05_16 : pairChecked 5 16 = true := by
  decide +kernel

theorem checked05_17 : pairChecked 5 17 = true := by
  decide +kernel

theorem checked05_18 : pairChecked 5 18 = true := by
  decide +kernel

theorem checked05_19 : pairChecked 5 19 = true := by
  decide +kernel

theorem checked06_07 : pairChecked 6 7 = true := by
  decide +kernel

theorem checked06_08 : pairChecked 6 8 = true := by
  decide +kernel

theorem checked06_09 : pairChecked 6 9 = true := by
  decide +kernel

theorem checked06_10 : pairChecked 6 10 = true := by
  decide +kernel

theorem checked06_11 : pairChecked 6 11 = true := by
  decide +kernel

theorem checked06_12 : pairChecked 6 12 = true := by
  decide +kernel

theorem checked06_13 : pairChecked 6 13 = true := by
  decide +kernel

theorem checked06_14 : pairChecked 6 14 = true := by
  decide +kernel

theorem checked06_15 : pairChecked 6 15 = true := by
  decide +kernel

theorem checked06_16 : pairChecked 6 16 = true := by
  decide +kernel

theorem checked06_17 : pairChecked 6 17 = true := by
  decide +kernel

theorem checked06_18 : pairChecked 6 18 = true := by
  decide +kernel

theorem checked06_19 : pairChecked 6 19 = true := by
  decide +kernel

theorem checked07_08 : pairChecked 7 8 = true := by
  decide +kernel

theorem checked07_09 : pairChecked 7 9 = true := by
  decide +kernel

theorem checked07_10 : pairChecked 7 10 = true := by
  decide +kernel

theorem checked07_11 : pairChecked 7 11 = true := by
  decide +kernel

theorem checked07_12 : pairChecked 7 12 = true := by
  decide +kernel

theorem checked07_13 : pairChecked 7 13 = true := by
  decide +kernel

theorem checked07_14 : pairChecked 7 14 = true := by
  decide +kernel

theorem checked07_15 : pairChecked 7 15 = true := by
  decide +kernel

theorem checked07_16 : pairChecked 7 16 = true := by
  decide +kernel

theorem checked07_17 : pairChecked 7 17 = true := by
  decide +kernel

theorem checked07_18 : pairChecked 7 18 = true := by
  decide +kernel

theorem checked07_19 : pairChecked 7 19 = true := by
  decide +kernel

theorem checked08_09 : pairChecked 8 9 = true := by
  decide +kernel

theorem checked08_10 : pairChecked 8 10 = true := by
  decide +kernel

theorem checked08_11 : pairChecked 8 11 = true := by
  decide +kernel

theorem checked08_12 : pairChecked 8 12 = true := by
  decide +kernel

theorem checked08_13 : pairChecked 8 13 = true := by
  decide +kernel

theorem checked08_14 : pairChecked 8 14 = true := by
  decide +kernel

theorem checked08_15 : pairChecked 8 15 = true := by
  decide +kernel

theorem checked08_16 : pairChecked 8 16 = true := by
  decide +kernel

theorem checked08_17 : pairChecked 8 17 = true := by
  decide +kernel

theorem checked08_18 : pairChecked 8 18 = true := by
  decide +kernel

theorem checked08_19 : pairChecked 8 19 = true := by
  decide +kernel

theorem checked09_10 : pairChecked 9 10 = true := by
  decide +kernel

theorem checked09_11 : pairChecked 9 11 = true := by
  decide +kernel

theorem checked09_12 : pairChecked 9 12 = true := by
  decide +kernel

theorem checked09_13 : pairChecked 9 13 = true := by
  decide +kernel

theorem checked09_14 : pairChecked 9 14 = true := by
  decide +kernel

theorem checked09_15 : pairChecked 9 15 = true := by
  decide +kernel

theorem checked09_16 : pairChecked 9 16 = true := by
  decide +kernel

theorem checked09_17 : pairChecked 9 17 = true := by
  decide +kernel

theorem checked09_18 : pairChecked 9 18 = true := by
  decide +kernel

theorem checked09_19 : pairChecked 9 19 = true := by
  decide +kernel

theorem checked10_11 : pairChecked 10 11 = true := by
  decide +kernel

theorem checked10_12 : pairChecked 10 12 = true := by
  decide +kernel

theorem checked10_13 : pairChecked 10 13 = true := by
  decide +kernel

theorem checked10_14 : pairChecked 10 14 = true := by
  decide +kernel

theorem checked10_15 : pairChecked 10 15 = true := by
  decide +kernel

theorem checked10_16 : pairChecked 10 16 = true := by
  decide +kernel

theorem checked10_17 : pairChecked 10 17 = true := by
  decide +kernel

theorem checked10_18 : pairChecked 10 18 = true := by
  decide +kernel

theorem checked10_19 : pairChecked 10 19 = true := by
  decide +kernel

theorem checked11_12 : pairChecked 11 12 = true := by
  decide +kernel

theorem checked11_13 : pairChecked 11 13 = true := by
  decide +kernel

theorem checked11_14 : pairChecked 11 14 = true := by
  decide +kernel

theorem checked11_15 : pairChecked 11 15 = true := by
  decide +kernel

theorem checked11_16 : pairChecked 11 16 = true := by
  decide +kernel

theorem checked11_17 : pairChecked 11 17 = true := by
  decide +kernel

theorem checked11_18 : pairChecked 11 18 = true := by
  decide +kernel

theorem checked11_19 : pairChecked 11 19 = true := by
  decide +kernel

theorem checked12_13 : pairChecked 12 13 = true := by
  decide +kernel

theorem checked12_14 : pairChecked 12 14 = true := by
  decide +kernel

theorem checked12_15 : pairChecked 12 15 = true := by
  decide +kernel

theorem checked12_16 : pairChecked 12 16 = true := by
  decide +kernel

theorem checked12_17 : pairChecked 12 17 = true := by
  decide +kernel

theorem checked12_18 : pairChecked 12 18 = true := by
  decide +kernel

theorem checked12_19 : pairChecked 12 19 = true := by
  decide +kernel

theorem checked13_14 : pairChecked 13 14 = true := by
  decide +kernel

theorem checked13_15 : pairChecked 13 15 = true := by
  decide +kernel

theorem checked13_16 : pairChecked 13 16 = true := by
  decide +kernel

theorem checked13_17 : pairChecked 13 17 = true := by
  decide +kernel

theorem checked13_18 : pairChecked 13 18 = true := by
  decide +kernel

theorem checked13_19 : pairChecked 13 19 = true := by
  decide +kernel

theorem checked14_15 : pairChecked 14 15 = true := by
  decide +kernel

theorem checked14_16 : pairChecked 14 16 = true := by
  decide +kernel

theorem checked14_17 : pairChecked 14 17 = true := by
  decide +kernel

theorem checked14_18 : pairChecked 14 18 = true := by
  decide +kernel

theorem checked14_19 : pairChecked 14 19 = true := by
  decide +kernel

theorem checked15_16 : pairChecked 15 16 = true := by
  decide +kernel

theorem checked15_17 : pairChecked 15 17 = true := by
  decide +kernel

theorem checked15_18 : pairChecked 15 18 = true := by
  decide +kernel

theorem checked15_19 : pairChecked 15 19 = true := by
  decide +kernel

theorem checked16_17 : pairChecked 16 17 = true := by
  decide +kernel

theorem checked16_18 : pairChecked 16 18 = true := by
  decide +kernel

theorem checked16_19 : pairChecked 16 19 = true := by
  decide +kernel

theorem checked17_18 : pairChecked 17 18 = true := by
  decide +kernel

theorem checked17_19 : pairChecked 17 19 = true := by
  decide +kernel

theorem checked18_19 : pairChecked 18 19 = true := by
  decide +kernel

theorem row00_checked (b : Label) (hab : 0 < b) :
    pairChecked 0 b = true := by
  fin_cases b
  · norm_num at hab
  · exact checked00_01
  · exact checked00_02
  · exact checked00_03
  · exact checked00_04
  · exact checked00_05
  · exact checked00_06
  · exact checked00_07
  · exact checked00_08
  · exact checked00_09
  · exact checked00_10
  · exact checked00_11
  · exact checked00_12
  · exact checked00_13
  · exact checked00_14
  · exact checked00_15
  · exact checked00_16
  · exact checked00_17
  · exact checked00_18
  · exact checked00_19

theorem row01_checked (b : Label) (hab : 1 < b) :
    pairChecked 1 b = true := by
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · exact checked01_02
  · exact checked01_03
  · exact checked01_04
  · exact checked01_05
  · exact checked01_06
  · exact checked01_07
  · exact checked01_08
  · exact checked01_09
  · exact checked01_10
  · exact checked01_11
  · exact checked01_12
  · exact checked01_13
  · exact checked01_14
  · exact checked01_15
  · exact checked01_16
  · exact checked01_17
  · exact checked01_18
  · exact checked01_19

theorem row02_checked (b : Label) (hab : 2 < b) :
    pairChecked 2 b = true := by
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · exact checked02_03
  · exact checked02_04
  · exact checked02_05
  · exact checked02_06
  · exact checked02_07
  · exact checked02_08
  · exact checked02_09
  · exact checked02_10
  · exact checked02_11
  · exact checked02_12
  · exact checked02_13
  · exact checked02_14
  · exact checked02_15
  · exact checked02_16
  · exact checked02_17
  · exact checked02_18
  · exact checked02_19

theorem row03_checked (b : Label) (hab : 3 < b) :
    pairChecked 3 b = true := by
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · exact checked03_04
  · exact checked03_05
  · exact checked03_06
  · exact checked03_07
  · exact checked03_08
  · exact checked03_09
  · exact checked03_10
  · exact checked03_11
  · exact checked03_12
  · exact checked03_13
  · exact checked03_14
  · exact checked03_15
  · exact checked03_16
  · exact checked03_17
  · exact checked03_18
  · exact checked03_19

theorem row04_checked (b : Label) (hab : 4 < b) :
    pairChecked 4 b = true := by
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · exact checked04_05
  · exact checked04_06
  · exact checked04_07
  · exact checked04_08
  · exact checked04_09
  · exact checked04_10
  · exact checked04_11
  · exact checked04_12
  · exact checked04_13
  · exact checked04_14
  · exact checked04_15
  · exact checked04_16
  · exact checked04_17
  · exact checked04_18
  · exact checked04_19

theorem row05_checked (b : Label) (hab : 5 < b) :
    pairChecked 5 b = true := by
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · exact checked05_06
  · exact checked05_07
  · exact checked05_08
  · exact checked05_09
  · exact checked05_10
  · exact checked05_11
  · exact checked05_12
  · exact checked05_13
  · exact checked05_14
  · exact checked05_15
  · exact checked05_16
  · exact checked05_17
  · exact checked05_18
  · exact checked05_19

theorem row06_checked (b : Label) (hab : 6 < b) :
    pairChecked 6 b = true := by
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · exact checked06_07
  · exact checked06_08
  · exact checked06_09
  · exact checked06_10
  · exact checked06_11
  · exact checked06_12
  · exact checked06_13
  · exact checked06_14
  · exact checked06_15
  · exact checked06_16
  · exact checked06_17
  · exact checked06_18
  · exact checked06_19

theorem row07_checked (b : Label) (hab : 7 < b) :
    pairChecked 7 b = true := by
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · exact checked07_08
  · exact checked07_09
  · exact checked07_10
  · exact checked07_11
  · exact checked07_12
  · exact checked07_13
  · exact checked07_14
  · exact checked07_15
  · exact checked07_16
  · exact checked07_17
  · exact checked07_18
  · exact checked07_19

theorem row08_checked (b : Label) (hab : 8 < b) :
    pairChecked 8 b = true := by
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · exact checked08_09
  · exact checked08_10
  · exact checked08_11
  · exact checked08_12
  · exact checked08_13
  · exact checked08_14
  · exact checked08_15
  · exact checked08_16
  · exact checked08_17
  · exact checked08_18
  · exact checked08_19

theorem row09_checked (b : Label) (hab : 9 < b) :
    pairChecked 9 b = true := by
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · exact checked09_10
  · exact checked09_11
  · exact checked09_12
  · exact checked09_13
  · exact checked09_14
  · exact checked09_15
  · exact checked09_16
  · exact checked09_17
  · exact checked09_18
  · exact checked09_19

theorem row10_checked (b : Label) (hab : 10 < b) :
    pairChecked 10 b = true := by
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · exact checked10_11
  · exact checked10_12
  · exact checked10_13
  · exact checked10_14
  · exact checked10_15
  · exact checked10_16
  · exact checked10_17
  · exact checked10_18
  · exact checked10_19

theorem row11_checked (b : Label) (hab : 11 < b) :
    pairChecked 11 b = true := by
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · exact checked11_12
  · exact checked11_13
  · exact checked11_14
  · exact checked11_15
  · exact checked11_16
  · exact checked11_17
  · exact checked11_18
  · exact checked11_19

theorem row12_checked (b : Label) (hab : 12 < b) :
    pairChecked 12 b = true := by
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · exact checked12_13
  · exact checked12_14
  · exact checked12_15
  · exact checked12_16
  · exact checked12_17
  · exact checked12_18
  · exact checked12_19

theorem row13_checked (b : Label) (hab : 13 < b) :
    pairChecked 13 b = true := by
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · exact checked13_14
  · exact checked13_15
  · exact checked13_16
  · exact checked13_17
  · exact checked13_18
  · exact checked13_19

theorem row14_checked (b : Label) (hab : 14 < b) :
    pairChecked 14 b = true := by
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · exact checked14_15
  · exact checked14_16
  · exact checked14_17
  · exact checked14_18
  · exact checked14_19

theorem row15_checked (b : Label) (hab : 15 < b) :
    pairChecked 15 b = true := by
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · exact checked15_16
  · exact checked15_17
  · exact checked15_18
  · exact checked15_19

theorem row16_checked (b : Label) (hab : 16 < b) :
    pairChecked 16 b = true := by
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · exact checked16_17
  · exact checked16_18
  · exact checked16_19

theorem row17_checked (b : Label) (hab : 17 < b) :
    pairChecked 17 b = true := by
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · exact checked17_18
  · exact checked17_19

theorem row18_checked (b : Label) (hab : 18 < b) :
    pairChecked 18 b = true := by
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · exact checked18_19

theorem row19_checked (b : Label) (hab : 19 < b) :
    pairChecked 19 b = true := by
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab

theorem all_pairs_checked (a b : Label) (hab : a < b) :
    pairChecked a b = true := by
  fin_cases a
  · exact row00_checked b hab
  · exact row01_checked b hab
  · exact row02_checked b hab
  · exact row03_checked b hab
  · exact row04_checked b hab
  · exact row05_checked b hab
  · exact row06_checked b hab
  · exact row07_checked b hab
  · exact row08_checked b hab
  · exact row09_checked b hab
  · exact row10_checked b hab
  · exact row11_checked b hab
  · exact row12_checked b hab
  · exact row13_checked b hab
  · exact row14_checked b hab
  · exact row15_checked b hab
  · exact row16_checked b hab
  · exact row17_checked b hab
  · exact row18_checked b hab
  · exact row19_checked b hab


theorem all_covered (a b c d : Label) (hab : a < b) (hbc : b < c) (hcd : c < d) :
    ∃ i : Index, core i ⊆ (((Finset.univ.erase a).erase b).erase c).erase d := by
  have h := all_pairs_checked a b hab
  unfold pairChecked at h
  have hc := List.all_eq_true.mp h c (List.mem_finRange c)
  have hd := List.all_eq_true.mp hc d (List.mem_finRange d)
  have havoid : avoids (witness a b c d) a b c d = true := by
    simpa only [if_pos (show b < c ∧ c < d from ⟨hbc, hcd⟩)] using hd
  refine ⟨witness a b c d, ?_⟩
  intro x hx
  have hx' : x ∈ coreList (witness a b c d) := List.mem_toFinset.mp hx
  unfold avoids at havoid
  have hne : x ≠ a ∧ x ≠ b ∧ x ≠ c ∧ x ≠ d :=
    of_decide_eq_true (List.all_eq_true.mp havoid x hx')
  obtain ⟨ha, hb, hc', hd'⟩ := hne
  exact Finset.mem_erase.mpr ⟨hd', Finset.mem_erase.mpr ⟨hc',
    Finset.mem_erase.mpr ⟨hb, Finset.mem_erase.mpr ⟨ha, Finset.mem_univ x⟩⟩⟩⟩

end Prize.JSP404.ThreeArcOrder16Coverage
