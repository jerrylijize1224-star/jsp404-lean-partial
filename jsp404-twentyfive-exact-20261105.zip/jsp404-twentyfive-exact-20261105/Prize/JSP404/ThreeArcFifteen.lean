import Prize.JSP404.ThreeArcOrder16Checks
import Prize.JSP404.ThreeArcOrder16Coverage
import Prize.JSP404.ThreeArcOrderCoreHelpers
import Prize.JSP404.ThreeArcOrderModelFour

/-! Every set of sixteen active labels contains a checked contradictory core.
The continuous model bridge then bounds compatible three-arc families by fifteen. -/
namespace Prize.JSP404.ThreeArcTwenty
open ContinuousDirection ThreeArcOrderCertificate

theorem no_sixteen_family {d : ℝ} (hd : d < 36 / 5)
    (R : Fin 16 → ThreeArcRow d)
    (hpair : ∀ i j, i ≠ j → ∃ x y : ℝ, ∃ z : ℤ,
      (R i).Mem x ∧ (R j).Mem y ∧ y = x + 9 + 18 * z) : False := by
  obtain ⟨t, ht, x, hx⟩ := ThreeArcOrderModelGeneral.exists_order_model R hd hpair
  obtain ⟨a, b, c, e, hab, hbc, hce, ha⟩ :=
    ThreeArcOrderModelGeneralFour.active_erase_quadruple t ht
  obtain ⟨i, hi⟩ := ThreeArcOrder16Coverage.all_covered a b c e hab hbc hce
  have hcore : ThreeArcOrder16Data.core i ⊆ ThreeArcOrderModelGeneral.active t := by
    rw [ha]
    exact hi
  exact accepted_false_of_subset ThreeArcOrder16Data.spec _ _
    (ThreeArcOrder16Data.certificate i) hcore (ThreeArcOrder16Data.all_accepted i) ⟨x, hx⟩

theorem family_card_le_fifteen {V : Type*} [Fintype V] {d : ℝ}
    (hd : d < 36 / 5) (R : V → ThreeArcRow d)
    (hpair : ∀ i j, i ≠ j → ∃ x y : ℝ, ∃ z : ℤ,
      (R i).Mem x ∧ (R j).Mem y ∧ y = x + 9 + 18 * z) :
    Fintype.card V ≤ 15 := by
  by_contra hn
  have h16 : 16 ≤ Fintype.card V := by omega
  let e : Fin 16 → V := fun i => (Fintype.equivFin V).symm (Fin.castLE h16 i)
  have he : Function.Injective e := by
    intro i j h
    apply Fin.ext
    have hval := congrArg Fin.val ((Fintype.equivFin V).symm.injective h)
    exact hval
  exact no_sixteen_family hd (fun i => R (e i))
    (fun i j hij => hpair (e i) (e j) (he.ne hij))

end Prize.JSP404.ThreeArcTwenty
