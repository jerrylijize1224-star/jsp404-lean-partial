import Prize.JSP404.ThreeArcOrderModelGeneral

/-! Sixteen occupied type labels leave four omitted labels. -/
namespace Prize.JSP404.ThreeArcOrderModelGeneralFour
open ThreeArcOrderCertificate

set_option maxHeartbeats 1000000 in
/-- List the four omitted labels in increasing order. -/
theorem active_erase_quadruple (t : Fin 16 → Label) (ht : Function.Injective t) :
    ∃ a b c d : Label, a < b ∧ b < c ∧ c < d ∧
      ThreeArcOrderModelGeneral.active t =
        ((((Finset.univ : Finset Label).erase a).erase b).erase c).erase d := by
  classical
  let missing := (Finset.univ : Finset Label) \ ThreeArcOrderModelGeneral.active t
  have hc : missing.card = 4 := by
    dsimp [missing]
    rw [Finset.card_sdiff_of_subset (Finset.subset_univ _),
      ThreeArcOrderModelGeneral.active_card t ht]
    norm_num
  let e : Fin 4 ≃o missing := missing.orderIsoOfFin hc
  let a : Label := (e 0).val
  let b : Label := (e 1).val
  let c : Label := (e 2).val
  let d : Label := (e 3).val
  have hab : a < b := e.strictMono (by decide : (0 : Fin 4) < 1)
  have hbc : b < c := e.strictMono (by decide : (1 : Fin 4) < 2)
  have hcd : c < d := e.strictMono (by decide : (2 : Fin 4) < 3)
  have hmissing (i : Label) : i ∈ missing ↔ i = a ∨ i = b ∨ i = c ∨ i = d := by
    constructor
    · intro hi
      obtain ⟨j, hj⟩ := e.surjective ⟨i, hi⟩
      have hv := congrArg Subtype.val hj
      fin_cases j
      · exact Or.inl hv.symm
      · exact Or.inr (Or.inl hv.symm)
      · exact Or.inr (Or.inr (Or.inl hv.symm))
      · exact Or.inr (Or.inr (Or.inr hv.symm))
    · intro hi
      rcases hi with rfl | rfl | rfl | rfl
      · exact (e 0).property
      · exact (e 1).property
      · exact (e 2).property
      · exact (e 3).property
  have hmem (i : Label) : i ∈ ThreeArcOrderModelGeneral.active t ↔
      i ≠ a ∧ i ≠ b ∧ i ≠ c ∧ i ≠ d := by
    have hn : i ∉ ThreeArcOrderModelGeneral.active t ↔
        i = a ∨ i = b ∨ i = c ∨ i = d := by
      simpa [missing] using hmissing i
    have he := not_congr hn
    simpa only [not_not, not_or] using he
  refine ⟨a, b, c, d, hab, hbc, hcd, ?_⟩
  ext i
  rw [hmem]
  simp [and_assoc, and_comm]

end Prize.JSP404.ThreeArcOrderModelGeneralFour
