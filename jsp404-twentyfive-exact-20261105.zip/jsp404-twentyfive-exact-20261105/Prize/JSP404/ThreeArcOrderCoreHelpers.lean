import Prize.JSP404.ThreeArcOrderCertificate

/-! A contradiction on a selected label subset also excludes any larger active set. -/
namespace Prize.JSP404.ThreeArcOrderCertificate

theorem Model.mono {S : Spec} {A B : Finset Label} {x : Var → ℝ}
    (h : Model S A x) (hBA : B ⊆ A) : Model S B x := by
  constructor
  · intro i hi
    exact h.1 i (hBA hi)
  · intro i hi j hj hij
    exact h.2 i (hBA hi) j (hBA hj) hij

theorem accepted_false_of_subset (S : Spec) (A B : Finset Label) (nodes : Array Node)
    (hBA : B ⊆ A) (h : accepted S B nodes = true) : ¬ ∃ x, Model S A x := by
  rintro ⟨x, hx⟩
  exact accepted_false S B nodes h ⟨x, hx.mono hBA⟩

end Prize.JSP404.ThreeArcOrderCertificate
