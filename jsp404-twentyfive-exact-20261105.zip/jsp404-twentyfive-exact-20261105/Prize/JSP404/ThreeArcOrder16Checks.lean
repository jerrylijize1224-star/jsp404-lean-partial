import Prize.JSP404.ThreeArcOrder16Data
import Mathlib.Tactic.FinCases

/-! Each concrete core certificate is checked by kernel reduction. -/
namespace Prize.JSP404.ThreeArcOrder16Data
open ThreeArcOrderCertificate

set_option maxHeartbeats 1000000 in
theorem accepted_000 : accepted spec (core 0) (certificate 0) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_001 : accepted spec (core 1) (certificate 1) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_002 : accepted spec (core 2) (certificate 2) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_003 : accepted spec (core 3) (certificate 3) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_004 : accepted spec (core 4) (certificate 4) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_005 : accepted spec (core 5) (certificate 5) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_006 : accepted spec (core 6) (certificate 6) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_007 : accepted spec (core 7) (certificate 7) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_008 : accepted spec (core 8) (certificate 8) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_009 : accepted spec (core 9) (certificate 9) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_010 : accepted spec (core 10) (certificate 10) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_011 : accepted spec (core 11) (certificate 11) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_012 : accepted spec (core 12) (certificate 12) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_013 : accepted spec (core 13) (certificate 13) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_014 : accepted spec (core 14) (certificate 14) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_015 : accepted spec (core 15) (certificate 15) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_016 : accepted spec (core 16) (certificate 16) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_017 : accepted spec (core 17) (certificate 17) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_018 : accepted spec (core 18) (certificate 18) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_019 : accepted spec (core 19) (certificate 19) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_020 : accepted spec (core 20) (certificate 20) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_021 : accepted spec (core 21) (certificate 21) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_022 : accepted spec (core 22) (certificate 22) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_023 : accepted spec (core 23) (certificate 23) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_024 : accepted spec (core 24) (certificate 24) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_025 : accepted spec (core 25) (certificate 25) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_026 : accepted spec (core 26) (certificate 26) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_027 : accepted spec (core 27) (certificate 27) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_028 : accepted spec (core 28) (certificate 28) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_029 : accepted spec (core 29) (certificate 29) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_030 : accepted spec (core 30) (certificate 30) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_031 : accepted spec (core 31) (certificate 31) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_032 : accepted spec (core 32) (certificate 32) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_033 : accepted spec (core 33) (certificate 33) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_034 : accepted spec (core 34) (certificate 34) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_035 : accepted spec (core 35) (certificate 35) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_036 : accepted spec (core 36) (certificate 36) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_037 : accepted spec (core 37) (certificate 37) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_038 : accepted spec (core 38) (certificate 38) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_039 : accepted spec (core 39) (certificate 39) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_040 : accepted spec (core 40) (certificate 40) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_041 : accepted spec (core 41) (certificate 41) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_042 : accepted spec (core 42) (certificate 42) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_043 : accepted spec (core 43) (certificate 43) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_044 : accepted spec (core 44) (certificate 44) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_045 : accepted spec (core 45) (certificate 45) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_046 : accepted spec (core 46) (certificate 46) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_047 : accepted spec (core 47) (certificate 47) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_048 : accepted spec (core 48) (certificate 48) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_049 : accepted spec (core 49) (certificate 49) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_050 : accepted spec (core 50) (certificate 50) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_051 : accepted spec (core 51) (certificate 51) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_052 : accepted spec (core 52) (certificate 52) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_053 : accepted spec (core 53) (certificate 53) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_054 : accepted spec (core 54) (certificate 54) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_055 : accepted spec (core 55) (certificate 55) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_056 : accepted spec (core 56) (certificate 56) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_057 : accepted spec (core 57) (certificate 57) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_058 : accepted spec (core 58) (certificate 58) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_059 : accepted spec (core 59) (certificate 59) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_060 : accepted spec (core 60) (certificate 60) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_061 : accepted spec (core 61) (certificate 61) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_062 : accepted spec (core 62) (certificate 62) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_063 : accepted spec (core 63) (certificate 63) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_064 : accepted spec (core 64) (certificate 64) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_065 : accepted spec (core 65) (certificate 65) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_066 : accepted spec (core 66) (certificate 66) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_067 : accepted spec (core 67) (certificate 67) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_068 : accepted spec (core 68) (certificate 68) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_069 : accepted spec (core 69) (certificate 69) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_070 : accepted spec (core 70) (certificate 70) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_071 : accepted spec (core 71) (certificate 71) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_072 : accepted spec (core 72) (certificate 72) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_073 : accepted spec (core 73) (certificate 73) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_074 : accepted spec (core 74) (certificate 74) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_075 : accepted spec (core 75) (certificate 75) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_076 : accepted spec (core 76) (certificate 76) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_077 : accepted spec (core 77) (certificate 77) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_078 : accepted spec (core 78) (certificate 78) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_079 : accepted spec (core 79) (certificate 79) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_080 : accepted spec (core 80) (certificate 80) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_081 : accepted spec (core 81) (certificate 81) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_082 : accepted spec (core 82) (certificate 82) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_083 : accepted spec (core 83) (certificate 83) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_084 : accepted spec (core 84) (certificate 84) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_085 : accepted spec (core 85) (certificate 85) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_086 : accepted spec (core 86) (certificate 86) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_087 : accepted spec (core 87) (certificate 87) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_088 : accepted spec (core 88) (certificate 88) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_089 : accepted spec (core 89) (certificate 89) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_090 : accepted spec (core 90) (certificate 90) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_091 : accepted spec (core 91) (certificate 91) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_092 : accepted spec (core 92) (certificate 92) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_093 : accepted spec (core 93) (certificate 93) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_094 : accepted spec (core 94) (certificate 94) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_095 : accepted spec (core 95) (certificate 95) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_096 : accepted spec (core 96) (certificate 96) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_097 : accepted spec (core 97) (certificate 97) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_098 : accepted spec (core 98) (certificate 98) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_099 : accepted spec (core 99) (certificate 99) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_100 : accepted spec (core 100) (certificate 100) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_101 : accepted spec (core 101) (certificate 101) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_102 : accepted spec (core 102) (certificate 102) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_103 : accepted spec (core 103) (certificate 103) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_104 : accepted spec (core 104) (certificate 104) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_105 : accepted spec (core 105) (certificate 105) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_106 : accepted spec (core 106) (certificate 106) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_107 : accepted spec (core 107) (certificate 107) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_108 : accepted spec (core 108) (certificate 108) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_109 : accepted spec (core 109) (certificate 109) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_110 : accepted spec (core 110) (certificate 110) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_111 : accepted spec (core 111) (certificate 111) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_112 : accepted spec (core 112) (certificate 112) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_113 : accepted spec (core 113) (certificate 113) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_114 : accepted spec (core 114) (certificate 114) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_115 : accepted spec (core 115) (certificate 115) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_116 : accepted spec (core 116) (certificate 116) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_117 : accepted spec (core 117) (certificate 117) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_118 : accepted spec (core 118) (certificate 118) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_119 : accepted spec (core 119) (certificate 119) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_120 : accepted spec (core 120) (certificate 120) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_121 : accepted spec (core 121) (certificate 121) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_122 : accepted spec (core 122) (certificate 122) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_123 : accepted spec (core 123) (certificate 123) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_124 : accepted spec (core 124) (certificate 124) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_125 : accepted spec (core 125) (certificate 125) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_126 : accepted spec (core 126) (certificate 126) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_127 : accepted spec (core 127) (certificate 127) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_128 : accepted spec (core 128) (certificate 128) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_129 : accepted spec (core 129) (certificate 129) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_130 : accepted spec (core 130) (certificate 130) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_131 : accepted spec (core 131) (certificate 131) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_132 : accepted spec (core 132) (certificate 132) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_133 : accepted spec (core 133) (certificate 133) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_134 : accepted spec (core 134) (certificate 134) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_135 : accepted spec (core 135) (certificate 135) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_136 : accepted spec (core 136) (certificate 136) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_137 : accepted spec (core 137) (certificate 137) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_138 : accepted spec (core 138) (certificate 138) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_139 : accepted spec (core 139) (certificate 139) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_140 : accepted spec (core 140) (certificate 140) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_141 : accepted spec (core 141) (certificate 141) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_142 : accepted spec (core 142) (certificate 142) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_143 : accepted spec (core 143) (certificate 143) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_144 : accepted spec (core 144) (certificate 144) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_145 : accepted spec (core 145) (certificate 145) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_146 : accepted spec (core 146) (certificate 146) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_147 : accepted spec (core 147) (certificate 147) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_148 : accepted spec (core 148) (certificate 148) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_149 : accepted spec (core 149) (certificate 149) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_150 : accepted spec (core 150) (certificate 150) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_151 : accepted spec (core 151) (certificate 151) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_152 : accepted spec (core 152) (certificate 152) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_153 : accepted spec (core 153) (certificate 153) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_154 : accepted spec (core 154) (certificate 154) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_155 : accepted spec (core 155) (certificate 155) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_156 : accepted spec (core 156) (certificate 156) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_157 : accepted spec (core 157) (certificate 157) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_158 : accepted spec (core 158) (certificate 158) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_159 : accepted spec (core 159) (certificate 159) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_160 : accepted spec (core 160) (certificate 160) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_161 : accepted spec (core 161) (certificate 161) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_162 : accepted spec (core 162) (certificate 162) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_163 : accepted spec (core 163) (certificate 163) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_164 : accepted spec (core 164) (certificate 164) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_165 : accepted spec (core 165) (certificate 165) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem accepted_166 : accepted spec (core 166) (certificate 166) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem all_accepted (i : Index) : accepted spec (core i) (certificate i) = true := by
  fin_cases i
  · exact accepted_000
  · exact accepted_001
  · exact accepted_002
  · exact accepted_003
  · exact accepted_004
  · exact accepted_005
  · exact accepted_006
  · exact accepted_007
  · exact accepted_008
  · exact accepted_009
  · exact accepted_010
  · exact accepted_011
  · exact accepted_012
  · exact accepted_013
  · exact accepted_014
  · exact accepted_015
  · exact accepted_016
  · exact accepted_017
  · exact accepted_018
  · exact accepted_019
  · exact accepted_020
  · exact accepted_021
  · exact accepted_022
  · exact accepted_023
  · exact accepted_024
  · exact accepted_025
  · exact accepted_026
  · exact accepted_027
  · exact accepted_028
  · exact accepted_029
  · exact accepted_030
  · exact accepted_031
  · exact accepted_032
  · exact accepted_033
  · exact accepted_034
  · exact accepted_035
  · exact accepted_036
  · exact accepted_037
  · exact accepted_038
  · exact accepted_039
  · exact accepted_040
  · exact accepted_041
  · exact accepted_042
  · exact accepted_043
  · exact accepted_044
  · exact accepted_045
  · exact accepted_046
  · exact accepted_047
  · exact accepted_048
  · exact accepted_049
  · exact accepted_050
  · exact accepted_051
  · exact accepted_052
  · exact accepted_053
  · exact accepted_054
  · exact accepted_055
  · exact accepted_056
  · exact accepted_057
  · exact accepted_058
  · exact accepted_059
  · exact accepted_060
  · exact accepted_061
  · exact accepted_062
  · exact accepted_063
  · exact accepted_064
  · exact accepted_065
  · exact accepted_066
  · exact accepted_067
  · exact accepted_068
  · exact accepted_069
  · exact accepted_070
  · exact accepted_071
  · exact accepted_072
  · exact accepted_073
  · exact accepted_074
  · exact accepted_075
  · exact accepted_076
  · exact accepted_077
  · exact accepted_078
  · exact accepted_079
  · exact accepted_080
  · exact accepted_081
  · exact accepted_082
  · exact accepted_083
  · exact accepted_084
  · exact accepted_085
  · exact accepted_086
  · exact accepted_087
  · exact accepted_088
  · exact accepted_089
  · exact accepted_090
  · exact accepted_091
  · exact accepted_092
  · exact accepted_093
  · exact accepted_094
  · exact accepted_095
  · exact accepted_096
  · exact accepted_097
  · exact accepted_098
  · exact accepted_099
  · exact accepted_100
  · exact accepted_101
  · exact accepted_102
  · exact accepted_103
  · exact accepted_104
  · exact accepted_105
  · exact accepted_106
  · exact accepted_107
  · exact accepted_108
  · exact accepted_109
  · exact accepted_110
  · exact accepted_111
  · exact accepted_112
  · exact accepted_113
  · exact accepted_114
  · exact accepted_115
  · exact accepted_116
  · exact accepted_117
  · exact accepted_118
  · exact accepted_119
  · exact accepted_120
  · exact accepted_121
  · exact accepted_122
  · exact accepted_123
  · exact accepted_124
  · exact accepted_125
  · exact accepted_126
  · exact accepted_127
  · exact accepted_128
  · exact accepted_129
  · exact accepted_130
  · exact accepted_131
  · exact accepted_132
  · exact accepted_133
  · exact accepted_134
  · exact accepted_135
  · exact accepted_136
  · exact accepted_137
  · exact accepted_138
  · exact accepted_139
  · exact accepted_140
  · exact accepted_141
  · exact accepted_142
  · exact accepted_143
  · exact accepted_144
  · exact accepted_145
  · exact accepted_146
  · exact accepted_147
  · exact accepted_148
  · exact accepted_149
  · exact accepted_150
  · exact accepted_151
  · exact accepted_152
  · exact accepted_153
  · exact accepted_154
  · exact accepted_155
  · exact accepted_156
  · exact accepted_157
  · exact accepted_158
  · exact accepted_159
  · exact accepted_160
  · exact accepted_161
  · exact accepted_162
  · exact accepted_163
  · exact accepted_164
  · exact accepted_165
  · exact accepted_166

end Prize.JSP404.ThreeArcOrder16Data
