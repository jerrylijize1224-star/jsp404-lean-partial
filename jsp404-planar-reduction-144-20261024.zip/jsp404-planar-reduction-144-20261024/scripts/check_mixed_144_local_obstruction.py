"""Extract the fixed model's three-vertex obstruction using exact arithmetic.

No SMT solver is used. The associated Lean theorem is in
Prize/JSP404/Fixed144TriangleObstruction.lean. This checks one fixed arc model,
not the full space of 21-vertex configurations.
"""

from fractions import Fraction as F
import hashlib
import json
from pathlib import Path


def main():
    source = Path("research/logs/jsp404-mixed144-9-12-20261022.json")
    raw = source.read_bytes()
    data = json.loads(raw)
    d = F(data["diameter"])
    assert d == F(43, 6)
    rows = [[(F(a), F(a) + d)] for a in data["starts_one"]]
    for a, b, c in data["starts_three"]:
        a, b, c = map(F, (a, b, c))
        rows.append([(a, c + d - 18), (b, a + d), (c, b + d)])
    assert all(0 <= lo <= hi < 36 for row in rows for lo, hi in row)

    def edge_intervals(i, j):
        # x in [0,18), x in row i, x+9 in row j, modulo 18.
        # All row endpoints lie in [0,36), so shifts -18,0,18 suffice.
        result = set()
        for lo, hi in rows[i]:
            for lo2, hi2 in rows[j]:
                for a in (-18, 0, 18):
                    for b in (-18, 0, 18):
                        lower = max(F(0), lo - a, lo2 - 9 - b)
                        upper = min(F(18), hi - a, hi2 - 9 - b)
                        if lower <= upper and lower < 18:
                            result.add((lower, upper))
        return sorted(result)

    pairs = [(7, 9), (7, 10), (9, 10)]
    bounds = [edge_intervals(*pair) for pair in pairs]
    assert bounds == [[(F(47, 3), F(497, 30))],
                      [(F(83, 5), F(499, 30))],
                      [(F(64, 5), F(77, 6))]]
    (ul, uh), (vl, vh), (wl, wh) = [bound[0] for bound in bounds]
    assert wh < ul and uh < vl and vh - wl < 9
    output = {
        "scope": "Exact obstruction for fixed rows 7,9,10 only; no new alpha bound",
        "input": str(source),
        "input_sha256": hashlib.sha256(raw).hexdigest(),
        "vertices_zero_based": [7, 9, 10],
        "rows": [[[str(lo), str(hi)] for lo, hi in rows[i]] for i in (7, 9, 10)],
        "edge_bounds": {str(pair): [[str(lo), str(hi)] for lo, hi in bound]
                        for pair, bound in zip(pairs, bounds)},
        "ordering": "w < u < v and v-w < 9; incompatible with either triangle orientation",
        "independent_fraction_check": True,
        "solver_used": False,
    }
    target = Path("research/logs/jsp404-mixed144-local-obstruction-20261023.json")
    target.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
