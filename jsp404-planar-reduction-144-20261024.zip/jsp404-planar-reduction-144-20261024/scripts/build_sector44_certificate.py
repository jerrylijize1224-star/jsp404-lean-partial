"""Build the 44-sector certificate modules in sequence to limit peak memory.

This only schedules ordinary Lake builds; Lean's kernel checks every proof.
Prepare the pinned environment and external packages as described in README.
"""
from pathlib import Path
import argparse
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--lake', default='lake', help='Lake executable or wrapper path')
args = parser.parse_args()
modules = ['Sector44Types', 'Sector44NonarcData']
modules += [f'Sector44NonarcChecks{k}' for k in range(12)]
modules += ['Sector44NonarcGraph']
modules += [f'Sector44NonarcRoot{k}' for k in [0, 1, 3, 4, 7, 9, 10, 14, 17, 19, 25, 29]]
modules += ['Sector44ArcCertificate', 'Sector44LowerBound']
for name in modules:
    started = time.monotonic()
    print(f'Checking {name}', flush=True)
    subprocess.run([args.lake, 'build', f'Prize.JSP404.{name}'], cwd=ROOT, check=True)
    print(f'Checked {name} in {time.monotonic() - started:.1f}s', flush=True)
print('44-sector modules checked. Run the full build and axiom audit next.', flush=True)
