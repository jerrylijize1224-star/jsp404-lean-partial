"""Build the 62-sector certificate modules in sequence to limit peak memory.

This only schedules ordinary Lake builds; Lean's kernel checks every proof.
Prepare the pinned environment and external packages as described in README.
"""
from pathlib import Path
import argparse
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--lake', default='lake', help='Lake executable or wrapper path')
parser.add_argument('--start-from', choices=['types', 'roots'], default='types', help='Resume at roots only after the graph checkpoint has passed')
parser.add_argument('--through', choices=['graph', 'all'], default='all', help='Optional checkpoint after the nonarc graph')
args = parser.parse_args()
modules = ['Sector62Types', 'Sector62NonarcData']
modules += [f'Sector62NonarcChecks{k}' for k in range(22)]
modules += ['Sector62NonarcGraph']
if args.start_from == 'roots':
    if args.through != 'all':
        parser.error('--start-from roots requires --through all')
    modules = []
if args.through == 'all':
    modules += [f'Sector62NonarcRoot{k}' for k in [0, 1, 3, 4, 7, 9, 10, 14, 17, 19, 20, 25, 29, 32, 34, 35, 41, 46, 50, 53, 69, 74]]
    modules += ['Sector62ArcCertificate', 'Sector62LowerBound']
for name in modules:
    started = time.monotonic()
    print(f'Checking {name}', flush=True)
    subprocess.run([args.lake, 'build', f'Prize.JSP404.{name}'], cwd=ROOT, check=True)
    print(f'Checked {name} in {time.monotonic() - started:.1f}s', flush=True)
print('62-sector '+args.through+' checkpoint checked. Full build and axiom audit are still required.', flush=True)
