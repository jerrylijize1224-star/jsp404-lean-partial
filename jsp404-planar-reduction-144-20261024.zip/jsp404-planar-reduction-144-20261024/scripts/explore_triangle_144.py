"""Explore variable arc rows with all triangle orientation constraints.

This is not a proof. A chosen one/three-arc partition is tested; other partitions
are not covered. Even a SAT direction model need not be a planar point set.
"""
import argparse
from fractions import Fraction as F
from itertools import combinations
import json
from pathlib import Path
import time
import z3


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--one", type=int, default=9)
    parser.add_argument("--three", type=int, default=12)
    parser.add_argument("--seconds", type=int, default=60)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    assert args.one >= 0 and args.three >= 0 and args.one + args.three >= 3
    if args.output.exists():
        raise SystemExit("Output already exists; choose a new path.")
    D = F(36, 5)
    Q = lambda x: z3.RealVal(str(x))
    one = [z3.Real(f"a_{i}") for i in range(args.one)]
    three = [[z3.Real(f"b_{i}_{j}") for j in range(3)] for i in range(args.three)]
    s = z3.SolverFor("QF_RDL")
    s.set(timeout=args.seconds * 1000, random_seed=0)
    for x in one:
        s.add(0 <= x, x < 18)
    for a, b, c in three:
        s.add(0 <= a, a < b, b < c, c < 18,
              a < c + Q(D) - 18, b < a + Q(D), c < b + Q(D))
    if one:
        s.add(one[0] == 0)
    else:
        s.add(three[0][0] == 0)
    for a, b in zip(one, one[1:]):
        s.add(a <= b)
    for a, b in zip(three, three[1:]):
        s.add(a[0] <= b[0])

    def rows_at(ones, threes, d):
        return [[(x, x + d)] for x in ones] + [
            [(a, c + d - 18), (b, a + d), (c, b + d)] for a, b, c in threes]

    rows = rows_at(one, three, Q(D))
    n = len(rows)
    edge = {ij: z3.Real("edge_%s_%s" % ij) for ij in combinations(range(n), 2)}

    def member(x, row):
        return z3.Or([z3.And(lo <= x + shift, x + shift < hi)
                      for lo, hi in row for shift in (-18, 0, 18)])

    def turn(x, y):
        return z3.Or(z3.And(0 < y - x, y - x < 9),
                     z3.And(-18 < y - x, y - x < -9))

    for (i, j), x in edge.items():
        s.add(0 <= x, x < 18, member(x, rows[i]), member(x + 9, rows[j]))
    for i, j, k in combinations(range(n), 3):
        u, v, w = edge[i, j], edge[i, k], edge[j, k]
        s.add(z3.Or(z3.And(turn(u, v), turn(u, w), turn(v, w)),
                    z3.And(turn(v, u), turn(w, u), turn(w, v))))
    start = time.monotonic()
    answer = s.check()
    output = {"scope": "Exploratory variable direction model, not a Lean proof",
              "one_arcs": args.one, "three_arcs": args.three,
              "limit": str(D), "vertices": n, "edges": len(edge),
              "triangles": n * (n - 1) * (n - 2) // 6,
              "result": str(answer), "elapsed_seconds": time.monotonic() - start,
              "solver": z3.get_version_string()}
    if answer == z3.unknown:
        output["reason"] = s.reason_unknown()
    if answer == z3.sat:
        model = s.model()
        val = lambda x: model.eval(x).as_fraction()
        av = list(map(val, one))
        bv = [list(map(val, row)) for row in three]
        ev = {ij: val(x) for ij, x in edge.items()}
        rows = rows_at(av, bv, D)
        margins = [D - 6] + [hi - lo for row in rows for lo, hi in row]
        for (i, j), x in ev.items():
            for y, row in [(x, rows[i]), (x + 9, rows[j])]:
                margins.append(max(hi - y - shift for lo, hi in row
                                   for shift in (-18, 0, 18) if lo <= y + shift < hi))
        assert min(margins) > 0
        d = D - min(margins) / 2
        rows = rows_at(av, bv, d)
        assert 6 <= d < D
        assert all(0 <= x < 18 for x in av)
        assert all(0 <= a < b < c < 18 for a, b, c in bv)
        assert all(lo <= hi and hi - lo <= d for row in rows for lo, hi in row)
        for row in rows[len(av):]:
            assert row[1][1] - row[0][0] <= d
            assert row[2][1] - row[1][0] <= d
            assert row[0][1] + 18 - row[2][0] <= d
        mem = lambda x, row: any(lo <= x + sh <= hi for lo, hi in row for sh in (-18, 0, 18))
        positive = lambda x, y: 0 < y - x < 9 or -18 < y - x < -9
        for (i, j), x in ev.items():
            assert 0 <= x < 18 and mem(x, rows[i]) and mem(x + 9, rows[j])
        for i, j, k in combinations(range(n), 3):
            u, v, w = ev[i, j], ev[i, k], ev[j, k]
            assert ((positive(u, v) and positive(u, w) and positive(v, w)) or
                    (positive(v, u) and positive(w, u) and positive(w, v)))
        output.update(diameter=str(d), degrees=str(20 * d),
                      starts_one=list(map(str, av)),
                      starts_three=[list(map(str, row)) for row in bv],
                      edge_directions={str(ij): str(x) for ij, x in ev.items()},
                      independent_fraction_check=True)
    args.output.write_text(json.dumps(output, indent=2) + "\n")
    print({k: v for k, v in output.items()
           if k not in ("starts_one", "starts_three", "edge_directions")})


if __name__ == "__main__":
    main()
