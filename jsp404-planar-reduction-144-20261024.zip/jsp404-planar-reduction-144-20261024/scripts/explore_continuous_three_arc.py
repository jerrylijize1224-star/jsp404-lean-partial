"""Exact rational discovery for the three-arc obstruction, NOT a Lean proof.

Circle circumference is 18, antipodal shift is 9, and the limiting diameter
is 7 (140 degrees). A type with starts a < b < c has arcs
[a, c+d-18], [b, a+d], [c, b+d]. For d < 7 these describe a particular
family of diameter-d sets. For 6 <= d < 36/5, the one-arc/three-arc classification is proved in
ContinuousDirectionClassification.lean. Pairwise antipodal intersection is another relaxation of
the original planar problem; a model here is not a planar counterexample.

Use the chosen limiting d (default 7) with strict inequalities. Finitely many positive rational slacks
then give d<7, checked independently with Fraction below.
"""
import argparse
from fractions import Fraction
import itertools
import json
from pathlib import Path
import time

import z3


def intervals(starts, diameter):
    a, b, c = starts
    return [(a, c + diameter - 18), (b, a + diameter), (c, b + diameter)]


def check_model(starts, diameter):
    """Independent exact check of widths, pairwise diameter and every edge."""
    assert 6 <= diameter < 9
    arcs = []
    for a, b, c in starts:
        assert 0 <= a < b < c < 18
        row = intervals((a, b, c), diameter)
        assert all(lo <= hi for lo, hi in row)
        # Each gap between adjacent arcs excludes the antipodal forbidden band:
        # clockwise distances from an earlier arc to the next are <= d;
        # distances from the first to the third are >= 18-d.
        assert row[1][1] - row[0][0] <= diameter
        assert row[2][1] - row[1][0] <= diameter
        assert row[0][1] + 18 - row[2][0] <= diameter
        assert all(hi - lo <= diameter for lo, hi in row)
        arcs.append(row)
    witnesses = []
    for i, j in itertools.combinations(range(len(arcs)), 2):
        choices = []
        for k, (lo, hi) in enumerate(arcs[i]):
            for l, (other_lo, other_hi) in enumerate(arcs[j]):
                for shift in (-9, 9):
                    left, right = max(lo, other_lo + shift), min(hi, other_hi + shift)
                    if left <= right:
                        choices.append((k, l, shift, left))
        assert choices, (i, j)
        k, l, shift, point = choices[0]
        witnesses.append({"i": i, "j": j, "arc_i": k, "arc_j": l,
                          "shift": shift, "point": str(point)})
    return witnesses


def solve(count, seconds, seed, proof_path=None, limit=Fraction(7)):
    assert 6 < limit <= Fraction(36, 5)
    limit_z3 = z3.RealVal(str(limit))
    if proof_path is not None:
        z3.set_param(proof=True)
    starts = [[z3.Real(f"x_{i}_{j}") for j in range(3)] for i in range(count)]
    solver = z3.SolverFor("QF_RDL")
    solver.set(timeout=seconds * 1000, random_seed=seed)
    for a, b, c in starts:
        solver.add(0 <= a, a < b, b < c, c < 18)
        solver.add(c + limit_z3 - 18 > a, a + limit_z3 > b, b + limit_z3 > c)
    # A common rotation and cyclic renaming permit the first start to be zero.
    # Sorting other types only permutes the nine labels.
    solver.add(starts[0][0] == 0)
    for i in range(1, count - 1):
        solver.add(starts[i][0] <= starts[i + 1][0])
    arcs = [intervals(s, limit_z3) for s in starts]
    for i, j in itertools.combinations(range(count), 2):
        solver.add(z3.Or([
            z3.And(lo < other_hi + shift, other_lo + shift < hi)
            for lo, hi in arcs[i] for other_lo, other_hi in arcs[j]
            for shift in (-9, 9)
        ]))
    before = time.monotonic()
    result = solver.check()
    data = {"status": "Exploratory only; no Lean proof or planar counterexample",
            "points": count, "limiting_diameter": str(limit), "solver": "z3 " + z3.get_version_string(),
            "seed": seed, "timeout_seconds": seconds, "result": str(result),
            "elapsed_seconds": round(time.monotonic() - before, 3)}
    if result == z3.unknown:
        data["reason"] = solver.reason_unknown()
    elif result == z3.unsat and proof_path is not None:
        assert not proof_path.exists(), "Do not overwrite a previous solver trace"
        proof = solver.proof()
        proof_path.write_text(proof.sexpr() + "\n")
        seen, rules, stack = set(), {}, [proof]
        while stack:
            node = stack.pop()
            if node.get_id() in seen:
                continue
            seen.add(node.get_id())
            if str(node.sort()) == "Proof":
                name = str(node.decl().name())
                rules[name] = rules.get(name, 0) + 1
                stack.extend(node.children())
        data["untrusted_solver_trace"] = str(proof_path)
        data["proof_rules"] = rules
        data["proof_bytes"] = proof_path.stat().st_size
    elif result == z3.sat:
        model = solver.model()
        values = [[model.eval(x).as_fraction() for x in row] for row in starts]
        # All upper interval endpoints decrease by epsilon when d decreases.
        slacks = [hi - lo for row in values for lo, hi in intervals(row, limit)]
        for i, j in itertools.combinations(range(count), 2):
            best = max(min(other_hi + shift - lo, hi - other_lo - shift)
                       for lo, hi in intervals(values[i], limit)
                       for other_lo, other_hi in intervals(values[j], limit)
                       for shift in (-9, 9))
            slacks.append(best)
        epsilon = min(slacks) / 2
        diameter = limit - epsilon
        witnesses = check_model(values, diameter)
        data.update({"diameter": str(diameter), "degrees": str(20 * diameter),
                     "starts": [[str(x) for x in row] for row in values],
                     "independent_rational_check": True, "witnesses": witnesses})
    return data


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--points", type=int, default=9)
    parser.add_argument("--seconds", type=int, default=50)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--limit", type=Fraction, default=Fraction(7))
    parser.add_argument("--output", type=Path)
    parser.add_argument("--proof", type=Path, help="Save an untrusted Z3 proof trace")
    args = parser.parse_args()
    assert args.points >= 2
    data = solve(args.points, args.seconds, args.seed, args.proof, args.limit)
    report = json.dumps(data, indent=2) + "\n"
    if args.output:
        assert not args.output.exists(), "Do not overwrite previous experiment records"
        args.output.write_text(report)
    print(report, end="")


if __name__ == "__main__":
    main()
