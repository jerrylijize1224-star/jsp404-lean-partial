"""Check triangle orientation consistency for a fixed exploratory arc model.

This is not a Lean proof, and neither SAT nor UNSAT decides planar realizability.
A planar triangle must have consistent signs of its three cyclic cross products.
"""
from fractions import Fraction as F
import itertools
import json
from pathlib import Path
import time
import z3
from explore_continuous_three_arc import intervals

p=Path('research/logs/jsp404-mixed144-9-12-20261022.json')
data=json.loads(p.read_text())
d=F(data['diameter'])
a=list(map(F,data['starts_one']))
b=[list(map(F,row)) for row in data['starts_three']]
assert 6 <= d < F(36,5)
assert all(0 <= x < 18 for x in a)
assert all(0 <= x < y < z < 18 for x,y,z in b)
rows=[[(x,x+d)] for x in a]+[intervals(r,d) for r in b]
assert all(lo <= hi and hi-lo <= d for row in rows for lo,hi in row)
for row in rows[len(a):]:
 assert row[1][1]-row[0][0] <= d
 assert row[2][1]-row[1][0] <= d
 assert row[0][1]+18-row[2][0] <= d
n=len(rows)
for i,j in itertools.combinations(range(n),2):
 assert any(max(lo,lo2+k) <= min(hi,hi2+k) for lo,hi in rows[i] for lo2,hi2 in rows[j] for k in (-9,9))

def Q(x):return z3.RealVal(str(x))
def member(x,row):
 return z3.Or([z3.And(Q(lo)<=x+shift,x+shift<=Q(hi)) for lo,hi in row for shift in (-18,0,18)])
def turn(x,y):
 return z3.Or(z3.And(0<y-x,y-x<9),z3.And(-18<y-x,y-x<-9))
s=z3.SolverFor('QF_RDL');s.set(timeout=60000,random_seed=0)
e={ij:z3.Real('edge_%s_%s'%ij) for ij in itertools.combinations(range(n),2)}
for (i,j),x in e.items():s.add(0<=x,x<18,member(x,rows[i]),member(x+9,rows[j]))
for i,j,k in itertools.combinations(range(n),3):
 u,v,w=e[i,j],e[i,k],e[j,k]
 s.add(z3.Or(z3.And(turn(u,v),turn(u,w),turn(v,w)),z3.And(turn(v,u),turn(w,u),turn(w,v))))
t=time.monotonic();ans=s.check()
out={'status':'Exploratory only; not a Lean proof or realizability decision','input':str(p),'independent_arc_check':True,'vertices':n,'edges':len(e),'triangles':n*(n-1)*(n-2)//6,'result':str(ans),'elapsed_seconds':time.monotonic()-t,'solver':z3.get_version_string()}
if ans==z3.unknown:out['reason']=s.reason_unknown()
if ans==z3.sat:
 m=s.model();v={ij:m.eval(x).as_fraction() for ij,x in e.items()}
 def mem(x,row):return any(lo<=x+shift<=hi for lo,hi in row for shift in (-18,0,18))
 def positive(x,y):return 0<y-x<9 or -18<y-x<-9
 assert all(0<=x<18 and mem(x,rows[i]) and mem(x+9,rows[j]) for (i,j),x in v.items())
 for i,j,k in itertools.combinations(range(n),3):
  u,w,t=v[i,j],v[i,k],v[j,k]
  assert (positive(u,w) and positive(u,t) and positive(w,t)) or (positive(w,u) and positive(t,u) and positive(t,w))
 out['independent_triangle_check']=True
 out['edge_directions']={str(ij):str(x) for ij,x in v.items()}
Path('research/logs/jsp404-mixed144-triangles-20261022.json').write_text(json.dumps(out,indent=2)+'\n')
print({k:v for k,v in out.items() if k!='edge_directions'})
