"""Export explicit 62-sector data for checking by Lean's kernel.

The exporter is not trusted: generic Lean soundness theorems check all data,
including domination reductions, type coverage and graph interpretations.
"""
from pathlib import Path
import json
import generate_sector62_candidate as candidate
from generate_sector62_candidate import e
ROOT=Path(__file__).resolve().parents[1]
d=json.loads((ROOT/'research/logs/jsp404-sector62-candidate-v2.json').read_text())
def labels(x):return list(e.bits(x))
def emit(c):
    if 'child' in c:
        steps='['+', '.join(f'({v}, {w})' for v,w in c['reductions'])+']'
        return f'(.reduce {steps} {emit(c["child"])})'
    if 'vertex' in c:
        return f'(.split {c["vertex"]} {emit(c["no"])} {emit(c["yes"])})'
    return '(.color '+str([labels(g) for g in c['colors']])+')'
def emit_cover(c):
    if 'leaf' in c:return '(.leaf '+str(c['leaf'])+')'
    return f'(.split {c["v"]} {emit_cover(c["no"])} {emit_cover(c["yes"])})'
def lookup_tree(values, variable, offset=0):
    """Balanced literal lookup; kernel evaluation avoids long array spines."""
    if len(set(values)) == 1:
        return values[0]
    mid = len(values) // 2
    return (f'(if {variable} < {offset + mid} then '
            f'{lookup_tree(values[:mid], variable, offset)} else '
            f'{lookup_tree(values[mid:], variable, offset + mid)})')
def write(name,s):
    dest=ROOT/'Prize/JSP404'/name
    if not dest.exists() or dest.read_text()!=s:dest.write_text(s)
    print(name,len(s.encode()))
def bounded_root(rep,r,A,n):
    """Compose separately kernel-checked subtrees, bounding reduction batches."""
    out=['import Prize.JSP404.Sector62MaskGraph\nnamespace Prize.JSP404.FiniteCliqueCertificate.Sector62Nonarc\nset_option maxRecDepth 65536\nset_option maxHeartbeats 0\nset_option Elab.async false\n']
    counter=0
    def domain_decl(P):
        nonlocal counter
        i=counter;counter+=1
        name=f'domain{rep}_{i}'
        out.append(f'def {name} : List Vertex := ({labels(P)} : List Nat).map vertex\n')
        return i,name
    def assumptions(name,P):
        return f'''  have hn : {name}.Nodup := by
    have h : {name}.IsChain (· < ·) := by decide +kernel
    exact h.pairwise.imp (fun hlt => ne_of_lt hlt)
  have hm : MaskReduction.Covers {name} {P} := by
    have h : {name}.all (fun u => decide (({P} / 2^u.val)%2 = 1)) = true := by decide +kernel
    intro u hu
    simpa only [Nat.testBit_eq_decide_div_mod_eq] using List.all_eq_true.mp h u hu
'''
    def cost(c,P):
        if 'child' in c:
            q=P;v=0
            for x,y in c['reductions']:v+=bin(q).count('1');q&=~(1<<x)
            return v+cost(c['child'],q)
        if 'vertex' in c:
            q=P&~(1<<c['vertex'])
            return 2*bin(P).count('1')+cost(c['no'],q)+cost(c['yes'],q&A[c['vertex']])
        return sum(bin(x).count('1')**2 for x in c['colors'])+bin(P).count('1')*sum(bin(x).count('1') for x in c['colors'])
    def node(c,P,k):
        i,name=domain_decl(P);bound=f'node_bound{rep}_{i}'
        if cost(c,P)<=12000 or 'colors' in c:
            out.append(f'def nodeCert{rep}_{i} : ReducedCertificate Vertex := MaskReduction.mapCertificate vertex ('+emit(c)+' : ReducedCertificate Nat)\n')
            out.append(f'theorem {bound} : Bound graph {name} {k} := by\n'+assumptions(name,P)+f'''  apply MaskReduction.check_sound graph (fun v => rows v.val) graph_rows graph_symmetric
    nodeCert{rep}_{i} {name} {P} {k} hn hm
  decide +kernel
''')
            return name,bound
        if 'child' in c:
            steps=c['reductions'];chunks=[steps[j:j+32] for j in range(0,len(steps),32)]
            domains=[P]
            for chunk in chunks:
                q=domains[-1]
                for x,y in chunk:q&=~(1<<x)
                domains.append(q)
            child_name,child_bound=node(c['child'],domains[-1],k)
            for j in reversed(range(len(chunks))):
                if j==0:di,dname,dbound=i,name,bound
                else:
                    di,dname=domain_decl(domains[j]);dbound=f'node_bound{rep}_{di}'
                stepname=f'nodeSteps{rep}_{di}'
                stepstr='['+', '.join(f'({v}, {w})' for v,w in chunks[j])+']'
                out.append(f'def {stepname} : List (Vertex × Vertex) := ({stepstr} : List (Nat × Nat)).map (fun (v,w) => (vertex v,vertex w))\n')
                out.append(f'theorem {dbound} : Bound graph {dname} {k} := by\n'+assumptions(dname,domains[j])+f'''  have hc : MaskReduction.reduction graph (fun v => rows v.val) {dname} {domains[j]} {stepname} = true := by decide +kernel
  apply reductionCheck_sound graph {stepname} {dname} {k}
    (MaskReduction.reduction_sound graph (fun v => rows v.val) graph_rows graph_symmetric
      {stepname} {dname} {domains[j]} hn hm hc).1
  have he : reducedDomain {dname} {stepname} = {child_name} := by decide +kernel
  simpa only [he] using {child_bound}
''')
                child_name,child_bound=dname,dbound
            assert child_name==name
            return name,bound
        v=c['vertex'];q=P&~(1<<v)
        no_name,no_bound=node(c['no'],q,k)
        yes_name,yes_bound=node(c['yes'],q&A[v],k-1)
        out.append(f'''theorem {bound} : Bound graph {name} {k} := by
  apply MaskReduction.bound_split graph {name} (vertex {v}) {k} (by decide)
  · have he : {name}.erase (vertex {v}) = {no_name} := by decide +kernel
    simpa only [he] using {no_bound}
  · have he : ({name}.erase (vertex {v})).filter (fun w => graph (vertex {v}) w) = {yes_name} := by decide +kernel
    simpa only [he] using {yes_bound}
''')
        return name,bound
    out.append(f'def neighbors{rep} : List Vertex := ({labels(A[rep])} : List Nat).map vertex\n')
    out.append(f'''theorem neighbors_eq{rep} : neighbors{rep} = (List.finRange {n}).filter (graph {rep}) := by
  decide +kernel
theorem neighbors_complete{rep} : ∀ v, graph {rep} v = true → v ∈ neighbors{rep} := by
  intro v hv
  rw [neighbors_eq{rep}]
  exact List.mem_filter.mpr ⟨List.mem_finRange v, hv⟩
''')
    name,bound=node({'reductions':r['reductions'],'child':r['recursive_certificate']},A[rep],7)
    out.append(f'theorem root_bound{rep} : Bound graph neighbors{rep} 7 := {bound}\n')
    out.append('end Prize.JSP404.FiniteCliqueCertificate.Sector62Nonarc\n')
    return ''.join(out)

s='''import Prize.JSP404.IndexedCliqueCover

/-! Explicit 62-sector type cover, checked by kernel reduction.
Generated by scripts/export_sector62_certificate.py. -/
namespace Prize.JSP404.FiniteCliqueCertificate.Sector62
set_option maxRecDepth 65536
set_option maxHeartbeats 0
abbrev Sector := Fin 62

def antipode (i : Sector) : Sector := ⟨(i.val+31)%62, Nat.mod_lt _ (by decide)⟩
def circularDistance (i j : Sector) : Nat :=
  min ((i.val+62-j.val)%62) ((j.val+62-i.val)%62)
def sectorGraph (i j : Sector) : Bool := decide (i ≠ j ∧ circularDistance i j ≤ 24)
'''
s+='def allTypes : List (List Sector) := '+str([labels(x) for x in d['types']])+'\n'
s+='def typeAt (i : Fin 1426) : List Sector := '+lookup_tree([str(labels(x)) for x in d['types']], 'i.val')+'\n'
s+='def coverCert : IndexedCoverCertificate Sector (Fin 1426) := '+emit_cover(d['cover'])+'\n'
s+='''theorem allTypes_cover : Covers sectorGraph (List.finRange 62) allTypes := by
  have hc : indexedCoverCheck sectorGraph typeAt (List.finRange 62) [] coverCert = true := by decide +kernel
  have hm : (List.range 1426).map (fun n => typeAt ⟨n % 1426, Nat.mod_lt _ (by decide)⟩) = allTypes := by decide +kernel
  intro s hs hclique
  obtain ⟨i, _, hi⟩ := indexedCoverCheck_sound sectorGraph typeAt coverCert _ _ hc s hs hclique
  refine ⟨typeAt i, ?_, hi⟩
  rw [← hm]
  apply List.mem_map.mpr
  refine ⟨i.val, List.mem_range.mpr i.isLt, ?_⟩
  congr 1
  exact Fin.ext (Nat.mod_eq_of_lt i.isLt)

theorem allTypes_no_antipodes : ∀ T ∈ allTypes, ∀ i : Sector,
    i ∈ T → antipode i ∉ T := by
  have h : allTypes.all (fun T => T.all (fun i => !(T.contains (antipode i)))) = true := by decide +kernel
  intro T hT i hi
  have hrow := List.all_eq_true.mp h T hT
  have he := List.all_eq_true.mp hrow i hi
  simpa using he

theorem antipode_involutive : Function.Involutive antipode := by
  change ∀ i : Sector, antipode (antipode i) = i
  decide +kernel
end Prize.JSP404.FiniteCliqueCertificate.Sector62
'''
write('Sector62Types.lean',s)
for f,name in zip(d['families'],['Nonarc','Arc']):
    types=f['types'];A=e.graph(types);n=len(types);lookup={x:i for i,x in enumerate(types)}
    shift=[lookup[e.rotate(x,1)] for x in types];reps=[r['representative'] for r in f['roots']]
    s='''import Prize.JSP404.RecursiveCliqueReduction
import Prize.JSP404.FiniteMaskIntersection
import Prize.JSP404.Sector62Types

/-! Explicit graph capacity, including checked domination reductions.
Generated by scripts/export_sector62_certificate.py. -/
'''
    s+=f'namespace Prize.JSP404.FiniteCliqueCertificate.Sector62{name}\n'
    s+='set_option maxRecDepth 65536\nset_option maxHeartbeats 0\nset_option Elab.async false\n'
    s+=f'abbrev Vertex := Fin {n}\n'
    s+='def labelsTable (i : Nat) : List Sector62.Sector := '+lookup_tree([str(labels(x)) for x in types], 'i')+'\n'
    s+='def labels (v : Vertex) : List Sector62.Sector := labelsTable v.val\n'
    s+='def mask (v : Vertex) : Nat := '+lookup_tree([str(x) for x in types], 'v.val')+'\n'
    s+='def reverseMask (v : Vertex) : Nat := '+lookup_tree([str(e.rotate(x,e.HALF)) for x in types], 'v.val')+'\n'
    s+='def rows (i : Nat) : Nat := '+lookup_tree([str(x) for x in A], 'i')+'\n'
    s+='def graph (i j : Vertex) : Bool := decide ((rows i.val / 2 ^ j.val) % 2 = 1)\n'
    s+=f'def vertex (i : Nat) : Vertex := ⟨i % {n}, Nat.mod_lt _ (by decide)⟩\n'
    s+='def shiftTable (i : Nat) : Vertex := '+lookup_tree([str(x) for x in shift], 'i')+'\n'
    s+='def shift (v : Vertex) : Vertex := shiftTable v.val\n'
    inverse=[shift.index(i) for i in range(n)]
    s+='def inverseShift (v : Vertex) : Vertex := '+lookup_tree([str(x) for x in inverse], 'v.val')+'\n'
    s+='def representatives : List Vertex := '+str(reps)+'\n'
    checks=['']*22
    if name == 'Nonarc':
        write('Sector62NonarcData.lean',s+'end Prize.JSP404.FiniteCliqueCertificate.Sector62Nonarc\n')
        s=''.join(f'import Prize.JSP404.Sector62NonarcChecks{k}\n' for k in range(22))
        s+='import Prize.JSP404.Sector62Rotation\nimport Mathlib.Tactic.FinCases\nnamespace Prize.JSP404.FiniteCliqueCertificate.Sector62Nonarc\nset_option maxRecDepth 65536\nset_option maxHeartbeats 0\nset_option Elab.async false\n'
    if name == 'Arc':s='import Prize.JSP404.Sector62Rotation\n'+s
    relation='graph i j = (decide (i ≠ j) && (labels i).any (fun b => (labels j).contains (Sector62.antipode b)))'
    def checked_pairs(theorem_name, statement, predicate):
        out=''
        if name == 'Nonarc':
            for k in range(22):
                for block in range(8):
                    checks[k]+=(f'theorem {theorem_name}_check{k}_block{block} : (List.range 8).all (fun a => (List.range {n}).all (fun b =>\n'+
                        f'    let i := vertex (62*{k}+8*{block}+a); let j := vertex b; decide ({predicate}))) = true := by decide +kernel\n')
                checks[k]+=(f'theorem {theorem_name}_check{k} : (List.range 62).all (fun a => (List.range {n}).all (fun b =>\n'+
                    f'    let i := vertex (62*{k}+a); let j := vertex b; decide ({predicate}))) = true := by\n')
                checks[k]+=f'  have h : ∀ block : Fin 8, (List.range 8).all (fun a => (List.range {n}).all (fun b =>\n'
                checks[k]+=f'      let i := vertex (62*{k}+8*block.val+a); let j := vertex b; decide ({predicate}))) = true := by\n'
                checks[k]+='    intro block\n    fin_cases block\n'+''.join(f'    · exact {theorem_name}_check{k}_block{block}\n' for block in range(8))
                checks[k]+='  apply List.all_eq_true.mpr\n  intro a ha\n  apply List.all_eq_true.mpr\n  intro b hb\n'
                checks[k]+='  have ha0 : a < 62 := List.mem_range.mp ha\n  have hblock : a / 8 < 8 := by omega\n'
                checks[k]+=f'  have heq : 62*{k}+8*(a/8)+a%8 = 62*{k}+a := by omega\n'
                checks[k]+='  have hr := List.all_eq_true.mp (h ⟨a/8, hblock⟩) (a%8) (List.mem_range.mpr (Nat.mod_lt _ (by decide)))\n'
                checks[k]+='  have he := List.all_eq_true.mp hr b hb\n  dsimp only at he ⊢\n  simpa only [heq] using he\n'
            out+='theorem '+theorem_name+' : '+statement+' := by\n'
            out+=f'  have h : ∀ k : Fin 22, (List.range 62).all (fun a => (List.range {n}).all (fun b =>\n'
            out+=f'      let i := vertex (62*k.val+a); let j := vertex b; decide ({predicate}))) = true := by\n'
            out+='    intro k\n    fin_cases k\n'+''.join(f'    · exact {theorem_name}_check{k}\n' for k in range(22))
            out+='  intro i j\n'
            out+='  have hi : vertex i.val = i := Fin.ext (Nat.mod_eq_of_lt i.isLt)\n'
            out+='  have hj : vertex j.val = j := Fin.ext (Nat.mod_eq_of_lt j.isLt)\n'
            out+='  have hk : i.val / 62 < 22 := by omega\n'
            out+='  have heq : 62 * (i.val / 62) + i.val % 62 = i.val := by omega\n'
            out+='  have hrow := List.all_eq_true.mp (h ⟨i.val / 62, hk⟩) (i.val % 62) (List.mem_range.mpr (Nat.mod_lt _ (by decide)))\n'
            out+='  have hentry := List.all_eq_true.mp hrow j.val (List.mem_range.mpr j.isLt)\n'
            out+='  dsimp only at hentry\n  simpa only [heq, hi, hj, decide_eq_true_eq] using hentry\n'
        else:
            out+='theorem '+theorem_name+' : '+statement+' := by\n'
            out+=f'  have h : (List.range {n}).all (fun a => (List.range {n}).all (fun b =>\n'
            out+=f'      let i := vertex a; let j := vertex b; decide ({predicate}))) = true := by decide +kernel\n'
            out+='  intro i j\n'
            out+='  have hi : vertex i.val = i := Fin.ext (Nat.mod_eq_of_lt i.isLt)\n'
            out+='  have hj : vertex j.val = j := Fin.ext (Nat.mod_eq_of_lt j.isLt)\n'
            out+='  have hrow := List.all_eq_true.mp h i.val (List.mem_range.mpr i.isLt)\n'
            out+='  have hentry := List.all_eq_true.mp hrow j.val (List.mem_range.mpr j.isLt)\n'
            out+='  simpa only [hi, hj, decide_eq_true_eq] using hentry\n'
        return out
    maskrelation='graph i j = decide (i ≠ j ∧ mask i &&& reverseMask j ≠ 0)'
    s+=checked_pairs('graph_mask_correct','∀ i j, '+maskrelation,maskrelation)
    s+=f'''theorem mask_bounded (v : Vertex) : mask v < 2^62 := by
  have h : (List.range {n}).all (fun a => decide (mask (vertex a) < 2^62)) = true := by decide +kernel
  have hv : vertex v.val = v := Fin.ext (Nat.mod_eq_of_lt v.isLt)
  have he := List.all_eq_true.mp h v.val (List.mem_range.mpr v.isLt)
  simpa only [hv, decide_eq_true_eq] using he

theorem mask_bits : ∀ v : Vertex, ∀ b : Sector62.Sector,
    (mask v).testBit b.val = decide (b ∈ labels v) ∧
    (reverseMask v).testBit b.val = decide (Sector62.antipode b ∈ labels v) := by
  have h : (List.range {n}).all (fun a => (List.range 62).all (fun k =>
      let v := vertex a
      let b : Sector62.Sector := ⟨k % 62, Nat.mod_lt _ (by decide)⟩
      decide ((decide ((mask v / 2^b.val)%2 = 1) = decide (b ∈ labels v)) ∧
        (decide ((reverseMask v / 2^b.val)%2 = 1) = decide (Sector62.antipode b ∈ labels v))))) = true := by decide +kernel
  intro v b
  have hv : vertex v.val = v := Fin.ext (Nat.mod_eq_of_lt v.isLt)
  have hb : (⟨b.val % 62, Nat.mod_lt _ (by decide)⟩ : Sector62.Sector) = b := Fin.ext (Nat.mod_eq_of_lt b.isLt)
  have hr := List.all_eq_true.mp h v.val (List.mem_range.mpr v.isLt)
  have he := List.all_eq_true.mp hr b.val (List.mem_range.mpr b.isLt)
  dsimp only at he
  simpa only [hv, hb, Nat.mod_eq_of_lt b.isLt, decide_eq_true_eq, Nat.testBit_eq_decide_div_mod_eq] using he

theorem graph_correct : ∀ i j, {relation} := by
  intro i j
  rw [graph_mask_correct]
  have hm := mask_intersects_iff (mask_bounded i)
    (fun b : Sector62.Sector => b ∈ labels i)
    (fun b : Sector62.Sector => Sector62.antipode b ∈ labels j)
    (fun b => (mask_bits i b).1) (fun b => (mask_bits j b).2)
  apply Bool.eq_iff_iff.mpr
  simp only [decide_eq_true_eq, Bool.and_eq_true, List.any_eq_true, List.contains_iff_mem, hm]
''' 
    s+=f'''theorem shift_injective : Function.Injective shift := by
  have h : (List.range {n}).all (fun a => decide (inverseShift (shift (vertex a)) = vertex a)) = true := by decide +kernel
  apply Function.LeftInverse.injective (g := inverseShift)
  intro v
  have hv : vertex v.val = v := Fin.ext (Nat.mod_eq_of_lt v.isLt)
  have he := List.all_eq_true.mp h v.val (List.mem_range.mpr v.isLt)
  simpa only [hv, decide_eq_true_eq] using he
'''
    s+=f'''theorem labels_shift (v : Vertex) : (labels (shift v)).Perm ((labels v).map Sector62.rotateSector) := by
  have h : (List.range {n}).all (fun a => decide
      ((labels (shift (vertex a))).Perm ((labels (vertex a)).map Sector62.rotateSector))) = true := by decide +kernel
  have hv : vertex v.val = v := Fin.ext (Nat.mod_eq_of_lt v.isLt)
  have he := List.all_eq_true.mp h v.val (List.mem_range.mpr v.isLt)
  simpa only [hv, decide_eq_true_eq] using he

theorem shift_preserves : ∀ i j, graph i j = true → graph (shift i) (shift j) = true := by
  intro i j h
  rw [graph_correct] at h ⊢
  have hh : i ≠ j ∧ (labels i).any (fun b => (labels j).contains (Sector62.antipode b)) = true := by
    simpa only [Bool.and_eq_true, decide_eq_true_eq] using h
  rw [Bool.and_eq_true]
  refine ⟨?_, ?_⟩
  · simpa only [decide_eq_true_eq] using shift_injective.ne hh.1
  · rw [antipodalOverlap_perm Sector62.antipode (labels_shift i) (labels_shift j),
      antipodalOverlap_map Sector62.antipode Sector62.rotateSector
        Sector62.rotateSector_injective Sector62.rotateSector_antipode]
    exact hh.2
'''

    orbit_steps=[]
    for v in range(n):
        w=v; count=0
        while w not in reps:
            w=shift[w]; count+=1
            assert count<62
        orbit_steps.append(count)
    s+='def orbitStep (v : Vertex) : Fin 62 := '+lookup_tree([str(x) for x in orbit_steps], 'v.val')+'\n'
    s+=f'''theorem orbit_covers : ∀ v : Vertex, ∃ r : Fin 62, shift^[r.val] v ∈ representatives := by
  have h : (List.range {n}).all (fun a =>
      representatives.contains (shift^[(orbitStep (vertex a)).val] (vertex a))) = true := by decide +kernel
  intro v
  have hv : vertex v.val = v := Fin.ext (Nat.mod_eq_of_lt v.isLt)
  have he := List.all_eq_true.mp h v.val (List.mem_range.mpr v.isLt)
  refine ⟨orbitStep v, ?_⟩
  simpa only [hv, List.contains_iff_mem] using he
'''
    if name == 'Nonarc':
        for k,check in enumerate(checks):
            write(f'Sector62NonarcChecks{k}.lean','import Prize.JSP404.Sector62NonarcData\nimport Mathlib.Tactic.FinCases\nnamespace Prize.JSP404.FiniteCliqueCertificate.Sector62Nonarc\nset_option maxRecDepth 65536\nset_option maxHeartbeats 0\nset_option Elab.async false\n'+check+'end Prize.JSP404.FiniteCliqueCertificate.Sector62Nonarc\n')
        write('Sector62NonarcGraph.lean',s+'end Prize.JSP404.FiniteCliqueCertificate.Sector62Nonarc\n')
    for r in f['roots']:
        if name == 'Nonarc':
            s='import Prize.JSP404.Sector62NonarcGraph\nnamespace Prize.JSP404.FiniteCliqueCertificate.Sector62Nonarc\nset_option maxRecDepth 65536\nset_option maxHeartbeats 0\nset_option Elab.async false\n'
        rep=r['representative'];steps='['+', '.join(f'({v}, {w})' for v,w in r['reductions'])+']'
        if name == 'Nonarc':
            write(f'Sector62NonarcRoot{rep}.lean',bounded_root(rep,r,A,n))
            continue
        s+=f'def neighbors{rep} : List Vertex := '+str(labels(A[rep]))+'\n'
        s+=f'def reductions{rep} : List (Vertex × Vertex) := '+steps+'\n'
        s+=f'def cert{rep} : ReducedCertificate Vertex := '+emit(r['recursive_certificate'])+'\n'
        s+=f'theorem neighbors_complete{rep} : ∀ v, graph {rep} v = true → v ∈ neighbors{rep} := by decide +kernel\n'
        domain=A[rep]; previous=f'neighbors{rep}'; part_names=[]
        for part,start in enumerate(range(0,len(r['reductions']),16)):
            chunk=r['reductions'][start:start+16]
            for v,w in chunk:domain&=~(1<<v)
            current=f'domain{rep}_{part}'
            stepname=f'reductionSteps{rep}_{part}'
            theoremname=f'reductionPart{rep}_{part}'
            s+=f'def {current} : List Vertex := '+str(labels(domain))+'\n'
            s+=f'def {stepname} : List (Vertex × Vertex) := ['+', '.join(f'({v}, {w})' for v,w in chunk)+']\n'
            s+=f'''theorem {theoremname} (k : Nat) (h : Bound graph {current} k) : Bound graph {previous} k := by
  apply reductionCheck_sound graph {stepname} {previous} k
  · decide +kernel
  · have he : reducedDomain {previous} {stepname} = {current} := by decide +kernel
    simpa only [he] using h
'''
            previous=current;part_names.append(theoremname)
        s+=f'''theorem reduced_bound{rep} : Bound graph {previous} 7 := by
  apply reducedCheck_sound graph cert{rep}
  decide +kernel
'''
        term=f'reduced_bound{rep}'
        for stepname in reversed(part_names):term=f'{stepname} 7 ({term})'
        s+=f'theorem root_bound{rep} : Bound graph neighbors{rep} 7 := by\n  exact {term}\n'
        if name == 'Nonarc':
            write(f'Sector62NonarcRoot{rep}.lean',s+'end Prize.JSP404.FiniteCliqueCertificate.Sector62Nonarc\n')
    if name == 'Nonarc':
        s=''.join(f'import Prize.JSP404.Sector62NonarcRoot{rep}\n' for rep in reps)+'\nnamespace Prize.JSP404.FiniteCliqueCertificate.Sector62Nonarc\n'
    s+='''theorem clique_card_le_eight (s : Finset Vertex) (hs : Clique graph s) : s.card ≤ 8 := by
  apply bound_of_orbit_neighbors graph shift shift_injective shift_preserves representatives ?_ 7 ?_ s hs
  · intro v
    obtain ⟨r, hr⟩ := orbit_covers v
    exact ⟨r.val, hr⟩
  · intro r hr t ht hn
    simp only [representatives, List.mem_cons, List.not_mem_nil, or_false] at hr
'''
    if len(reps)==1:
        rep=reps[0];s+=f'    subst r\n    exact root_bound{rep} t (fun v hv => neighbors_complete{rep} v (hn v hv)) ht\n'
    else:
        s+='    rcases hr with '+' | '.join(['rfl']*len(reps))+'\n'
        for rep in reps:s+=f'    · exact root_bound{rep} t (fun v hv => neighbors_complete{rep} v (hn v hv)) ht\n'
    s+=f'end Prize.JSP404.FiniteCliqueCertificate.Sector62{name}\n'
    write(f'Sector62{name}Certificate.lean',s)
