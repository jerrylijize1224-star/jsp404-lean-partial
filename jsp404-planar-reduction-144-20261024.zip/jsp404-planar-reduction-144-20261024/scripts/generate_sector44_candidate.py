"""Discover and independently check a 44-sector certificate candidate.

Python is untrusted discovery code. Only the exported Lean proof can establish
an original-problem lower bound. This does not modify the sealed 26-sector data.
"""
from pathlib import Path
import argparse, hashlib, json, time
import explore_sector_types as e
ROOT = Path(__file__).resolve().parents[1]
e.M, e.D, e.HALF, e.MASK = 44, 17, 22, (1 << 44)-1

def maximal_types():
    adj=e.sector_adj();result=[]
    def rec(R,P,X):
        if not P and not X:
            result.append(R);return
        u=max(e.bits(P|X),key=lambda u:bin(P&adj[u]).count('1'))
        for v in list(e.bits(P&~adj[u])):
            b=1<<v
            rec(R|b,P&adj[v],X&adj[v]);P^=b;X|=b
    rec(0,e.MASK,0)
    return sorted(result)

def reduce_domain(P,A):
    steps=[]
    while True:
        vs=list(e.bits(P));ns={v:A[v]&P for v in vs};found=False
        for v in sorted(vs,key=lambda v:bin(ns[v]).count('1')):
            for w in vs:
                if v!=w and not ns[v]&~ns[w]:
                    steps.append([v,w]);P^=1<<v;found=True;break
            if found:break
        if not found:return P,steps

def verify_reduction(P,A,steps):
    for v,w in steps:
        assert v!=w and P>>v&1 and P>>w&1 and not A[v]>>w&1
        for u in e.bits(P):
            assert not (A[v]>>u&1) or A[w]>>u&1
            assert not (A[u]>>v&1) or A[u]>>w&1
        P&=~(1<<v)
    return P

def cover(types):
    A=e.sector_adj()
    def rec(P,ts):
        for i in ts:
            if not P&~types[i]:return {'leaf':i}
        v=max(e.bits(P),key=lambda v:bin(P&~A[v]).count('1'));Q=P&~(1<<v)
        return {'v':v,'no':rec(Q,ts),'yes':rec(Q&A[v],[i for i in ts if types[i]>>v&1])}
    return rec(e.MASK,list(range(len(types))))

def verify_cover(types,c):
    A=e.sector_adj()
    def rec(P,ts,c):
        if 'leaf' in c:
            assert c['leaf'] in ts and not P&~types[c['leaf']];return 1
        v=c['v'];assert P>>v&1;Q=P&~(1<<v)
        return 1+rec(Q,ts,c['no'])+rec(Q&A[v],[i for i in ts if types[i]>>v&1],c['yes'])
    return rec(e.MASK,list(range(len(types))),c)

def compact_certificate(P,A):
    original=e.color_order
    best=e.certificate(P,8,A);best_size=e.verify_node(P,8,best,A)
    for descending in [True,False]:
        priority=sorted(e.bits(P),key=lambda v:bin(A[v]&P).count('1'),reverse=descending)
        def coloring(p,adj):
            order,bounds,groups=[],[],[]
            while p:
                q=p;group=0
                for v in priority:
                    b=1<<v
                    if q&b:
                        order.append(v);bounds.append(len(groups)+1)
                        group|=b;p^=b;q&=~(b|adj[v])
                groups.append(group)
            return order,bounds,groups
        try:
            e.color_order=coloring
            c=e.certificate(P,8,A);size=e.verify_node(P,8,c,A)
            if size<best_size:best,best_size=c,size
        finally:e.color_order=original
    return best

def family(types,size):
    A=e.graph(types);lookup={x:i for i,x in enumerate(types)};rest=set(range(len(types)));roots=[]
    while rest:
        rep=min(rest);rest-={lookup[e.rotate(types[rep],r)] for r in range(44)}
        P,steps=reduce_domain(A[rep],A)
        cert=compact_certificate(P,A)
        roots.append({'representative':rep,'reductions':steps,'certificate':cert})
    return {'types':types,'type_size':size,'bound':8,'roots':roots}

def verify_family(f):
    T=f['types'];A=e.graph(T);lookup={x:i for i,x in enumerate(T)}
    assert len(lookup)==len(T) and f['bound']==8
    assert all(bin(x).count('1')==f['type_size'] for x in T)
    for r in range(44):
        perm=[lookup[e.rotate(x,r)] for x in T]
        assert len(set(perm))==len(T)
        for i in range(len(T)):
            assert sum(1<<perm[j] for j in e.bits(A[i]))==A[perm[i]]
    covered=set();counts=[]
    for root in f['roots']:
        rep=root['representative'];covered.update(lookup[e.rotate(T[rep],r)] for r in range(44))
        P=verify_reduction(A[rep],A,root['reductions'])
        counts.append(e.verify_node(P,8,root['certificate'],A))
    assert covered==set(range(len(T)))
    return counts

def main():
    p=argparse.ArgumentParser();p.add_argument('--verify-only',action='store_true');p.add_argument('--output',default='research/logs/jsp404-sector44-candidate-v2.json');args=p.parse_args()
    dest=ROOT/args.output;started=time.monotonic();T=maximal_types()
    if args.verify_only:data=json.loads(dest.read_text())
    else:
        assert not dest.exists(), 'Preserve candidate data; choose a new version instead.'
        data={'status':'Untrusted discovery data; see Lean modules for verification status',
              'sectors':44,'distance_bound':17,'types':T,'cover':cover(T),
              'families':[family([x for x in T if bin(x).count('1')==k],k) for k in [10,18]]}
    assert data['sectors']==44 and data['distance_bound']==17 and data['types']==T
    assert len(T)==572 and sorted(x for f in data['families'] for x in f['types'])==T
    covernodes=verify_cover(T,data['cover']);counts=[verify_family(f) for f in data['families']]
    if not args.verify_only:dest.write_text(json.dumps(data,separators=(',',':'))+'\n')
    print(json.dumps({'types':len(T),'family_sizes':[len(f['types']) for f in data['families']],
         'cover_nodes':covernodes,'bound_nodes':counts,'reduction_steps':sum(len(r['reductions']) for f in data['families'] for r in f['roots']),
         'seconds':round(time.monotonic()-started,3),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),
         'status':'Python verified candidate only; not a Lean proof'}))
if __name__=='__main__':main()
