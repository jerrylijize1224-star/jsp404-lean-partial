from fractions import Fraction as F
import itertools, json, time, sys
from pathlib import Path
sys.path.insert(0,str(Path('scripts').resolve()))
import z3
from explore_continuous_three_arc import intervals
one, three = 9, 12
D=F(36,5);Dz=z3.RealVal(str(D))
a=[z3.Real(f'a{i}') for i in range(one)]
b=[[z3.Real(f'b{i}_{j}') for j in range(3)] for i in range(three)]
s=z3.SolverFor('QF_RDL');s.set(timeout=60000,random_seed=0)
for x in a:s.add(0<=x,x<18)
for x,y,z in b:s.add(0<=x,x<y,y<z,z<18,x<z+Dz-18,y<x+Dz,z<y+Dz)
s.add(a[0]==0)
for i in range(one-1):s.add(a[i]<=a[i+1])
for i in range(three-1):s.add(b[i][0]<=b[i+1][0])
rows=[[(x,x+Dz)] for x in a]+[intervals(r,Dz) for r in b]
for i,j in itertools.combinations(range(len(rows)),2):
 s.add(z3.Or([z3.And(lo<hi2+k,lo2+k<hi) for lo,hi in rows[i] for lo2,hi2 in rows[j] for k in (-9,9)]))
t=time.monotonic();ans=s.check()
out={'status':'Exploratory only; not a Lean proof or planar counterexample','one_arcs':one,'three_arcs':three,'limit':str(D),'result':str(ans),'seconds':time.monotonic()-t,'solver':z3.get_version_string()}
if ans==z3.unknown:out['reason']=s.reason_unknown()
if ans==z3.sat:
 m=s.model();av=[m.eval(x).as_fraction() for x in a];bv=[[m.eval(x).as_fraction() for x in r] for r in b]
 def rr(d):return [[(x,x+d)] for x in av]+[intervals(r,d) for r in bv]
 rows=rr(D);sl=[hi-lo for r in rows for lo,hi in r]
 for i,j in itertools.combinations(range(len(rows)),2):sl.append(max(min(hi2+k-lo,hi-lo2-k) for lo,hi in rows[i] for lo2,hi2 in rows[j] for k in (-9,9)))
 d=D-min(sl)/2;rows=rr(d);w=[]
 for i,j in itertools.combinations(range(len(rows)),2):
  choices=[(k,l,h,max(lo,lo2+h)) for k,(lo,hi) in enumerate(rows[i]) for l,(lo2,hi2) in enumerate(rows[j]) for h in (-9,9) if max(lo,lo2+h)<=min(hi,hi2+h)]
  assert choices
  w.append([i,j,*map(str,choices[0])])
 out.update(diameter=str(d),degrees=str(20*d),starts_one=list(map(str,av)),starts_three=[list(map(str,r)) for r in bv],witnesses=w,independent_rational_check=True)
Path('research/logs/jsp404-mixed144-9-12-20261022.json').write_text(json.dumps(out,indent=2)+'\n')
print({k:v for k,v in out.items() if k not in ['starts_one','starts_three','witnesses']})
