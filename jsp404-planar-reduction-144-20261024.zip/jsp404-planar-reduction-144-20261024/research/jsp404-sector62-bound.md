# 62 扇区：已验证的 24π/31 下界

验证日期：2026-10-21。

## 数值结果与范围

Lean 已证明 `GuaranteedAngle N (24π/31)` 对所有 N≥17 成立。
任意有限平面点集适用，不增加凸性、一般位置或其他几何假设。
结合既有上界，得到 **(24/31)π≤alpha 17≤(7/9)π**，即
**139.354838709677…°≤alpha 17≤140°**。
剩余间距为 **20/31°≈0.645161290323°**。
相比前一正式下界 (17/22)π，下界提升 90/341°，区间宽度缩小 9/31（约 29.03%）。
这不是精确值 140° 的证明，完整 `SendovClaim` 仍未证明。

关键结果位于 `Sector62LowerBound.lean`：

- `card_le_sixteen_of_complex_angles_sector62`
- `card_le_sixteen_of_plane_angles_sector62`
- `guaranteedAngle_sector62`
- `sector62_alpha_lower`
- `alpha_seventeen_sector62_bounds`

## 有限证书与几何连接

62 个扇区，反向编号相差 31，循环距离上限 24。完整覆盖包含 1426 个方向类型：
1364 个非弧型（每型 13 个编号）及 62 个弧型（每型 25 个编号）。
类型覆盖证书包含 5147 个节点。22 个非弧型旋转代表和弧型证书均通过，
证明两族相容团各至多 8 个顶点。原始几何中的反向边一致性和无反向对性
把严格低于阈值的点集限制为最多 16 点。

`Sector62Quantization` 用准确的实数取整及复数辐角处理扇区边界，
`Sector62LowerBound` 将结果接回原题的普通平面点集定义。
下界的本地导入闭包为 87 个模块及 mathlib，不导入九点、十一点外部证书。
完整项目仍保留这些明确注明来源的其他结果。

检查方法及其可靠性均在 Lean 中证明：索引型完整覆盖检查；
位集合与标签关系；旋转保持相容图及轨道覆盖；递归支配约简；
整数位集合支配检查到原列表检查的转换；分支证明的接合。
图对称性由已验证的标签关系和反向映射对合性推出，不作为额外几何假设。
每个非弧型约简段至多 32 步；子域的排序无重复性、位覆盖及域转换逐一核验。
分段只控制内存，所有约简、分支、颜色证书仍在完整证明链中。

初版数据约 21.5 MB；递归内部约简把数据压缩至 1,270,583 字节、1927 个递归节点。
根层约简 13124 次，递归内部约简 27967 次。Python 仅负责发现、独立复查与导出，
不在形式化证明的信任基础内。检查没有使用 `native_decide`。

## 验证与复现

完整构建退出成功：3246 项含依赖；随后公理审计退出成功：2286 项。
新增 59 个模块中的全部 1746 个定理已在审计中；多数是有限证书的小段核验，
不应把数量当成数学进度。4 项审计无公理依赖，其余仅依赖标准基础
`propext`、`Classical.choice`、`Quot.sound` 的子集。
最终成功前，被主动停止的整块核验、旧格式诊断及失败编译均未计为通过。
没有独立第三方审查或全新机器重建的声明。

```sh
python3 scripts/generate_sector62_candidate.py --verify-only --output research/logs/jsp404-sector62-candidate-v2.json
python3 scripts/export_sector62_certificate.py
python3 scripts/build_sector62_certificate.py --lake ./scripts/lake.sh
./scripts/lake.sh build
./scripts/lake.sh env lean Prize/Audit.lean
```

公开包使用系统安装的固定 Lean 工具链，将上述 `./scripts/lake.sh` 改为 `lake`；
按 README 准备已固定的依赖和外部证书。顺序构建用于限制内存峰值。

数据 SHA-256：

- 初版 `jsp404-sector62-candidate.json`：`a8045a27f203a9a5f7117170632837d14da06591f39ea08901c10e6ec1284745`。
- 递归版 `jsp404-sector62-candidate-v2.json`：`44fbc857b4e21c9c4959ea0a984854e4ae75392450b0a8c0bc0e27bb68e68cb4`。

## 尚未解决的精确值与来源

候选族 M=18t+8、D=7t+3 的 t=1,2,3 分别对应已验证的 26、44、62 扇区，
阈值 360D/M 从下方趋向 140°。**尚未证明所有 t 均具有 8+8 容量界，
不能从三个实例推断一般情形。** 九个连续三弧类型的早期探索曾在限时内返回 unknown。后续已通过整数差压缩
及本证书证明连续三弧模型的统一排除；见 [连续三弧路线](jsp404-continuous-three-arc.md)。
原题的方向分类与单弧族统一计数仍未完成。

若证明 alpha 17=140°，既有单调性与上界可推出 17–20 点均为 140°。
下一未闭合区间的最小点数是 21，目标 144°，可覆盖 21–32 点。
完整 SendovClaim 还要求所有后续区间，无法给出可靠的整题完成百分比。

目标及经典精确分类来自 Sendov (1995)。本项目完成上述部分形式化及其核验，
不声称新数学发现、首次形式化或他人尚未解决。
本轮没有重新进行外部文献或奖项优先权检索。
来源访问和证明范围见 [证明路线](jsp404-proof-map.md)、
[英文来源](jsp404-english-source.md) 和 [44 扇区结果](jsp404-sector44-bound.md)。
