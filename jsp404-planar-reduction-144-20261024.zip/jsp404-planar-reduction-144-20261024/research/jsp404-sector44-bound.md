# 44 扇区路线：17 点已验证下界 17π/22

日期：2026-10-14。完整构建成功（3183 项含依赖），随后全部 540 项公理审计通过。
三十三个新增模块的 82 个定理全部纳入审计；所有实际依赖均在
`propext`、`Classical.choice`、`Quot.sound` 范围内。没有额外公理、证明占位或 native_decide。
新下界的导入闭包为 60 个本地模块及 mathlib，不导入外部有限证书。
当前原题区间为 **(17/22)π≤alpha 17≤(7/9)π**。

## 目标与数值

已证明原题任意至少 17 个平面点中，存在一个角至少为 17π/22。
这对应 **139.090909…°**；17 点上下界间距为
**10/11°≈0.909091°**。它是精确有理倍数的下界，不是精确值 140°。
不增加凸性、一般位置或有限方向可实现性假设。

## 有限证书与压缩

沿用已验证的 26 扇区框架，将整圆等分成 44 个半开扇区，每格 π/22。
严格角度上限 17π/22 给出循环编号距离至多 17，反向编号相差 22。
572 个覆盖类型分成 528 个非弧型（每型 10 个编号）和 44 个弧型
（每型 18 个编号）。覆盖证书有 1947 个节点。
Lean 已证明每族的相容图中团的大小至多 8，并将原题反例点集注入其中。

直接着色分支会生成数百万个搜索节点。本轮加入顶点支配约简：
在当前候选域中，若 v 与 w 不相邻，且 v 的每条入边、出边都能由 w 替代，
则任意包含 v 的团可用 w 替换 v，团大小保持不变。因此可以删除 v。
此规则检查两种边方向，通用可靠性定理不暗中假定图对称。
`FiniteCliqueReduction.lean` 将每一步约简接到已有团上界检查器。

证书共有 2759 次约简。非弧型的 12 个旋转轨道代表分别为
0、1、3、4、7、9、10、14、17、19、25、29；约简后各代表的分支证书节点数为
262、449、421、14、7、14、125、31、126、903、28、19。
弧型只有一个轨道代表和一个着色叶节点。
初版非弧型证书为 8215 个节点；比较编号次序与两种度数次序后，
最终非弧型证书共 2399 个节点。旧版数据保留，首次较慢的编译已取消，
不得把这些未完成运行计为通过。
核验实现改用自然数区间的布尔遍历，再由 `List.all_eq_true` 恢复有限全称命题。
数据表用平衡分支查找，位读取用除以二的幂后取余；这避免内核反复展开长数组、
有限编号列表和递归移位。独立的 `graph_correct` 仍检查全部边与原始反向标签的关系。
类型分类和旋转轨道均提供逐项核对的明确见证，避免重新搜索已知见证；
旋转的单射性通过核对一个显式左逆得到。见证本身仍须通过内核检查。
所有有限事实仍须通过 `decide +kernel` 核验，不依赖 Python 的计算结果。
这些数字统计 Python 证书中的递归节点，不等于 Lean 定理数，也不包含
导出为二叉分支时增加的构造器。

## 复查入口

`research/logs/jsp404-sector44-candidate-v2.json` 保存最终紧凑证书，SHA-256：
`adf05cb12e89a568abde94cc1d364dd93e74ffb7897f4fff26538321a2465593`。
初版 `jsp404-sector44-candidate.json` 保留不改写，其 SHA-256 为
`eb791757fac23fe5a0e6324b82f0a2ce2049a455eba4898ee3b19b211e8c893a`。

```sh
python3 scripts/generate_sector44_candidate.py --verify-only
python3 scripts/export_sector44_certificate.py
```

发现程序使用 Bron–Kerbosch 列举，但正确性不依赖信任该枚举：
导出的 Lean 覆盖证书须独立证明所有方向团都已覆盖。
Python 独立复查反向相容关系、旋转自同构、轨道覆盖、每次支配约简和
每个分支/着色叶节点；人为改成自替换的错误约简被检查器拒绝。
这些 Python 检查本身不证明原题下界。
生成器只生成有限数据文件；几何转移和检查器可靠性由手写 Lean 证明处理。

新增主模块为 `FiniteCliqueReduction.lean`、`Sector44Types.lean`、
`Sector44ArcCertificate.lean`、`Sector44NonarcCertificate.lean`、
`Sector44DiscreteBound.lean`、`Sector44Quantization.lean` 和
`Sector44LowerBound.lean`。非弧型数据和各个根证书另拆为
`Sector44NonarcGraph.lean` 及 12 个 `Sector44NonarcRoot*.lean` 模块，
另有 `Sector44NonarcData.lean` 和 12 个 `Sector44NonarcChecks*.lean`，
各检查 44 行而非一次检查整个 528×528 的图，共 33 个新增模块。
独立模块保存已通过的检查，顺序核验限制内存占用。
取整与复平面转移沿用本项目此前 26 扇区的
证明模式，重新代入并核验精确常数，不靠浮点近似。

内存受限时，先顺序构建有限证书（已准备好 README 指定的环境和依赖）：

```sh
python3 scripts/build_sector44_certificate.py
```

原工作区可加 `--lake ./scripts/lake.sh`。这只改变编译顺序，不绕过任何检查。
随后原工作区的必需验证命令：

```sh
./scripts/lake.sh build
./scripts/lake.sh env lean Prize/Audit.lean
```

发布归档的环境准备和直接 lake 命令见其 README。普通构建不必重新运行生成器。

## 来源和未完成范围

原题、经典分类以及 17 点目标 140° 来自 Sendov，
*Minimax of the angles in a plane configuration of points*，Acta Mathematica
Hungarica 69 (1995), 27–46，[DOI](https://doi.org/10.1007/BF01874605)，
[公开馆藏](https://real-j.mtak.hu/7467/)。原文访问及论证复核范围见
`jsp404-english-source.md`、`jsp404-proof-map.md`。
本轮沿用 `jsp404-sector26-bound.md` 的方向类型框架，增加经过检查的支配约简
以压缩更细划分的证书。标准平面等距转换也用于此前注明来源的
`SendovDirectionModel` 接口。新证书不引用九点或十一点的外部有限证书。

不声称数学新发现、首次形式化或他人尚未解决；本轮没有重新进行外部文献检索。
140° 精确值与完整 SendovClaim 仍未证明。
