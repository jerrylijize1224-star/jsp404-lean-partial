import Prize.JSP404.Sector62ArcCertificate
import Prize.JSP404.Sector62NonarcCertificate
import Mathlib.Data.Finset.Sum
import Mathlib.Data.Fintype.Sum

/-! Capacity 16 for an antipodal 62-sector assignment. The transfer from actual
Euclidean directions is a separate obligation, not an assumption hidden here. -/
namespace Prize.JSP404.FiniteCliqueCertificate.Sector62

abbrev Kind := Sector62Nonarc.Vertex ⊕ Sector62Arc.Vertex

def labels : Kind → List Sector
  | .inl i => Sector62Nonarc.labels i
  | .inr i => Sector62Arc.labels i

def kindGraph (i j : Kind) : Bool :=
  decide (i ≠ j) && (labels i).any (fun b => (labels j).contains (antipode b))

set_option maxRecDepth 65536
set_option maxHeartbeats 0

/-- Explicit witnesses in the order of `Sector62.allTypes`; the equality below
checks every entry against the actual labels in the two families. -/
def typeWitnesses : List Kind := [.inr 0, .inr 1, .inr 2, .inr 3, .inr 4, .inr 5, .inr 6, .inr 7, .inr 8, .inr 9, .inr 10, .inr 11, .inr 12, .inr 13, .inl 0, .inr 14, .inl 1, .inl 2, .inl 3, .inr 15, .inl 4, .inl 5, .inl 6, .inl 7, .inl 8, .inl 9, .inr 16, .inl 10, .inl 11, .inl 12, .inl 13, .inl 14, .inl 15, .inl 16, .inl 17, .inl 18, .inl 19, .inr 17, .inl 20, .inl 21, .inl 22, .inl 23, .inl 24, .inl 25, .inl 26, .inl 27, .inl 28, .inl 29, .inl 30, .inl 31, .inl 32, .inl 33, .inl 34, .inr 18, .inl 35, .inl 36, .inl 37, .inl 38, .inl 39, .inl 40, .inl 41, .inl 42, .inl 43, .inl 44, .inl 45, .inl 46, .inl 47, .inl 48, .inl 49, .inl 50, .inl 51, .inl 52, .inl 53, .inl 54, .inl 55, .inr 19, .inl 56, .inl 57, .inl 58, .inl 59, .inl 60, .inl 61, .inl 62, .inl 63, .inl 64, .inl 65, .inl 66, .inl 67, .inl 68, .inl 69, .inl 70, .inl 71, .inl 72, .inl 73, .inl 74, .inl 75, .inl 76, .inl 77, .inl 78, .inl 79, .inl 80, .inl 81, .inl 82, .inl 83, .inr 20, .inl 84, .inl 85, .inl 86, .inl 87, .inl 88, .inl 89, .inl 90, .inl 91, .inl 92, .inl 93, .inl 94, .inl 95, .inl 96, .inl 97, .inl 98, .inl 99, .inl 100, .inl 101, .inl 102, .inl 103, .inl 104, .inl 105, .inl 106, .inl 107, .inl 108, .inl 109, .inl 110, .inl 111, .inl 112, .inl 113, .inl 114, .inl 115, .inl 116, .inl 117, .inl 118, .inl 119, .inr 21, .inl 120, .inl 121, .inl 122, .inl 123, .inl 124, .inl 125, .inl 126, .inl 127, .inl 128, .inl 129, .inl 130, .inl 131, .inl 132, .inl 133, .inl 134, .inl 135, .inl 136, .inl 137, .inl 138, .inl 139, .inl 140, .inl 141, .inl 142, .inl 143, .inl 144, .inl 145, .inl 146, .inl 147, .inl 148, .inl 149, .inl 150, .inl 151, .inl 152, .inl 153, .inl 154, .inl 155, .inl 156, .inl 157, .inl 158, .inl 159, .inl 160, .inl 161, .inl 162, .inl 163, .inl 164, .inr 22, .inl 165, .inl 166, .inl 167, .inl 168, .inl 169, .inl 170, .inl 171, .inl 172, .inl 173, .inl 174, .inl 175, .inl 176, .inl 177, .inl 178, .inl 179, .inl 180, .inl 181, .inl 182, .inl 183, .inl 184, .inl 185, .inl 186, .inl 187, .inl 188, .inl 189, .inl 190, .inl 191, .inl 192, .inl 193, .inl 194, .inl 195, .inl 196, .inl 197, .inl 198, .inl 199, .inl 200, .inl 201, .inl 202, .inl 203, .inl 204, .inl 205, .inl 206, .inl 207, .inl 208, .inl 209, .inl 210, .inl 211, .inl 212, .inl 213, .inl 214, .inl 215, .inl 216, .inl 217, .inl 218, .inl 219, .inr 23, .inl 220, .inl 221, .inl 222, .inl 223, .inl 224, .inl 225, .inl 226, .inl 227, .inl 228, .inl 229, .inl 230, .inl 231, .inl 232, .inl 233, .inl 234, .inl 235, .inl 236, .inl 237, .inl 238, .inl 239, .inl 240, .inl 241, .inl 242, .inl 243, .inl 244, .inl 245, .inl 246, .inl 247, .inl 248, .inl 249, .inl 250, .inl 251, .inl 252, .inl 253, .inl 254, .inl 255, .inl 256, .inl 257, .inl 258, .inl 259, .inl 260, .inl 261, .inl 262, .inl 263, .inl 264, .inl 265, .inl 266, .inl 267, .inl 268, .inl 269, .inl 270, .inl 271, .inl 272, .inl 273, .inl 274, .inl 275, .inl 276, .inl 277, .inl 278, .inl 279, .inl 280, .inl 281, .inl 282, .inl 283, .inl 284, .inl 285, .inr 24, .inl 286, .inl 287, .inl 288, .inl 289, .inl 290, .inl 291, .inl 292, .inl 293, .inl 294, .inl 295, .inl 296, .inl 297, .inl 298, .inl 299, .inl 300, .inl 301, .inl 302, .inl 303, .inl 304, .inl 305, .inl 306, .inl 307, .inl 308, .inl 309, .inl 310, .inl 311, .inl 312, .inl 313, .inl 314, .inl 315, .inl 316, .inl 317, .inl 318, .inl 319, .inl 320, .inl 321, .inl 322, .inl 323, .inl 324, .inl 325, .inl 326, .inl 327, .inl 328, .inl 329, .inl 330, .inl 331, .inl 332, .inl 333, .inl 334, .inl 335, .inl 336, .inl 337, .inl 338, .inl 339, .inl 340, .inl 341, .inl 342, .inl 343, .inl 344, .inl 345, .inl 346, .inl 347, .inl 348, .inl 349, .inl 350, .inl 351, .inr 25, .inl 352, .inl 353, .inl 354, .inl 355, .inl 356, .inl 357, .inl 358, .inl 359, .inl 360, .inl 361, .inl 362, .inl 363, .inl 364, .inl 365, .inl 366, .inl 367, .inl 368, .inl 369, .inl 370, .inl 371, .inl 372, .inl 373, .inl 374, .inl 375, .inl 376, .inl 377, .inl 378, .inl 379, .inl 380, .inl 381, .inl 382, .inl 383, .inl 384, .inl 385, .inl 386, .inl 387, .inl 388, .inl 389, .inl 390, .inl 391, .inl 392, .inl 393, .inl 394, .inl 395, .inl 396, .inl 397, .inl 398, .inl 399, .inl 400, .inl 401, .inl 402, .inl 403, .inl 404, .inl 405, .inl 406, .inl 407, .inl 408, .inl 409, .inl 410, .inl 411, .inl 412, .inl 413, .inl 414, .inl 415, .inl 416, .inl 417, .inr 26, .inl 418, .inl 419, .inl 420, .inl 421, .inl 422, .inl 423, .inl 424, .inl 425, .inl 426, .inl 427, .inl 428, .inl 429, .inl 430, .inl 431, .inl 432, .inl 433, .inl 434, .inl 435, .inl 436, .inl 437, .inl 438, .inl 439, .inl 440, .inl 441, .inl 442, .inl 443, .inl 444, .inl 445, .inl 446, .inl 447, .inl 448, .inl 449, .inl 450, .inl 451, .inl 452, .inl 453, .inl 454, .inl 455, .inl 456, .inl 457, .inl 458, .inl 459, .inl 460, .inl 461, .inl 462, .inl 463, .inl 464, .inl 465, .inl 466, .inl 467, .inl 468, .inl 469, .inl 470, .inl 471, .inl 472, .inl 473, .inl 474, .inl 475, .inl 476, .inl 477, .inl 478, .inl 479, .inl 480, .inl 481, .inl 482, .inl 483, .inr 27, .inl 484, .inl 485, .inl 486, .inl 487, .inl 488, .inl 489, .inl 490, .inl 491, .inl 492, .inl 493, .inl 494, .inl 495, .inl 496, .inl 497, .inl 498, .inl 499, .inl 500, .inl 501, .inl 502, .inl 503, .inl 504, .inl 505, .inl 506, .inl 507, .inl 508, .inl 509, .inl 510, .inl 511, .inl 512, .inl 513, .inl 514, .inl 515, .inl 516, .inl 517, .inl 518, .inl 519, .inl 520, .inl 521, .inl 522, .inl 523, .inl 524, .inl 525, .inl 526, .inl 527, .inl 528, .inl 529, .inl 530, .inl 531, .inl 532, .inl 533, .inl 534, .inl 535, .inl 536, .inl 537, .inl 538, .inl 539, .inl 540, .inl 541, .inl 542, .inl 543, .inl 544, .inl 545, .inl 546, .inl 547, .inl 548, .inl 549, .inr 28, .inl 550, .inl 551, .inl 552, .inl 553, .inl 554, .inl 555, .inl 556, .inl 557, .inl 558, .inl 559, .inl 560, .inl 561, .inl 562, .inl 563, .inl 564, .inl 565, .inl 566, .inl 567, .inl 568, .inl 569, .inl 570, .inl 571, .inl 572, .inl 573, .inl 574, .inl 575, .inl 576, .inl 577, .inl 578, .inl 579, .inl 580, .inl 581, .inl 582, .inl 583, .inl 584, .inl 585, .inl 586, .inl 587, .inl 588, .inl 589, .inl 590, .inl 591, .inl 592, .inl 593, .inl 594, .inl 595, .inl 596, .inl 597, .inl 598, .inl 599, .inl 600, .inl 601, .inl 602, .inl 603, .inl 604, .inl 605, .inl 606, .inl 607, .inl 608, .inl 609, .inl 610, .inl 611, .inl 612, .inl 613, .inl 614, .inl 615, .inr 29, .inl 616, .inl 617, .inl 618, .inl 619, .inl 620, .inl 621, .inl 622, .inl 623, .inl 624, .inl 625, .inl 626, .inl 627, .inl 628, .inl 629, .inl 630, .inl 631, .inl 632, .inl 633, .inl 634, .inl 635, .inl 636, .inl 637, .inl 638, .inl 639, .inl 640, .inl 641, .inl 642, .inl 643, .inl 644, .inl 645, .inl 646, .inl 647, .inl 648, .inl 649, .inl 650, .inl 651, .inl 652, .inl 653, .inl 654, .inl 655, .inl 656, .inl 657, .inl 658, .inl 659, .inl 660, .inl 661, .inl 662, .inl 663, .inl 664, .inl 665, .inl 666, .inl 667, .inl 668, .inl 669, .inl 670, .inl 671, .inl 672, .inl 673, .inl 674, .inl 675, .inl 676, .inl 677, .inl 678, .inl 679, .inl 680, .inl 681, .inr 30, .inl 682, .inl 683, .inl 684, .inl 685, .inl 686, .inl 687, .inl 688, .inl 689, .inl 690, .inl 691, .inl 692, .inl 693, .inl 694, .inl 695, .inl 696, .inl 697, .inl 698, .inl 699, .inl 700, .inl 701, .inl 702, .inl 703, .inl 704, .inl 705, .inl 706, .inl 707, .inl 708, .inl 709, .inl 710, .inl 711, .inl 712, .inl 713, .inl 714, .inl 715, .inl 716, .inl 717, .inl 718, .inl 719, .inl 720, .inl 721, .inl 722, .inl 723, .inl 724, .inl 725, .inl 726, .inl 727, .inl 728, .inl 729, .inl 730, .inl 731, .inl 732, .inl 733, .inl 734, .inl 735, .inl 736, .inl 737, .inl 738, .inl 739, .inl 740, .inl 741, .inl 742, .inl 743, .inl 744, .inl 745, .inl 746, .inl 747, .inr 31, .inl 748, .inl 749, .inl 750, .inl 751, .inl 752, .inl 753, .inl 754, .inl 755, .inl 756, .inl 757, .inl 758, .inl 759, .inl 760, .inl 761, .inl 762, .inl 763, .inl 764, .inl 765, .inl 766, .inl 767, .inl 768, .inl 769, .inl 770, .inl 771, .inl 772, .inl 773, .inl 774, .inl 775, .inl 776, .inl 777, .inl 778, .inl 779, .inl 780, .inl 781, .inl 782, .inl 783, .inl 784, .inl 785, .inl 786, .inl 787, .inl 788, .inl 789, .inl 790, .inl 791, .inl 792, .inl 793, .inl 794, .inl 795, .inl 796, .inl 797, .inl 798, .inl 799, .inl 800, .inl 801, .inl 802, .inl 803, .inl 804, .inl 805, .inl 806, .inl 807, .inl 808, .inl 809, .inl 810, .inl 811, .inl 812, .inl 813, .inr 32, .inl 814, .inl 815, .inl 816, .inl 817, .inl 818, .inl 819, .inl 820, .inl 821, .inl 822, .inl 823, .inl 824, .inl 825, .inl 826, .inl 827, .inl 828, .inl 829, .inl 830, .inl 831, .inl 832, .inl 833, .inl 834, .inl 835, .inl 836, .inl 837, .inl 838, .inl 839, .inl 840, .inl 841, .inl 842, .inl 843, .inl 844, .inl 845, .inl 846, .inl 847, .inl 848, .inl 849, .inl 850, .inl 851, .inl 852, .inl 853, .inl 854, .inl 855, .inl 856, .inl 857, .inl 858, .inl 859, .inl 860, .inl 861, .inl 862, .inl 863, .inl 864, .inl 865, .inl 866, .inl 867, .inl 868, .inl 869, .inl 870, .inl 871, .inl 872, .inl 873, .inl 874, .inl 875, .inl 876, .inl 877, .inl 878, .inl 879, .inr 33, .inl 880, .inl 881, .inl 882, .inl 883, .inl 884, .inl 885, .inl 886, .inl 887, .inl 888, .inl 889, .inl 890, .inl 891, .inl 892, .inl 893, .inl 894, .inl 895, .inl 896, .inl 897, .inl 898, .inl 899, .inl 900, .inl 901, .inl 902, .inl 903, .inl 904, .inl 905, .inl 906, .inl 907, .inl 908, .inl 909, .inl 910, .inl 911, .inl 912, .inl 913, .inl 914, .inl 915, .inl 916, .inl 917, .inl 918, .inl 919, .inl 920, .inl 921, .inl 922, .inl 923, .inl 924, .inl 925, .inl 926, .inl 927, .inl 928, .inl 929, .inl 930, .inl 931, .inl 932, .inl 933, .inl 934, .inl 935, .inl 936, .inl 937, .inl 938, .inl 939, .inl 940, .inl 941, .inl 942, .inl 943, .inl 944, .inl 945, .inr 34, .inl 946, .inl 947, .inl 948, .inl 949, .inl 950, .inl 951, .inl 952, .inl 953, .inl 954, .inl 955, .inl 956, .inl 957, .inl 958, .inl 959, .inl 960, .inl 961, .inl 962, .inl 963, .inl 964, .inl 965, .inl 966, .inl 967, .inl 968, .inl 969, .inl 970, .inl 971, .inl 972, .inl 973, .inl 974, .inl 975, .inl 976, .inl 977, .inl 978, .inl 979, .inl 980, .inl 981, .inl 982, .inl 983, .inl 984, .inl 985, .inl 986, .inl 987, .inl 988, .inl 989, .inl 990, .inl 991, .inl 992, .inl 993, .inl 994, .inl 995, .inl 996, .inl 997, .inl 998, .inl 999, .inl 1000, .inl 1001, .inl 1002, .inl 1003, .inl 1004, .inl 1005, .inl 1006, .inl 1007, .inl 1008, .inl 1009, .inl 1010, .inl 1011, .inr 35, .inl 1012, .inl 1013, .inl 1014, .inl 1015, .inl 1016, .inl 1017, .inl 1018, .inl 1019, .inl 1020, .inl 1021, .inl 1022, .inl 1023, .inl 1024, .inl 1025, .inl 1026, .inl 1027, .inl 1028, .inl 1029, .inl 1030, .inl 1031, .inl 1032, .inl 1033, .inl 1034, .inl 1035, .inl 1036, .inl 1037, .inl 1038, .inl 1039, .inl 1040, .inl 1041, .inl 1042, .inl 1043, .inl 1044, .inl 1045, .inl 1046, .inl 1047, .inl 1048, .inl 1049, .inl 1050, .inl 1051, .inl 1052, .inl 1053, .inl 1054, .inl 1055, .inl 1056, .inl 1057, .inl 1058, .inl 1059, .inl 1060, .inl 1061, .inl 1062, .inl 1063, .inl 1064, .inl 1065, .inl 1066, .inl 1067, .inl 1068, .inl 1069, .inl 1070, .inl 1071, .inl 1072, .inl 1073, .inl 1074, .inl 1075, .inl 1076, .inl 1077, .inr 36, .inr 37, .inl 1078, .inl 1079, .inl 1080, .inl 1081, .inl 1082, .inl 1083, .inl 1084, .inl 1085, .inl 1086, .inl 1087, .inl 1088, .inl 1089, .inl 1090, .inl 1091, .inl 1092, .inl 1093, .inl 1094, .inl 1095, .inl 1096, .inl 1097, .inl 1098, .inl 1099, .inl 1100, .inl 1101, .inl 1102, .inl 1103, .inl 1104, .inl 1105, .inl 1106, .inl 1107, .inl 1108, .inl 1109, .inl 1110, .inl 1111, .inl 1112, .inl 1113, .inl 1114, .inl 1115, .inl 1116, .inl 1117, .inl 1118, .inl 1119, .inl 1120, .inl 1121, .inl 1122, .inl 1123, .inl 1124, .inl 1125, .inl 1126, .inl 1127, .inl 1128, .inl 1129, .inl 1130, .inl 1131, .inl 1132, .inl 1133, .inl 1134, .inl 1135, .inl 1136, .inl 1137, .inl 1138, .inl 1139, .inl 1140, .inl 1141, .inl 1142, .inl 1143, .inr 38, .inl 1144, .inl 1145, .inl 1146, .inl 1147, .inl 1148, .inl 1149, .inl 1150, .inl 1151, .inl 1152, .inl 1153, .inl 1154, .inl 1155, .inl 1156, .inl 1157, .inl 1158, .inl 1159, .inl 1160, .inl 1161, .inl 1162, .inl 1163, .inl 1164, .inl 1165, .inl 1166, .inl 1167, .inl 1168, .inl 1169, .inl 1170, .inl 1171, .inl 1172, .inl 1173, .inl 1174, .inl 1175, .inl 1176, .inl 1177, .inl 1178, .inl 1179, .inl 1180, .inl 1181, .inl 1182, .inl 1183, .inl 1184, .inl 1185, .inl 1186, .inl 1187, .inl 1188, .inl 1189, .inl 1190, .inl 1191, .inl 1192, .inl 1193, .inl 1194, .inl 1195, .inl 1196, .inl 1197, .inl 1198, .inr 39, .inl 1199, .inl 1200, .inl 1201, .inl 1202, .inl 1203, .inl 1204, .inl 1205, .inl 1206, .inl 1207, .inl 1208, .inl 1209, .inl 1210, .inl 1211, .inl 1212, .inl 1213, .inl 1214, .inl 1215, .inl 1216, .inl 1217, .inl 1218, .inl 1219, .inl 1220, .inl 1221, .inl 1222, .inl 1223, .inl 1224, .inl 1225, .inl 1226, .inl 1227, .inl 1228, .inl 1229, .inl 1230, .inl 1231, .inl 1232, .inl 1233, .inl 1234, .inl 1235, .inl 1236, .inl 1237, .inl 1238, .inl 1239, .inl 1240, .inl 1241, .inl 1242, .inl 1243, .inr 40, .inl 1244, .inl 1245, .inl 1246, .inl 1247, .inl 1248, .inl 1249, .inl 1250, .inl 1251, .inl 1252, .inl 1253, .inl 1254, .inl 1255, .inl 1256, .inl 1257, .inl 1258, .inl 1259, .inl 1260, .inl 1261, .inl 1262, .inl 1263, .inl 1264, .inl 1265, .inl 1266, .inl 1267, .inl 1268, .inl 1269, .inl 1270, .inl 1271, .inl 1272, .inl 1273, .inl 1274, .inl 1275, .inl 1276, .inl 1277, .inl 1278, .inl 1279, .inr 41, .inl 1280, .inl 1281, .inl 1282, .inl 1283, .inl 1284, .inl 1285, .inl 1286, .inl 1287, .inl 1288, .inl 1289, .inl 1290, .inl 1291, .inl 1292, .inl 1293, .inl 1294, .inl 1295, .inl 1296, .inl 1297, .inl 1298, .inl 1299, .inl 1300, .inl 1301, .inl 1302, .inl 1303, .inl 1304, .inl 1305, .inl 1306, .inl 1307, .inr 42, .inl 1308, .inl 1309, .inl 1310, .inl 1311, .inl 1312, .inl 1313, .inl 1314, .inl 1315, .inl 1316, .inl 1317, .inl 1318, .inl 1319, .inl 1320, .inl 1321, .inl 1322, .inl 1323, .inl 1324, .inl 1325, .inl 1326, .inl 1327, .inl 1328, .inr 43, .inl 1329, .inl 1330, .inl 1331, .inl 1332, .inl 1333, .inl 1334, .inl 1335, .inl 1336, .inl 1337, .inl 1338, .inl 1339, .inl 1340, .inl 1341, .inl 1342, .inl 1343, .inr 44, .inl 1344, .inl 1345, .inl 1346, .inl 1347, .inl 1348, .inl 1349, .inl 1350, .inl 1351, .inl 1352, .inl 1353, .inr 45, .inl 1354, .inl 1355, .inl 1356, .inl 1357, .inl 1358, .inl 1359, .inr 46, .inl 1360, .inl 1361, .inl 1362, .inr 47, .inl 1363, .inr 48, .inr 49, .inr 50, .inr 51, .inr 52, .inr 53, .inr 54, .inr 55, .inr 56, .inr 57, .inr 58, .inr 59, .inr 60, .inr 61]

theorem types_classified : ∀ T ∈ allTypes, ∃ i : Kind, labels i = T := by
  have h : typeWitnesses.map labels = allTypes := by decide +kernel
  intro T hT
  rw [← h] at hT
  obtain ⟨i, _, hi⟩ := List.mem_map.mp hT
  exact ⟨i, hi⟩

theorem kind_clique_card_le_sixteen (s : Finset Kind) (hs : Clique kindGraph s) :
    s.card ≤ 16 := by
  have hl : Clique Sector62Nonarc.graph s.toLeft := by
    intro a ha b hb hab
    have h := hs (.inl a) (Finset.mem_toLeft.mp ha) (.inl b) (Finset.mem_toLeft.mp hb)
      (fun he => hab (Sum.inl.inj he))
    rw [Sector62Nonarc.graph_correct]
    simpa [kindGraph, labels] using h
  have hr : Clique Sector62Arc.graph s.toRight := by
    intro a ha b hb hab
    have h := hs (.inr a) (Finset.mem_toRight.mp ha) (.inr b) (Finset.mem_toRight.mp hb)
      (fun he => hab (Sum.inr.inj he))
    rw [Sector62Arc.graph_correct]
    simpa [kindGraph, labels] using h
  have h₁ := Sector62Nonarc.clique_card_le_eight _ hl
  have h₂ := Sector62Arc.clique_card_le_eight _ hr
  have hcard := s.card_toLeft_add_card_toRight
  omega

theorem card_le_sixteen_of_sector_assignment {V : Type*} [Fintype V]
    (q : V → V → Sector)
    (hrev : ∀ u v, u ≠ v → q v u = antipode (q u v))
    (hsmall : ∀ v u w, v ≠ u → v ≠ w → u ≠ w →
      circularDistance (q v u) (q v w) ≤ 24) : Fintype.card V ≤ 16 := by
  classical
  let outgoing (v : V) : Finset Sector := (Finset.univ.erase v).image (q v)
  have ho (v : V) : Clique sectorGraph (outgoing v) := by
    intro a ha b hb hab
    obtain ⟨u, hu, rfl⟩ := Finset.mem_image.mp ha
    obtain ⟨w, hw, rfl⟩ := Finset.mem_image.mp hb
    have huv : u ≠ v := (Finset.mem_erase.mp hu).1
    have hwv : w ≠ v := (Finset.mem_erase.mp hw).1
    have huw : u ≠ w := fun he => hab (congrArg (q v) he)
    simpa [sectorGraph, hab] using hsmall v u w (Ne.symm huv) hwv.symm huw
  have hex (v : V) : ∃ i : Kind, labels i ∈ allTypes ∧
      ∀ w, w ≠ v → q v w ∈ labels i := by
    obtain ⟨T, hT, hc⟩ := allTypes_cover (outgoing v) (by simp) (ho v)
    obtain ⟨i, hi⟩ := types_classified T hT
    refine ⟨i, hi ▸ hT, ?_⟩
    intro w hw
    rw [hi]
    exact hc _ (Finset.mem_image.mpr ⟨w, by simp [hw], rfl⟩)
  let t : V → Kind := fun v => Classical.choose (hex v)
  have ht (v : V) : labels (t v) ∈ allTypes ∧ ∀ w, w ≠ v → q v w ∈ labels (t v) :=
    Classical.choose_spec (hex v)
  have hi : Function.Injective t := by
    intro u v he
    by_contra huv
    have h₁ := (ht u).2 v (Ne.symm huv)
    have h₂ := (ht v).2 u huv
    rw [hrev u v huv, ← he] at h₂
    exact allTypes_no_antipodes _ (ht u).1 _ h₁ h₂
  let s : Finset Kind := Finset.univ.image t
  have hs : Clique kindGraph s := by
    intro a ha b hb hab
    obtain ⟨u, hu, rfl⟩ := Finset.mem_image.mp ha
    obtain ⟨v, hv, rfl⟩ := Finset.mem_image.mp hb
    have huv : u ≠ v := fun he => hab (congrArg t he)
    have h₁ := (ht u).2 v (Ne.symm huv)
    have h₂ := (ht v).2 u huv
    rw [hrev u v huv] at h₂
    simp only [kindGraph, ne_eq, hab, not_false_eq_true, decide_true, Bool.true_and,
      List.any_eq_true]
    exact ⟨q u v, h₁, by simpa using h₂⟩
  have hc : s.card = Fintype.card V := by
    simpa [s] using Finset.card_image_of_injective (Finset.univ : Finset V) hi
  rw [← hc]
  exact kind_clique_card_le_sixteen s hs

end Prize.JSP404.FiniteCliqueCertificate.Sector62
