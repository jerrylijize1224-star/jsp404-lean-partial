import Prize.JSP404.SeventeenTwentyExact
import Mathlib.Geometry.Euclidean.Triangle

/-!
# Necessary triangle constraints for continuous directions

The pairwise arc model forgets that three edge vectors are differences of
three points. This module recovers the resulting orientation constraint.
It does not assert that these necessary constraints suffice for realizability.
-/

namespace Prize.JSP404

namespace ContinuousDirection

/-- A strictly positive turn of less than a half-circle, with period 18. -/
def PositiveTurn (x y : ℝ) : Prop :=
  ∃ k : ℤ, 0 < y - x + 18 * k ∧ y - x + 18 * k < 9

/-- Directions of the edges i→j, i→k, j→k of a noncollinear triangle. -/
def TriangleCompatible (u v w : ℝ) : Prop :=
  (PositiveTurn u v ∧ PositiveTurn u w ∧ PositiveTurn v w) ∨
  (PositiveTurn v u ∧ PositiveTurn w u ∧ PositiveTurn w v)

theorem positiveTurn_translate {x y : ℝ} (h : PositiveTurn x y) (a b : ℤ) :
    PositiveTurn (x + 18 * a) (y + 18 * b) := by
  obtain ⟨k, hk⟩ := h
  refine ⟨k + a - b, ?_⟩
  have he : y + 18 * b - (x + 18 * a) + 18 * ((k + a - b : ℤ) : ℝ) =
      y - x + 18 * k := by push_cast; ring
  simpa only [he] using hk

theorem triangleCompatible_translate {u v w : ℝ} (h : TriangleCompatible u v w)
    (a b c : ℤ) : TriangleCompatible (u + 18 * a) (v + 18 * b) (w + 18 * c) := by
  rcases h with h | h
  · exact Or.inl ⟨positiveTurn_translate h.1 a b,
      positiveTurn_translate h.2.1 a c, positiveTurn_translate h.2.2 b c⟩
  · exact Or.inr ⟨positiveTurn_translate h.1 b a,
      positiveTurn_translate h.2.1 c a, positiveTurn_translate h.2.2 c b⟩

theorem positiveTurn_iff_of_normalized {x y : ℝ}
    (hx : 0 ≤ x ∧ x < 18) (hy : 0 ≤ y ∧ y < 18) :
    PositiveTurn x y ↔ (0 < y - x ∧ y - x < 9) ∨
      (-18 < y - x ∧ y - x < -9) := by
  constructor
  · rintro ⟨k, hk⟩
    have hk0 : 0 ≤ k := by
      by_contra h
      have h' : (k : ℝ) ≤ -1 := by exact_mod_cast (show k ≤ -1 by omega)
      linarith [hx.1, hy.2]
    have hk1 : k ≤ 1 := by
      by_contra h
      have h' : (2 : ℝ) ≤ k := by exact_mod_cast (show 2 ≤ k by omega)
      linarith [hx.2, hy.1]
    interval_cases k <;> norm_num at hk
    · exact Or.inl ⟨by linarith [hk.1], hk.2⟩
    · exact Or.inr ⟨by linarith [hx.2, hy.1], by linarith [hk.2]⟩
  · rintro (h | h)
    · exact ⟨0, by simpa using h⟩
    · refine ⟨1, ?_⟩
      norm_num
      constructor <;> linarith

end ContinuousDirection

/-- The real determinant of two complex vectors. -/
def directionDet (u v : ℂ) : ℝ := u.re * v.im - u.im * v.re

theorem directionDet_swap (u v : ℂ) : directionDet v u = -directionDet u v := by
  unfold directionDet
  ring

theorem directionDet_triangle (a b c : ℂ) :
    directionDet (b - a) (c - a) = directionDet (b - a) (c - b) ∧
    directionDet (b - a) (c - a) = directionDet (c - a) (c - b) := by
  simp only [directionDet, Complex.sub_re, Complex.sub_im]
  constructor <;> ring

theorem div_im_eq_directionDet (u v : ℂ) :
    (v / u).im = directionDet u v / Complex.normSq u := by
  rw [Complex.div_im]
  unfold directionDet
  ring

theorem positiveTurn_scaledArg_of_det_pos {u v : ℂ} (h : 0 < directionDet u v) :
    ContinuousDirection.PositiveTurn (scaledArg u) (scaledArg v) := by
  have hu : u ≠ 0 := by intro he; simp [he, directionDet] at h
  have hv : v ≠ 0 := by intro he; simp [he, directionDet] at h
  have him : 0 < (v / u).im := by
    rw [div_im_eq_directionDet]
    exact div_pos h (Complex.normSq_pos.mpr hu)
  have ha0 : 0 < (v / u).arg := by
    have hn := Complex.arg_nonneg_iff.mpr him.le
    have hne : (v / u).arg ≠ 0 := by
      intro he
      exact (ne_of_gt him) (Complex.arg_eq_zero_iff.mp he).2
    exact lt_of_le_of_ne hn (Ne.symm hne)
  have hapi : (v / u).arg < Real.pi :=
    Complex.arg_lt_pi_iff.mpr (Or.inr (ne_of_gt him))
  have he : (v.arg : Real.Angle) = ((u.arg + (v / u).arg : ℝ) : Real.Angle) := by
    rw [Real.Angle.coe_add, Complex.arg_div_coe_angle hv hu]
    abel
  obtain ⟨k, hk⟩ := Real.Angle.angle_eq_iff_two_pi_dvd_sub.mp he
  have hgap : scaledArg v - scaledArg u + 18 * ((-k : ℤ) : ℝ) =
      9 * (v / u).arg / Real.pi := by
    unfold scaledArg
    push_cast
    field_simp
    nlinarith
  refine ⟨-k, ?_⟩
  rw [hgap]
  constructor
  · exact div_pos (mul_pos (by norm_num) ha0) Real.pi_pos
  · apply (div_lt_iff₀ Real.pi_pos).mpr
    linarith

theorem triangleCompatible_scaledArg_of_det_ne_zero {a b c : ℂ}
    (h : directionDet (b - a) (c - a) ≠ 0) :
    ContinuousDirection.TriangleCompatible
      (scaledArg (b - a)) (scaledArg (c - a)) (scaledArg (c - b)) := by
  obtain ⟨h₁, h₂⟩ := directionDet_triangle a b c
  rcases lt_or_gt_of_ne h with hn | hp
  · right
    refine ⟨positiveTurn_scaledArg_of_det_pos ?_,
      positiveTurn_scaledArg_of_det_pos ?_, positiveTurn_scaledArg_of_det_pos ?_⟩
    · rw [directionDet_swap]; linarith
    · rw [directionDet_swap, ← h₁]; linarith
    · rw [directionDet_swap, ← h₂]; linarith
  · left
    exact ⟨positiveTurn_scaledArg_of_det_pos hp,
      positiveTurn_scaledArg_of_det_pos (by linarith),
      positiveTurn_scaledArg_of_det_pos (by linarith)⟩

theorem angle_zero_of_det_zero_of_lt_pi {u v : ℂ} (hu : u ≠ 0) (hv : v ≠ 0)
    (hdet : directionDet u v = 0) (hangle : InnerProductGeometry.angle u v < Real.pi) :
    InnerProductGeometry.angle u v = 0 := by
  have him : (u / v).im = 0 := by
    rw [div_im_eq_directionDet, directionDet_swap, hdet]
    simp
  rw [Complex.angle_eq_abs_arg hu hv] at hangle ⊢
  by_cases hr : 0 ≤ (u / v).re
  · rw [Complex.arg_eq_zero_iff.mpr ⟨hr, him⟩, abs_zero]
  · have he := Complex.arg_eq_pi_iff.mpr ⟨lt_of_not_ge hr, him⟩
    rw [he, abs_of_pos Real.pi_pos] at hangle
    exact (lt_irrefl _ hangle).elim

/-- No general-position assumption is added: three angles strictly below pi
already force a nonzero determinant. -/
theorem directionDet_ne_zero_of_angles_lt_pi {a b c : ℂ}
    (hab : a ≠ b) (hac : a ≠ c) (hbc : b ≠ c)
    (ha : EuclideanGeometry.angle b a c < Real.pi)
    (hb : EuclideanGeometry.angle a b c < Real.pi)
    (hc : EuclideanGeometry.angle a c b < Real.pi) :
    directionDet (b - a) (c - a) ≠ 0 := by
  intro he
  have heB : directionDet (a - b) (c - b) = 0 := by
    simp only [directionDet, Complex.sub_re, Complex.sub_im] at he ⊢
    nlinarith
  have heC : directionDet (a - c) (b - c) = 0 := by
    simp only [directionDet, Complex.sub_re, Complex.sub_im] at he ⊢
    nlinarith
  have ha0 := angle_zero_of_det_zero_of_lt_pi
    (sub_ne_zero.mpr hab.symm) (sub_ne_zero.mpr hac.symm) he ha
  have hb0 := angle_zero_of_det_zero_of_lt_pi
    (sub_ne_zero.mpr hab) (sub_ne_zero.mpr hbc.symm) heB hb
  have hc0 := angle_zero_of_det_zero_of_lt_pi
    (sub_ne_zero.mpr hac) (sub_ne_zero.mpr hbc) heC hc
  have hsum := EuclideanGeometry.angle_add_angle_add_angle_eq_pi c hab.symm
  change EuclideanGeometry.angle b a c = 0 at ha0
  change EuclideanGeometry.angle a b c = 0 at hb0
  change EuclideanGeometry.angle a c b = 0 at hc0
  rw [EuclideanGeometry.angle_comm b c a, EuclideanGeometry.angle_comm c a b] at hsum
  linarith [Real.pi_pos]

theorem triangleCompatible_of_complex_angles_lt_pi {a b c : ℂ}
    (hab : a ≠ b) (hac : a ≠ c) (hbc : b ≠ c)
    (ha : EuclideanGeometry.angle b a c < Real.pi)
    (hb : EuclideanGeometry.angle a b c < Real.pi)
    (hc : EuclideanGeometry.angle a c b < Real.pi) :
    ContinuousDirection.TriangleCompatible
      (scaledArg (b - a)) (scaledArg (c - a)) (scaledArg (c - b)) :=
  triangleCompatible_scaledArg_of_det_ne_zero
    (directionDet_ne_zero_of_angles_lt_pi hab hac hbc ha hb hc)

/-- The unique direction representative in [0,18). -/
noncomputable def normalizedDirection (z : ℂ) : ℝ :=
  scaledArg z - 18 * (⌊scaledArg z / 18⌋ : ℤ)

theorem normalizedDirection_bounds (z : ℂ) :
    0 ≤ normalizedDirection z ∧ normalizedDirection z < 18 := by
  have hlo := Int.floor_le (scaledArg z / 18)
  have hhi := Int.lt_floor_add_one (scaledArg z / 18)
  unfold normalizedDirection
  constructor <;> linarith

theorem triangleCompatible_normalizedDirection {a b c : ℂ}
    (hab : a ≠ b) (hac : a ≠ c) (hbc : b ≠ c)
    (ha : EuclideanGeometry.angle b a c < Real.pi)
    (hb : EuclideanGeometry.angle a b c < Real.pi)
    (hc : EuclideanGeometry.angle a c b < Real.pi) :
    ContinuousDirection.TriangleCompatible
      (normalizedDirection (b - a)) (normalizedDirection (c - a))
      (normalizedDirection (c - b)) := by
  have h := ContinuousDirection.triangleCompatible_translate
    (triangleCompatible_of_complex_angles_lt_pi hab hac hbc ha hb hc)
    (-⌊scaledArg (b - a) / 18⌋) (-⌊scaledArg (c - a) / 18⌋)
    (-⌊scaledArg (c - b) / 18⌋)
  simpa [normalizedDirection, sub_eq_add_neg] using h

end Prize.JSP404
