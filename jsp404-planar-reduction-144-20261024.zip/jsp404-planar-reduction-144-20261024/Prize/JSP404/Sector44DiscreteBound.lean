import Prize.JSP404.Sector44ArcCertificate
import Prize.JSP404.Sector44NonarcCertificate
import Mathlib.Data.Finset.Sum
import Mathlib.Data.Fintype.Sum

/-! Capacity 16 for an antipodal 44-sector assignment. The transfer from actual
Euclidean directions is a separate obligation, not an assumption hidden here. -/
namespace Prize.JSP404.FiniteCliqueCertificate.Sector44

abbrev Kind := Sector44Nonarc.Vertex ⊕ Sector44Arc.Vertex

def labels : Kind → List Sector
  | .inl i => Sector44Nonarc.labels i
  | .inr i => Sector44Arc.labels i

def kindGraph (i j : Kind) : Bool :=
  decide (i ≠ j) && (labels i).any (fun b => (labels j).contains (antipode b))

set_option maxRecDepth 65536
set_option maxHeartbeats 0

/-- Explicit witnesses in the order of `Sector44.allTypes`; the equality below
checks every entry against the actual labels in the two families. -/
def typeWitnesses : List Kind := [.inr 0, .inr 1, .inr 2, .inr 3, .inr 4, .inr 5, .inr 6, .inr 7, .inr 8, .inr 9, .inl 0, .inr 10, .inl 1, .inl 2, .inl 3, .inr 11, .inl 4, .inl 5, .inl 6, .inl 7, .inl 8, .inl 9, .inr 12, .inl 10, .inl 11, .inl 12, .inl 13, .inl 14, .inl 15, .inl 16, .inl 17, .inl 18, .inl 19, .inr 13, .inl 20, .inl 21, .inl 22, .inl 23, .inl 24, .inl 25, .inl 26, .inl 27, .inl 28, .inl 29, .inl 30, .inl 31, .inl 32, .inl 33, .inl 34, .inr 14, .inl 35, .inl 36, .inl 37, .inl 38, .inl 39, .inl 40, .inl 41, .inl 42, .inl 43, .inl 44, .inl 45, .inl 46, .inl 47, .inl 48, .inl 49, .inl 50, .inl 51, .inl 52, .inl 53, .inl 54, .inl 55, .inr 15, .inl 56, .inl 57, .inl 58, .inl 59, .inl 60, .inl 61, .inl 62, .inl 63, .inl 64, .inl 65, .inl 66, .inl 67, .inl 68, .inl 69, .inl 70, .inl 71, .inl 72, .inl 73, .inl 74, .inl 75, .inl 76, .inl 77, .inl 78, .inl 79, .inl 80, .inl 81, .inl 82, .inl 83, .inr 16, .inl 84, .inl 85, .inl 86, .inl 87, .inl 88, .inl 89, .inl 90, .inl 91, .inl 92, .inl 93, .inl 94, .inl 95, .inl 96, .inl 97, .inl 98, .inl 99, .inl 100, .inl 101, .inl 102, .inl 103, .inl 104, .inl 105, .inl 106, .inl 107, .inl 108, .inl 109, .inl 110, .inl 111, .inl 112, .inl 113, .inl 114, .inl 115, .inl 116, .inl 117, .inl 118, .inl 119, .inr 17, .inl 120, .inl 121, .inl 122, .inl 123, .inl 124, .inl 125, .inl 126, .inl 127, .inl 128, .inl 129, .inl 130, .inl 131, .inl 132, .inl 133, .inl 134, .inl 135, .inl 136, .inl 137, .inl 138, .inl 139, .inl 140, .inl 141, .inl 142, .inl 143, .inl 144, .inl 145, .inl 146, .inl 147, .inl 148, .inl 149, .inl 150, .inl 151, .inl 152, .inl 153, .inl 154, .inl 155, .inr 18, .inl 156, .inl 157, .inl 158, .inl 159, .inl 160, .inl 161, .inl 162, .inl 163, .inl 164, .inl 165, .inl 166, .inl 167, .inl 168, .inl 169, .inl 170, .inl 171, .inl 172, .inl 173, .inl 174, .inl 175, .inl 176, .inl 177, .inl 178, .inl 179, .inl 180, .inl 181, .inl 182, .inl 183, .inl 184, .inl 185, .inl 186, .inl 187, .inl 188, .inl 189, .inl 190, .inl 191, .inr 19, .inl 192, .inl 193, .inl 194, .inl 195, .inl 196, .inl 197, .inl 198, .inl 199, .inl 200, .inl 201, .inl 202, .inl 203, .inl 204, .inl 205, .inl 206, .inl 207, .inl 208, .inl 209, .inl 210, .inl 211, .inl 212, .inl 213, .inl 214, .inl 215, .inl 216, .inl 217, .inl 218, .inl 219, .inl 220, .inl 221, .inl 222, .inl 223, .inl 224, .inl 225, .inl 226, .inl 227, .inr 20, .inl 228, .inl 229, .inl 230, .inl 231, .inl 232, .inl 233, .inl 234, .inl 235, .inl 236, .inl 237, .inl 238, .inl 239, .inl 240, .inl 241, .inl 242, .inl 243, .inl 244, .inl 245, .inl 246, .inl 247, .inl 248, .inl 249, .inl 250, .inl 251, .inl 252, .inl 253, .inl 254, .inl 255, .inl 256, .inl 257, .inl 258, .inl 259, .inl 260, .inl 261, .inl 262, .inl 263, .inr 21, .inl 264, .inl 265, .inl 266, .inl 267, .inl 268, .inl 269, .inl 270, .inl 271, .inl 272, .inl 273, .inl 274, .inl 275, .inl 276, .inl 277, .inl 278, .inl 279, .inl 280, .inl 281, .inl 282, .inl 283, .inl 284, .inl 285, .inl 286, .inl 287, .inl 288, .inl 289, .inl 290, .inl 291, .inl 292, .inl 293, .inl 294, .inl 295, .inl 296, .inl 297, .inl 298, .inl 299, .inr 22, .inl 300, .inl 301, .inl 302, .inl 303, .inl 304, .inl 305, .inl 306, .inl 307, .inl 308, .inl 309, .inl 310, .inl 311, .inl 312, .inl 313, .inl 314, .inl 315, .inl 316, .inl 317, .inl 318, .inl 319, .inl 320, .inl 321, .inl 322, .inl 323, .inl 324, .inl 325, .inl 326, .inl 327, .inl 328, .inl 329, .inl 330, .inl 331, .inl 332, .inl 333, .inl 334, .inl 335, .inr 23, .inl 336, .inl 337, .inl 338, .inl 339, .inl 340, .inl 341, .inl 342, .inl 343, .inl 344, .inl 345, .inl 346, .inl 347, .inl 348, .inl 349, .inl 350, .inl 351, .inl 352, .inl 353, .inl 354, .inl 355, .inl 356, .inl 357, .inl 358, .inl 359, .inl 360, .inl 361, .inl 362, .inl 363, .inl 364, .inl 365, .inl 366, .inl 367, .inl 368, .inl 369, .inl 370, .inl 371, .inr 24, .inl 372, .inl 373, .inl 374, .inl 375, .inl 376, .inl 377, .inl 378, .inl 379, .inl 380, .inl 381, .inl 382, .inl 383, .inl 384, .inl 385, .inl 386, .inl 387, .inl 388, .inl 389, .inl 390, .inl 391, .inl 392, .inl 393, .inl 394, .inl 395, .inl 396, .inl 397, .inl 398, .inl 399, .inl 400, .inl 401, .inl 402, .inl 403, .inl 404, .inl 405, .inl 406, .inl 407, .inr 25, .inr 26, .inl 408, .inl 409, .inl 410, .inl 411, .inl 412, .inl 413, .inl 414, .inl 415, .inl 416, .inl 417, .inl 418, .inl 419, .inl 420, .inl 421, .inl 422, .inl 423, .inl 424, .inl 425, .inl 426, .inl 427, .inl 428, .inl 429, .inl 430, .inl 431, .inl 432, .inl 433, .inl 434, .inl 435, .inl 436, .inl 437, .inl 438, .inl 439, .inl 440, .inl 441, .inl 442, .inl 443, .inr 27, .inl 444, .inl 445, .inl 446, .inl 447, .inl 448, .inl 449, .inl 450, .inl 451, .inl 452, .inl 453, .inl 454, .inl 455, .inl 456, .inl 457, .inl 458, .inl 459, .inl 460, .inl 461, .inl 462, .inl 463, .inl 464, .inl 465, .inl 466, .inl 467, .inl 468, .inl 469, .inl 470, .inl 471, .inr 28, .inl 472, .inl 473, .inl 474, .inl 475, .inl 476, .inl 477, .inl 478, .inl 479, .inl 480, .inl 481, .inl 482, .inl 483, .inl 484, .inl 485, .inl 486, .inl 487, .inl 488, .inl 489, .inl 490, .inl 491, .inl 492, .inr 29, .inl 493, .inl 494, .inl 495, .inl 496, .inl 497, .inl 498, .inl 499, .inl 500, .inl 501, .inl 502, .inl 503, .inl 504, .inl 505, .inl 506, .inl 507, .inr 30, .inl 508, .inl 509, .inl 510, .inl 511, .inl 512, .inl 513, .inl 514, .inl 515, .inl 516, .inl 517, .inr 31, .inl 518, .inl 519, .inl 520, .inl 521, .inl 522, .inl 523, .inr 32, .inl 524, .inl 525, .inl 526, .inr 33, .inl 527, .inr 34, .inr 35, .inr 36, .inr 37, .inr 38, .inr 39, .inr 40, .inr 41, .inr 42, .inr 43]

theorem types_classified : ∀ T ∈ allTypes, ∃ i : Kind, labels i = T := by
  have h : typeWitnesses.map labels = allTypes := by decide +kernel
  intro T hT
  rw [← h] at hT
  obtain ⟨i, _, hi⟩ := List.mem_map.mp hT
  exact ⟨i, hi⟩

theorem kind_clique_card_le_sixteen (s : Finset Kind) (hs : Clique kindGraph s) :
    s.card ≤ 16 := by
  have hl : Clique Sector44Nonarc.graph s.toLeft := by
    intro a ha b hb hab
    have h := hs (.inl a) (Finset.mem_toLeft.mp ha) (.inl b) (Finset.mem_toLeft.mp hb)
      (fun he => hab (Sum.inl.inj he))
    rw [Sector44Nonarc.graph_correct]
    simpa [kindGraph, labels] using h
  have hr : Clique Sector44Arc.graph s.toRight := by
    intro a ha b hb hab
    have h := hs (.inr a) (Finset.mem_toRight.mp ha) (.inr b) (Finset.mem_toRight.mp hb)
      (fun he => hab (Sum.inr.inj he))
    rw [Sector44Arc.graph_correct]
    simpa [kindGraph, labels] using h
  have h₁ := Sector44Nonarc.clique_card_le_eight _ hl
  have h₂ := Sector44Arc.clique_card_le_eight _ hr
  have hcard := s.card_toLeft_add_card_toRight
  omega

theorem card_le_sixteen_of_sector_assignment {V : Type*} [Fintype V]
    (q : V → V → Sector)
    (hrev : ∀ u v, u ≠ v → q v u = antipode (q u v))
    (hsmall : ∀ v u w, v ≠ u → v ≠ w → u ≠ w →
      circularDistance (q v u) (q v w) ≤ 17) : Fintype.card V ≤ 16 := by
  classical
  let outgoing (v : V) : Finset Sector := (Finset.univ.erase v).image (q v)
  have ho (v : V) : Clique sectorGraph (outgoing v) := by
    intro a ha b hb hab
    obtain ⟨u, hu, rfl⟩ := Finset.mem_image.mp ha
    obtain ⟨w, hw, rfl⟩ := Finset.mem_image.mp hb
    have huv : u ≠ v := (Finset.mem_erase.mp hu).1
    have hwv : w ≠ v := (Finset.mem_erase.mp hw).1
    have huw : u ≠ w := fun he => hab (congrArg (q v) he)
    simpa [sectorGraph, hab] using hsmall v u w (Ne.symm huv) hwv.symm huw
  have hex (v : V) : ∃ i : Kind, labels i ∈ allTypes ∧
      ∀ w, w ≠ v → q v w ∈ labels i := by
    obtain ⟨T, hT, hc⟩ := allTypes_cover (outgoing v) (by simp) (ho v)
    obtain ⟨i, hi⟩ := types_classified T hT
    refine ⟨i, hi ▸ hT, ?_⟩
    intro w hw
    rw [hi]
    exact hc _ (Finset.mem_image.mpr ⟨w, by simp [hw], rfl⟩)
  let t : V → Kind := fun v => Classical.choose (hex v)
  have ht (v : V) : labels (t v) ∈ allTypes ∧ ∀ w, w ≠ v → q v w ∈ labels (t v) :=
    Classical.choose_spec (hex v)
  have hi : Function.Injective t := by
    intro u v he
    by_contra huv
    have h₁ := (ht u).2 v (Ne.symm huv)
    have h₂ := (ht v).2 u huv
    rw [hrev u v huv, ← he] at h₂
    exact allTypes_no_antipodes _ (ht u).1 _ h₁ h₂
  let s : Finset Kind := Finset.univ.image t
  have hs : Clique kindGraph s := by
    intro a ha b hb hab
    obtain ⟨u, hu, rfl⟩ := Finset.mem_image.mp ha
    obtain ⟨v, hv, rfl⟩ := Finset.mem_image.mp hb
    have huv : u ≠ v := fun he => hab (congrArg t he)
    have h₁ := (ht u).2 v (Ne.symm huv)
    have h₂ := (ht v).2 u huv
    rw [hrev u v huv] at h₂
    simp only [kindGraph, ne_eq, hab, not_false_eq_true, decide_true, Bool.true_and,
      List.any_eq_true]
    exact ⟨q u v, h₁, by simpa using h₂⟩
  have hc : s.card = Fintype.card V := by
    simpa [s] using Finset.card_image_of_injective (Finset.univ : Finset V) hi
  rw [← hc]
  exact kind_clique_card_le_sixteen s hs

end Prize.JSP404.FiniteCliqueCertificate.Sector44
