import Prize.JSP404.ContinuousOneArc144
import Prize.JSP404.TriangleDirection

/-!
# A uniform reduction of the ordinary 144-degree problem

Every finite planar configuration with all distinct-point angles below 144
degrees supplies a continuous direction model with the triangle constraints.
Every such model has at most nine selected single-arc covers, hence at least
twelve selected three-arc covers when it has at least twenty-one vertices.
The exclusion of this remaining class is NOT proved here.
-/

namespace Prize.JSP404.ContinuousDirection

structure TriangleCoverModel (V : Type*) (d : ℝ) where
  direction : V → V → ℝ
  cover : V → Cover d
  reverse : ∀ u v, u ≠ v → ∃ k : ℤ,
    direction v u = direction u v + 9 + 18 * k
  small : ∀ v u w, v ≠ u → v ≠ w → Close d (direction v u) (direction v w)
  triangle : ∀ u v w, u ≠ v → u ≠ w → v ≠ w →
    TriangleCompatible (direction u v) (direction u w) (direction v w)
  covered : ∀ u v, u ≠ v → ∃ k : ℤ, (cover u).Mem (direction u v + 18 * k)

theorem exists_covers_of_small {V : Type*} [Fintype V] {d : ℝ}
    (hd0 : 6 ≤ d) (hd : d < 36 / 5) (q : V → V → ℝ)
    (hsmall : ∀ v u w, v ≠ u → v ≠ w → Close d (q v u) (q v w)) :
    ∃ C : V → Cover d, ∀ u v, u ≠ v → ∃ k : ℤ, (C u).Mem (q u v + 18 * k) := by
  classical
  have hex (v : V) : ∃ C : Cover d, ∀ w, v ≠ w → ∃ k : ℤ, C.Mem (q v w + 18 * k) := by
    let outgoing := (Finset.univ.erase v).image (q v)
    have hc : OneArcCover d outgoing ∨ ThreeArcCover d outgoing := by
      apply classification _ hd0 hd
      intro x hx y hy
      obtain ⟨u, hu, rfl⟩ := Finset.mem_image.mp hx
      obtain ⟨w, hw, rfl⟩ := Finset.mem_image.mp hy
      exact hsmall v u w (Finset.mem_erase.mp hu).1.symm (Finset.mem_erase.mp hw).1.symm
    rcases hc with ⟨a, ha⟩ | ⟨R, hR⟩
    · refine ⟨Sum.inl a, ?_⟩
      intro w hvw
      exact ha _ (Finset.mem_image.mpr ⟨w, by simp [hvw.symm], rfl⟩)
    · refine ⟨Sum.inr R, ?_⟩
      intro w hvw
      exact hR _ (Finset.mem_image.mpr ⟨w, by simp [hvw.symm], rfl⟩)
  exact ⟨fun v => Classical.choose (hex v), fun u => Classical.choose_spec (hex u)⟩

def TriangleCoverModel.IsOne {V : Type*} {d : ℝ} (M : TriangleCoverModel V d) (v : V) : Prop :=
  ∃ a, M.cover v = Sum.inl a

noncomputable def TriangleCoverModel.threeVertices {V : Type*} [Fintype V] {d : ℝ}
    (M : TriangleCoverModel V d) : Finset V := by
  classical
  exact Finset.univ.filter (fun v => ¬ M.IsOne v)

noncomputable def TriangleCoverModel.oneVertices {V : Type*} [Fintype V] {d : ℝ}
    (M : TriangleCoverModel V d) : Finset V := by
  classical
  exact Finset.univ.filter M.IsOne

theorem TriangleCoverModel.one_card_le_nine {V : Type*} [Fintype V] {d : ℝ}
    (M : TriangleCoverModel V d) (hd0 : 0 ≤ d) (hd : d < 36 / 5) :
    M.oneVertices.card ≤ 9 := by
  classical
  let S := M.oneVertices
  let e := S.equivFin.symm
  have hex (i : Fin S.card) : M.IsOne (e i).val :=
    (Finset.mem_filter.mp (e i).property).2
  let a (i : Fin S.card) := Classical.choose (hex i)
  have ha (i : Fin S.card) : M.cover (e i).val = Sum.inl (a i) :=
    Classical.choose_spec (hex i)
  let L : ContinuousOneArc.Model S.card d := {
    start := a
    nonneg := hd0
    overlap := by
      intro i j hij
      have hne : (e i).val ≠ (e j).val := by
        intro he
        exact hij (e.injective (Subtype.ext he))
      obtain ⟨k, hk⟩ := M.covered (e i).val (e j).val hne
      obtain ⟨l, hl⟩ := M.covered (e j).val (e i).val hne.symm
      obtain ⟨z, hz⟩ := M.reverse (e i).val (e j).val hne
      rw [ha i] at hk
      rw [ha j] at hl
      change a i ≤ M.direction (e i).val (e j).val + 18 * k ∧
        M.direction (e i).val (e j).val + 18 * k ≤ a i + d at hk
      change a j ≤ M.direction (e j).val (e i).val + 18 * l ∧
        M.direction (e j).val (e i).val + 18 * l ≤ a j + d at hl
      refine ⟨k - l - z - 1, ?_, ?_⟩ <;> push_cast <;> linarith [hk.1, hk.2, hl.1, hl.2] }
  exact L.card_le_nine hd

theorem TriangleCoverModel.card_le_nine_add_three {V : Type*} [Fintype V] {d : ℝ}
    (M : TriangleCoverModel V d) (hd0 : 0 ≤ d) (hd : d < 36 / 5) :
    Fintype.card V ≤ 9 + M.threeVertices.card := by
  classical
  have h := M.one_card_le_nine hd0 hd
  have hc := Finset.card_filter_add_card_filter_not (s := (Finset.univ : Finset V)) M.IsOne
  change (Finset.univ.filter M.IsOne).card ≤ 9 at h
  change Fintype.card V ≤ 9 + (Finset.univ.filter (fun v => ¬ M.IsOne v)).card
  simp only [Finset.card_univ] at hc
  omega

theorem TriangleCoverModel.twelve_le_three_card {V : Type*} [Fintype V] {d : ℝ}
    (M : TriangleCoverModel V d) (hd0 : 0 ≤ d) (hd : d < 36 / 5)
    (hV : 21 ≤ Fintype.card V) : 12 ≤ M.threeVertices.card := by
  have := M.card_le_nine_add_three hd0 hd
  omega

end Prize.JSP404.ContinuousDirection

namespace Prize.JSP404

open ContinuousDirection

theorem exists_triangleCoverModel_of_complex_angles_lt_four_pi_fifths
    {V : Type*} [Fintype V] (p : V → ℂ) (hp : Function.Injective p)
    (hangle : ∀ u v w, u ≠ v → u ≠ w → v ≠ w →
      EuclideanGeometry.angle (p u) (p v) (p w) < 4 * Real.pi / 5) :
    ∃ d : ℝ, 6 ≤ d ∧ d < 36 / 5 ∧ Nonempty (TriangleCoverModel V d) := by
  classical
  let f (t : V × V × V) : ℝ :=
    if t.1 ≠ t.2.1 ∧ t.1 ≠ t.2.2 ∧ t.2.1 ≠ t.2.2 then
      EuclideanGeometry.angle (p t.1) (p t.2.1) (p t.2.2) else 0
  let s := insert (2 * Real.pi / 3) (Finset.univ.image f)
  have hne : s.Nonempty := ⟨2 * Real.pi / 3, Finset.mem_insert_self _ _⟩
  let A := s.max' hne
  have hAlo : 2 * Real.pi / 3 ≤ A := Finset.le_max' _ _ (Finset.mem_insert_self _ _)
  have hAhi : A < 4 * Real.pi / 5 := by
    have hmem := Finset.max'_mem s hne
    rcases Finset.mem_insert.mp hmem with h | h
    · change A = 2 * Real.pi / 3 at h
      rw [h]; linarith [Real.pi_pos]
    · obtain ⟨⟨u, v, w⟩, _, he⟩ := Finset.mem_image.mp h
      change f (u, v, w) = A at he
      rw [← he]
      dsimp [f]
      split_ifs with h
      · exact hangle u v w h.1 h.2.1 h.2.2
      · positivity
  have hAle (u v w : V) (huv : u ≠ v) (huw : u ≠ w) (hvw : v ≠ w) :
      EuclideanGeometry.angle (p u) (p v) (p w) ≤ A := by
    apply Finset.le_max' s _
    apply Finset.mem_insert_of_mem
    exact Finset.mem_image.mpr ⟨(u, v, w), Finset.mem_univ _, by simp [f, huv, huw, hvw]⟩
  let d := 9 * A / Real.pi
  have hd0 : 6 ≤ d := by
    apply (le_div_iff₀ Real.pi_pos).mpr
    linarith
  have hd : d < 36 / 5 := by
    apply (div_lt_iff₀ Real.pi_pos).mpr
    linarith
  let q (u v : V) := scaledArg (p v - p u)
  have hsmall : ∀ v u w, v ≠ u → v ≠ w → Close d (q v u) (q v w) := by
    intro v u w hvu hvw
    by_cases huw : u = w
    · subst w
      refine ⟨0, ?_⟩
      simp only [sub_self, Int.cast_zero, mul_zero, add_zero, abs_zero]
      linarith
    · apply scaledArg_close (sub_ne_zero.mpr (hp.ne hvu.symm))
        (sub_ne_zero.mpr (hp.ne hvw.symm))
      exact hAle u v w hvu.symm huw hvw
  obtain ⟨C, hC⟩ := exists_covers_of_small hd0 hd q hsmall
  refine ⟨d, hd0, hd, ⟨{
    direction := q, cover := C, small := hsmall, covered := hC
    reverse := ?_, triangle := ?_ }⟩⟩
  · intro u v huv
    change ∃ k : ℤ, scaledArg (p u - p v) = scaledArg (p v - p u) + 9 + 18 * k
    rw [show p u - p v = -(p v - p u) by abel]
    exact scaledArg_neg (sub_ne_zero.mpr (hp.ne huv.symm))
  · intro u v w huv huw hvw
    apply triangleCompatible_of_complex_angles_lt_pi (hp.ne huv) (hp.ne huw) (hp.ne hvw)
    · linarith [hangle v u w huv.symm hvw huw, Real.pi_pos]
    · linarith [hangle u v w huv huw hvw, Real.pi_pos]
    · linarith [hangle u w v huw huv hvw.symm, Real.pi_pos]

theorem exists_triangleCoverModel_of_plane_angles_lt_four_pi_fifths
    {V : Type*} [Fintype V] (p : V → Plane) (hp : Function.Injective p)
    (hangle : ∀ u v w, u ≠ v → u ≠ w → v ≠ w →
      EuclideanGeometry.angle (p u) (p v) (p w) < 4 * Real.pi / 5) :
    ∃ d : ℝ, 6 ≤ d ∧ d < 36 / 5 ∧ Nonempty (TriangleCoverModel V d) := by
  let e := Complex.orthonormalBasisOneI.repr.symm
  apply exists_triangleCoverModel_of_complex_angles_lt_four_pi_fifths
    (fun v => e (p v)) (e.injective.comp hp)
  intro u v w huv huw hvw
  change InnerProductGeometry.angle (e (p u) - e (p v)) (e (p w) - e (p v)) < _
  rw [← map_sub, ← map_sub]
  change InnerProductGeometry.angle (e.toLinearIsometry (p u - p v))
    (e.toLinearIsometry (p w - p v)) < _
  rw [e.toLinearIsometry.angle_map]
  exact hangle u v w huv huw hvw

/-- Every ordinary counterexample at 21 or more points must have twelve
three-arc covers in a triangle-consistent model. This is a necessary condition,
not an exclusion of the counterexample or an assertion of realizability. -/
theorem twelve_three_covers_of_plane_counterexample {s : Finset Plane}
    (hs : 21 ≤ s.card) (h : ¬ HasLargeAngle s (4 * Real.pi / 5)) :
    ∃ d : ℝ, ∃ M : TriangleCoverModel s d,
      6 ≤ d ∧ d < 36 / 5 ∧ 12 ≤ M.threeVertices.card := by
  classical
  have hangle : ∀ u v w : s, u ≠ v → u ≠ w → v ≠ w →
      EuclideanGeometry.angle (u : Plane) (v : Plane) (w : Plane) < 4 * Real.pi / 5 := by
    intro u v w huv huw hvw
    apply lt_of_not_ge
    intro ha
    exact h ⟨u, u.property, v, v.property, w, w.property,
      (fun he => huv (Subtype.ext he)), (fun he => huw (Subtype.ext he)),
      (fun he => hvw (Subtype.ext he)), ha⟩
  obtain ⟨d, hd0, hd, ⟨M⟩⟩ := exists_triangleCoverModel_of_plane_angles_lt_four_pi_fifths
    (fun v : s => (v : Plane)) Subtype.val_injective hangle
  exact ⟨d, M, hd0, hd, M.twelve_le_three_card (by linarith) hd (by simpa using hs)⟩

end Prize.JSP404
