import Prize.JSP404.ContinuousOneArc

/-!
# Single-arc capacity below 144 degrees

On the circle of period 18, diameter below 36/5 forces pairwise start
separation greater than 9/5. Anchored bins then give capacity at most nine.
This bounds every single-arc subfamily, not just a fixed candidate.
-/

namespace Prize.JSP404.ContinuousOneArc

theorem Model.separated_nine_fifths {n : ℕ} {d : ℝ} (M : Model n d) (hd : d < 36 / 5)
    (i j : Fin n) (hij : i ≠ j) (k : ℤ) :
    9 / 5 < |M.start i - M.start j + 18 * k| := by
  obtain ⟨z, hz₁, hz₂⟩ := M.overlap i j hij
  by_contra h
  have hab := abs_le.mp (le_of_not_gt h)
  by_cases hz : 0 ≤ z + k
  · have hz' : (0 : ℝ) ≤ (z : ℝ) + k := by exact_mod_cast hz
    linarith
  · have hz' : (z : ℝ) + k ≤ -1 := by
      have : z + k ≤ -1 := by omega
      exact_mod_cast this
    linarith

/-- Ten half-open bins and an anchor exclude the last bin, giving capacity nine. -/
theorem card_le_nine_of_separated {n : ℕ} (x : Fin n → ℝ)
    (hsep : ∀ i j, i ≠ j → ∀ k : ℤ, 9 / 5 < |x i - x j + 18 * k|) : n ≤ 9 := by
  classical
  by_cases hn : n = 0
  · omega
  let o : Fin n := ⟨0, by omega⟩
  let q (i : Fin n) : ℤ := ⌊(x i - x o) / 18⌋
  let r (i : Fin n) : ℝ := x i - x o - 18 * q i
  have hr (i : Fin n) : 0 ≤ r i ∧ r i < 18 := by
    have h₁ := Int.floor_le ((x i - x o) / 18)
    have h₂ := Int.lt_floor_add_one ((x i - x o) / 18)
    dsimp [r, q]
    constructor <;> linarith
  have hr₀ : r o = 0 := by simp [r, q]
  have hr81 (i : Fin n) : r i < 81 / 5 := by
    by_cases hi : i = o
    · subst i; rw [hr₀]; norm_num
    · have hs := hsep i o hi (-q i - 1)
      have he : x i - x o + 18 * ((-q i - 1 : ℤ) : ℝ) = r i - 18 := by
        dsimp [r]; push_cast; ring
      rw [he] at hs
      have hri := hr i
      by_contra h
      have hab : |r i - 18| ≤ 9 / 5 := by rw [abs_le]; constructor <;> linarith
      linarith
  let b (i : Fin n) : ℤ := ⌊r i / (9 / 5)⌋
  have hb (i : Fin n) : 0 ≤ b i ∧ b i < 9 := by
    have h₁ := Int.floor_le (r i / (9 / 5))
    have h₂ := Int.lt_floor_add_one (r i / (9 / 5))
    have hri := hr i
    have hri' := hr81 i
    have hl : (-1 : ℝ) < (b i : ℝ) := by dsimp [b]; linarith
    have hu : (b i : ℝ) < 9 := by dsimp [b]; linarith
    have hl' : -1 < b i := by exact_mod_cast hl
    have hu' : b i < 9 := by exact_mod_cast hu
    omega
  let f (i : Fin n) : Fin 9 := ⟨(b i).toNat, by
    have := hb i
    omega⟩
  have hf : Function.Injective f := by
    intro i j he
    have he' : b i = b j := by
      have := congrArg Fin.val he
      dsimp [f] at this
      have := hb i
      have := hb j
      omega
    by_contra hij
    have hs := hsep i j hij (-q i + q j)
    have heq : x i - x j + 18 * ((-q i + q j : ℤ) : ℝ) = r i - r j := by
      dsimp [r]; push_cast; ring
    rw [heq] at hs
    have hi₁ := Int.floor_le (r i / (9 / 5))
    have hi₂ := Int.lt_floor_add_one (r i / (9 / 5))
    have hj₁ := Int.floor_le (r j / (9 / 5))
    have hj₂ := Int.lt_floor_add_one (r j / (9 / 5))
    have heR : (⌊r i / (9 / 5)⌋ : ℝ) = ⌊r j / (9 / 5)⌋ := by exact_mod_cast he'
    have hab : |r i - r j| ≤ 9 / 5 := by rw [abs_le]; constructor <;> linarith
    linarith
  simpa using Fintype.card_le_of_injective f hf

theorem Model.card_le_nine {n : ℕ} {d : ℝ} (M : Model n d) (hd : d < 36 / 5) : n ≤ 9 :=
  card_le_nine_of_separated M.start (M.separated_nine_fifths hd)


end Prize.JSP404.ContinuousOneArc
