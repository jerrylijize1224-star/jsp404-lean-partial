import Prize.JSP404.Sector62NonarcData
import Mathlib.Tactic.FinCases
namespace Prize.JSP404.FiniteCliqueCertificate.Sector62Nonarc
set_option maxRecDepth 65536
set_option maxHeartbeats 0
set_option Elab.async false
theorem graph_mask_correct_check14_block0 : (List.range 8).all (fun a => (List.range 1364).all (fun b =>
    let i := vertex (62*14+8*0+a); let j := vertex b; decide (graph i j = decide (i ≠ j ∧ mask i &&& reverseMask j ≠ 0)))) = true := by decide +kernel
theorem graph_mask_correct_check14_block1 : (List.range 8).all (fun a => (List.range 1364).all (fun b =>
    let i := vertex (62*14+8*1+a); let j := vertex b; decide (graph i j = decide (i ≠ j ∧ mask i &&& reverseMask j ≠ 0)))) = true := by decide +kernel
theorem graph_mask_correct_check14_block2 : (List.range 8).all (fun a => (List.range 1364).all (fun b =>
    let i := vertex (62*14+8*2+a); let j := vertex b; decide (graph i j = decide (i ≠ j ∧ mask i &&& reverseMask j ≠ 0)))) = true := by decide +kernel
theorem graph_mask_correct_check14_block3 : (List.range 8).all (fun a => (List.range 1364).all (fun b =>
    let i := vertex (62*14+8*3+a); let j := vertex b; decide (graph i j = decide (i ≠ j ∧ mask i &&& reverseMask j ≠ 0)))) = true := by decide +kernel
theorem graph_mask_correct_check14_block4 : (List.range 8).all (fun a => (List.range 1364).all (fun b =>
    let i := vertex (62*14+8*4+a); let j := vertex b; decide (graph i j = decide (i ≠ j ∧ mask i &&& reverseMask j ≠ 0)))) = true := by decide +kernel
theorem graph_mask_correct_check14_block5 : (List.range 8).all (fun a => (List.range 1364).all (fun b =>
    let i := vertex (62*14+8*5+a); let j := vertex b; decide (graph i j = decide (i ≠ j ∧ mask i &&& reverseMask j ≠ 0)))) = true := by decide +kernel
theorem graph_mask_correct_check14_block6 : (List.range 8).all (fun a => (List.range 1364).all (fun b =>
    let i := vertex (62*14+8*6+a); let j := vertex b; decide (graph i j = decide (i ≠ j ∧ mask i &&& reverseMask j ≠ 0)))) = true := by decide +kernel
theorem graph_mask_correct_check14_block7 : (List.range 8).all (fun a => (List.range 1364).all (fun b =>
    let i := vertex (62*14+8*7+a); let j := vertex b; decide (graph i j = decide (i ≠ j ∧ mask i &&& reverseMask j ≠ 0)))) = true := by decide +kernel
theorem graph_mask_correct_check14 : (List.range 62).all (fun a => (List.range 1364).all (fun b =>
    let i := vertex (62*14+a); let j := vertex b; decide (graph i j = decide (i ≠ j ∧ mask i &&& reverseMask j ≠ 0)))) = true := by
  have h : ∀ block : Fin 8, (List.range 8).all (fun a => (List.range 1364).all (fun b =>
      let i := vertex (62*14+8*block.val+a); let j := vertex b; decide (graph i j = decide (i ≠ j ∧ mask i &&& reverseMask j ≠ 0)))) = true := by
    intro block
    fin_cases block
    · exact graph_mask_correct_check14_block0
    · exact graph_mask_correct_check14_block1
    · exact graph_mask_correct_check14_block2
    · exact graph_mask_correct_check14_block3
    · exact graph_mask_correct_check14_block4
    · exact graph_mask_correct_check14_block5
    · exact graph_mask_correct_check14_block6
    · exact graph_mask_correct_check14_block7
  apply List.all_eq_true.mpr
  intro a ha
  apply List.all_eq_true.mpr
  intro b hb
  have ha0 : a < 62 := List.mem_range.mp ha
  have hblock : a / 8 < 8 := by omega
  have heq : 62*14+8*(a/8)+a%8 = 62*14+a := by omega
  have hr := List.all_eq_true.mp (h ⟨a/8, hblock⟩) (a%8) (List.mem_range.mpr (Nat.mod_lt _ (by decide)))
  have he := List.all_eq_true.mp hr b hb
  dsimp only at he ⊢
  simpa only [heq] using he
end Prize.JSP404.FiniteCliqueCertificate.Sector62Nonarc
