import Prize.JSP404.RecursiveCliqueReduction
import Mathlib.Data.Nat.Bitwise

/-! Integer-mask acceleration of domination checks. Soundness is proved by
translation to the existing list-based checker; all graph, symmetry and domain
representation hypotheses are explicit. -/
namespace Prize.JSP404.FiniteCliqueCertificate
namespace MaskReduction
variable {n : Nat}

def mapCertificate {A B : Type*} (f : A → B) : ReducedCertificate A → ReducedCertificate B
  | .color cs => .color (cs.map (List.map f))
  | .split v no yes => .split (f v) (mapCertificate f no) (mapCertificate f yes)
  | .reduce steps child => .reduce (steps.map (fun (v,w) => (f v,f w))) (mapCertificate f child)

def Covers (P : List (Fin n)) (m : Nat) : Prop :=
  ∀ u ∈ P, m.testBit u.val = true

def clear (m : Nat) (v : Fin n) : Nat := m ^^^ (m &&& 2^v.val)

theorem clear_bit (m : Nat) (v u : Fin n) (h : u ≠ v) :
    (clear m v).testBit u.val = m.testBit u.val := by
  have hv : v.val ≠ u.val := fun he => h (Fin.ext he.symm)
  simp [clear, Nat.testBit_two_pow_of_ne hv]

theorem covers_erase {P : List (Fin n)} {m : Nat}
    (hn : P.Nodup) (hm : Covers P m) (v : (Fin n)) : Covers (P.erase v) (clear m v) := by
  intro u hu
  obtain ⟨hne, hp⟩ := hn.mem_erase_iff.mp hu
  rw [clear_bit m v u hne]
  exact hm u hp

def dominates (G : Fin n → (Fin n) → Bool) (rows : (Fin n) → Nat)
    (P : List (Fin n)) (m : Nat) (v w : (Fin n)) : Bool :=
  P.contains w && decide (v ≠ w) && !(G v w) &&
    decide ((rows v &&& m) &&& rows w = rows v &&& m)

theorem dominates_sound (G : Fin n → (Fin n) → Bool) (rows : (Fin n) → Nat)
    (hr : ∀ v u, G v u = (rows v).testBit u.val)
    (hs : ∀ v u, G v u = G u v) (P : List (Fin n)) (m : Nat)
    (hm : Covers P m) (v w : (Fin n)) (h : dominates G rows P m v w = true) :
    dominatesCheck G P v w = true := by
  have hh : ((w ∈ P ∧ v ≠ w) ∧ G v w = false) ∧
      (rows v &&& m) &&& rows w = rows v &&& m := by
    simpa only [dominates, Bool.and_eq_true, List.contains_iff_mem,
      decide_eq_true_eq, Bool.not_eq_true'] using h
  have hedge (u : (Fin n)) (hu : u ∈ P) (he : G v u = true) : G w u = true := by
    have hb := congrArg (fun a : Nat => a.testBit u.val) hh.2
    have hv : (rows v).testBit u.val = true := (hr v u).symm.trans he
    simpa only [Nat.testBit_and, hv, hm u hu, Bool.true_and, ← hr w u] using hb
  simp only [dominatesCheck, Bool.and_eq_true, List.contains_iff_mem,
    decide_eq_true_eq, Bool.not_eq_true', List.all_eq_true, Bool.or_eq_true]
  refine ⟨hh.1, ?_⟩
  intro u hu
  constructor
  · cases he : G v u with
    | false => exact Or.inl rfl
    | true => exact Or.inr (hedge u hu he)
  · cases he : G u v with
    | false => exact Or.inl rfl
    | true => exact Or.inr (by rw [hs u w]; exact hedge u hu (by rw [hs v u]; exact he))

def reducedMask (m : Nat) : List (Fin n × (Fin n)) → Nat
  | [] => m
  | (v, _) :: rest => reducedMask (clear m v) rest

def reduction (G : Fin n → (Fin n) → Bool) (rows : (Fin n) → Nat)
    (P : List (Fin n)) (m : Nat) : List ((Fin n) × (Fin n)) → Bool
  | [] => true
  | (v,w) :: rest => dominates G rows P m v w &&
      reduction G rows (P.erase v) (clear m v) rest

theorem reduction_sound (G : Fin n → (Fin n) → Bool) (rows : (Fin n) → Nat)
    (hr : ∀ v u, G v u = (rows v).testBit u.val)
    (hs : ∀ v u, G v u = G u v) (steps : List ((Fin n) × (Fin n))) :
    ∀ P m, P.Nodup → Covers P m → reduction G rows P m steps = true →
      reductionCheck G P steps = true ∧ (reducedDomain P steps).Nodup ∧
        Covers (reducedDomain P steps) (reducedMask m steps) := by
  induction steps with
  | nil => intro P m hn hm h; exact ⟨rfl, hn, hm⟩
  | cons step rest ih =>
    obtain ⟨v,w⟩ := step
    intro P m hn hm h
    have hh : dominates G rows P m v w = true ∧
        reduction G rows (P.erase v) (clear m v) rest = true := by
      simpa only [reduction, Bool.and_eq_true] using h
    obtain ⟨hc, hnd, hcov⟩ := ih (P.erase v) (clear m v) (hn.erase v)
      (covers_erase hn hm v) hh.2
    refine ⟨?_, hnd, hcov⟩
    simpa only [reductionCheck, Bool.and_eq_true] using
      And.intro (dominates_sound G rows hr hs P m hm v w hh.1) hc

def check (G : Fin n → (Fin n) → Bool) (rows : (Fin n) → Nat)
    (P : List (Fin n)) (m k : Nat) : ReducedCertificate (Fin n) → Bool
  | .color cs => colorCheck G P k cs
  | .split v no yes => decide (0 < k) && check G rows (P.erase v) (clear m v) k no &&
      check G rows ((P.erase v).filter (fun w => G v w))
        (clear m v &&& rows v) (k-1) yes
  | .reduce steps child => reduction G rows P m steps &&
      check G rows (reducedDomain P steps) (reducedMask m steps) k child

theorem check_implies (G : Fin n → (Fin n) → Bool) (rows : (Fin n) → Nat)
    (hr : ∀ v u, G v u = (rows v).testBit u.val)
    (hs : ∀ v u, G v u = G u v) (cert : ReducedCertificate (Fin n)) :
    ∀ P m k, P.Nodup → Covers P m → check G rows P m k cert = true →
      reducedCheck G P k cert = true := by
  induction cert with
  | color cs => intro P m k hn hm h; exact h
  | reduce steps child ih =>
    intro P m k hn hm h
    have hh : reduction G rows P m steps = true ∧
        check G rows (reducedDomain P steps) (reducedMask m steps) k child = true := by
      simpa only [check, Bool.and_eq_true] using h
    obtain ⟨hc, hnd, hcov⟩ := reduction_sound G rows hr hs steps P m hn hm hh.1
    simpa only [reducedCheck, Bool.and_eq_true] using
      And.intro hc (ih _ _ k hnd hcov hh.2)
  | split v no yes ihno ihyes =>
    intro P m k hn hm h
    have hh : (decide (0 < k) = true ∧ check G rows (P.erase v) (clear m v) k no = true) ∧
        check G rows ((P.erase v).filter (fun w => G v w))
          (clear m v &&& rows v) (k-1) yes = true := by
      simpa only [check, Bool.and_eq_true] using h
    have hn' := hn.erase v
    have hm' := covers_erase hn hm v
    have hy : Covers ((P.erase v).filter (fun w => G v w)) (clear m v &&& rows v) := by
      intro u hu
      obtain ⟨hp, he⟩ := List.mem_filter.mp hu
      simp only [Nat.testBit_and, hm' u hp, Bool.true_and, ← hr v u]
      exact he
    simpa only [reducedCheck, Bool.and_eq_true] using
      And.intro (And.intro hh.1.1 (ihno _ _ k hn' hm' hh.1.2))
        (ihyes _ _ (k-1) (hn'.filter _) hy hh.2)

theorem check_sound (G : Fin n → (Fin n) → Bool) (rows : (Fin n) → Nat)
    (hr : ∀ v u, G v u = (rows v).testBit u.val)
    (hs : ∀ v u, G v u = G u v) (cert : ReducedCertificate (Fin n))
    (P : List (Fin n)) (m k : Nat) (hn : P.Nodup) (hm : Covers P m)
    (h : check G rows P m k cert = true) : Bound G P k :=
  reducedCheck_sound G cert P k (check_implies G rows hr hs cert P m k hn hm h)

theorem bound_split (G : Fin n → Fin n → Bool) (P : List (Fin n))
    (v : Fin n) (k : Nat) (hk : 0 < k)
    (hno : Bound G (P.erase v) k)
    (hyes : Bound G ((P.erase v).filter (fun w => G v w)) (k-1)) : Bound G P k := by
  intro s hs hc
  by_cases hv : v ∈ s
  · have he : ∀ w ∈ s.erase v, w ∈ (P.erase v).filter (fun w => G v w) := by
      intro w hw
      obtain ⟨hne, hws⟩ := Finset.mem_erase.mp hw
      exact List.mem_filter.mpr
        ⟨(List.mem_erase_of_ne hne).mpr (hs w hws), hc v hv w hws hne.symm⟩
    have hce : Clique G (s.erase v) := by
      intro a ha b hb hab
      exact hc a (Finset.mem_of_mem_erase ha) b (Finset.mem_of_mem_erase hb) hab
    have hb := hyes (s.erase v) he hce
    have hsize := Finset.card_erase_add_one hv
    omega
  · apply hno s ?_ hc
    intro w hw
    exact (List.mem_erase_of_ne (show w ≠ v from fun he => hv (he ▸ hw))).mpr (hs w hw)

end MaskReduction
end Prize.JSP404.FiniteCliqueCertificate
