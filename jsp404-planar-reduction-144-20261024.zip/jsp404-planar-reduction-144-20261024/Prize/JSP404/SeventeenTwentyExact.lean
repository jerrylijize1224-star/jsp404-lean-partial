import Prize.JSP404.ContinuousDirectionCapacity
import Prize.JSP404.GeneralAngleBounds
import Prize.JSP404.Sharpness

/-!
# The exact ordinary values for seventeen through twenty points

The lower proof classifies continuous direction sets and uses the two capacity
bounds. The upper proof reuses the existing first-band planar construction.
The mathematical target is Sendov's classical 140-degree value; no novelty or
complete arbitrary-cardinality result is asserted by this module.
-/

namespace Prize.JSP404

open ContinuousDirection

noncomputable def scaledArg (z : ℂ) : ℝ := 9 * z.arg / Real.pi

theorem scaledArg_neg {z : ℂ} (hz : z ≠ 0) :
    ∃ k : ℤ, scaledArg (-z) = scaledArg z + 9 + 18 * k := by
  have he : ((-z).arg : Real.Angle) = ((z.arg + Real.pi : ℝ) : Real.Angle) := by
    simpa only [Real.Angle.coe_add] using Complex.arg_neg_coe_angle hz
  obtain ⟨k, hk⟩ := Real.Angle.angle_eq_iff_two_pi_dvd_sub.mp he
  refine ⟨k, ?_⟩
  unfold scaledArg
  apply (div_eq_iff Real.pi_ne_zero).mpr
  field_simp
  nlinarith [Real.pi_pos]

theorem scaledArg_close {z w : ℂ} (hz : z ≠ 0) (hw : w ≠ 0) {A : ℝ}
    (h : InnerProductGeometry.angle z w ≤ A) :
    Close (9 * A / Real.pi) (scaledArg z) (scaledArg w) := by
  have he : (z.arg : Real.Angle) = ((w.arg + (z / w).arg : ℝ) : Real.Angle) := by
    rw [Real.Angle.coe_add, Complex.arg_div_coe_angle hz hw]
    abel
  obtain ⟨k, hk⟩ := Real.Angle.angle_eq_iff_two_pi_dvd_sub.mp he
  refine ⟨-k, ?_⟩
  have hgap : scaledArg z - scaledArg w + 18 * ((-k : ℤ) : ℝ) =
      9 * (z / w).arg / Real.pi := by
    unfold scaledArg
    push_cast
    field_simp
    nlinarith
  rw [hgap, abs_div, abs_mul, abs_of_pos Real.pi_pos]
  rw [abs_of_pos (by norm_num : (0 : ℝ) < 9)]
  rw [Complex.angle_eq_abs_arg hz hw] at h
  exact div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_left h (by norm_num))
    Real.pi_pos.le

theorem card_le_sixteen_of_complex_angles_seven_pi_ninths {V : Type*} [Fintype V]
    (p : V → ℂ) (hp : Function.Injective p)
    (hangle : ∀ u v w, u ≠ v → u ≠ w → v ≠ w →
      EuclideanGeometry.angle (p u) (p v) (p w) < 7 * Real.pi / 9) :
    Fintype.card V ≤ 16 := by
  classical
  let f (t : V × V × V) : ℝ :=
    if t.1 ≠ t.2.1 ∧ t.1 ≠ t.2.2 ∧ t.2.1 ≠ t.2.2 then
      EuclideanGeometry.angle (p t.1) (p t.2.1) (p t.2.2) else 0
  let s := insert (2 * Real.pi / 3) (Finset.univ.image f)
  have hne : s.Nonempty := ⟨2 * Real.pi / 3, Finset.mem_insert_self _ _⟩
  let A := s.max' hne
  have hAlo : 2 * Real.pi / 3 ≤ A := Finset.le_max' _ _ (Finset.mem_insert_self _ _)
  have hAhi : A < 7 * Real.pi / 9 := by
    have hmem := Finset.max'_mem s hne
    rcases Finset.mem_insert.mp hmem with h | h
    · change A = 2 * Real.pi / 3 at h
      rw [h]; linarith [Real.pi_pos]
    · obtain ⟨⟨u, v, w⟩, _, he⟩ := Finset.mem_image.mp h
      change f (u, v, w) = A at he
      rw [← he]
      dsimp [f]
      split_ifs with h
      · exact hangle u v w h.1 h.2.1 h.2.2
      · positivity
  have hAle (u v w : V) (huv : u ≠ v) (huw : u ≠ w) (hvw : v ≠ w) :
      EuclideanGeometry.angle (p u) (p v) (p w) ≤ A := by
    apply Finset.le_max' s _
    apply Finset.mem_insert_of_mem
    exact Finset.mem_image.mpr ⟨(u, v, w), Finset.mem_univ _, by simp [f, huv, huw, hvw]⟩
  let d := 9 * A / Real.pi
  have hd0 : 6 ≤ d := by
    apply (le_div_iff₀ Real.pi_pos).mpr
    linarith
  have hd : d < 7 := by
    apply (div_lt_iff₀ Real.pi_pos).mpr
    linarith
  let q (u v : V) := scaledArg (p v - p u)
  apply card_le_sixteen_of_assignment hd0 hd q
  · intro u v huv
    change ∃ k : ℤ, scaledArg (p u - p v) = scaledArg (p v - p u) + 9 + 18 * k
    rw [show p u - p v = -(p v - p u) by abel]
    exact scaledArg_neg (sub_ne_zero.mpr (hp.ne huv.symm))
  · intro v u w hvu hvw
    by_cases huw : u = w
    · subst w
      refine ⟨0, ?_⟩
      simp only [sub_self, Int.cast_zero, mul_zero, add_zero, abs_zero]
      linarith
    · apply scaledArg_close (sub_ne_zero.mpr (hp.ne hvu.symm))
        (sub_ne_zero.mpr (hp.ne hvw.symm))
      exact hAle u v w hvu.symm huw hvw

theorem card_le_sixteen_of_plane_angles_seven_pi_ninths {V : Type*} [Fintype V]
    (p : V → Plane) (hp : Function.Injective p)
    (hangle : ∀ u v w, u ≠ v → u ≠ w → v ≠ w →
      EuclideanGeometry.angle (p u) (p v) (p w) < 7 * Real.pi / 9) :
    Fintype.card V ≤ 16 := by
  let e := Complex.orthonormalBasisOneI.repr.symm
  apply card_le_sixteen_of_complex_angles_seven_pi_ninths (fun v => e (p v)) (e.injective.comp hp)
  intro u v w huv huw hvw
  change InnerProductGeometry.angle (e (p u) - e (p v)) (e (p w) - e (p v)) < _
  rw [← map_sub, ← map_sub]
  change InnerProductGeometry.angle (e.toLinearIsometry (p u - p v))
    (e.toLinearIsometry (p w - p v)) < _
  rw [e.toLinearIsometry.angle_map]
  exact hangle u v w huv huw hvw

theorem guaranteedAngle_seven_pi_ninths {N : ℕ} (hN : 17 ≤ N) :
    GuaranteedAngle N (7 * Real.pi / 9) := by
  intro s hs
  classical
  by_contra hn
  have hb : ∀ u v w : s, u ≠ v → u ≠ w → v ≠ w →
      EuclideanGeometry.angle (u : Plane) (v : Plane) (w : Plane) < 7 * Real.pi / 9 := by
    intro u v w huv huw hvw
    apply lt_of_not_ge
    intro ha
    apply hn
    exact ⟨u, u.property, v, v.property, w, w.property,
      (fun h => huv (Subtype.ext h)), (fun h => huw (Subtype.ext h)),
      (fun h => hvw (Subtype.ext h)), ha⟩
  have hc := card_le_sixteen_of_plane_angles_seven_pi_ninths (fun u : s => (u : Plane))
    Subtype.val_injective hb
  simp only [Fintype.card_coe] at hc
  omega

theorem seventeen_twenty_isSharpBound {N : ℕ} (hlo : 17 ≤ N) (hhi : N ≤ 20) :
    IsSharpBound N (7 * Real.pi / 9) := by
  apply isSharpBound_of_approximation (by positivity) (by linarith [Real.pi_pos])
    (guaranteedAngle_seven_pi_ninths hlo)
  intro ε hε
  obtain ⟨s, hs, hb⟩ := exists_firstBand_counterexample 2 hε
  refine ⟨s, ?_, ?_⟩
  · norm_num at hs
    omega
  · have he : Real.pi - 2 * firstBandStep 2 + ε = 7 * Real.pi / 9 + ε := by
      norm_num [firstBandStep]
      ring
    rw [he] at hb
    exact hb

theorem alpha_seventeen : alpha 17 = 7 * Real.pi / 9 :=
  (seventeen_twenty_isSharpBound (by decide) (by decide)).alpha_eq

theorem alpha_eighteen : alpha 18 = 7 * Real.pi / 9 :=
  (seventeen_twenty_isSharpBound (by decide) (by decide)).alpha_eq

theorem alpha_nineteen : alpha 19 = 7 * Real.pi / 9 :=
  (seventeen_twenty_isSharpBound (by decide) (by decide)).alpha_eq

theorem alpha_twenty : alpha 20 = 7 * Real.pi / 9 :=
  (seventeen_twenty_isSharpBound (by decide) (by decide)).alpha_eq

end Prize.JSP404
