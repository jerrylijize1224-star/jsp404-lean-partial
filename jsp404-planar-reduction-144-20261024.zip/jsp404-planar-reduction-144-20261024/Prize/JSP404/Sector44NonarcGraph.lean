import Prize.JSP404.Sector44NonarcChecks0
import Prize.JSP404.Sector44NonarcChecks1
import Prize.JSP404.Sector44NonarcChecks2
import Prize.JSP404.Sector44NonarcChecks3
import Prize.JSP404.Sector44NonarcChecks4
import Prize.JSP404.Sector44NonarcChecks5
import Prize.JSP404.Sector44NonarcChecks6
import Prize.JSP404.Sector44NonarcChecks7
import Prize.JSP404.Sector44NonarcChecks8
import Prize.JSP404.Sector44NonarcChecks9
import Prize.JSP404.Sector44NonarcChecks10
import Prize.JSP404.Sector44NonarcChecks11
import Mathlib.Tactic.FinCases
namespace Prize.JSP404.FiniteCliqueCertificate.Sector44Nonarc
set_option maxRecDepth 65536
set_option maxHeartbeats 0
set_option Elab.async false
theorem graph_correct : ∀ i j, graph i j = (decide (i ≠ j) && (labels i).any (fun b => (labels j).contains (Sector44.antipode b))) := by
  have h : ∀ k : Fin 12, (List.range 44).all (fun a => (List.range 528).all (fun b =>
      let i := vertex (44*k.val+a); let j := vertex b; decide (graph i j = (decide (i ≠ j) && (labels i).any (fun b => (labels j).contains (Sector44.antipode b)))))) = true := by
    intro k
    fin_cases k
    · exact graph_correct_check0
    · exact graph_correct_check1
    · exact graph_correct_check2
    · exact graph_correct_check3
    · exact graph_correct_check4
    · exact graph_correct_check5
    · exact graph_correct_check6
    · exact graph_correct_check7
    · exact graph_correct_check8
    · exact graph_correct_check9
    · exact graph_correct_check10
    · exact graph_correct_check11
  intro i j
  have hi : vertex i.val = i := Fin.ext (Nat.mod_eq_of_lt i.isLt)
  have hj : vertex j.val = j := Fin.ext (Nat.mod_eq_of_lt j.isLt)
  have hk : i.val / 44 < 12 := by omega
  have heq : 44 * (i.val / 44) + i.val % 44 = i.val := by omega
  have hrow := List.all_eq_true.mp (h ⟨i.val / 44, hk⟩) (i.val % 44) (List.mem_range.mpr (Nat.mod_lt _ (by decide)))
  have hentry := List.all_eq_true.mp hrow j.val (List.mem_range.mpr j.isLt)
  dsimp only at hentry
  simpa only [heq, hi, hj, decide_eq_true_eq] using hentry
theorem shift_injective : Function.Injective shift := by
  have h : (List.range 528).all (fun a => decide (inverseShift (shift (vertex a)) = vertex a)) = true := by decide +kernel
  apply Function.LeftInverse.injective (g := inverseShift)
  intro v
  have hv : vertex v.val = v := Fin.ext (Nat.mod_eq_of_lt v.isLt)
  have he := List.all_eq_true.mp h v.val (List.mem_range.mpr v.isLt)
  simpa only [hv, decide_eq_true_eq] using he
theorem shift_preserves : ∀ i j, graph i j = true → graph (shift i) (shift j) = true := by
  have h : ∀ k : Fin 12, (List.range 44).all (fun a => (List.range 528).all (fun b =>
      let i := vertex (44*k.val+a); let j := vertex b; decide (graph i j = true → graph (shift i) (shift j) = true))) = true := by
    intro k
    fin_cases k
    · exact shift_preserves_check0
    · exact shift_preserves_check1
    · exact shift_preserves_check2
    · exact shift_preserves_check3
    · exact shift_preserves_check4
    · exact shift_preserves_check5
    · exact shift_preserves_check6
    · exact shift_preserves_check7
    · exact shift_preserves_check8
    · exact shift_preserves_check9
    · exact shift_preserves_check10
    · exact shift_preserves_check11
  intro i j
  have hi : vertex i.val = i := Fin.ext (Nat.mod_eq_of_lt i.isLt)
  have hj : vertex j.val = j := Fin.ext (Nat.mod_eq_of_lt j.isLt)
  have hk : i.val / 44 < 12 := by omega
  have heq : 44 * (i.val / 44) + i.val % 44 = i.val := by omega
  have hrow := List.all_eq_true.mp (h ⟨i.val / 44, hk⟩) (i.val % 44) (List.mem_range.mpr (Nat.mod_lt _ (by decide)))
  have hentry := List.all_eq_true.mp hrow j.val (List.mem_range.mpr j.isLt)
  dsimp only at hentry
  simpa only [heq, hi, hj, decide_eq_true_eq] using hentry
def orbitStep (v : Vertex) : Fin 44 := (if v.val < 264 then (if v.val < 132 then (if v.val < 66 then (if v.val < 33 then (if v.val < 16 then (if v.val < 8 then (if v.val < 4 then (if v.val < 2 then 0 else (if v.val < 3 then 43 else 0)) else (if v.val < 6 then (if v.val < 5 then 0 else 43) else (if v.val < 7 then 42 else 0))) else (if v.val < 12 then (if v.val < 10 then (if v.val < 9 then 43 else 0) else (if v.val < 11 then 0 else 43)) else (if v.val < 14 then (if v.val < 13 then 42 else 41) else (if v.val < 15 then 0 else 43)))) else (if v.val < 24 then (if v.val < 20 then (if v.val < 18 then (if v.val < 17 then 42 else 0) else (if v.val < 19 then 43 else 0)) else (if v.val < 22 then (if v.val < 21 then 13 else 43) else (if v.val < 23 then 42 else 41))) else (if v.val < 28 then (if v.val < 26 then (if v.val < 25 then 40 else 0) else (if v.val < 27 then 43 else 42)) else (if v.val < 30 then (if v.val < 29 then 41 else 0) else (if v.val < 31 then 43 else (if v.val < 32 then 42 else 30)))))) else (if v.val < 49 then (if v.val < 41 then (if v.val < 37 then (if v.val < 35 then (if v.val < 34 then 43 else 30) else 12) else (if v.val < 39 then (if v.val < 38 then 42 else 41) else (if v.val < 40 then 40 else 39))) else (if v.val < 45 then (if v.val < 43 then (if v.val < 42 then 13 else 43) else (if v.val < 44 then 42 else 41)) else (if v.val < 47 then (if v.val < 46 then 40 else 14) else (if v.val < 48 then 43 else 42)))) else (if v.val < 57 then (if v.val < 53 then (if v.val < 51 then (if v.val < 50 then 41 else 29) else (if v.val < 52 then 29 else 42)) else (if v.val < 55 then 29 else (if v.val < 56 then 29 else 11))) else (if v.val < 61 then (if v.val < 59 then 11 else (if v.val < 60 then 41 else 40)) else (if v.val < 63 then (if v.val < 62 then 39 else 38) else (if v.val < 64 then 12 else (if v.val < 65 then 12 else 42))))))) else (if v.val < 99 then (if v.val < 82 then (if v.val < 74 then (if v.val < 70 then (if v.val < 68 then (if v.val < 67 then 41 else 40) else (if v.val < 69 then 39 else 13)) else (if v.val < 72 then (if v.val < 71 then 13 else 42) else (if v.val < 73 then 41 else 40))) else (if v.val < 78 then (if v.val < 76 then (if v.val < 75 then 14 else 28) else (if v.val < 77 then 28 else 41)) else 28)) else (if v.val < 90 then (if v.val < 86 then (if v.val < 84 then 28 else 10) else (if v.val < 88 then 10 else (if v.val < 89 then 40 else 39))) else (if v.val < 94 then (if v.val < 92 then (if v.val < 91 then 38 else 37) else 11) else (if v.val < 96 then (if v.val < 95 then 11 else 41) else (if v.val < 97 then 40 else (if v.val < 98 then 39 else 38)))))) else (if v.val < 115 then (if v.val < 107 then (if v.val < 103 then (if v.val < 101 then 12 else (if v.val < 102 then 12 else 41)) else (if v.val < 105 then (if v.val < 104 then 40 else 39) else 13)) else (if v.val < 111 then (if v.val < 109 then 27 else (if v.val < 110 then 40 else 27)) else 27)) else (if v.val < 123 then (if v.val < 119 then 27 else (if v.val < 121 then (if v.val < 120 then 27 else 9) else 9)) else (if v.val < 127 then (if v.val < 125 then (if v.val < 124 then 9 else 39) else (if v.val < 126 then 38 else 37)) else (if v.val < 129 then (if v.val < 128 then 36 else 10) else (if v.val < 130 then 10 else (if v.val < 131 then 10 else 40)))))))) else (if v.val < 198 then (if v.val < 165 then (if v.val < 148 then (if v.val < 140 then (if v.val < 136 then (if v.val < 134 then (if v.val < 133 then 39 else 38) else (if v.val < 135 then 37 else 11)) else (if v.val < 138 then 11 else (if v.val < 139 then 40 else 39))) else (if v.val < 144 then (if v.val < 142 then (if v.val < 141 then 38 else 12) else (if v.val < 143 then 12 else 26)) else (if v.val < 146 then (if v.val < 145 then 26 else 39) else 26))) else (if v.val < 156 then 26 else (if v.val < 160 then 8 else (if v.val < 162 then (if v.val < 161 then 38 else 37) else (if v.val < 163 then 36 else (if v.val < 164 then 35 else 9)))))) else (if v.val < 181 then (if v.val < 173 then (if v.val < 169 then (if v.val < 167 then 9 else (if v.val < 168 then 39 else 38)) else (if v.val < 171 then (if v.val < 170 then 37 else 36) else 10)) else (if v.val < 177 then (if v.val < 175 then (if v.val < 174 then 10 else 39) else (if v.val < 176 then 38 else 37)) else (if v.val < 179 then 11 else 25))) else (if v.val < 189 then (if v.val < 185 then (if v.val < 183 then (if v.val < 182 then 38 else 25) else 25) else 25) else (if v.val < 193 then (if v.val < 191 then 25 else (if v.val < 192 then 25 else 7)) else (if v.val < 195 then 7 else (if v.val < 196 then 7 else (if v.val < 197 then 37 else 36))))))) else (if v.val < 231 then (if v.val < 214 then (if v.val < 206 then (if v.val < 202 then (if v.val < 200 then (if v.val < 199 then 35 else 34) else 8) else (if v.val < 204 then (if v.val < 203 then 8 else 38) else (if v.val < 205 then 37 else 36))) else (if v.val < 210 then (if v.val < 208 then (if v.val < 207 then 35 else 9) else 9) else (if v.val < 212 then (if v.val < 211 then 38 else 37) else (if v.val < 213 then 36 else 10)))) else (if v.val < 222 then (if v.val < 218 then (if v.val < 216 then (if v.val < 215 then 10 else 24) else (if v.val < 217 then 24 else 37)) else 24) else (if v.val < 226 then 24 else (if v.val < 228 then 24 else 6)))) else (if v.val < 247 then (if v.val < 239 then (if v.val < 235 then (if v.val < 233 then (if v.val < 232 then 6 else 36) else (if v.val < 234 then 35 else 34)) else (if v.val < 237 then (if v.val < 236 then 33 else 7) else 7)) else (if v.val < 243 then (if v.val < 241 then (if v.val < 240 then 37 else 36) else (if v.val < 242 then 35 else 34)) else (if v.val < 245 then 8 else (if v.val < 246 then 8 else 37)))) else (if v.val < 255 then (if v.val < 251 then (if v.val < 249 then (if v.val < 248 then 36 else 35) else 9) else (if v.val < 253 then 23 else (if v.val < 254 then 36 else 23))) else 23))))) else (if v.val < 396 then (if v.val < 330 then (if v.val < 297 then (if v.val < 280 then (if v.val < 272 then (if v.val < 268 then 5 else (if v.val < 270 then (if v.val < 269 then 35 else 34) else (if v.val < 271 then 33 else 32))) else (if v.val < 276 then (if v.val < 274 then 6 else (if v.val < 275 then 6 else 36)) else (if v.val < 278 then (if v.val < 277 then 35 else 34) else (if v.val < 279 then 33 else 7)))) else (if v.val < 288 then (if v.val < 284 then (if v.val < 282 then 7 else (if v.val < 283 then 36 else 35)) else (if v.val < 286 then (if v.val < 285 then 34 else 8) else (if v.val < 287 then 8 else 22))) else (if v.val < 292 then (if v.val < 290 then (if v.val < 289 then 22 else 35) else 22) else 22))) else (if v.val < 313 then (if v.val < 305 then (if v.val < 301 then (if v.val < 299 then 22 else (if v.val < 300 then 22 else 4)) else (if v.val < 303 then 4 else (if v.val < 304 then 4 else 34))) else (if v.val < 309 then (if v.val < 307 then (if v.val < 306 then 33 else 32) else (if v.val < 308 then 31 else 5)) else (if v.val < 311 then 5 else (if v.val < 312 then 35 else 34)))) else (if v.val < 321 then (if v.val < 317 then (if v.val < 315 then (if v.val < 314 then 33 else 32) else 6) else (if v.val < 319 then (if v.val < 318 then 6 else 35) else (if v.val < 320 then 34 else 33))) else (if v.val < 325 then (if v.val < 323 then 7 else 21) else (if v.val < 327 then (if v.val < 326 then 34 else 21) else 21))))) else (if v.val < 363 then (if v.val < 346 then (if v.val < 338 then (if v.val < 334 then 21 else (if v.val < 336 then 21 else 3)) else (if v.val < 342 then (if v.val < 340 then 3 else (if v.val < 341 then 33 else 32)) else (if v.val < 344 then (if v.val < 343 then 31 else 30) else 4))) else (if v.val < 354 then (if v.val < 350 then (if v.val < 348 then (if v.val < 347 then 4 else 34) else (if v.val < 349 then 33 else 32)) else (if v.val < 352 then (if v.val < 351 then 31 else 5) else 5)) else (if v.val < 358 then (if v.val < 356 then (if v.val < 355 then 34 else 33) else (if v.val < 357 then 32 else 6)) else (if v.val < 360 then (if v.val < 359 then 6 else 20) else (if v.val < 361 then 20 else (if v.val < 362 then 33 else 20)))))) else (if v.val < 379 then (if v.val < 371 then 20 else (if v.val < 375 then (if v.val < 373 then (if v.val < 372 then 20 else 2) else 2) else (if v.val < 377 then (if v.val < 376 then 2 else 32) else (if v.val < 378 then 31 else 30)))) else (if v.val < 387 then (if v.val < 383 then (if v.val < 381 then (if v.val < 380 then 29 else 3) else 3) else (if v.val < 385 then (if v.val < 384 then 33 else 32) else (if v.val < 386 then 31 else 30))) else (if v.val < 391 then (if v.val < 389 then 4 else (if v.val < 390 then 4 else 33)) else (if v.val < 393 then (if v.val < 392 then 32 else 31) else (if v.val < 394 then 5 else (if v.val < 395 then 5 else 19)))))))) else (if v.val < 462 then (if v.val < 429 then (if v.val < 412 then (if v.val < 404 then (if v.val < 400 then (if v.val < 398 then (if v.val < 397 then 19 else 32) else 19) else 19) else (if v.val < 408 then 19 else 1)) else (if v.val < 420 then (if v.val < 416 then 1 else (if v.val < 418 then 1 else (if v.val < 419 then 14 else 1))) else (if v.val < 424 then (if v.val < 422 then (if v.val < 421 then 1 else 31) else (if v.val < 423 then 31 else 13)) else (if v.val < 426 then (if v.val < 425 then 14 else 15) else 30)))) else (if v.val < 445 then (if v.val < 437 then (if v.val < 433 then (if v.val < 431 then (if v.val < 430 then 12 else 13) else (if v.val < 432 then 14 else 15)) else (if v.val < 435 then 29 else (if v.val < 436 then 29 else 11))) else (if v.val < 441 then (if v.val < 439 then (if v.val < 438 then 12 else 13) else (if v.val < 440 then 14 else 28)) else (if v.val < 443 then 28 else (if v.val < 444 then 28 else 2)))) else (if v.val < 453 then (if v.val < 449 then 2 else (if v.val < 451 then (if v.val < 450 then 2 else 15) else 2)) else (if v.val < 457 then (if v.val < 455 then (if v.val < 454 then 32 else 14) else (if v.val < 456 then 15 else 16)) else (if v.val < 459 then 31 else (if v.val < 460 then 13 else (if v.val < 461 then 14 else 15))))))) else (if v.val < 495 then (if v.val < 478 then (if v.val < 470 then (if v.val < 466 then (if v.val < 464 then (if v.val < 463 then 16 else 30) else (if v.val < 465 then 30 else 12)) else (if v.val < 468 then (if v.val < 467 then 13 else 14) else (if v.val < 469 then 15 else 29))) else (if v.val < 474 then (if v.val < 472 then 29 else 3) else (if v.val < 476 then (if v.val < 475 then 3 else 16) else 3))) else (if v.val < 486 then (if v.val < 482 then (if v.val < 480 then (if v.val < 479 then 15 else 16) else (if v.val < 481 then 17 else 32)) else (if v.val < 484 then (if v.val < 483 then 14 else 15) else (if v.val < 485 then 16 else 17))) else (if v.val < 490 then (if v.val < 488 then (if v.val < 487 then 31 else 13) else (if v.val < 489 then 14 else 15)) else (if v.val < 492 then (if v.val < 491 then 16 else 30) else (if v.val < 493 then 30 else (if v.val < 494 then 4 else 17)))))) else (if v.val < 511 then (if v.val < 503 then (if v.val < 499 then (if v.val < 497 then (if v.val < 496 then 4 else 16) else (if v.val < 498 then 17 else 18)) else (if v.val < 501 then (if v.val < 500 then 15 else 16) else (if v.val < 502 then 17 else 18))) else (if v.val < 507 then (if v.val < 505 then (if v.val < 504 then 14 else 15) else (if v.val < 506 then 16 else 17)) else (if v.val < 509 then (if v.val < 508 then 31 else 18) else (if v.val < 510 then 17 else 18)))) else (if v.val < 519 then (if v.val < 515 then (if v.val < 513 then (if v.val < 512 then 16 else 17) else (if v.val < 514 then 18 else 15)) else (if v.val < 517 then (if v.val < 516 then 16 else 17) else 18)) else (if v.val < 523 then (if v.val < 521 then (if v.val < 520 then 17 else 18) else (if v.val < 522 then 16 else 17)) else (if v.val < 525 then 18 else (if v.val < 526 then 17 else 18)))))))))
theorem orbit_covers : ∀ v : Vertex, ∃ r : Fin 44, shift^[r.val] v ∈ representatives := by
  have h : (List.range 528).all (fun a =>
      representatives.contains (shift^[(orbitStep (vertex a)).val] (vertex a))) = true := by decide +kernel
  intro v
  have hv : vertex v.val = v := Fin.ext (Nat.mod_eq_of_lt v.isLt)
  have he := List.all_eq_true.mp h v.val (List.mem_range.mpr v.isLt)
  refine ⟨orbitStep v, ?_⟩
  simpa only [hv, List.contains_iff_mem] using he
end Prize.JSP404.FiniteCliqueCertificate.Sector44Nonarc
