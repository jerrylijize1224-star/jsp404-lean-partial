import Prize.JSP404.Sector62Types
import Mathlib.Analysis.Complex.Angle
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Ring

namespace Prize.JSP404.FiniteCliqueCertificate.Sector62

def intSector (z : ℤ) : Sector := ⟨(z % 62).toNat, by
  have h0 := Int.emod_nonneg z (by decide : (62 : ℤ) ≠ 0)
  have h1 := Int.emod_lt_of_pos z (by decide : (0 : ℤ) < 62)
  omega⟩

noncomputable def angleBin (θ : ℝ) : Sector := intSector ⌊31 * θ / Real.pi⌋

theorem intSector_add_period (z k : ℤ) : intSector (z+62*k) = intSector z := by
  apply Fin.ext
  simp only [intSector]
  omega

theorem intSector_add_half (z : ℤ) : intSector (z+31) = antipode (intSector z) := by
  apply Fin.ext
  simp only [intSector, antipode]
  omega

theorem intSector_close (z w : ℤ) (hlo : -24 ≤ z-w) (hhi : z-w ≤ 24) :
    circularDistance (intSector z) (intSector w) ≤ 24 := by
  simp only [circularDistance, intSector]
  omega

theorem angleBin_add_period (θ : ℝ) (k : ℤ) :
    angleBin (θ+2*Real.pi*k) = angleBin θ := by
  have he : 31*(θ+2*Real.pi*k)/Real.pi = 31*θ/Real.pi + ((62*k : ℤ) : ℝ) := by
    push_cast
    field_simp
    ring
  unfold angleBin
  rw [he, Int.floor_add_intCast, intSector_add_period]

theorem angleBin_add_pi (θ : ℝ) :
    angleBin (θ+Real.pi) = antipode (angleBin θ) := by
  have he : 31*(θ+Real.pi)/Real.pi = 31*θ/Real.pi + (31 : ℤ) := by
    field_simp
    ring
  unfold angleBin
  rw [he, Int.floor_add_intCast, intSector_add_half]

theorem angleBin_congr_angle {θ φ : ℝ} (h : (θ : Real.Angle) = (φ : Real.Angle)) :
    angleBin θ = angleBin φ := by
  obtain ⟨k, hk⟩ := Real.Angle.angle_eq_iff_two_pi_dvd_sub.mp h
  have he : θ = φ+2*Real.pi*k := by linarith
  rw [he, angleBin_add_period]

theorem angleBin_close {θ φ : ℝ} (h : |θ-φ| < 24*Real.pi/31) :
    circularDistance (angleBin θ) (angleBin φ) ≤ 24 := by
  have h₁ : 31*θ/Real.pi - 31*φ/Real.pi < 24 := by
    rw [← sub_div]
    apply (div_lt_iff₀ Real.pi_pos).mpr
    linarith [(abs_lt.mp h).2]
  have h₂ : -24 < 31*θ/Real.pi - 31*φ/Real.pi := by
    rw [← sub_div]
    apply (lt_div_iff₀ Real.pi_pos).mpr
    linarith [(abs_lt.mp h).1]
  have hx := Int.floor_le (31*θ/Real.pi)
  have hx' := Int.lt_floor_add_one (31*θ/Real.pi)
  have hy := Int.floor_le (31*φ/Real.pi)
  have hy' := Int.lt_floor_add_one (31*φ/Real.pi)
  have hu : (⌊31*θ/Real.pi⌋ - ⌊31*φ/Real.pi⌋ : ℤ) < 25 := by
    have hr : (⌊31*θ/Real.pi⌋ : ℝ) - (⌊31*φ/Real.pi⌋ : ℝ) < 25 := by linarith
    exact_mod_cast hr
  have hl : (-25 : ℤ) < ⌊31*θ/Real.pi⌋ - ⌊31*φ/Real.pi⌋ := by
    have hr : (-25 : ℝ) < (⌊31*θ/Real.pi⌋ : ℝ) - (⌊31*φ/Real.pi⌋ : ℝ) := by linarith
    exact_mod_cast hr
  exact intSector_close _ _ (by omega) (by omega)

theorem argBin_neg {z : ℂ} (hz : z ≠ 0) :
    angleBin (-z).arg = antipode (angleBin z.arg) := by
  have he : ((-z).arg : Real.Angle) = ((z.arg+Real.pi : ℝ) : Real.Angle) := by
    simpa only [Real.Angle.coe_add] using Complex.arg_neg_coe_angle hz
  rw [angleBin_congr_angle he, angleBin_add_pi]

theorem argBin_close {z w : ℂ} (hz : z ≠ 0) (hw : w ≠ 0)
    (h : InnerProductGeometry.angle z w < 24*Real.pi/31) :
    circularDistance (angleBin z.arg) (angleBin w.arg) ≤ 24 := by
  have he : (z.arg : Real.Angle) = ((w.arg+(z/w).arg : ℝ) : Real.Angle) := by
    rw [Real.Angle.coe_add, Complex.arg_div_coe_angle hz hw]
    abel
  rw [angleBin_congr_angle he]
  apply angleBin_close
  rw [show w.arg+(z/w).arg-w.arg = (z/w).arg by ring]
  rwa [Complex.angle_eq_abs_arg hz hw] at h

end Prize.JSP404.FiniteCliqueCertificate.Sector62
