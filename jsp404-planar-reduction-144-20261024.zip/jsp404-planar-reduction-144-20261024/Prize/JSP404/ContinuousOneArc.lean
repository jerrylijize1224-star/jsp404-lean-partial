import Prize.JSP404.IntegerGapCompression

/-!
# Uniform capacity of the continuous one-arc family

The circle has period 18 and antipodal shift 9. Arcs of length `d < 7`
that intersect every other arc after an antipodal shift form a family of
at most eight. This is a continuous model theorem, not a classification
of the directions of arbitrary planar configurations.
-/

namespace Prize.JSP404.ContinuousOneArc

/-- One interval per row, with explicit periodic antipodal intersections. -/
structure Model (n : ℕ) (d : ℝ) where
  start : Fin n → ℝ
  nonneg : 0 ≤ d
  overlap : ∀ i j, i ≠ j → ∃ z : ℤ,
    start i ≤ start j + d + 9 + 18 * z ∧
    start j + 9 + 18 * z ≤ start i + d

/-- Every pair of starts is more than two units apart modulo 18. -/
theorem Model.separated {n : ℕ} {d : ℝ} (M : Model n d) (hd : d < 7)
    (i j : Fin n) (hij : i ≠ j) (k : ℤ) :
    2 < |M.start i - M.start j + 18 * k| := by
  obtain ⟨z, hz₁, hz₂⟩ := M.overlap i j hij
  by_contra h
  have hab := abs_le.mp (le_of_not_gt h)
  by_cases hz : 0 ≤ z + k
  · have hz' : (0 : ℝ) ≤ (z : ℝ) + k := by exact_mod_cast hz
    linarith
  · have hz' : (z : ℝ) + k ≤ -1 := by
      have : z + k ≤ -1 := by omega
      exact_mod_cast this
    linarith

/-- Nine half-open bins suffice for a first packing bound; anchoring one point
at zero makes the last bin empty, giving the sharp bound eight. -/
theorem card_le_eight_of_separated {n : ℕ} (x : Fin n → ℝ)
    (hsep : ∀ i j, i ≠ j → ∀ k : ℤ, 2 < |x i - x j + 18 * k|) : n ≤ 8 := by
  classical
  by_cases hn : n = 0
  · omega
  let o : Fin n := ⟨0, by omega⟩
  let q (i : Fin n) : ℤ := ⌊(x i - x o) / 18⌋
  let r (i : Fin n) : ℝ := x i - x o - 18 * q i
  have hr (i : Fin n) : 0 ≤ r i ∧ r i < 18 := by
    have h₁ := Int.floor_le ((x i - x o) / 18)
    have h₂ := Int.lt_floor_add_one ((x i - x o) / 18)
    dsimp [r, q]
    constructor <;> linarith
  have hr₀ : r o = 0 := by simp [r, q]
  have hr16 (i : Fin n) : r i < 16 := by
    by_cases hi : i = o
    · subst i; rw [hr₀]; norm_num
    · have hs := hsep i o hi (-q i - 1)
      have he : x i - x o + 18 * ((-q i - 1 : ℤ) : ℝ) = r i - 18 := by
        dsimp [r]; push_cast; ring
      rw [he] at hs
      have hri := hr i
      by_contra h
      have hab : |r i - 18| ≤ 2 := by rw [abs_le]; constructor <;> linarith
      linarith
  let b (i : Fin n) : ℤ := ⌊r i / 2⌋
  have hb (i : Fin n) : 0 ≤ b i ∧ b i < 8 := by
    have h₁ := Int.floor_le (r i / 2)
    have h₂ := Int.lt_floor_add_one (r i / 2)
    have hri := hr i
    have hri' := hr16 i
    have hl : (-1 : ℝ) < (b i : ℝ) := by dsimp [b]; linarith
    have hu : (b i : ℝ) < 8 := by dsimp [b]; linarith
    have hl' : -1 < b i := by exact_mod_cast hl
    have hu' : b i < 8 := by exact_mod_cast hu
    omega
  let f (i : Fin n) : Fin 8 := ⟨(b i).toNat, by
    have := hb i
    omega⟩
  have hf : Function.Injective f := by
    intro i j he
    have he' : b i = b j := by
      have := congrArg Fin.val he
      dsimp [f] at this
      have := hb i
      have := hb j
      omega
    by_contra hij
    have hs := hsep i j hij (-q i + q j)
    have heq : x i - x j + 18 * ((-q i + q j : ℤ) : ℝ) = r i - r j := by
      dsimp [r]; push_cast; ring
    rw [heq] at hs
    have hi₁ := Int.floor_le (r i / 2)
    have hi₂ := Int.lt_floor_add_one (r i / 2)
    have hj₁ := Int.floor_le (r j / 2)
    have hj₂ := Int.lt_floor_add_one (r j / 2)
    have heR : (⌊r i / 2⌋ : ℝ) = ⌊r j / 2⌋ := by exact_mod_cast he'
    have hab : |r i - r j| ≤ 2 := by rw [abs_le]; constructor <;> linarith
    linarith
  simpa using Fintype.card_le_of_injective f hf

theorem Model.card_le_eight {n : ℕ} {d : ℝ} (M : Model n d) (hd : d < 7) : n ≤ 8 :=
  card_le_eight_of_separated M.start (M.separated hd)

theorem no_nine_model_below_seven {d : ℝ} (hd : d < 7) : ¬ Nonempty (Model 9 d) := by
  rintro ⟨M⟩
  have := M.card_le_eight hd
  omega

end Prize.JSP404.ContinuousOneArc
