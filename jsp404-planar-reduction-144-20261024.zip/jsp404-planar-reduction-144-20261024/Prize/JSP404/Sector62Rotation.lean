import Prize.JSP404.Sector62Types
import Prize.JSP404.FiniteCliqueRelabel

namespace Prize.JSP404.FiniteCliqueCertificate.Sector62

def rotateSector (i : Sector) : Sector := ⟨(i.val + 1) % 62, Nat.mod_lt _ (by decide)⟩

theorem rotateSector_injective : Function.Injective rotateSector := by
  intro i j h
  have he := congrArg Fin.val h
  apply Fin.ext
  simp only [rotateSector] at he
  omega

theorem rotateSector_antipode : ∀ i, rotateSector (antipode i) = antipode (rotateSector i) := by
  decide +kernel

end Prize.JSP404.FiniteCliqueCertificate.Sector62
