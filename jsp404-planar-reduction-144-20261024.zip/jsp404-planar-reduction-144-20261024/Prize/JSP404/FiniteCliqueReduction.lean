import Prize.JSP404.FiniteCliqueCertificate

/-! Checked vertex domination for compressing finite clique certificates.
A discarded vertex can be replaced by a retained, nonadjacent vertex.
Both edge directions are checked, so graph symmetry is not assumed. -/
namespace Prize.JSP404.FiniteCliqueCertificate
variable {V : Type*} [DecidableEq V]

def dominatesCheck (G : V → V → Bool) (P : List V) (v w : V) : Bool :=
  P.contains w && decide (v ≠ w) && !(G v w) &&
  P.all (fun u => (!(G v u) || G w u) && (!(G u v) || G u w))

theorem bound_of_dominatesCheck (G : V → V → Bool) (P : List V) (v w : V)
    (h : dominatesCheck G P v w = true) {k : ℕ}
    (hb : Bound G (P.erase v) k) : Bound G P k := by
  have hh : ((w ∈ P ∧ v ≠ w) ∧ G v w = false) ∧
      ∀ u ∈ P, (G v u = true → G w u = true) ∧
        (G u v = true → G u w = true) := by
    have raw : ((w ∈ P ∧ v ≠ w) ∧ G v w = false) ∧
        ∀ u ∈ P, (G v u = false ∨ G w u = true) ∧
          (G u v = false ∨ G u w = true) := by
      simpa [dominatesCheck, Bool.and_eq_true, List.all_eq_true,
        Bool.or_eq_true, Bool.not_eq_true] using h
    refine ⟨raw.1, ?_⟩
    intro u hu
    constructor
    · intro he
      rcases (raw.2 u hu).1 with hf | ht
      · rw [he] at hf; contradiction
      · exact ht
    · intro he
      rcases (raw.2 u hu).2 with hf | ht
      · rw [he] at hf; contradiction
      · exact ht
  intro s hs hc
  by_cases hv : v ∈ s
  · have hw : w ∉ s := by
      intro hw
      have he := hc v hv w hw hh.1.1.2
      rw [hh.1.2] at he
      contradiction
    let t := insert w (s.erase v)
    have ht : Clique G t := by
      intro a ha b hbt hab
      simp only [t, Finset.mem_insert, Finset.mem_erase] at ha hbt
      rcases ha with rfl | ⟨hav, has⟩
      · rcases hbt with rfl | ⟨hbv, hbs⟩
        · exact (hab rfl).elim
        · exact (hh.2 b (hs b hbs)).1 (hc v hv b hbs hbv.symm)
      · rcases hbt with rfl | ⟨hbv, hbs⟩
        · exact (hh.2 a (hs a has)).2 (hc a has v hv hav)
        · exact hc a has b hbs hab
    have hsub : ∀ a ∈ t, a ∈ P.erase v := by
      intro a ha
      simp only [t, Finset.mem_insert, Finset.mem_erase] at ha
      rcases ha with rfl | ⟨hav, has⟩
      · exact (List.mem_erase_of_ne hh.1.1.2.symm).mpr hh.1.1.1
      · exact (List.mem_erase_of_ne hav).mpr (hs a has)
    have hbound := hb t hsub ht
    have hn : w ∉ s.erase v := fun hmem => hw (Finset.mem_of_mem_erase hmem)
    have htcard : t.card = (s.erase v).card + 1 := Finset.card_insert_of_notMem hn
    have hscard := Finset.card_erase_add_one hv
    omega
  · apply hb s ?_ hc
    intro a ha
    exact (List.mem_erase_of_ne (show a ≠ v from fun he => hv (he ▸ ha))).mpr (hs a ha)

def reducedDomain (P : List V) : List (V × V) → List V
  | [] => P
  | (v, _) :: rest => reducedDomain (P.erase v) rest

def reductionCheck (G : V → V → Bool) (P : List V) : List (V × V) → Bool
  | [] => true
  | (v, w) :: rest => dominatesCheck G P v w && reductionCheck G (P.erase v) rest

theorem reductionCheck_sound (G : V → V → Bool) (steps : List (V × V)) :
    ∀ P k, reductionCheck G P steps = true →
      Bound G (reducedDomain P steps) k → Bound G P k := by
  induction steps with
  | nil => intro P k h hb; exact hb
  | cons step rest ih =>
    obtain ⟨v,w⟩ := step
    intro P k h hb
    have hh : dominatesCheck G P v w = true ∧ reductionCheck G (P.erase v) rest = true := by
      simpa only [reductionCheck, Bool.and_eq_true] using h
    apply bound_of_dominatesCheck G P v w hh.1
    exact ih (P.erase v) k hh.2 hb

end Prize.JSP404.FiniteCliqueCertificate
