import Prize.JSP404.FiniteCliqueCertificate

/-! Relabeling direction lists by an injective map that commutes with reversal
preserves their antipodal overlap. -/
namespace Prize.JSP404.FiniteCliqueCertificate
variable {V : Type*} [DecidableEq V]

theorem antipodalOverlap_perm (a : V → V) {A A' B B' : List V}
    (hA : A.Perm A') (hB : B.Perm B') :
    A.any (fun v => B.contains (a v)) = A'.any (fun v => B'.contains (a v)) := by
  apply Bool.eq_iff_iff.mpr
  simp only [List.any_eq_true, List.contains_iff_mem, hA.mem_iff, hB.mem_iff]

theorem antipodalOverlap_map (a f : V → V) (hf : Function.Injective f)
    (ha : ∀ v, f (a v) = a (f v)) (A B : List V) :
    (A.map f).any (fun v => (B.map f).contains (a v)) =
      A.any (fun v => B.contains (a v)) := by
  apply Bool.eq_iff_iff.mpr
  simp only [List.any_eq_true, List.mem_map, List.contains_iff_mem]
  constructor
  · rintro ⟨_, ⟨x, hx, rfl⟩, y, hy, he⟩
    refine ⟨x, hx, ?_⟩
    have hxy : y = a x := hf (he.trans (ha x).symm)
    exact hxy ▸ hy
  · rintro ⟨x, hx, hax⟩
    exact ⟨f x, ⟨x, hx, rfl⟩, a x, hax, ha x⟩

end Prize.JSP404.FiniteCliqueCertificate
