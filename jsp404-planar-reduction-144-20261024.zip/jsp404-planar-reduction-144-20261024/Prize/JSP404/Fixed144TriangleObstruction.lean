import Prize.JSP404.TriangleDirection

/-!
# A three-vertex obstruction in one exploratory 144-degree arc model

These exact rational intervals are rows 7, 9, 10 (zero-based) of the fixed
21-row, diameter 43/6 model recorded in
`research/logs/jsp404-mixed144-9-12-20261022.json`.
The result excludes this candidate, not all 21-row models or the full target.
The proof uses real inequalities; the solver output is not trusted or imported.
-/

namespace Prize.JSP404.Fixed144TriangleObstruction

open ContinuousDirection

def PeriodicInterval (a b x : ℝ) : Prop :=
  ∃ k : ℤ, a ≤ x + 18 * k ∧ x + 18 * k ≤ b

def RowSeven (x : ℝ) : Prop := PeriodicInterval (71 / 5) (641 / 30) x

def RowNine (x : ℝ) : Prop :=
  PeriodicInterval (2 / 5) (59 / 30) x ∨
  PeriodicInterval (20 / 3) (227 / 30) x ∨
  PeriodicInterval (64 / 5) (83 / 6) x

def RowTen (x : ℝ) : Prop :=
  PeriodicInterval (7 / 15) (23 / 6) x ∨
  PeriodicInterval (38 / 5) (229 / 30) x ∨
  PeriodicInterval (44 / 3) (443 / 30) x

theorem periodicInterval_cases {a b x : ℝ} (ha : 0 ≤ a) (hb : b < 36)
    (hx : 0 ≤ x ∧ x < 27) (h : PeriodicInterval a b x) :
    (a ≤ x - 18 ∧ x - 18 ≤ b) ∨ (a ≤ x ∧ x ≤ b) ∨
    (a ≤ x + 18 ∧ x + 18 ≤ b) := by
  obtain ⟨k, hk⟩ := h
  have hlo : -1 ≤ k := by
    by_contra hn
    have h' : (k : ℝ) ≤ -2 := by exact_mod_cast (show k ≤ -2 by omega)
    linarith [hk.1, hx.2]
  have hhi : k ≤ 1 := by
    by_contra hn
    have h' : (2 : ℝ) ≤ k := by exact_mod_cast (show 2 ≤ k by omega)
    linarith [hk.2, hx.1]
  interval_cases k <;> norm_num at hk
  · exact Or.inl (by simpa [sub_eq_add_neg] using hk)
  · exact Or.inr (Or.inl hk)
  · exact Or.inr (Or.inr hk)

theorem edge_seven_nine {u : ℝ} (hu : 0 ≤ u ∧ u < 18)
    (h₇ : RowSeven u) (h₉ : RowNine (u + 9)) :
    47 / 3 ≤ u ∧ u ≤ 497 / 30 := by
  have H {a b : ℝ} (ha : 0 ≤ a) (hb : b < 36)
      (h : PeriodicInterval a b (u + 9)) :=
    periodicInterval_cases ha hb (by constructor <;> linarith [hu.1, hu.2]) h
  have h7 := periodicInterval_cases (by norm_num : (0 : ℝ) ≤ 71 / 5)
    (by norm_num : (641 : ℝ) / 30 < 36)
    (by constructor <;> linarith [hu.1, hu.2]) h₇
  rcases h₉ with h9 | h9 | h9 <;>
    have h9' := H (by norm_num) (by norm_num) h9 <;>
    rcases h7 with h7 | h7 | h7 <;>
    rcases h9' with h9' | h9' | h9' <;>
    constructor <;> linarith [hu.1, hu.2]

theorem edge_seven_ten {v : ℝ} (hv : 0 ≤ v ∧ v < 18)
    (h₇ : RowSeven v) (h₁₀ : RowTen (v + 9)) :
    83 / 5 ≤ v ∧ v ≤ 499 / 30 := by
  have H {a b : ℝ} (ha : 0 ≤ a) (hb : b < 36)
      (h : PeriodicInterval a b (v + 9)) :=
    periodicInterval_cases ha hb (by constructor <;> linarith [hv.1, hv.2]) h
  have h7 := periodicInterval_cases (by norm_num : (0 : ℝ) ≤ 71 / 5)
    (by norm_num : (641 : ℝ) / 30 < 36)
    (by constructor <;> linarith [hv.1, hv.2]) h₇
  rcases h₁₀ with h10 | h10 | h10 <;>
    have h10' := H (by norm_num) (by norm_num) h10 <;>
    rcases h7 with h7 | h7 | h7 <;>
    rcases h10' with h10' | h10' | h10' <;>
    constructor <;> linarith [hv.1, hv.2]

theorem edge_nine_ten {w : ℝ} (hw : 0 ≤ w ∧ w < 18)
    (h₉ : RowNine w) (h₁₀ : RowTen (w + 9)) :
    64 / 5 ≤ w ∧ w ≤ 77 / 6 := by
  have H {a b : ℝ} (ha : 0 ≤ a) (hb : b < 36)
      (h : PeriodicInterval a b w) :=
    periodicInterval_cases ha hb (by constructor <;> linarith [hw.1, hw.2]) h
  have H' {a b : ℝ} (ha : 0 ≤ a) (hb : b < 36)
      (h : PeriodicInterval a b (w + 9)) :=
    periodicInterval_cases ha hb (by constructor <;> linarith [hw.1, hw.2]) h
  rcases h₉ with h9 | h9 | h9 <;>
    have h9' := H (by norm_num) (by norm_num) h9 <;>
    rcases h₁₀ with h10 | h10 | h10 <;>
    have h10' := H' (by norm_num) (by norm_num) h10 <;>
    rcases h9' with h9' | h9' | h9' <;>
    rcases h10' with h10' | h10' | h10' <;>
    constructor <;> linarith [hw.1, hw.2]

theorem not_triangleCompatible {u v w : ℝ}
    (hu : 0 ≤ u ∧ u < 18) (hv : 0 ≤ v ∧ v < 18) (hw : 0 ≤ w ∧ w < 18)
    (hu7 : RowSeven u) (hu9 : RowNine (u + 9))
    (hv7 : RowSeven v) (hv10 : RowTen (v + 9))
    (hw9 : RowNine w) (hw10 : RowTen (w + 9)) :
    ¬ TriangleCompatible u v w := by
  obtain ⟨hulo, huhi⟩ := edge_seven_nine hu hu7 hu9
  obtain ⟨hvlo, hvhi⟩ := edge_seven_ten hv hv7 hv10
  obtain ⟨hwlo, hwhi⟩ := edge_nine_ten hw hw9 hw10
  rintro (h | h)
  · rcases (positiveTurn_iff_of_normalized hu hw).mp h.2.1 with h | h <;> linarith
  · rcases (positiveTurn_iff_of_normalized hv hu).mp h.1 with h | h <;> linarith

/-- A concrete geometric exclusion, using the exact six endpoint constraints.
The strict angle bound supplies noncollinearity rather than assuming it. -/
theorem no_complex_triangle {a b c : ℂ}
    (hab : a ≠ b) (hac : a ≠ c) (hbc : b ≠ c)
    (ha : EuclideanGeometry.angle b a c < Real.pi)
    (hb : EuclideanGeometry.angle a b c < Real.pi)
    (hc : EuclideanGeometry.angle a c b < Real.pi)
    (hu7 : RowSeven (normalizedDirection (b - a)))
    (hu9 : RowNine (normalizedDirection (b - a) + 9))
    (hv7 : RowSeven (normalizedDirection (c - a)))
    (hv10 : RowTen (normalizedDirection (c - a) + 9))
    (hw9 : RowNine (normalizedDirection (c - b)))
    (hw10 : RowTen (normalizedDirection (c - b) + 9)) : False :=
  not_triangleCompatible (normalizedDirection_bounds _) (normalizedDirection_bounds _)
    (normalizedDirection_bounds _) hu7 hu9 hv7 hv10 hw9 hw10
    (triangleCompatible_normalizedDirection hab hac hbc ha hb hc)

end Prize.JSP404.Fixed144TriangleObstruction
