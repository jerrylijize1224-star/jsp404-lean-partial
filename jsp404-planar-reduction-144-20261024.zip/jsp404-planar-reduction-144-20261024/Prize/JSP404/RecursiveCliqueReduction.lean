import Prize.JSP404.FiniteCliqueReduction

/-! Clique certificates with checked domination inside the search tree.
Every reduction retains the same bound; only a branch containing a selected
vertex reduces the remaining bound. No graph symmetry is assumed. -/
namespace Prize.JSP404.FiniteCliqueCertificate
variable {V : Type*} [DecidableEq V]

inductive ReducedCertificate (V : Type*) where
  | color : List (List V) → ReducedCertificate V
  | split : V → ReducedCertificate V → ReducedCertificate V → ReducedCertificate V
  | reduce : List (V × V) → ReducedCertificate V → ReducedCertificate V

def reducedCheck (G : V → V → Bool) (P : List V) (k : ℕ) :
    ReducedCertificate V → Bool
  | .color cs => colorCheck G P k cs
  | .split v no yes => decide (0 < k) && reducedCheck G (P.erase v) k no &&
      reducedCheck G ((P.erase v).filter (fun w => G v w)) (k-1) yes
  | .reduce steps child => reductionCheck G P steps &&
      reducedCheck G (reducedDomain P steps) k child

theorem reducedCheck_sound (G : V → V → Bool) (cert : ReducedCertificate V) :
    ∀ P k, reducedCheck G P k cert = true → Bound G P k := by
  induction cert with
  | color cs => intro P k h; exact colorCheck_sound G P k cs h
  | reduce steps child ih =>
    intro P k h
    have hh : reductionCheck G P steps = true ∧
        reducedCheck G (reducedDomain P steps) k child = true := by
      simpa only [reducedCheck, Bool.and_eq_true] using h
    exact reductionCheck_sound G steps P k hh.1 (ih _ _ hh.2)
  | split v no yes ihno ihyes =>
    intro P k h
    have hh : (0 < k ∧ reducedCheck G (P.erase v) k no = true) ∧
        reducedCheck G ((P.erase v).filter (fun w => G v w)) (k-1) yes = true := by
      simpa only [reducedCheck, Bool.and_eq_true, decide_eq_true_eq] using h
    intro s hs hc
    by_cases hv : v ∈ s
    · have he : ∀ w ∈ s.erase v, w ∈ (P.erase v).filter (fun w => G v w) := by
        intro w hw
        obtain ⟨hne, hws⟩ := Finset.mem_erase.mp hw
        exact List.mem_filter.mpr
          ⟨(List.mem_erase_of_ne hne).mpr (hs w hws), hc v hv w hws hne.symm⟩
      have hce : Clique G (s.erase v) := by
        intro a ha b hb hab
        exact hc a (Finset.mem_of_mem_erase ha) b (Finset.mem_of_mem_erase hb) hab
      have hb := ihyes _ _ hh.2 (s.erase v) he hce
      have hsize := Finset.card_erase_add_one hv
      omega
    · apply ihno _ _ hh.1.2 s ?_ hc
      intro w hw
      exact (List.mem_erase_of_ne (show w ≠ v from fun he => hv (he ▸ hw))).mpr (hs w hw)

end Prize.JSP404.FiniteCliqueCertificate
