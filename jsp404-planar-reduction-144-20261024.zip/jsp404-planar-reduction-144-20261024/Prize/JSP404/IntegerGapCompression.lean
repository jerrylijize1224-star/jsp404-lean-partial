import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Analysis.Complex.Angle
import Mathlib.Data.Fintype.Card
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Ring

/-!
# Compressing finitely many real coordinates while preserving integer gaps

Replace fractional parts by their ranks. For `n` coordinates, every strict
integer difference inequality acquires a margin at least `1 / n`. This is a
finite cutoff tool for continuous direction models, not a proof of a new angle
bound. No completeness or realizability of a three-arc model is assumed here.
-/

namespace Prize.JSP404.IntegerGapCompression

variable {V : Type*} [Fintype V]

noncomputable def fractionalRank (x : V → ℝ) (i : V) : ℕ :=
  (Finset.univ.filter (fun j => Int.fract (x j) < Int.fract (x i))).card

theorem fractionalRank_lt_card (x : V → ℝ) (i : V) :
    fractionalRank x i < Fintype.card V := by
  classical
  unfold fractionalRank
  apply Finset.card_lt_card
  refine Finset.ssubset_iff_subset_ne.mpr ⟨Finset.filter_subset _ _, ?_⟩
  intro h
  have hi : i ∈ Finset.univ.filter (fun j => Int.fract (x j) < Int.fract (x i)) :=
    by rw [h]; exact Finset.mem_univ i
  simp at hi

theorem fractionalRank_mono (x : V → ℝ) {i j : V}
    (h : Int.fract (x i) ≤ Int.fract (x j)) :
    fractionalRank x i ≤ fractionalRank x j := by
  classical
  apply Finset.card_le_card
  intro k hk
  exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, lt_of_lt_of_le (Finset.mem_filter.mp hk).2 h⟩

theorem fractionalRank_strictMono (x : V → ℝ) {i j : V}
    (h : Int.fract (x i) < Int.fract (x j)) :
    fractionalRank x i < fractionalRank x j := by
  classical
  apply Finset.card_lt_card
  refine Finset.ssubset_iff_subset_ne.mpr ⟨?_, ?_⟩
  · intro k hk
    exact Finset.mem_filter.mpr
      ⟨Finset.mem_univ _, lt_trans (Finset.mem_filter.mp hk).2 h⟩
  · intro he
    have hi : i ∈ Finset.univ.filter (fun k => Int.fract (x k) < Int.fract (x j)) :=
      Finset.mem_filter.mpr ⟨Finset.mem_univ _, h⟩
    rw [← he] at hi
    simp at hi

noncomputable def code (x : V → ℝ) (i : V) : ℤ :=
  (Fintype.card V : ℤ) * ⌊x i⌋ + fractionalRank x i

/-- Every strict difference bound by an integer becomes an integer bound with
one unit of slack after multiplying the scale by the number of coordinates. -/
theorem code_strict_gap (x : V → ℝ) (i j : V) (k : ℤ)
    (h : x i - x j < k) :
    code x i - code x j ≤ (Fintype.card V : ℤ) * k - 1 := by
  have hi := Int.floor_le (x i)
  have hj := Int.lt_floor_add_one (x j)
  have hf : ⌊x i⌋ - ⌊x j⌋ ≤ k := by
    have hr : ((⌊x i⌋ - ⌊x j⌋ : ℤ) : ℝ) < (k : ℝ) + 1 := by
      push_cast
      linarith
    have hz : ⌊x i⌋ - ⌊x j⌋ < k + 1 := by exact_mod_cast hr
    omega
  have hri := fractionalRank_lt_card x i
  have hrj := fractionalRank_lt_card x j
  have hn : 0 < Fintype.card V := lt_of_le_of_lt (Nat.zero_le _) hri
  by_cases he : ⌊x i⌋ - ⌊x j⌋ = k
  · have hfract : Int.fract (x i) < Int.fract (x j) := by
      have her : (⌊x i⌋ : ℝ) - ⌊x j⌋ = k := by exact_mod_cast he
      simp only [Int.fract]
      linarith
    have hr := fractionalRank_strictMono x hfract
    have hr' : (fractionalRank x i : ℤ) + 1 ≤ fractionalRank x j := by
      exact_mod_cast hr
    unfold code
    nlinarith
  · have hgap : ⌊x i⌋ - ⌊x j⌋ ≤ k - 1 := by omega
    have hprod := mul_le_mul_of_nonneg_left hgap (show (0 : ℤ) ≤ Fintype.card V by omega)
    unfold code
    simp only [mul_sub, mul_one] at hprod
    omega

/-- Weak integer bounds are preserved too, including order and period bounds. -/
theorem code_weak_gap (x : V → ℝ) (i j : V) (k : ℤ)
    (h : x i - x j ≤ k) :
    code x i - code x j ≤ (Fintype.card V : ℤ) * k := by
  by_cases hs : x i - x j < k
  · have := code_strict_gap x i j k hs
    omega
  · have he : x i = x j + k := by linarith
    have hf : ⌊x i⌋ = ⌊x j⌋ + k := by rw [he, Int.floor_add_intCast]
    have hfract : Int.fract (x i) = Int.fract (x j) := by
      simp only [Int.fract]
      push_cast [hf]
      linarith
    have hr : fractionalRank x i = fractionalRank x j := by
      unfold fractionalRank
      rw [hfract]
    unfold code
    rw [hf, hr]
    ring_nf
    exact le_rfl

noncomputable def compressed (x : V → ℝ) (i : V) : ℝ :=
  (code x i : ℝ) / Fintype.card V

theorem compressed_strict_gap (x : V → ℝ) (i j : V) (k : ℤ)
    (h : x i - x j < k) :
    compressed x i - compressed x j ≤ (k : ℝ) - 1 / Fintype.card V := by
  have hcard : 0 < Fintype.card V :=
    lt_of_le_of_lt (Nat.zero_le _) (fractionalRank_lt_card x i)
  have hn : (0 : ℝ) < Fintype.card V := by exact_mod_cast hcard
  have hc := code_strict_gap x i j k h
  have hcr : (code x i : ℝ) - code x j ≤ (Fintype.card V : ℝ) * k - 1 := by
    exact_mod_cast hc
  unfold compressed
  rw [← sub_div]
  apply (div_le_iff₀ hn).mpr
  have he : ((k : ℝ) - 1 / Fintype.card V) * Fintype.card V =
      (Fintype.card V : ℝ) * k - 1 := by field_simp
  rwa [he]

/-- The 27 endpoints of nine three-arc types have a common margin 1/27.
In units of 20 degrees, this is 3760/27 degrees, strictly below the already
verified 62-sector threshold. The geometry-to-model bridge is still required. -/
theorem compressed_twenty_seven_gap (x : Fin 27 → ℝ) (i j : Fin 27)
    (h : x i - x j < 7) :
    compressed x i - compressed x j ≤ (188 : ℝ) / 27 := by
  have hc := compressed_strict_gap x i j 7 (by norm_num; exact h)
  norm_num at hc ⊢
  linarith

end Prize.JSP404.IntegerGapCompression
