import Prize.JSP404.ContinuousThreeArcModel
import Prize.JSP404.Sector62Quantization

/-! Geometry of the explicit three-arc model and its 62-sector quantization.
This does not assert that every geometric direction set is a three-arc set. -/

namespace Prize.JSP404.ContinuousThreeArc

open FiniteCliqueCertificate

def Model.Mem {n : ℕ} {d : ℝ} (M : Model n d) (i : Fin n) (x : ℝ) : Prop :=
  ∃ k : Fin 3, M.start (i, k) ≤ x ∧
    x ≤ M.start (i, previous k) + d - periodOffset k

theorem Model.start_mem {n : ℕ} {d : ℝ} (M : Model n d) (i : Fin n) (k : Fin 3) :
    M.Mem i (M.start (i, k)) := ⟨k, le_rfl, M.width i k⟩

/-- Any two points in one three-arc row have circular distance at most d. -/
theorem Model.circular_close {n : ℕ} {d : ℝ} (M : Model n d) (hd : d < 9)
    (i : Fin n) {x y : ℝ} (hx : M.Mem i x) (hy : M.Mem i y) :
    ∃ z : ℤ, |x - y + 18 * z| ≤ d := by
  obtain ⟨k, hxlo, hxhi⟩ := hx
  obtain ⟨l, hylo, hyhi⟩ := hy
  have h01 := M.order01 i
  have h12 := M.order12 i
  have hp := M.period i
  have h0 := M.width i 0
  have h1 := M.width i 1
  have h2 := M.width i 2
  norm_num [previous, periodOffset] at h0 h1 h2
  fin_cases k <;> fin_cases l <;>
    norm_num [previous, periodOffset] at hxlo hxhi hylo hyhi
  · refine ⟨0, ?_⟩; norm_num only [Int.cast_zero, Int.cast_one, Int.cast_neg, mul_zero, mul_one, mul_neg_one, add_zero]; rw [abs_le]; constructor <;> linarith
  · refine ⟨0, ?_⟩; norm_num only [Int.cast_zero, Int.cast_one, Int.cast_neg, mul_zero, mul_one, mul_neg_one, add_zero]; rw [abs_le]; constructor <;> linarith
  · refine ⟨1, ?_⟩; norm_num only [Int.cast_zero, Int.cast_one, Int.cast_neg, mul_zero, mul_one, mul_neg_one, add_zero]; rw [abs_le]; constructor <;> linarith
  · refine ⟨0, ?_⟩; norm_num only [Int.cast_zero, Int.cast_one, Int.cast_neg, mul_zero, mul_one, mul_neg_one, add_zero]; rw [abs_le]; constructor <;> linarith
  · refine ⟨0, ?_⟩; norm_num only [Int.cast_zero, Int.cast_one, Int.cast_neg, mul_zero, mul_one, mul_neg_one, add_zero]; rw [abs_le]; constructor <;> linarith
  · refine ⟨0, ?_⟩; norm_num only [Int.cast_zero, Int.cast_one, Int.cast_neg, mul_zero, mul_one, mul_neg_one, add_zero]; rw [abs_le]; constructor <;> linarith
  · refine ⟨-1, ?_⟩; norm_num only [Int.cast_zero, Int.cast_one, Int.cast_neg, mul_zero, mul_one, mul_neg_one, add_zero]; rw [abs_le]; constructor <;> linarith
  · refine ⟨0, ?_⟩; norm_num only [Int.cast_zero, Int.cast_one, Int.cast_neg, mul_zero, mul_one, mul_neg_one, add_zero]; rw [abs_le]; constructor <;> linarith
  · refine ⟨0, ?_⟩; norm_num only [Int.cast_zero, Int.cast_one, Int.cast_neg, mul_zero, mul_one, mul_neg_one, add_zero]; rw [abs_le]; constructor <;> linarith

noncomputable def sector (x : ℝ) : Sector62.Sector := Sector62.intSector ⌊31 * x / 9⌋

theorem sector_period (x : ℝ) (z : ℤ) : sector (x + 18 * z) = sector x := by
  have he : 31 * (x + 18 * z) / 9 = 31 * x / 9 + ((62 * z : ℤ) : ℝ) := by
    push_cast
    ring
  unfold sector
  rw [he, Int.floor_add_intCast, Sector62.intSector_add_period]

theorem sector_antipode (x : ℝ) : sector (x + 9) = Sector62.antipode (sector x) := by
  have he : 31 * (x + 9) / 9 = 31 * x / 9 + (31 : ℤ) := by push_cast; ring
  unfold sector
  rw [he, Int.floor_add_intCast, Sector62.intSector_add_half]

theorem sector_close {x y : ℝ} (h : |x - y| ≤ (188 : ℝ) / 27) :
    Sector62.circularDistance (sector x) (sector y) ≤ 24 := by
  have hb := abs_le.mp h
  have hx := Int.floor_le (31 * x / 9)
  have hx' := Int.lt_floor_add_one (31 * x / 9)
  have hy := Int.floor_le (31 * y / 9)
  have hy' := Int.lt_floor_add_one (31 * y / 9)
  have hu : (⌊31 * x / 9⌋ : ℝ) - ⌊31 * y / 9⌋ < 25 := by linarith
  have hl : (-25 : ℝ) < (⌊31 * x / 9⌋ : ℝ) - ⌊31 * y / 9⌋ := by linarith
  have hu' : ⌊31 * x / 9⌋ - ⌊31 * y / 9⌋ < 25 := by exact_mod_cast hu
  have hl' : -25 < ⌊31 * x / 9⌋ - ⌊31 * y / 9⌋ := by exact_mod_cast hl
  exact Sector62.intSector_close _ _ (by omega) (by omega)

theorem Model.sector_close {n : ℕ} (M : Model n ((188 : ℝ) / 27))
    (i : Fin n) {x y : ℝ} (hx : M.Mem i x) (hy : M.Mem i y) :
    Sector62.circularDistance (sector x) (sector y) ≤ 24 := by
  obtain ⟨z, hz⟩ := M.circular_close (by norm_num) i hx hy
  have h := ContinuousThreeArc.sector_close (x := x + 18 * z) (y := y) (by
    rw [show x + 18 * z - y = x - y + 18 * z by ring]
    exact hz)
  rwa [sector_period] at h

theorem sector_separated {x y : ℝ}
    (hlo : (110 : ℝ) / 27 ≤ y - x) (hhi : y - x ≤ (188 : ℝ) / 27) :
    14 ≤ Sector62.circularDistance (sector x) (sector y) := by
  have hx := Int.floor_le (31 * x / 9)
  have hx' := Int.lt_floor_add_one (31 * x / 9)
  have hy := Int.floor_le (31 * y / 9)
  have hy' := Int.lt_floor_add_one (31 * y / 9)
  have hu : (⌊31 * y / 9⌋ : ℝ) - ⌊31 * x / 9⌋ < 25 := by linarith
  have hl : (13 : ℝ) < (⌊31 * y / 9⌋ : ℝ) - ⌊31 * x / 9⌋ := by linarith
  have hu' : ⌊31 * y / 9⌋ - ⌊31 * x / 9⌋ < 25 := by exact_mod_cast hu
  have hl' : 13 < ⌊31 * y / 9⌋ - ⌊31 * x / 9⌋ := by exact_mod_cast hl
  simp only [sector, Sector62.circularDistance, Sector62.intSector]
  omega

theorem Model.starts_separated {n : ℕ} (M : Model n ((188 : ℝ) / 27))
    (i : Fin n) :
    14 ≤ Sector62.circularDistance (sector (M.start (i, 0))) (sector (M.start (i, 1))) ∧
    14 ≤ Sector62.circularDistance (sector (M.start (i, 1))) (sector (M.start (i, 2))) ∧
    14 ≤ Sector62.circularDistance (sector (M.start (i, 2))) (sector (M.start (i, 0))) := by
  have h0 := M.width i 0
  have h1 := M.width i 1
  have h2 := M.width i 2
  norm_num [previous, periodOffset] at h0 h1 h2
  refine ⟨sector_separated (by linarith) (by linarith),
    sector_separated (by linarith) (by linarith), ?_⟩
  have h := sector_separated (x := M.start (i, 2)) (y := M.start (i, 0) + 18)
    (by linarith) (by linarith)
  have hp := sector_period (M.start (i, 0)) 1
  norm_num at hp
  rwa [hp] at h

end Prize.JSP404.ContinuousThreeArc
