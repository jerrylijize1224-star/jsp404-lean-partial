import Prize.JSP404.ThreeArcGeometry
import Prize.JSP404.Sector62DiscreteBound

/-! Excluding nine pairwise antipodally compatible three-arc rows by the
previously verified 62-sector certificate. The original planar classification
and the separate one-arc family are not established in this module. -/

namespace Prize.JSP404.ContinuousThreeArc

open FiniteCliqueCertificate

def arcOrigin (i : Sector62Arc.Vertex) : Sector62.Sector :=
  ⟨if i.val < 37 then i.val else 98 - i.val, by split <;> omega⟩

theorem arc_span : ∀ i : Sector62Arc.Vertex, ∀ b ∈ Sector62Arc.labels i,
    (b.val + 62 - (arcOrigin i).val) % 62 ≤ 24 := by
  decide +kernel

theorem arc_no_three_separated (i : Sector62Arc.Vertex) (a b c : Sector62.Sector)
    (ha : a ∈ Sector62Arc.labels i) (hb : b ∈ Sector62Arc.labels i)
    (hc : c ∈ Sector62Arc.labels i)
    (hab : 14 ≤ Sector62.circularDistance a b)
    (hbc : 14 ≤ Sector62.circularDistance b c)
    (hca : 14 ≤ Sector62.circularDistance c a) : False := by
  have hsa := arc_span i a ha
  have hsb := arc_span i b hb
  have hsc := arc_span i c hc
  simp only [Sector62.circularDistance, le_min_iff] at hab hbc hca
  omega

noncomputable def Model.sectors {n : ℕ} {d : ℝ} (M : Model n d) (i : Fin n) :
    Finset Sector62.Sector := by
  classical
  exact Finset.univ.filter (fun b => ∃ x, M.Mem i x ∧ sector x = b)

theorem Model.mem_sectors {n : ℕ} {d : ℝ} (M : Model n d) (i : Fin n)
    {x : ℝ} (hx : M.Mem i x) : sector x ∈ M.sectors i := by
  classical
  simp only [Model.sectors, Finset.mem_filter, Finset.mem_univ, true_and]
  exact ⟨x, hx, rfl⟩

theorem Model.sectors_clique {n : ℕ} (M : Model n ((188 : ℝ) / 27)) (i : Fin n) :
    Clique Sector62.sectorGraph (M.sectors i) := by
  classical
  intro a ha b hb hab
  obtain ⟨x, hx, rfl⟩ := (Finset.mem_filter.mp ha).2
  obtain ⟨y, hy, rfl⟩ := (Finset.mem_filter.mp hb).2
  simp [Sector62.sectorGraph, hab, M.sector_close i hx hy]

theorem Model.nonarc_cover {n : ℕ} (M : Model n ((188 : ℝ) / 27)) (i : Fin n) :
    ∃ t : Sector62Nonarc.Vertex,
      Sector62Nonarc.labels t ∈ Sector62.allTypes ∧
      ∀ x, M.Mem i x → sector x ∈ Sector62Nonarc.labels t := by
  classical
  obtain ⟨T, hT, hcover⟩ := Sector62.allTypes_cover (M.sectors i) (by simp)
    (M.sectors_clique i)
  obtain ⟨t, ht⟩ := Sector62.types_classified T hT
  cases t with
  | inl t =>
    change Sector62Nonarc.labels t = T at ht
    refine ⟨t, ht ▸ hT, ?_⟩
    intro x hx
    rw [ht]
    exact hcover _ (M.mem_sectors i hx)
  | inr t =>
    change Sector62Arc.labels t = T at ht
    have hmem (k : Fin 3) : sector (M.start (i, k)) ∈ Sector62Arc.labels t := by
      rw [ht]
      exact hcover _ (M.mem_sectors i (M.start_mem i k))
    obtain ⟨h01, h12, h20⟩ := M.starts_separated i
    exact (arc_no_three_separated t _ _ _ (hmem 0) (hmem 1) (hmem 2)
      h01 h12 h20).elim

theorem Model.antipodal_witness {n : ℕ} {d : ℝ} (M : Model n d)
    (i j : Fin n) (hij : i ≠ j) :
    ∃ x y : ℝ, M.Mem i x ∧ M.Mem j y ∧ sector y = Sector62.antipode (sector x) := by
  obtain ⟨k, l, z, h₁, h₂⟩ := M.overlap i j hij
  let shift : ℝ := 9 + 18 * z
  let x : ℝ := max (M.start (i, k)) (M.start (j, l) + shift)
  let y : ℝ := x - shift
  have hxlo : M.start (i, k) ≤ x := le_max_left _ _
  have hylo : M.start (j, l) + shift ≤ x := le_max_right _ _
  have hxhi : x ≤ M.start (i, previous k) + d - periodOffset k := by
    apply max_le
    · exact M.width i k
    · dsimp [shift]
      linarith
  have hyhi : x ≤ M.start (j, previous l) + d - periodOffset l + shift := by
    apply max_le
    · dsimp [shift]
      linarith
    · have := M.width j l
      linarith
  refine ⟨x, y, ⟨k, hxlo, hxhi⟩, ⟨l, ?_, ?_⟩, ?_⟩
  · dsimp [y]; linarith
  · dsimp [y]; linarith
  · have he : x = y + 9 + 18 * z := by dsimp [y, shift]; ring
    have hrev : sector x = Sector62.antipode (sector y) := by
      rw [he, sector_period, sector_antipode]
    rw [hrev, Sector62.antipode_involutive]

/-- The previously verified finite nonarc bound excludes the rational cutoff
model. This theorem contains no dependence on the exploratory SMT solver. -/
theorem nine_model_excluded : NineModelExcluded := by
  rintro ⟨M⟩
  classical
  let t : Fin 9 → Sector62Nonarc.Vertex := fun i => Classical.choose (M.nonarc_cover i)
  have ht (i : Fin 9) : Sector62Nonarc.labels (t i) ∈ Sector62.allTypes ∧
      ∀ x, M.Mem i x → sector x ∈ Sector62Nonarc.labels (t i) :=
    Classical.choose_spec (M.nonarc_cover i)
  have hi : Function.Injective t := by
    intro i j he
    by_contra hij
    obtain ⟨x, y, hx, hy, hrev⟩ := M.antipodal_witness i j hij
    have h₁ := (ht i).2 x hx
    have h₂ := (ht j).2 y hy
    rw [hrev, ← he] at h₂
    exact Sector62.allTypes_no_antipodes _ (ht i).1 _ h₁ h₂
  let s : Finset Sector62Nonarc.Vertex := Finset.univ.image t
  have hs : Clique Sector62Nonarc.graph s := by
    intro a ha b hb hab
    obtain ⟨i, _, rfl⟩ := Finset.mem_image.mp ha
    obtain ⟨j, _, rfl⟩ := Finset.mem_image.mp hb
    have hij : i ≠ j := fun he => hab (congrArg t he)
    obtain ⟨x, y, hx, hy, hrev⟩ := M.antipodal_witness i j hij
    have h₁ := (ht i).2 x hx
    have h₂ := (ht j).2 y hy
    rw [hrev] at h₂
    rw [Sector62Nonarc.graph_correct]
    simp only [hab, ne_eq, not_false_eq_true, decide_true, Bool.true_and, List.any_eq_true]
    exact ⟨sector x, h₁, by simpa using h₂⟩
  have hcard : s.card = 9 := by
    simpa [s] using Finset.card_image_of_injective (Finset.univ : Finset (Fin 9)) hi
  have hbound := Sector62Nonarc.clique_card_le_eight s hs
  omega

theorem no_nine_model_below_seven {d : ℝ} (hd : d < 7) : ¬ Nonempty (Model 9 d) := by
  rintro ⟨M⟩
  exact nine_model_excluded ⟨M.compress hd⟩

end Prize.JSP404.ContinuousThreeArc
