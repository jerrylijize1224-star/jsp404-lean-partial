import Prize.JSP404.Sector44NonarcData
namespace Prize.JSP404.FiniteCliqueCertificate.Sector44Nonarc
set_option maxRecDepth 65536
set_option maxHeartbeats 0
set_option Elab.async false
theorem graph_correct_check10 : (List.range 44).all (fun a => (List.range 528).all (fun b =>
    let i := vertex (44*10+a); let j := vertex b; decide (graph i j = (decide (i ≠ j) && (labels i).any (fun b => (labels j).contains (Sector44.antipode b)))))) = true := by decide +kernel
theorem shift_preserves_check10 : (List.range 44).all (fun a => (List.range 528).all (fun b =>
    let i := vertex (44*10+a); let j := vertex b; decide (graph i j = true → graph (shift i) (shift j) = true))) = true := by decide +kernel
end Prize.JSP404.FiniteCliqueCertificate.Sector44Nonarc
