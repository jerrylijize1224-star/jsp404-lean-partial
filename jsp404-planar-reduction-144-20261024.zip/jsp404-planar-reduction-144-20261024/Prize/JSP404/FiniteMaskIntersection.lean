import Mathlib.Data.Nat.Bitwise
import Mathlib.Data.Fin.Basic

/-! A bounded bit mask represents exactly the predicates checked at its bits.
This lets large finite graph checks use masks without trusting their exporter. -/
namespace Prize.JSP404.FiniteCliqueCertificate

theorem mask_intersects_iff {m a b : ℕ} (ha : a < 2 ^ m)
    (P Q : Fin m → Prop) [DecidablePred P] [DecidablePred Q]
    (hP : ∀ i, a.testBit i.val = decide (P i))
    (hQ : ∀ i, b.testBit i.val = decide (Q i)) :
    a &&& b ≠ 0 ↔ ∃ i, P i ∧ Q i := by
  constructor
  · intro hn
    by_contra he
    apply hn
    apply Nat.eq_of_testBit_eq
    intro i
    rw [Nat.testBit_and]
    by_cases hi : i < m
    · have hn' : ¬ (P ⟨i, hi⟩ ∧ Q ⟨i, hi⟩) := fun h => he ⟨⟨i, hi⟩, h⟩
      rw [hP ⟨i, hi⟩, hQ ⟨i, hi⟩]
      by_cases hp : P ⟨i, hi⟩
      · have hq : ¬ Q ⟨i, hi⟩ := fun hq => hn' ⟨hp, hq⟩
        simp [hp, hq]
      · simp [hp]
    · have hp : 2 ^ m ≤ 2 ^ i := Nat.pow_le_pow_right (by decide) (by omega)
      simp only [Nat.testBit_lt_two_pow (ha.trans_le hp), Bool.false_and, Nat.zero_testBit]
  · rintro ⟨i, hp, hq⟩ hz
    have hb : (a &&& b).testBit i.val = true := by
      simp only [Nat.testBit_and, hP, hQ, hp, hq, decide_true, Bool.true_and]
    simp [hz] at hb

end Prize.JSP404.FiniteCliqueCertificate
