import Prize.JSP404.Sector62NonarcGraph
import Prize.JSP404.MaskCliqueReduction

namespace Prize.JSP404.FiniteCliqueCertificate.Sector62Nonarc

theorem graph_rows (v u : Vertex) : graph v u = (rows v.val).testBit u.val := by
  simp only [graph, Nat.testBit_eq_decide_div_mod_eq]

theorem graph_symmetric (v u : Vertex) : graph v u = graph u v := by
  apply Bool.eq_iff_iff.mpr
  simp only [graph_correct, Bool.and_eq_true, decide_eq_true_eq,
    List.any_eq_true, List.contains_iff_mem]
  constructor
  · rintro ⟨hne, b, hb, ha⟩
    exact ⟨hne.symm, Sector62.antipode b, ha, by
      simpa only [Sector62.antipode_involutive b] using hb⟩
  · rintro ⟨hne, b, hb, ha⟩
    exact ⟨hne.symm, Sector62.antipode b, ha, by
      simpa only [Sector62.antipode_involutive b] using hb⟩

end Prize.JSP404.FiniteCliqueCertificate.Sector62Nonarc
