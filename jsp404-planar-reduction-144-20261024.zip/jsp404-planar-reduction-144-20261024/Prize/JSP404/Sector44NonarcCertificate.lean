import Prize.JSP404.Sector44NonarcRoot0
import Prize.JSP404.Sector44NonarcRoot1
import Prize.JSP404.Sector44NonarcRoot3
import Prize.JSP404.Sector44NonarcRoot4
import Prize.JSP404.Sector44NonarcRoot7
import Prize.JSP404.Sector44NonarcRoot9
import Prize.JSP404.Sector44NonarcRoot10
import Prize.JSP404.Sector44NonarcRoot14
import Prize.JSP404.Sector44NonarcRoot17
import Prize.JSP404.Sector44NonarcRoot19
import Prize.JSP404.Sector44NonarcRoot25
import Prize.JSP404.Sector44NonarcRoot29

namespace Prize.JSP404.FiniteCliqueCertificate.Sector44Nonarc
theorem clique_card_le_eight (s : Finset Vertex) (hs : Clique graph s) : s.card ≤ 8 := by
  apply bound_of_orbit_neighbors graph shift shift_injective shift_preserves representatives ?_ 7 ?_ s hs
  · intro v
    obtain ⟨r, hr⟩ := orbit_covers v
    exact ⟨r.val, hr⟩
  · intro r hr t ht hn
    simp only [representatives, List.mem_cons, List.not_mem_nil, or_false] at hr
    rcases hr with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact root_bound0 t (fun v hv => neighbors_complete0 v (hn v hv)) ht
    · exact root_bound1 t (fun v hv => neighbors_complete1 v (hn v hv)) ht
    · exact root_bound3 t (fun v hv => neighbors_complete3 v (hn v hv)) ht
    · exact root_bound4 t (fun v hv => neighbors_complete4 v (hn v hv)) ht
    · exact root_bound7 t (fun v hv => neighbors_complete7 v (hn v hv)) ht
    · exact root_bound9 t (fun v hv => neighbors_complete9 v (hn v hv)) ht
    · exact root_bound10 t (fun v hv => neighbors_complete10 v (hn v hv)) ht
    · exact root_bound14 t (fun v hv => neighbors_complete14 v (hn v hv)) ht
    · exact root_bound17 t (fun v hv => neighbors_complete17 v (hn v hv)) ht
    · exact root_bound19 t (fun v hv => neighbors_complete19 v (hn v hv)) ht
    · exact root_bound25 t (fun v hv => neighbors_complete25 v (hn v hv)) ht
    · exact root_bound29 t (fun v hv => neighbors_complete29 v (hn v hv)) ht
end Prize.JSP404.FiniteCliqueCertificate.Sector44Nonarc
