import Prize.JSP404.FiniteCliqueCover

/-! Type-cover certificates with explicit indices and accumulated required
vertices. A leaf checks its complete obligation instead of repeatedly filtering
the full type list at every branch. -/
namespace Prize.JSP404.FiniteCliqueCertificate
variable {V I : Type*} [DecidableEq V]

inductive IndexedCoverCertificate (V I : Type*) where
  | leaf : I → IndexedCoverCertificate V I
  | split : V → IndexedCoverCertificate V I → IndexedCoverCertificate V I →
      IndexedCoverCertificate V I

def indexedCoverCheck (G : V → V → Bool) (labels : I → List V)
    (P required : List V) : IndexedCoverCertificate V I → Bool
  | .leaf i => P.all (fun v => (labels i).contains v) &&
      required.all (fun v => (labels i).contains v)
  | .split v no yes => indexedCoverCheck G labels (P.erase v) required no &&
      indexedCoverCheck G labels ((P.erase v).filter (fun w => G v w))
        (v :: required) yes

theorem indexedCoverCheck_sound (G : V → V → Bool) (labels : I → List V)
    (cert : IndexedCoverCertificate V I) :
    ∀ P required, indexedCoverCheck G labels P required cert = true →
      ∀ s : Finset V, (∀ v ∈ s, v ∈ P) → Clique G s →
      ∃ i, (∀ v ∈ required, v ∈ labels i) ∧ ∀ v ∈ s, v ∈ labels i := by
  induction cert with
  | leaf i =>
    intro P required h s hs hc
    have hh : (∀ v ∈ P, v ∈ labels i) ∧ ∀ v ∈ required, v ∈ labels i := by
      simpa [indexedCoverCheck, Bool.and_eq_true, List.all_eq_true] using h
    exact ⟨i, hh.2, fun v hv => hh.1 v (hs v hv)⟩
  | split v no yes ihno ihyes =>
    intro P required h s hs hc
    have hh : indexedCoverCheck G labels (P.erase v) required no = true ∧
        indexedCoverCheck G labels ((P.erase v).filter (fun w => G v w))
          (v :: required) yes = true := by
      simpa only [indexedCoverCheck, Bool.and_eq_true] using h
    by_cases hv : v ∈ s
    · have he : ∀ w ∈ s.erase v, w ∈ (P.erase v).filter (fun w => G v w) := by
        intro w hw
        obtain ⟨hne, hws⟩ := Finset.mem_erase.mp hw
        exact List.mem_filter.mpr
          ⟨(List.mem_erase_of_ne hne).mpr (hs w hws), hc v hv w hws hne.symm⟩
      have hce : Clique G (s.erase v) := by
        intro a ha b hb hab
        exact hc a (Finset.mem_of_mem_erase ha) b (Finset.mem_of_mem_erase hb) hab
      obtain ⟨i, hr, hcov⟩ := ihyes _ _ hh.2 (s.erase v) he hce
      refine ⟨i, fun w hw => hr w (List.mem_cons_of_mem v hw), ?_⟩
      intro w hw
      by_cases hwv : w = v
      · exact hwv ▸ hr v (by simp)
      · exact hcov w (Finset.mem_erase.mpr ⟨hwv, hw⟩)
    · apply ihno _ _ hh.1 s ?_ hc
      intro w hw
      exact (List.mem_erase_of_ne (show w ≠ v from fun he => hv (he ▸ hw))).mpr (hs w hw)

end Prize.JSP404.FiniteCliqueCertificate
