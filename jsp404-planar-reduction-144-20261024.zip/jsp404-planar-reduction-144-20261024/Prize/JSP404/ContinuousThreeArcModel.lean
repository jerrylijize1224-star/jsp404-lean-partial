import Prize.JSP404.IntegerGapCompression
import Mathlib.Data.Fintype.Prod
import Mathlib.Tactic.FinCases

/-!
# A finite cutoff for the continuous three-arc model

The circle has circumference 18, antipodal shift 9, and target diameter 7.
Each row has three starts a < b < c < a+18 and arcs
[a,c+d-18], [b,a+d], [c,b+d]. Pairwise antipodal intersection is explicit.

The definitions below are an intermediate model. It is NOT yet proved that
every relevant geometric direction set has this form, or that a nine-row
model is impossible. The compression theorem is unconditional on any solver.
-/

namespace Prize.JSP404.ContinuousThreeArc

def previous (k : Fin 3) : Fin 3 := ⟨(k.val + 2) % 3, Nat.mod_lt _ (by decide)⟩

def periodOffset (k : Fin 3) : ℤ := if k = 0 then 18 else 0

structure Model (n : ℕ) (d : ℝ) where
  start : Fin n × Fin 3 → ℝ
  order01 : ∀ i, start (i, 0) < start (i, 1)
  order12 : ∀ i, start (i, 1) < start (i, 2)
  period : ∀ i, start (i, 2) < start (i, 0) + 18
  width : ∀ i k, start (i, k) ≤ start (i, previous k) + d - periodOffset k
  overlap : ∀ i j, i ≠ j → ∃ k l : Fin 3, ∃ z : ℤ,
    start (i, k) ≤ start (j, previous l) + d - periodOffset l + 9 + 18 * z ∧
    start (j, l) + 9 + 18 * z ≤ start (i, previous k) + d - periodOffset k

open IntegerGapCompression

theorem compressed27_gap (x : Fin 9 × Fin 3 → ℝ)
    (i j : Fin 9 × Fin 3) (k : ℤ) (h : x i - x j < k) :
    compressed x i - compressed x j ≤ (k : ℝ) - 1 / 27 := by
  simpa using compressed_strict_gap x i j k h

/-- Any nine-row model strictly below 140 degrees can be compressed to the
single diameter 188/27 in units of 20 degrees. No numerical solver is used. -/
noncomputable def Model.compress {d : ℝ} (M : Model 9 d) (hd : d < 7) :
    Model 9 ((188 : ℝ) / 27) where
  start := compressed M.start
  order01 := by
    intro i
    have h := compressed27_gap M.start (i, 0) (i, 1) 0 (by
      have := M.order01 i
      norm_num
      linarith)
    norm_num at h
    linarith
  order12 := by
    intro i
    have h := compressed27_gap M.start (i, 1) (i, 2) 0 (by
      have := M.order12 i
      norm_num
      linarith)
    norm_num at h
    linarith
  period := by
    intro i
    have h := compressed27_gap M.start (i, 2) (i, 0) 18 (by
      have := M.period i
      norm_num
      linarith)
    norm_num at h
    linarith
  width := by
    intro i k
    have h := compressed27_gap M.start (i, k) (i, previous k) (7 - periodOffset k) (by
      have := M.width i k
      push_cast
      linarith)
    push_cast at h
    linarith
  overlap := by
    intro i j hij
    obtain ⟨k, l, z, h₁, h₂⟩ := M.overlap i j hij
    refine ⟨k, l, z, ?_, ?_⟩
    · have h := compressed27_gap M.start (i, k) (j, previous l)
        (16 - periodOffset l + 18 * z) (by push_cast; linarith)
      push_cast at h
      linarith
    · have h := compressed27_gap M.start (j, l) (i, previous k)
        (-2 - periodOffset k - 18 * z) (by push_cast; linarith)
      push_cast at h
      linarith

/-- A continuum of possible countermodels reduces to one fixed rational
diameter. Neither side of this equivalence is asserted to be inhabited. -/
theorem nine_model_cutoff :
    (∃ d : ℝ, d < 7 ∧ Nonempty (Model 9 d)) ↔
      Nonempty (Model 9 ((188 : ℝ) / 27)) := by
  constructor
  · rintro ⟨d, hd, ⟨M⟩⟩
    exact ⟨M.compress hd⟩
  · intro h
    exact ⟨188 / 27, by norm_num, h⟩

/-- This is the unresolved finite-model obligation, not a theorem stub. -/
def NineModelExcluded : Prop := ¬ Nonempty (Model 9 ((188 : ℝ) / 27))

end Prize.JSP404.ContinuousThreeArc
