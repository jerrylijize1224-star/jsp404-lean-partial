import Mathlib.GroupTheory.Perm.Sign
import Mathlib.Data.Fintype.EquivFin

/-! Abstract parity of nineteen occupied labels and one empty slot.
This module contains no assertion that the geometric event sweep exists. -/
namespace Prize.JSP404.ThreeArcParity

open Equiv

variable {L T : Type*}

/-- Exactly one occupied label moves; the empty label may move as well. -/
def SingleChange (p q : L ≃ T) (hole : L) : Prop :=
  ∃ r, r ≠ hole ∧ q r ≠ p r ∧ ∀ x, x ≠ r → x ≠ hole → q x = p x

theorem singleChange_eq_swap_trans [DecidableEq L] {p q : L ≃ T} {hole : L}
    (h : SingleChange p q hole) :
    ∃ r, r ≠ hole ∧ q = (swap r hole).trans p := by
  obtain ⟨r, hr, hmove, hfix⟩ := h
  have hrow : q r = p hole := by
    obtain ⟨x, hx⟩ := p.surjective (q r)
    by_cases hxr : x = r
    · subst x
      exact False.elim (hmove hx.symm)
    by_cases hxh : x = hole
    · subst x
      exact hx.symm
    have hqr : q x = q r := (hfix x hxr hxh).trans hx
    exact False.elim (hxr (q.injective hqr))
  have hhole : q hole = p r := by
    obtain ⟨x, hx⟩ := p.surjective (q hole)
    by_cases hxr : x = r
    · subst x
      exact hx.symm
    by_cases hxh : x = hole
    · subst x
      have hqr : q r = q hole := hrow.trans hx
      exact False.elim (hr (q.injective hqr))
    have hqh : q x = q hole := (hfix x hxr hxh).trans hx
    exact False.elim (hxh (q.injective hqh))
  refine ⟨r, hr, ?_⟩
  ext x
  by_cases hxr : x = r
  · subst x
    simpa using hrow
  by_cases hxh : x = hole
  · subst x
    simpa using hhole
  simpa [swap_apply_of_ne_of_ne hxr hxh] using hfix x hxr hxh

theorem singleChange_sign [Fintype L] [DecidableEq L]
    {p q : L ≃ T} {hole : L} (h : SingleChange p q hole) (e : L ≃ T) :
    Equiv.Perm.sign (q.trans e.symm) = Equiv.Perm.sign (p.trans e.symm) * (-1) := by
  obtain ⟨r, hr, rfl⟩ := singleChange_eq_swap_trans h
  rw [Equiv.trans_assoc, Equiv.Perm.sign_trans, Equiv.Perm.sign_swap hr]

theorem sign_after_changes [Fintype L] [DecidableEq L]
    (P : ℕ → L ≃ T) (hole : L) (e : L ≃ T) {n : ℕ}
    (hstep : ∀ k, k < n → SingleChange (P k) (P (k + 1)) hole) :
    Equiv.Perm.sign ((P n).trans e.symm) =
      (-1) ^ n * Equiv.Perm.sign ((P 0).trans e.symm) := by
  have h : ∀ k, k ≤ n → Equiv.Perm.sign ((P k).trans e.symm) =
      (-1) ^ k * Equiv.Perm.sign ((P 0).trans e.symm) := by
    intro k
    induction k with
    | zero => intro _; simp
    | succ k ih =>
      intro hk
      rw [singleChange_sign (hstep k (by omega)) e, ih (by omega), pow_succ]
      ac_rfl
  exact h n le_rfl

/-- Fifty-seven single-label changes cannot finish by an even rotation. -/
theorem no_fiftyseven_changes [Fintype L] [DecidableEq L]
    [Fintype T] [DecidableEq T] (P : ℕ → L ≃ T) (hole : L)
    (rotation : Equiv.Perm T) (hrotation : Equiv.Perm.sign rotation = 1)
    (hstep : ∀ k, k < 57 → SingleChange (P k) (P (k + 1)) hole)
    (hend : P 57 = (P 0).trans rotation) : False := by
  have h := sign_after_changes P hole (P 0) hstep
  rw [hend, Equiv.Perm.sign_trans_trans_symm] at h
  norm_num [hrotation] at h
  have hp : ((-1 : ℤˣ) ^ 57) = -1 := by decide +kernel
  rw [hp] at h
  have hz := congrArg (fun u : ℤˣ => (u : ℤ)) h
  norm_num at hz

theorem exists_missing {T : Type*} [Fintype T]
    (f : Fin 19 → T) (hf : Function.Injective f) (hT : Fintype.card T = 20) :
    ∃ t : T, ∀ i, f i ≠ t := by
  classical
  obtain ⟨t, ht, _⟩ :=
    Fintype.existsUnique_notMem_image_of_injective_of_card_eq_add_one f hf
      (by simp [hT])
  refine ⟨t, ?_⟩
  intro i he
  exact ht (Finset.mem_image.mpr ⟨i, Finset.mem_univ _, he⟩)

noncomputable def missing {T : Type*} [Fintype T]
    (f : Fin 19 → T) (hf : Function.Injective f) (hT : Fintype.card T = 20) : T :=
  Classical.choose (exists_missing f hf hT)

theorem missing_ne {T : Type*} [Fintype T]
    (f : Fin 19 → T) (hf : Function.Injective f) (hT : Fintype.card T = 20) (i : Fin 19) :
    f i ≠ missing f hf hT := Classical.choose_spec (exists_missing f hf hT) i

noncomputable def completionMap {T : Type*} [Fintype T]
    (f : Fin 19 → T) (hf : Function.Injective f) (hT : Fintype.card T = 20) : Fin 20 → T :=
  Fin.lastCases (missing f hf hT) f

theorem completionMap_injective {T : Type*} [Fintype T]
    (f : Fin 19 → T) (hf : Function.Injective f) (hT : Fintype.card T = 20) :
    Function.Injective (completionMap f hf hT) := by
  intro i
  refine Fin.lastCases ?_ (fun i => ?_) i
  · intro j
    refine Fin.lastCases ?_ (fun j => ?_) j
    · intro _; rfl
    · intro h
      exact False.elim (missing_ne f hf hT j (by
        simpa only [completionMap, Fin.lastCases_last, Fin.lastCases_castSucc] using h.symm))
  · intro j
    refine Fin.lastCases ?_ (fun j => ?_) j
    · intro h
      exact False.elim (missing_ne f hf hT i (by
        simpa only [completionMap, Fin.lastCases_last, Fin.lastCases_castSucc] using h))
    · intro h
      exact congrArg Fin.castSucc (hf (by simpa [completionMap] using h))

noncomputable def completion {T : Type*} [Fintype T]
    (f : Fin 19 → T) (hf : Function.Injective f) (hT : Fintype.card T = 20) : Fin 20 ≃ T :=
  Equiv.ofBijective (completionMap f hf hT)
    ((Fintype.bijective_iff_injective_and_card _).mpr
      ⟨completionMap_injective f hf hT, by simpa using hT.symm⟩)

@[simp] theorem completion_castSucc {T : Type*} [Fintype T]
    (f : Fin 19 → T) (hf : Function.Injective f) (hT : Fintype.card T = 20) (i : Fin 19) :
    completion f hf hT i.castSucc = f i := by
  simp [completion, completionMap]

@[simp] theorem completion_last {T : Type*} [Fintype T]
    (f : Fin 19 → T) (hf : Function.Injective f) (hT : Fintype.card T = 20) :
    completion f hf hT (Fin.last 19) = missing f hf hT := by
  change (Fin.lastCases (missing f hf hT) f (Fin.last 19) : T) = missing f hf hT
  exact Fin.lastCases_last

theorem equiv_eq_of_agree_off (p q : L ≃ T) (hole : L)
    (h : ∀ x, x ≠ hole → p x = q x) : p = q := by
  ext x
  by_cases hx : x = hole
  · subst x
    obtain ⟨i, hi⟩ := q.surjective (p hole)
    by_cases hie : i = hole
    · subst i; exact hi.symm
    have hip : p i = p hole := (h i hie).trans hi
    exact False.elim (hie (p.injective hip))
  · exact h x hx

theorem equiv_eq_of_agree_castSucc {T : Type*} (p q : Fin 20 ≃ T)
    (h : ∀ i : Fin 19, p i.castSucc = q i.castSucc) : p = q := by
  apply equiv_eq_of_agree_off p q (Fin.last 19)
  intro x
  refine Fin.lastCases ?_ (fun i => ?_) x
  · intro hne; exact False.elim (hne rfl)
  · intro _; exact h i

theorem completion_singleChange {T : Type*} [Fintype T]
    (f g : Fin 19 → T) (hf : Function.Injective f) (hg : Function.Injective g)
    (hT : Fintype.card T = 20) (r : Fin 19) (hmove : g r ≠ f r)
    (hfix : ∀ i, i ≠ r → g i = f i) :
    SingleChange (completion f hf hT) (completion g hg hT) (Fin.last 19) := by
  refine ⟨r.castSucc, ne_of_lt (Fin.castSucc_lt_last r), ?_, ?_⟩
  · simpa using hmove
  · intro x hxr hxh
    obtain ⟨i, rfl⟩ := Fin.exists_castSucc_eq.mpr hxh
    have hir : i ≠ r := fun hi => hxr (congrArg Fin.castSucc hi)
    simpa using hfix i hir

theorem completion_rotated {T : Type*} [Fintype T]
    (f g : Fin 19 → T) (hf : Function.Injective f) (hg : Function.Injective g)
    (hT : Fintype.card T = 20) (rotation : Equiv.Perm T)
    (h : ∀ i, g i = rotation (f i)) :
    completion g hg hT = (completion f hf hT).trans rotation := by
  apply equiv_eq_of_agree_castSucc
  intro i
  simpa using h i

/-- Interface for a discrete sweep: nineteen distinct occupied masks, one
changed row at each of fifty-seven steps, and an even final mask rotation. -/
theorem no_fiftyseven_injective_sweep {T : Type*} [Fintype T] [DecidableEq T]
    (f : ℕ → Fin 19 → T) (hf : ∀ k, Function.Injective (f k))
    (hT : Fintype.card T = 20) (rotation : Equiv.Perm T)
    (hrotation : Equiv.Perm.sign rotation = 1)
    (hstep : ∀ k, k < 57 → ∃ r : Fin 19,
      f (k + 1) r ≠ f k r ∧ ∀ i, i ≠ r → f (k + 1) i = f k i)
    (hend : ∀ i, f 57 i = rotation (f 0 i)) : False := by
  let P (k : ℕ) : Fin 20 ≃ T := completion (f k) (hf k) hT
  apply no_fiftyseven_changes P (Fin.last 19) rotation hrotation
  · intro k hk
    obtain ⟨r, hm, hs⟩ := hstep k hk
    exact completion_singleChange (f k) (f (k + 1)) (hf k) (hf (k + 1)) hT r hm hs
  · exact completion_rotated (f 0) (f 57) (hf 0) (hf 57) hT rotation hend

end Prize.JSP404.ThreeArcParity
