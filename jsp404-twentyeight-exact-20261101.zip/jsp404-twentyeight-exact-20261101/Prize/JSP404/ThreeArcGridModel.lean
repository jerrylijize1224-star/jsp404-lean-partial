import Prize.JSP404.ThreeArcPhaseGrid
import Prize.JSP404.ThreeArcPerturb
import Prize.JSP404.ThreeArcGeneric

/-! A strict continuous three-arc family gives a half-shifted grid family
with 57 distinct endpoint residues. All translations in the finite sweep
retain the original pairwise antipodal intersections. -/
namespace Prize.JSP404.ThreeArcGrid
open ContinuousDirection

def modelOfRows {d : ℝ} (R : Fin 19 → ThreeArcRow d)
    (hpair : ∀ i j, i ≠ j → ∃ x y : ℝ, ∃ z : ℤ,
      (R i).Mem x ∧ (R j).Mem y ∧ y = x + 9 + 18 * z) :
    ContinuousThreeArc.Model 19 d where
  start := fun p => (R p.1).start p.2
  order01 := by intro i; simpa [ThreeArcRow.start] using (R i).ab
  order12 := by intro i; simpa [ThreeArcRow.start] using (R i).bc
  period := by intro i; simpa [ThreeArcRow.start] using (R i).ca
  width := by
    intro i k
    fin_cases k
    · simpa [ThreeArcRow.start, ContinuousThreeArc.previous,
        ContinuousThreeArc.periodOffset] using (R i).width0
    · simpa [ThreeArcRow.start, ContinuousThreeArc.previous,
        ContinuousThreeArc.periodOffset] using (R i).width1
    · simpa [ThreeArcRow.start, ContinuousThreeArc.previous,
        ContinuousThreeArc.periodOffset] using (R i).width2
  overlap := by
    intro i j hij
    obtain ⟨x, y, z, hx, hy, hxy⟩ := hpair i j hij
    obtain ⟨k, hk⟩ := (R i).mem_start hx
    obtain ⟨l, hl⟩ := (R j).mem_start hy
    refine ⟨k, l, -z - 1, ?_, ?_⟩ <;> push_cast <;>
      linarith [hk.1, hk.2, hl.1, hl.2]

def scaledOffset (k : Fin 3) : ℤ := if k = 0 then 10 else 0

theorem offset_scaled (k : Fin 3) :
    (9 : ℝ) / 5 * scaledOffset k = ContinuousThreeArc.periodOffset k := by
  fin_cases k <;> norm_num [scaledOffset, ContinuousThreeArc.periodOffset]

noncomputable def scaledFinite {d : ℝ} (M : ContinuousThreeArc.Model 19 d)
    (i : Fin 57) : ℝ := 5 * M.start (indexEquiv.symm i) / 9

noncomputable def codePoint {d : ℝ} (M : ContinuousThreeArc.Model 19 d) (p : Point) : ℤ :=
  ThreeArcGeneric.code (scaledFinite M) (indexEquiv p)

theorem codePoint_residues {d : ℝ} (M : ContinuousThreeArc.Model 19 d) :
    Function.Injective (fun p => codePoint M p % 57) := by
  intro p q h
  apply indexEquiv.injective
  apply ThreeArcGeneric.code_residues_injective (scaledFinite M)
  exact h

theorem codePoint_gap {d : ℝ} (M : ContinuousThreeArc.Model 19 d)
    (p q : Point) (k : ℤ)
    (h : 5 * M.start p / 9 - 5 * M.start q / 9 < k) :
    codePoint M p - codePoint M q ≤ 57 * k - 1 := by
  apply ThreeArcGeneric.code_strict_gap (scaledFinite M) (indexEquiv p) (indexEquiv q) k
  simpa only [scaledFinite, Equiv.symm_apply_apply] using h

theorem coordinate_gap_bound {d : ℝ} (M : ContinuousThreeArc.Model 19 d)
    (p q : Point) (k : ℤ)
    (h : 5 * M.start p / 9 - 5 * M.start q / 9 < k) :
    coordinate (codePoint M p) - coordinate (codePoint M q) ≤ (9 : ℝ) / 5 * k - 3 / 95 := by
  have hc := codePoint_gap M p q k h
  have hcR : (codePoint M p : ℝ) - codePoint M q ≤ 57 * (k : ℝ) - 1 := by
    exact_mod_cast hc
  rw [coordinate_gap]
  linarith

noncomputable def compressModel {d : ℝ} (M : ContinuousThreeArc.Model 19 d)
    (hd : d < 36 / 5) : ContinuousThreeArc.Model 19 (681 / 95) where
  start := fun p => coordinate (codePoint M p)
  order01 := by
    intro i
    have h := coordinate_gap_bound M (i, 0) (i, 1) 0 (by
      norm_num
      linarith [M.order01 i])
    norm_num at h
    linarith
  order12 := by
    intro i
    have h := coordinate_gap_bound M (i, 1) (i, 2) 0 (by
      norm_num
      linarith [M.order12 i])
    norm_num at h
    linarith
  period := by
    intro i
    have h := coordinate_gap_bound M (i, 2) (i, 0) 10 (by
      norm_num
      linarith [M.period i])
    norm_num at h
    linarith
  width := by
    intro i k
    have ho := offset_scaled k
    have h := coordinate_gap_bound M (i, k) (i, ContinuousThreeArc.previous k)
      (4 - scaledOffset k) (by
        push_cast
        linarith [M.width i k])
    push_cast at h
    linarith
  overlap := by
    intro i j hij
    obtain ⟨k, l, z, hk, hl⟩ := M.overlap i j hij
    have hok := offset_scaled k
    have hol := offset_scaled l
    refine ⟨k, l, z, ?_, ?_⟩
    · have h := coordinate_gap_bound M (i, k) (j, ContinuousThreeArc.previous l)
        (9 - scaledOffset l + 10 * z) (by push_cast; linarith)
      push_cast at h
      linarith
    · have h := coordinate_gap_bound M (j, l) (i, ContinuousThreeArc.previous k)
        (-1 - scaledOffset k - 10 * z) (by push_cast; linarith)
      push_cast at h
      linarith

def rowOfModel {d : ℝ} (M : ContinuousThreeArc.Model 19 d) (i : Fin 19) : ThreeArcRow d where
  a := M.start (i, 0)
  b := M.start (i, 1)
  c := M.start (i, 2)
  ab := M.order01 i
  bc := M.order12 i
  ca := M.period i
  width0 := by
    have h := M.width i 0
    simpa [ContinuousThreeArc.previous, ContinuousThreeArc.periodOffset, sub_le_iff_le_add] using h
  width1 := by
    simpa [ContinuousThreeArc.previous, ContinuousThreeArc.periodOffset] using M.width i 1
  width2 := by
    simpa [ContinuousThreeArc.previous, ContinuousThreeArc.periodOffset] using M.width i 2

theorem rowOfModel_start {d : ℝ} (M : ContinuousThreeArc.Model 19 d) (i : Fin 19) (k : Fin 3) :
    (rowOfModel M i).start k = M.start (i, k) := by
  fin_cases k <;> simp [rowOfModel, ThreeArcRow.start]

theorem rowOfModel_mem {d : ℝ} (M : ContinuousThreeArc.Model 19 d) (i : Fin 19) {x : ℝ}
    (h : M.Mem i x) : (rowOfModel M i).Mem x := by
  obtain ⟨k, hlo, hhi⟩ := h
  fin_cases k
  · exact Or.inl ⟨hlo, by simpa [rowOfModel, ContinuousThreeArc.previous,
      ContinuousThreeArc.periodOffset] using hhi⟩
  · exact Or.inr (Or.inl ⟨hlo, by simpa [rowOfModel, ContinuousThreeArc.previous,
      ContinuousThreeArc.periodOffset] using hhi⟩)
  · exact Or.inr (Or.inr ⟨hlo, by simpa [rowOfModel, ContinuousThreeArc.previous,
      ContinuousThreeArc.periodOffset] using hhi⟩)

theorem rowOfModel_pair {d : ℝ} (M : ContinuousThreeArc.Model 19 d) :
    ∀ i j, i ≠ j → ∃ x y : ℝ, ∃ z : ℤ,
      (rowOfModel M i).Mem x ∧ (rowOfModel M j).Mem y ∧ y = x + 9 + 18 * z := by
  intro i j hij
  obtain ⟨k, l, z, h₁, h₂⟩ := M.overlap i j hij
  let shift : ℝ := 9 + 18 * z
  let x : ℝ := max (M.start (i, k)) (M.start (j, l) + shift)
  let y : ℝ := x - shift
  have hxlo : M.start (i, k) ≤ x := le_max_left _ _
  have hylo : M.start (j, l) + shift ≤ x := le_max_right _ _
  have hxhi : x ≤ M.start (i, ContinuousThreeArc.previous k) + d -
      ContinuousThreeArc.periodOffset k := by
    apply max_le
    · exact M.width i k
    · dsimp [shift]; linarith
  have hyhi : x ≤ M.start (j, ContinuousThreeArc.previous l) + d -
      ContinuousThreeArc.periodOffset l + shift := by
    apply max_le
    · dsimp [shift]; linarith
    · have := M.width j l; linarith
  refine ⟨x, y, -z - 1, rowOfModel_mem M i ⟨k, hxlo, hxhi⟩,
    rowOfModel_mem M j ⟨l, ?_, ?_⟩, ?_⟩
  · dsimp [y]; linarith
  · dsimp [y]; linarith
  · dsimp [y, shift]; push_cast; ring

structure Family where
  code : Point → ℤ
  residues : Function.Injective (fun p => code p % 57)
  rows : ℤ → Fin 19 → ThreeArcRow (681 / 95)
  start_eq : ∀ k i j, (rows k i).start j = coordinate (code (i, j) + k)
  pair : ∀ k i j, i ≠ j → ∃ x y : ℝ, ∃ z : ℤ,
    (rows k i).Mem x ∧ (rows k j).Mem y ∧ y = x + 9 + 18 * z

theorem exists_family {d : ℝ} (R : Fin 19 → ThreeArcRow d) (hd : d < 36 / 5)
    (hpair : ∀ i j, i ≠ j → ∃ x y : ℝ, ∃ z : ℤ,
      (R i).Mem x ∧ (R j).Mem y ∧ y = x + 9 + 18 * z) : Nonempty Family := by
  let M := compressModel (modelOfRows R hpair) hd
  let C := codePoint (modelOfRows R hpair)
  let rows (k : ℤ) (i : Fin 19) :=
    (rowOfModel M i).widenTranslate le_rfl (3 * (k : ℝ) / 95)
  refine ⟨⟨C, codePoint_residues _, rows, ?_, ?_⟩⟩
  · intro k i j
    have hs : (rows k i).start j = (rowOfModel M i).start j + 3 * (k : ℝ) / 95 := by
      fin_cases j <;> simp [rows, ThreeArcRow.start, ThreeArcRow.widenTranslate]
    rw [hs, rowOfModel_start]
    change coordinate (C (i, j)) + 3 * (k : ℝ) / 95 = coordinate (C (i, j) + k)
    have hg := coordinate_gap (C (i, j) + k) (C (i, j))
    push_cast at hg
    linarith
  · intro k
    exact family_pair_widenTranslate (rowOfModel M) le_rfl
      (fun _ => 3 * (k : ℝ) / 95) (by intro i j; simp) (rowOfModel_pair M)

end Prize.JSP404.ThreeArcGrid
