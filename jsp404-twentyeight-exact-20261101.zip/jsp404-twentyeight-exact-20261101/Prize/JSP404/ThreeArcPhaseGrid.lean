import Prize.JSP404.ThreeArcTwenty
import Mathlib.Logic.Equiv.Fin.Basic

/-! A half-shifted grid turns a one-sector sweep of 57 starts into exactly
57 single-start events. No general-position assumption is imposed. -/
namespace Prize.JSP404.ThreeArcGrid

abbrev Point := Fin 19 × Fin 3

def indexEquiv : Point ≃ Fin 57 := finProdFinEquiv

noncomputable def coordinate (z : ℤ) : ℝ := 9 / 5 * ((z : ℝ) + 1 / 2) / 57

theorem coordinate_gap (z w : ℤ) :
    coordinate z - coordinate w = 3 * ((z : ℝ) - w) / 95 := by
  unfold coordinate
  ring

theorem floor_coordinate (z : ℤ) : ⌊5 * coordinate z / 9⌋ = z / 57 := by
  have hlo : 57 * (z / 57) ≤ z := by omega
  have hhi : z ≤ 57 * (z / 57) + 56 := by omega
  have hloR : 57 * ((z / 57 : ℤ) : ℝ) ≤ z := by exact_mod_cast hlo
  have hhiR : (z : ℝ) ≤ 57 * (z / 57 : ℤ) + 56 := by exact_mod_cast hhi
  have he : 5 * coordinate z / 9 = ((z : ℝ) + 1 / 2) / 57 := by
    unfold coordinate
    ring
  rw [he]
  apply Int.floor_eq_iff.mpr
  constructor <;> push_cast <;> linarith

theorem quotient_step (z k : ℤ) :
    (z + (k + 1)) / 57 = (z + k) / 57 + if (z + k) % 57 = 56 then 1 else 0 := by
  split_ifs <;> omega

theorem quotient_period (z k : ℤ) : (z + (k + 57)) / 57 = (z + k) / 57 + 1 := by
  omega

theorem unique_event (code : Point → ℤ)
    (hinj : Function.Injective (fun p => code p % 57)) (k : Fin 57) :
    ∃! p : Point, (code p + k.val) % 57 = 56 := by
  let f (p : Point) : Fin 57 := ⟨(code p % 57).toNat, by omega⟩
  have hf : Function.Injective f := by
    intro p q h
    apply hinj
    change code p % 57 = code q % 57
    have hval := congrArg Fin.val h
    dsimp [f] at hval
    omega
  have hsur : Function.Surjective f :=
    (Fintype.bijective_iff_injective_and_card f).mpr
      ⟨hf, by simp [Point]⟩ |>.2
  let r : Fin 57 := ⟨((56 - (k.val : ℤ)) % 57).toNat, by omega⟩
  obtain ⟨p, hp⟩ := hsur r
  have hpv := congrArg Fin.val hp
  have hevent : (code p + k.val) % 57 = 56 := by
    dsimp [f, r] at hpv
    omega
  refine ⟨p, hevent, ?_⟩
  intro q hq
  apply hinj
  change code q % 57 = code p % 57
  omega

end Prize.JSP404.ThreeArcGrid
