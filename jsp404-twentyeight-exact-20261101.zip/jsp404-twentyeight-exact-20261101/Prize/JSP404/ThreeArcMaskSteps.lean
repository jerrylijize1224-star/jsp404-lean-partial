import Prize.JSP404.ThreeArcMaskEvent
import Mathlib.GroupTheory.Perm.Sign
import Mathlib.Logic.Equiv.Fin.Rotate

/-! Integer start triples, their mask changes, and the even rotation of the
twenty mask types. These are finite helpers for the continuous event sweep. -/
namespace Prize.JSP404.ThreeArcTwenty

def TripleValid (a b c : ℤ) : Prop :=
  0 ≤ b - a ∧ b - a ≤ 4 ∧ 6 ≤ c - a ∧ c - b ≤ 4

def tripleShape (a b c : ℤ) : Finset Sector := shape a (b - a) (c - a)

def tripleAnchor (a b c : ℤ) (k : Fin 3) : ℤ :=
  if k = 0 then a else if k = 1 then b else c

theorem tripleShape_mem_types {a b c : ℤ} (h : TripleValid a b c) :
    tripleShape a b c ∈ types :=
  shape_mem_types a (b - a) (c - a) h.1 h.2.1 h.2.2.1 (by
    have hc := h.2.2.2
    omega)

theorem rowFloors_valid {d : ℝ} (R : ContinuousDirection.ThreeArcRow d)
    (hd : d < 36 / 5) :
    TripleValid ⌊5 * R.a / 9⌋ ⌊5 * R.b / 9⌋ ⌊5 * R.c / 9⌋ := by
  have h1 := floor_gap_le_four hd R.width1
  have h2 := floor_gap_le_four hd R.width2
  have h3 := floor_gap_le_four hd (show R.a + 18 ≤ R.c + d by linarith [R.width0])
  have he : 5 * (R.a + 18) / 9 = 5 * R.a / 9 + (10 : ℤ) := by push_cast; ring
  rw [he, Int.floor_add_intCast] at h3
  have hm := Int.floor_mono (show 5 * R.a / 9 ≤ 5 * R.b / 9 by linarith [R.ab])
  exact ⟨by omega, h1, by omega, h2⟩

theorem rowShape_eq_tripleShape {d : ℝ} (R : ContinuousDirection.ThreeArcRow d) :
    rowShape R = tripleShape ⌊5 * R.a / 9⌋ ⌊5 * R.b / 9⌋ ⌊5 * R.c / 9⌋ := rfl

theorem tripleShape_anchor_mem {a b c : ℤ} (h : TripleValid a b c) (k : Fin 3) :
    intSector (tripleAnchor a b c k) ∈ tripleShape a b c := by
  rcases h with ⟨hu0, hu4, hv6, hvu⟩
  have hv8 : c - a ≤ 8 := by omega
  fin_cases k
  · change intSector a ∈ shape a (b - a) (c - a)
    simp only [shape, Finset.mem_filter, Finset.mem_univ, true_and]
    have hm : (((intSector a).val : ℤ) - a) % 10 = 0 := by
      dsimp [intSector]; omega
    rw [hm]
    left; omega
  · change intSector b ∈ shape a (b - a) (c - a)
    simp only [shape, Finset.mem_filter, Finset.mem_univ, true_and]
    have hm : (((intSector b).val : ℤ) - a) % 10 = b - a := by
      dsimp [intSector]; omega
    rw [hm]
    right; left; omega
  · change intSector c ∈ shape a (b - a) (c - a)
    simp only [shape, Finset.mem_filter, Finset.mem_univ, true_and]
    have hm : (((intSector c).val : ℤ) - a) % 10 = c - a := by
      dsimp [intSector]; omega
    rw [hm]
    right; right; omega

theorem tripleShape_anchor_end_mem {a b c : ℤ} (h : TripleValid a b c) (k : Fin 3) :
    intSector (tripleAnchor a b c k + 4) ∈ tripleShape a b c := by
  rcases h with ⟨hu0, hu4, hv6, hvu⟩
  have hv8 : c - a ≤ 8 := by omega
  fin_cases k
  · change intSector (a + 4) ∈ shape a (b - a) (c - a)
    simp only [shape, Finset.mem_filter, Finset.mem_univ, true_and]
    have hm : (((intSector (a + 4)).val : ℤ) - a) % 10 = 4 := by
      dsimp [intSector]; omega
    rw [hm]
    right; left; omega
  · change intSector (b + 4) ∈ shape a (b - a) (c - a)
    simp only [shape, Finset.mem_filter, Finset.mem_univ, true_and]
    have hm : (((intSector (b + 4)).val : ℤ) - a) % 10 = b - a + 4 := by
      dsimp [intSector]; omega
    rw [hm]
    right; right; omega
  · change intSector (c + 4) ∈ shape a (b - a) (c - a)
    simp only [shape, Finset.mem_filter, Finset.mem_univ, true_and]
    have hm : (((intSector (c + 4)).val : ℤ) - a) % 10 = c - a - 6 := by
      dsimp [intSector]; omega
    rw [hm]
    left; omega

theorem tripleShape_ne_of_anchor_successor {a b c a' b' c' : ℤ}
    (h : TripleValid a b c) (h' : TripleValid a' b' c') (k : Fin 3)
    (hk : tripleAnchor a' b' c' k = tripleAnchor a b c k + 1) :
    tripleShape a b c ≠ tripleShape a' b' c' := by
  intro heq
  have hX := tripleShape_anchor_mem h k
  have hY := tripleShape_anchor_end_mem h' k
  have he : intSector (tripleAnchor a b c k + 1 + 4) =
      antipode (intSector (tripleAnchor a b c k)) := by
    apply Fin.ext
    dsimp [intSector, antipode]
    omega
  rw [hk, he, ← heq] at hY
  exact types_no_antipodes _ (tripleShape_mem_types h) _ hX hY

def rotateMask (T : Finset Sector) : Finset Sector := T.image (finRotate 10)

def unrotateMask (T : Finset Sector) : Finset Sector := T.image (finRotate 10).symm

theorem rotateMask_mem_types : ∀ T ∈ types, rotateMask T ∈ types := by decide +kernel

theorem unrotateMask_mem_types : ∀ T ∈ types, unrotateMask T ∈ types := by decide +kernel

def maskRotation : Equiv.Perm types where
  toFun T := ⟨rotateMask T.val, rotateMask_mem_types _ T.property⟩
  invFun T := ⟨unrotateMask T.val, unrotateMask_mem_types _ T.property⟩
  left_inv := by
    intro T
    apply Subtype.ext
    change unrotateMask (rotateMask T.val) = T.val
    simp [unrotateMask, rotateMask, Finset.image_image]
  right_inv := by
    intro T
    apply Subtype.ext
    change rotateMask (unrotateMask T.val) = T.val
    simp [unrotateMask, rotateMask, Finset.image_image]

theorem maskRotation_val (T : types) : (maskRotation T).val = rotateMask T.val := rfl

theorem tripleShape_add_one (a b c : ℤ) :
    tripleShape (a + 1) (b + 1) (c + 1) = rotateMask (tripleShape a b c) := by
  ext i
  simp only [tripleShape, rotateMask, Finset.mem_image]
  constructor
  · intro hi
    refine ⟨(finRotate 10).symm i, ?_, (finRotate 10).apply_symm_apply i⟩
    simp only [shape, Finset.mem_filter, Finset.mem_univ, true_and] at hi ⊢
    have hm : (((((finRotate 10).symm i).val : ℤ) - a) % 10) =
        (((i.val : ℤ) - (a + 1)) % 10) := by
      rw [finRotate_symm_apply]
      simp only [Fin.val_sub]
      omega
    rw [hm]
    simpa only [add_sub_add_right_eq_sub] using hi
  · rintro ⟨j, hj, rfl⟩
    simp only [shape, Finset.mem_filter, Finset.mem_univ, true_and] at hj ⊢
    have hm : ((((finRotate 10 j).val : ℤ) - (a + 1)) % 10) =
        (((j.val : ℤ) - a) % 10) := by
      rw [finRotate_apply]
      simp only [Fin.val_add]
      omega
    rw [hm]
    simpa only [add_sub_add_right_eq_sub] using hj

theorem maskRotation_sign : Equiv.Perm.sign maskRotation = 1 := by decide +kernel

end Prize.JSP404.ThreeArcTwenty
