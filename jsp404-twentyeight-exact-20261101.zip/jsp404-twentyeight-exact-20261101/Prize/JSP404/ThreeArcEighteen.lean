import Prize.JSP404.ThreeArcGridModel
import Prize.JSP404.ThreeArcMaskSteps
import Prize.JSP404.ThreeArcParityCore
import Prize.JSP404.ThreeArcNineteen

/-! Nineteen three-arc rows would make fifty-seven odd swaps, while a full
one-sector sweep acts by the even permutation of the twenty masks. -/
namespace Prize.JSP404.ThreeArcGrid
open ContinuousDirection ThreeArcTwenty

def atFloor (F : Family) (k : ℕ) (i : Fin 19) (j : Fin 3) : ℤ :=
  (F.code (i, j) + (k : ℤ)) / 57

noncomputable def mask (F : Family) (k : ℕ) (i : Fin 19) : types :=
  ⟨rowShape (F.rows (k : ℤ) i), rowShape_mem _ (by norm_num)⟩

theorem atFloor_eq (F : Family) (k : ℕ) (i : Fin 19) (j : Fin 3) :
    ⌊5 * ((F.rows (k : ℤ) i).start j) / 9⌋ = atFloor F k i j := by
  rw [F.start_eq, floor_coordinate]
  rfl

theorem mask_eq (F : Family) (k : ℕ) (i : Fin 19) :
    (mask F k i).val =
      tripleShape (atFloor F k i 0) (atFloor F k i 1) (atFloor F k i 2) := by
  have h0 := atFloor_eq F k i 0
  have h1 := atFloor_eq F k i 1
  have h2 := atFloor_eq F k i 2
  simp only [ThreeArcRow.start] at h0 h1 h2
  norm_num at h0 h1 h2
  change rowShape _ = _
  rw [rowShape_eq_tripleShape, h0, h1, h2]

theorem floors_valid (F : Family) (k : ℕ) (i : Fin 19) :
    TripleValid (atFloor F k i 0) (atFloor F k i 1) (atFloor F k i 2) := by
  have h0 := atFloor_eq F k i 0
  have h1 := atFloor_eq F k i 1
  have h2 := atFloor_eq F k i 2
  simp only [ThreeArcRow.start] at h0 h1 h2
  norm_num at h0 h1 h2
  rw [← h0, ← h1, ← h2]
  exact rowFloors_valid _ (by norm_num)

theorem tripleAnchor_atFloor (F : Family) (k : ℕ) (i : Fin 19) (j : Fin 3) :
    tripleAnchor (atFloor F k i 0) (atFloor F k i 1) (atFloor F k i 2) j =
      atFloor F k i j := by
  fin_cases j <;> norm_num [tripleAnchor]

theorem mask_injective (F : Family) (k : ℕ) : Function.Injective (mask F k) := by
  intro i j h
  exact family_masks_injective (by norm_num) (F.rows (k : ℤ)) (F.pair (k : ℤ))
    (congrArg Subtype.val h)

theorem mask_end (F : Family) (i : Fin 19) :
    mask F 57 i = maskRotation (mask F 0 i) := by
  apply Subtype.ext
  rw [mask_eq, maskRotation_val, mask_eq]
  have h (j : Fin 3) : atFloor F 57 i j = atFloor F 0 i j + 1 := by
    dsimp [atFloor]
    omega
  rw [h 0, h 1, h 2, tripleShape_add_one]

theorem mask_single_step (F : Family) (k : ℕ) (hk : k < 57) :
    ∃ r : Fin 19, mask F (k + 1) r ≠ mask F k r ∧
      ∀ i, i ≠ r → mask F (k + 1) i = mask F k i := by
  obtain ⟨p, hp, huniq⟩ := unique_event F.code F.residues ⟨k, hk⟩
  have hchange : atFloor F (k + 1) p.1 p.2 = atFloor F k p.1 p.2 + 1 := by
    dsimp [atFloor]
    push_cast
    rw [quotient_step, if_pos hp]
  have hsame (i : Fin 19) (hi : i ≠ p.1) (j : Fin 3) :
      atFloor F (k + 1) i j = atFloor F k i j := by
    have hnot : ¬ (F.code (i, j) + (k : ℤ)) % 57 = 56 := by
      intro he
      have hh := huniq (i, j) he
      exact hi (congrArg Prod.fst hh)
    dsimp [atFloor]
    push_cast
    rw [quotient_step, if_neg hnot, add_zero]
  refine ⟨p.1, ?_, ?_⟩
  · intro he
    have hv := congrArg Subtype.val he
    rw [mask_eq, mask_eq] at hv
    have hn := tripleShape_ne_of_anchor_successor (floors_valid F k p.1)
      (floors_valid F (k + 1) p.1) p.2 (by
        rw [tripleAnchor_atFloor, tripleAnchor_atFloor]
        exact hchange)
    exact hn hv.symm
  · intro i hi
    apply Subtype.ext
    rw [mask_eq, mask_eq, hsame i hi 0, hsame i hi 1, hsame i hi 2]

theorem no_grid_family (F : Family) : False := by
  apply ThreeArcParity.no_fiftyseven_injective_sweep (mask F) (mask_injective F)
    (by simp only [Fintype.card_coe, types_card]) maskRotation maskRotation_sign
  · exact mask_single_step F
  · exact mask_end F

end Prize.JSP404.ThreeArcGrid

namespace Prize.JSP404.ThreeArcTwenty
open ContinuousDirection

theorem no_nineteen_family {d : ℝ} (hd : d < 36 / 5)
    (R : Fin 19 → ThreeArcRow d)
    (hpair : ∀ i j, i ≠ j → ∃ x y : ℝ, ∃ z : ℤ,
      (R i).Mem x ∧ (R j).Mem y ∧ y = x + 9 + 18 * z) : False := by
  obtain ⟨F⟩ := ThreeArcGrid.exists_family R hd hpair
  exact ThreeArcGrid.no_grid_family F

theorem family_card_le_eighteen {V : Type*} [Fintype V] {d : ℝ}
    (hd : d < 36 / 5) (R : V → ThreeArcRow d)
    (hpair : ∀ i j, i ≠ j → ∃ x y : ℝ, ∃ z : ℤ,
      (R i).Mem x ∧ (R j).Mem y ∧ y = x + 9 + 18 * z) :
    Fintype.card V ≤ 18 := by
  by_contra hn
  have h19 : 19 ≤ Fintype.card V := by omega
  let e : Fin 19 → V := fun i => (Fintype.equivFin V).symm (Fin.castLE h19 i)
  have he : Function.Injective e := by
    intro i j h
    apply Fin.ext
    have hval := congrArg Fin.val ((Fintype.equivFin V).symm.injective h)
    exact hval
  exact no_nineteen_family hd (fun i => R (e i))
    (fun i j hij => hpair (e i) (e j) (he.ne hij))

end Prize.JSP404.ThreeArcTwenty
