import Prize.JSP404.IntegerGapCompression

/-! Tie-breaking fractional ranks preserves strict integer difference bounds
and gives pairwise distinct residues. This supplies a generic finite grid
without imposing general-position assumptions on the original coordinates. -/
namespace Prize.JSP404.ThreeArcGeneric

def Before {n : ℕ} (x : Fin n → ℝ) (i j : Fin n) : Prop :=
  Int.fract (x i) < Int.fract (x j) ∨
    (Int.fract (x i) = Int.fract (x j) ∧ i < j)

theorem before_irrefl {n : ℕ} (x : Fin n → ℝ) (i : Fin n) : ¬ Before x i i := by
  simp [Before]

theorem before_trans {n : ℕ} (x : Fin n → ℝ) {i j k : Fin n}
    (hij : Before x i j) (hjk : Before x j k) : Before x i k := by
  rcases hij with hij | ⟨hij, hij'⟩ <;> rcases hjk with hjk | ⟨hjk, hjk'⟩
  · exact Or.inl (lt_trans hij hjk)
  · exact Or.inl (lt_of_lt_of_eq hij hjk)
  · exact Or.inl (lt_of_eq_of_lt hij hjk)
  · exact Or.inr ⟨hij.trans hjk, lt_trans hij' hjk'⟩

theorem before_total {n : ℕ} (x : Fin n → ℝ) {i j : Fin n} (hij : i ≠ j) :
    Before x i j ∨ Before x j i := by
  rcases lt_trichotomy (Int.fract (x i)) (Int.fract (x j)) with h | h | h
  · exact Or.inl (Or.inl h)
  · rcases lt_or_gt_of_ne hij with hi | hi
    · exact Or.inl (Or.inr ⟨h, hi⟩)
    · exact Or.inr (Or.inr ⟨h.symm, hi⟩)
  · exact Or.inr (Or.inl h)

noncomputable def rank {n : ℕ} (x : Fin n → ℝ) (i : Fin n) : ℕ := by
  classical
  exact (Finset.univ.filter (fun j => Before x j i)).card

theorem rank_lt {n : ℕ} (x : Fin n → ℝ) (i : Fin n) : rank x i < n := by
  classical
  have hc : (Finset.univ.filter (fun j => Before x j i)).card <
      (Finset.univ : Finset (Fin n)).card := by
    apply Finset.card_lt_card
    refine Finset.ssubset_iff_subset_ne.mpr ⟨Finset.filter_subset _ _, ?_⟩
    intro h
    have hi : i ∈ Finset.univ.filter (fun j => Before x j i) :=
      by rw [h]; exact Finset.mem_univ i
    exact before_irrefl x i (Finset.mem_filter.mp hi).2
  simpa only [rank, Finset.card_univ, Fintype.card_fin] using hc

theorem rank_strictMono {n : ℕ} (x : Fin n → ℝ) {i j : Fin n}
    (h : Before x i j) : rank x i < rank x j := by
  classical
  unfold rank
  apply Finset.card_lt_card
  refine Finset.ssubset_iff_subset_ne.mpr ⟨?_, ?_⟩
  · intro k hk
    exact Finset.mem_filter.mpr
      ⟨Finset.mem_univ _, before_trans x (Finset.mem_filter.mp hk).2 h⟩
  · intro he
    have hi : i ∈ Finset.univ.filter (fun k => Before x k j) :=
      Finset.mem_filter.mpr ⟨Finset.mem_univ _, h⟩
    rw [← he] at hi
    exact before_irrefl x i (Finset.mem_filter.mp hi).2

theorem rank_injective {n : ℕ} (x : Fin n → ℝ) : Function.Injective (rank x) := by
  intro i j he
  by_contra hij
  rcases before_total x hij with h | h
  · have := rank_strictMono x h
    omega
  · have := rank_strictMono x h
    omega

noncomputable def code {n : ℕ} (x : Fin n → ℝ) (i : Fin n) : ℤ :=
  (n : ℤ) * ⌊x i⌋ + rank x i

theorem code_strict_gap {n : ℕ} (x : Fin n → ℝ) (i j : Fin n) (k : ℤ)
    (h : x i - x j < k) : code x i - code x j ≤ (n : ℤ) * k - 1 := by
  have hi := Int.floor_le (x i)
  have hj := Int.lt_floor_add_one (x j)
  have hf : ⌊x i⌋ - ⌊x j⌋ ≤ k := by
    have hr : ((⌊x i⌋ - ⌊x j⌋ : ℤ) : ℝ) < (k : ℝ) + 1 := by
      push_cast
      linarith
    have hz : ⌊x i⌋ - ⌊x j⌋ < k + 1 := by exact_mod_cast hr
    omega
  have hri := rank_lt x i
  have hrj := rank_lt x j
  have hn : 0 < n := lt_of_le_of_lt (Nat.zero_le _) hri
  by_cases he : ⌊x i⌋ - ⌊x j⌋ = k
  · have hfract : Int.fract (x i) < Int.fract (x j) := by
      have her : (⌊x i⌋ : ℝ) - ⌊x j⌋ = k := by exact_mod_cast he
      simp only [Int.fract]
      linarith
    have hr := rank_strictMono x (Or.inl hfract)
    have hr' : (rank x i : ℤ) + 1 ≤ rank x j := by exact_mod_cast hr
    unfold code
    nlinarith
  · have hgap : ⌊x i⌋ - ⌊x j⌋ ≤ k - 1 := by omega
    have hprod := mul_le_mul_of_nonneg_left hgap (show (0 : ℤ) ≤ n by omega)
    unfold code
    simp only [mul_sub, mul_one] at hprod
    omega

theorem code_emod {n : ℕ} (x : Fin n → ℝ) (i : Fin n) :
    code x i % n = rank x i := by
  have hr : (rank x i : ℤ) < n := by exact_mod_cast rank_lt x i
  have hr0 : (0 : ℤ) ≤ rank x i := by omega
  unfold code
  rw [add_comm, Int.add_mul_emod_self_left, Int.emod_eq_of_lt hr0 hr]

theorem code_residues_injective {n : ℕ} (x : Fin n → ℝ) :
    Function.Injective (fun i => code x i % n) := by
  intro i j h
  apply rank_injective x
  change code x i % n = code x j % n at h
  rw [code_emod, code_emod] at h
  exact_mod_cast h

noncomputable def compressed {n : ℕ} (x : Fin n → ℝ) (i : Fin n) : ℝ :=
  (code x i : ℝ) / n

theorem compressed_strict_gap {n : ℕ} (x : Fin n → ℝ) (i j : Fin n) (k : ℤ)
    (h : x i - x j < k) : compressed x i - compressed x j ≤ (k : ℝ) - 1 / n := by
  have hn : (0 : ℝ) < n := by exact_mod_cast (lt_of_le_of_lt (Nat.zero_le _) (rank_lt x i))
  have hc := code_strict_gap x i j k h
  have hcr : (code x i : ℝ) - code x j ≤ (n : ℝ) * k - 1 := by exact_mod_cast hc
  unfold compressed
  rw [← sub_div]
  apply (div_le_iff₀ hn).mpr
  have he : ((k : ℝ) - 1 / n) * n = (n : ℝ) * k - 1 := by field_simp
  rwa [he]

end Prize.JSP404.ThreeArcGeneric
