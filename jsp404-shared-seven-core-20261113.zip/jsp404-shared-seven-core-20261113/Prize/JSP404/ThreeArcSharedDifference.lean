import Prize.JSP404.ThreeArcSharedDirections
import Prize.JSP404.DifferenceCertificate
import Mathlib.Data.List.FinRange

/-! The shared-direction necessary conditions as finite disjunctive difference
constraints. Labels are enumerated in numerical order, independently of the
order and multiplicity in the input list. Membership lower bounds remain
non-strict. The anchor variable is interpreted as zero in the model bridge. -/
namespace Prize.JSP404.ThreeArcSharedDifference
open ContinuousDirection DifferenceCertificate

abbrev Label := Fin 20
abbrev Arc := Fin 3

def anchor : ℕ := 0

def startVar (i : Label) (k : Arc) : ℕ := 1 + 3 * i.val + k.val

def directionVar (i j : Label) : ℕ := 61 + 20 * i.val + j.val

def labels (active : List Label) : List Label :=
  (List.finRange 20).filter (fun i => decide (i ∈ active))

def pairs (active : List Label) : List (Label × Label) :=
  (labels active).flatMap fun i =>
    (labels active).flatMap fun j => if i < j then [(i, j)] else []

def triples (active : List Label) : List (Label × Label × Label) :=
  (labels active).flatMap fun i =>
    (labels active).flatMap fun j =>
      (labels active).flatMap fun k => if i < j ∧ j < k then [(i, j, k)] else []

def rowInitial (i : Label) : List Edge := [
  ⟨anchor, startVar i 0, -ThreeArcCanonical.starts i 0, false⟩,
  ⟨startVar i 0, anchor, ThreeArcCanonical.starts i 0 + 1, true⟩,
  ⟨anchor, startVar i 1, -ThreeArcCanonical.starts i 1, false⟩,
  ⟨startVar i 1, anchor, ThreeArcCanonical.starts i 1 + 1, true⟩,
  ⟨anchor, startVar i 2, -ThreeArcCanonical.starts i 2, false⟩,
  ⟨startVar i 2, anchor, ThreeArcCanonical.starts i 2 + 1, true⟩,
  ⟨startVar i 0, startVar i 1, 0, true⟩,
  ⟨startVar i 1, startVar i 2, 0, true⟩,
  ⟨startVar i 2, startVar i 0, 10, true⟩,
  ⟨startVar i 0, startVar i 2, -6, true⟩,
  ⟨startVar i 1, startVar i 0, 4, true⟩,
  ⟨startVar i 2, startVar i 1, 4, true⟩]

def pairInitial (i j : Label) : List Edge := [
  ⟨anchor, directionVar i j, 0, false⟩,
  ⟨directionVar i j, anchor, 10, true⟩]

def initial (active : List Label) : List Edge :=
  (labels active).flatMap rowInitial ++
    (pairs active).flatMap (fun p => pairInitial p.1 p.2)

def offset (k : Arc) : ℤ := if k = 0 then 10 else 0

def shifts : List ℤ := [-10, 0, 10]

def membershipChoice (row : Label) (direction : ℕ) (delta shift : ℤ) (k : Arc) : Choice := [
  ⟨startVar row k, direction, delta + shift, false⟩,
  ⟨direction, startVar row (ContinuousThreeArc.previous k),
    4 - offset k - delta - shift, true⟩]

def membershipClause (row : Label) (direction : ℕ) (delta : ℤ) : Clause :=
  shifts.flatMap fun shift =>
    (List.finRange 3).map (fun k => membershipChoice row direction delta shift k)

def pairClauses (i j : Label) : List Clause := [
  membershipClause i (directionVar i j) 0,
  membershipClause j (directionVar i j) 5]

def bools : List Bool := [false, true]

def turnChoice (u v : ℕ) (wrapped : Bool) : Choice := [
  ⟨u, v, if wrapped then 10 else 0, true⟩,
  ⟨v, u, if wrapped then -5 else 5, true⟩]

def triangleChoice (u v w : ℕ) (orientation first second third : Bool) : Choice :=
  if orientation then
    turnChoice v u first ++ turnChoice w u second ++ turnChoice w v third
  else
    turnChoice u v first ++ turnChoice u w second ++ turnChoice v w third

def triangleClause (u v w : ℕ) : Clause :=
  bools.flatMap fun orientation =>
    bools.flatMap fun first =>
      bools.flatMap fun second =>
        bools.map (fun third => triangleChoice u v w orientation first second third)

def clauseList (active : List Label) : List Clause :=
  (pairs active).flatMap (fun p => pairClauses p.1 p.2) ++
    (triples active).map (fun p =>
      triangleClause (directionVar p.1 p.2.1) (directionVar p.1 p.2.2)
        (directionVar p.2.1 p.2.2))

def spec (active : List Label) : Spec := ⟨initial active, (clauseList active).toArray⟩

def decodeLabel (n : ℕ) : Label := ⟨n % 20, Nat.mod_lt _ (by decide)⟩

def decodeArc (n : ℕ) : Arc := ⟨n % 3, Nat.mod_lt _ (by decide)⟩

def assignment (a : Label → Arc → ℝ) (q : Label → Label → ℝ) (n : ℕ) : ℝ :=
  if n = 0 then 0
  else if n < 61 then a (decodeLabel ((n - 1) / 3)) (decodeArc (n - 1))
  else q (decodeLabel ((n - 61) / 20)) (decodeLabel (n - 61))

theorem assignment_anchor (a : Label → Arc → ℝ) (q : Label → Label → ℝ) :
    assignment a q anchor = 0 := by
  simp [assignment, anchor]

theorem assignment_start (a : Label → Arc → ℝ) (q : Label → Label → ℝ)
    (i : Label) (k : Arc) : assignment a q (startVar i k) = a i k := by
  have h0 : startVar i k ≠ 0 := by dsimp [startVar]; omega
  have h61 : startVar i k < 61 := by dsimp [startVar]; omega
  rw [assignment, ite_eq_right h0, ite_eq_left h61]
  apply congrArg₂ a
  · apply Fin.ext
    dsimp [decodeLabel, startVar]
    omega
  · apply Fin.ext
    dsimp [decodeArc, startVar]
    omega

theorem assignment_direction (a : Label → Arc → ℝ) (q : Label → Label → ℝ)
    (i j : Label) : assignment a q (directionVar i j) = q i j := by
  have h0 : directionVar i j ≠ 0 := by dsimp [directionVar]; omega
  have h61 : ¬ directionVar i j < 61 := by dsimp [directionVar]; omega
  rw [assignment, ite_eq_right h0, ite_eq_right h61]
  apply congrArg₂ q
  · apply Fin.ext
    dsimp [decodeLabel, directionVar]
    omega
  · apply Fin.ext
    dsimp [decodeLabel, directionVar]
    omega

theorem mem_labels {active : List Label} {i : Label} : i ∈ labels active ↔ i ∈ active := by
  constructor
  · intro hi
    exact of_decide_eq_true (List.mem_filter.mp hi).2
  · intro hi
    exact List.mem_filter.mpr ⟨List.mem_finRange i, by simp [hi]⟩

theorem mem_pairs {active : List Label} {p : Label × Label} (hp : p ∈ pairs active) :
    p.1 ∈ active ∧ p.2 ∈ active ∧ p.1 < p.2 := by
  unfold pairs at hp
  obtain ⟨i, hi, hp⟩ := List.mem_flatMap.mp hp
  obtain ⟨j, hj, hp⟩ := List.mem_flatMap.mp hp
  by_cases hij : i < j
  · have he : p = (i, j) := by simpa [hij] using hp
    subst p
    exact ⟨mem_labels.mp hi, mem_labels.mp hj, hij⟩
  · simp [hij] at hp

theorem mem_triples {active : List Label} {p : Label × Label × Label}
    (hp : p ∈ triples active) :
    p.1 ∈ active ∧ p.2.1 ∈ active ∧ p.2.2 ∈ active ∧ p.1 < p.2.1 ∧ p.2.1 < p.2.2 := by
  unfold triples at hp
  obtain ⟨i, hi, hp⟩ := List.mem_flatMap.mp hp
  obtain ⟨j, hj, hp⟩ := List.mem_flatMap.mp hp
  obtain ⟨k, hk, hp⟩ := List.mem_flatMap.mp hp
  by_cases hijk : i < j ∧ j < k
  · have he : p = (i, j, k) := by simpa [hijk] using hp
    subst p
    exact ⟨mem_labels.mp hi, mem_labels.mp hj, mem_labels.mp hk, hijk.1, hijk.2⟩
  · simp [hijk] at hp

structure LabelledConstraints (active : List Label) (a : Label → Arc → ℝ)
    (q : Label → Label → ℝ) : Prop where
  cell : ∀ i, i ∈ active → ∀ k,
    (ThreeArcCanonical.starts i k : ℝ) ≤ a i k ∧ a i k < (ThreeArcCanonical.starts i k : ℝ) + 1
  order01 : ∀ i, i ∈ active → a i 0 < a i 1
  order12 : ∀ i, i ∈ active → a i 1 < a i 2
  period : ∀ i, i ∈ active → a i 2 < a i 0 + 10
  width0 : ∀ i, i ∈ active → a i 0 < a i 2 - 6
  width1 : ∀ i, i ∈ active → a i 1 < a i 0 + 4
  width2 : ∀ i, i ∈ active → a i 2 < a i 1 + 4
  direction_bounds : ∀ i, i ∈ active → ∀ j, j ∈ active → i < j → 0 ≤ q i j ∧ q i j < 10
  covered_left : ∀ i, i ∈ active → ∀ j, j ∈ active → i < j → SharedMember10 (a i) (q i j)
  covered_right : ∀ i, i ∈ active → ∀ j, j ∈ active → i < j → SharedMember10 (a j) (q i j + 5)
  triangle : ∀ i, i ∈ active → ∀ j, j ∈ active → ∀ k, k ∈ active → i < j → j < k →
    SharedTriangle10 (q i j) (q i k) (q j k)

theorem rowInitial_holds {active : List Label} {a : Label → Arc → ℝ}
    {q : Label → Label → ℝ} (H : LabelledConstraints active a q)
    (i : Label) (hi : i ∈ active) : Holds (assignment a q) (rowInitial i) := by
  have h0 := H.cell i hi 0
  have h1 := H.cell i hi 1
  have h2 := H.cell i hi 2
  have h01 := H.order01 i hi
  have h12 := H.order12 i hi
  have hp := H.period i hi
  have hw0 := H.width0 i hi
  have hw1 := H.width1 i hi
  have hw2 := H.width2 i hi
  intro edge he
  simp only [rowInitial, List.mem_cons, List.not_mem_nil, or_false] at he
  rcases he with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals
    simp [Satisfies, Bound, assignment_anchor, assignment_start]
    <;> push_cast
    <;> linarith [h0.1, h0.2, h1.1, h1.2, h2.1, h2.2]

theorem pairInitial_holds {active : List Label} {a : Label → Arc → ℝ}
    {q : Label → Label → ℝ} (H : LabelledConstraints active a q)
    (i j : Label) (hi : i ∈ active) (hj : j ∈ active) (hij : i < j) :
    Holds (assignment a q) (pairInitial i j) := by
  have hb := H.direction_bounds i hi j hj hij
  intro edge he
  simp only [pairInitial, List.mem_cons, List.not_mem_nil, or_false] at he
  rcases he with rfl | rfl
  · simpa [Satisfies, Bound, assignment_anchor, assignment_direction] using hb.1
  · simpa [Satisfies, Bound, assignment_anchor, assignment_direction] using hb.2

theorem rowMem_choice {a : Arc → ℝ} {x : ℝ} (h : SharedRowMem10 a x) :
    ∃ k : Arc, a k ≤ x ∧ x < a (ContinuousThreeArc.previous k) + 4 - (offset k : ℝ) := by
  rcases h with h | h | h
  · exact ⟨0, by simpa [ContinuousThreeArc.previous, offset] using h⟩
  · exact ⟨1, by simpa [ContinuousThreeArc.previous, offset] using h⟩
  · exact ⟨2, by simpa [ContinuousThreeArc.previous, offset] using h⟩

theorem member_choice {a : Arc → ℝ} {x : ℝ} (h : SharedMember10 a x) :
    ∃ shift ∈ shifts, ∃ k : Arc,
      a k ≤ x + (shift : ℝ) ∧
        x + (shift : ℝ) < a (ContinuousThreeArc.previous k) + 4 - (offset k : ℝ) := by
  rcases h with h | h | h
  · obtain ⟨k, hk⟩ := rowMem_choice h
    exact ⟨-10, by simp [shifts], k, by simpa [sub_eq_add_neg] using hk⟩
  · obtain ⟨k, hk⟩ := rowMem_choice h
    exact ⟨0, by simp [shifts], k, by simpa using hk⟩
  · obtain ⟨k, hk⟩ := rowMem_choice h
    exact ⟨10, by simp [shifts], k, by simpa using hk⟩

theorem membershipClause_holds (a : Label → Arc → ℝ) (q : Label → Label → ℝ)
    (row i j : Label) (delta : ℤ) (hm : SharedMember10 (a row) (q i j + delta)) :
    ∃ choice ∈ membershipClause row (directionVar i j) delta, Holds (assignment a q) choice := by
  obtain ⟨shift, hs, k, hlo, hhi⟩ := member_choice hm
  refine ⟨membershipChoice row (directionVar i j) delta shift k, ?_, ?_⟩
  · exact List.mem_flatMap.mpr ⟨shift, hs,
      List.mem_map.mpr ⟨k, List.mem_finRange k, rfl⟩⟩
  · intro edge he
    simp only [membershipChoice, List.mem_cons, List.not_mem_nil, or_false] at he
    rcases he with rfl | rfl
    · change assignment a q (startVar row k) ≤
        assignment a q (directionVar i j) + ((delta + shift : ℤ) : ℝ)
      rw [assignment_start, assignment_direction]
      push_cast
      linarith
    · change assignment a q (directionVar i j) <
        assignment a q (startVar row (ContinuousThreeArc.previous k)) +
          ((4 - offset k - delta - shift : ℤ) : ℝ)
      rw [assignment_start, assignment_direction]
      push_cast
      linarith

theorem mem_bools (b : Bool) : b ∈ bools := by
  cases b <;> simp [bools]

theorem turnChoice_holds (x : ℕ → ℝ) (u v : ℕ) (h : SharedTurn10 (x u) (x v)) :
    ∃ wrapped : Bool, Holds x (turnChoice u v wrapped) := by
  rcases h with h | h
  · refine ⟨false, ?_⟩
    intro edge he
    simp only [turnChoice, List.mem_cons, List.not_mem_nil, or_false] at he
    rcases he with rfl | rfl <;> simp [Satisfies, Bound] <;> linarith [h.1, h.2]
  · refine ⟨true, ?_⟩
    intro edge he
    simp only [turnChoice, List.mem_cons, List.not_mem_nil, or_false] at he
    rcases he with rfl | rfl <;> simp [Satisfies, Bound] <;> linarith [h.1, h.2]

theorem triangleChoice_mem (u v w : ℕ) (orientation first second third : Bool) :
    triangleChoice u v w orientation first second third ∈ triangleClause u v w := by
  exact List.mem_flatMap.mpr ⟨orientation, mem_bools _,
    List.mem_flatMap.mpr ⟨first, mem_bools _,
      List.mem_flatMap.mpr ⟨second, mem_bools _,
        List.mem_map.mpr ⟨third, mem_bools _, rfl⟩⟩⟩⟩

theorem triangleClause_holds (x : ℕ → ℝ) (u v w : ℕ)
    (h : SharedTriangle10 (x u) (x v) (x w)) :
    ∃ choice ∈ triangleClause u v w, Holds x choice := by
  rcases h with ⟨h1, h2, h3⟩ | ⟨h1, h2, h3⟩
  · obtain ⟨b1, hb1⟩ := turnChoice_holds x u v h1
    obtain ⟨b2, hb2⟩ := turnChoice_holds x u w h2
    obtain ⟨b3, hb3⟩ := turnChoice_holds x v w h3
    refine ⟨triangleChoice u v w false b1 b2 b3, triangleChoice_mem _ _ _ _ _ _ _, ?_⟩
    simpa [triangleChoice] using holds_append hb1 (holds_append hb2 hb3)
  · obtain ⟨b1, hb1⟩ := turnChoice_holds x v u h1
    obtain ⟨b2, hb2⟩ := turnChoice_holds x w u h2
    obtain ⟨b3, hb3⟩ := turnChoice_holds x w v h3
    refine ⟨triangleChoice u v w true b1 b2 b3, triangleChoice_mem _ _ _ _ _ _ _, ?_⟩
    simpa [triangleChoice] using holds_append hb1 (holds_append hb2 hb3)

theorem model_of_labelled (active : List Label) (a : Label → Arc → ℝ)
    (q : Label → Label → ℝ) (H : LabelledConstraints active a q) :
    Model (spec active) (assignment a q) := by
  constructor
  · change Holds (assignment a q) ((labels active).flatMap rowInitial ++
      (pairs active).flatMap (fun p => pairInitial p.1 p.2))
    apply holds_append
    · intro edge he
      obtain ⟨i, hi, he⟩ := List.mem_flatMap.mp he
      exact rowInitial_holds H i (mem_labels.mp hi) edge he
    · intro edge he
      obtain ⟨p, hp, he⟩ := List.mem_flatMap.mp he
      obtain ⟨hi, hj, hij⟩ := mem_pairs hp
      exact pairInitial_holds H p.1 p.2 hi hj hij edge he
  · intro index clause hget
    change (clauseList active).toArray[index]? = some clause at hget
    have hc : clause ∈ clauseList active :=
      List.mem_toArray.mp (Array.mem_of_getElem? hget)
    rcases List.mem_append.mp hc with hc | hc
    · obtain ⟨p, hp, hc⟩ := List.mem_flatMap.mp hc
      obtain ⟨hi, hj, hij⟩ := mem_pairs hp
      simp only [pairClauses, List.mem_cons, List.not_mem_nil, or_false] at hc
      rcases hc with rfl | rfl
      · exact membershipClause_holds a q p.1 p.1 p.2 0
          (by simpa using H.covered_left p.1 hi p.2 hj hij)
      · exact membershipClause_holds a q p.2 p.1 p.2 5
          (by simpa using H.covered_right p.1 hi p.2 hj hij)
    · obtain ⟨p, hp, rfl⟩ := List.mem_map.mp hc
      obtain ⟨hi, hj, hk, hij, hjk⟩ := mem_triples hp
      apply triangleClause_holds
      simpa only [assignment_direction] using H.triangle p.1 hi p.2.1 hj p.2.2 hk hij hjk

theorem model_of_canonical {V : Type*} (C : ThreeArcSharedCanonicalModel V)
    (active : List Label) (e : Label → V)
    (htype : ∀ i ∈ active, C.type (e i) = i) :
    Model (spec active)
      (assignment (fun i k => C.start (e i) k) (fun i j => C.direction (e i) (e j))) := by
  have hne (i j : Label) (hi : i ∈ active) (hj : j ∈ active) (hij : i ≠ j) :
      e i ≠ e j := by
    intro he
    apply hij
    calc
      i = C.type (e i) := (htype i hi).symm
      _ = C.type (e j) := congrArg C.type he
      _ = j := htype j hj
  apply model_of_labelled
  refine {
    cell := ?_, order01 := ?_, order12 := ?_, period := ?_
    width0 := ?_, width1 := ?_, width2 := ?_, direction_bounds := ?_
    covered_left := ?_, covered_right := ?_, triangle := ?_ }
  · intro i hi k
    simpa only [htype i hi] using C.cell (e i) k
  · intro i _
    exact C.order01 (e i)
  · intro i _
    exact C.order12 (e i)
  · intro i _
    exact C.period (e i)
  · intro i _
    exact C.width0 (e i)
  · intro i _
    exact C.width1 (e i)
  · intro i _
    exact C.width2 (e i)
  · intro i hi j hj hij
    exact C.direction_bounds (e i) (e j) (hne i j hi hj (ne_of_lt hij))
  · intro i hi j hj hij
    exact C.covered_left (e i) (e j) (hne i j hi hj (ne_of_lt hij))
  · intro i hi j hj hij
    exact C.covered_right (e i) (e j) (hne i j hi hj (ne_of_lt hij))
  · intro i hi j hj k hk hij hjk
    exact C.triangle (e i) (e j) (e k) (hne i j hi hj (ne_of_lt hij))
      (hne i k hi hk (ne_of_lt (lt_trans hij hjk))) (hne j k hj hk (ne_of_lt hjk))

end Prize.JSP404.ThreeArcSharedDifference
