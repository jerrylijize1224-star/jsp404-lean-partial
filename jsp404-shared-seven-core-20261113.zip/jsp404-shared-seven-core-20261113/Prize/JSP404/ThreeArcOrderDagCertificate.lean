import Prize.JSP404.ThreeArcOrderCertificate

/-! Each node states the edges required for its contradiction. A certificate
stores indexed nodes in an explicit tree. Every stored node is checked once,
and child references use tree lookup. Soundness requires no ordering or balance
property of the input tree. -/
namespace Prize.JSP404.ThreeArcOrderDagCertificate
open ThreeArcOrderCertificate

structure DagNode where
  required : List Edge
  step : Node

inductive NodeTree where
  | empty
  | node (index : ℕ) (value : DagNode) (left right : NodeTree)

structure Certificate where
  root : ℕ
  tree : NodeTree

def lookup : NodeTree → ℕ → Option DagNode
  | .empty, _ => none
  | .node key value left right, index =>
      if index = key then some value
      else if index < key then lookup left index else lookup right index

def allNodes (predicate : ℕ → DagNode → Bool) : NodeTree → Bool
  | .empty => true
  | .node index value left right =>
      predicate index value && (allNodes predicate left && allNodes predicate right)

def edgeSubset (required supplied : List Edge) : Bool :=
  required.all (fun e => decide (e ∈ supplied))

def requirementsCheck (required supplied : List Edge) (alt : Choice) : Bool :=
  (required.filter (fun e => !decide (e ∈ alt))).isSublist supplied

def childCheck (nodes : NodeTree) (index : ℕ) (required : List Edge)
    (alt : Choice) (child : Choice × ℕ) : Bool :=
  decide (child.1 = alt ∧ child.2 < index) &&
    (match lookup nodes child.2 with
     | none => false
     | some node => requirementsCheck node.required required alt)

def nodeCheck (S : Spec) (active : Finset Label) (nodes : NodeTree)
    (index : ℕ) (node : DagNode) : Bool :=
  match node.step with
  | .cycle path => cycleCheck node.required path
  | .branch i j children =>
      decide (i ∈ active ∧ j ∈ active ∧ i < j) &&
        (S.options i j).all (fun alt => children.any (childCheck nodes index node.required alt))

def accepted (S : Spec) (active : Finset Label) (certificate : Certificate) : Bool :=
  match lookup certificate.tree certificate.root with
  | none => false
  | some node =>
      edgeSubset node.required (initialEdges S active) &&
        allNodes (nodeCheck S active certificate.tree) certificate.tree

theorem lookup_some_checked (predicate : ℕ → DagNode → Bool) (tree : NodeTree)
    (hall : allNodes predicate tree = true) (index : ℕ) (node : DagNode)
    (hget : lookup tree index = some node) : predicate index node = true := by
  induction tree generalizing index node with
  | empty => simp [lookup] at hget
  | node key value left right ihleft ihright =>
    obtain ⟨hvalue, hbranches⟩ := Bool.and_eq_true_iff.mp hall
    obtain ⟨hleft, hright⟩ := Bool.and_eq_true_iff.mp hbranches
    by_cases he : index = key
    · have hv : value = node := by
        exact Option.some.inj (by simpa only [lookup, ite_eq_left he] using hget)
      simpa only [he, hv] using hvalue
    · by_cases hlt : index < key
      · exact ihleft hleft index node
          (by simpa only [lookup, ite_eq_right he, ite_eq_left hlt] using hget)
      · exact ihright hright index node
          (by simpa only [lookup, ite_eq_right he, ite_eq_right hlt] using hget)

theorem edgeSubset_holds {x : Var → ℝ} {required supplied : List Edge}
    (hsub : edgeSubset required supplied = true) (hsup : Holds x supplied) :
    Holds x required := by
  unfold edgeSubset at hsub
  intro e he
  exact hsup e (of_decide_eq_true (List.all_eq_true.mp hsub e he))

theorem requirementsCheck_holds {x : Var → ℝ} {required supplied : List Edge}
    {alt : Choice} (hsub : requirementsCheck required supplied alt = true)
    (hsup : Holds x supplied) (halt : Holds x alt) : Holds x required := by
  have hs : (required.filter (fun e => !decide (e ∈ alt))).Sublist supplied := by
    exact List.isSublist_iff_sublist.mp hsub
  intro e he
  by_cases ha : e ∈ alt
  · exact halt e ha
  · exact hsup e (hs.subset (List.mem_filter.mpr ⟨he, by simp [ha]⟩))

theorem checked_node_false (S : Spec) (active : Finset Label) (nodes : NodeTree)
    (x : Var → ℝ) (hm : Model S active x)
    (hall : allNodes (nodeCheck S active nodes) nodes = true)
    (index : ℕ) (node : DagNode) (hget : lookup nodes index = some node)
    (hreq : Holds x node.required) : False := by
  induction index using Nat.strongRecOn generalizing node with
  | ind index ih =>
    have hchecked := lookup_some_checked (nodeCheck S active nodes) nodes hall index node hget
    cases node with
    | mk required step =>
      cases step with
      | cycle path =>
        exact cycleCheck_false x required hreq path
          (by simpa only [nodeCheck] using hchecked)
      | branch i j children =>
        have hb : (decide (i ∈ active ∧ j ∈ active ∧ i < j) &&
            (S.options i j).all (fun alt =>
              children.any (childCheck nodes index required alt))) = true := by
          simpa only [nodeCheck] using hchecked
        obtain ⟨hpair, hchoices⟩ := Bool.and_eq_true_iff.mp hb
        have hp : i ∈ active ∧ j ∈ active ∧ i < j := of_decide_eq_true hpair
        obtain ⟨alt, halt, hxalt⟩ := hm.2 i hp.1 j hp.2.1 hp.2.2
        obtain ⟨child, _, hchild⟩ := List.any_eq_true.mp (List.all_eq_true.mp hchoices alt halt)
        unfold childCheck at hchild
        obtain ⟨hguard, hsub⟩ := Bool.and_eq_true_iff.mp hchild
        have hg : child.1 = alt ∧ child.2 < index := of_decide_eq_true hguard
        cases hnext : lookup nodes child.2 with
        | none => simp [hnext] at hsub
        | some next =>
          have hs : requirementsCheck next.required required alt = true := by
            simpa only [hnext] using hsub
          exact ih child.2 hg.2 next hnext (requirementsCheck_holds hs hreq hxalt)

theorem accepted_false (S : Spec) (active : Finset Label) (certificate : Certificate)
    (h : accepted S active certificate = true) : ¬ ∃ x, Model S active x := by
  rintro ⟨x, hx⟩
  cases hroot : lookup certificate.tree certificate.root with
  | none => simp [accepted, hroot] at h
  | some root =>
    have hc : (edgeSubset root.required (initialEdges S active) &&
        allNodes (nodeCheck S active certificate.tree) certificate.tree) = true := by
      simpa only [accepted, hroot] using h
    obtain ⟨hs, hall⟩ := Bool.and_eq_true_iff.mp hc
    exact checked_node_false S active certificate.tree x hx hall _ root hroot
      (edgeSubset_holds hs (initialEdges_hold S active x hx))

end Prize.JSP404.ThreeArcOrderDagCertificate
