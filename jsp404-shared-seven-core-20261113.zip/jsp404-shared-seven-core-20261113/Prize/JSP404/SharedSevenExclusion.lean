import Prize.JSP404.SharedSevenCertificate
import Prize.JSP404.ThreeArcSharedDifference

/-! A checked exclusion of one seven-label canonical shared-direction family.
This is one case needed for the twenty-three-point route, not its completion. -/
namespace Prize.JSP404.SharedSevenExclusion
open ContinuousDirection

/-- The endpoints are free within these seven canonical cells. -/
def active : List (Fin 20) := [10, 12, 13, 14, 15, 16, 19]

set_option maxRecDepth 65536 in
theorem spec_eq : SharedSevenCertificate.spec = ThreeArcSharedDifference.spec active := by
  rfl

theorem no_labelled_family {V : Type*} (C : ThreeArcSharedCanonicalModel V)
    (e : Fin 20 → V) (htype : ∀ i ∈ active, C.type (e i) = i) : False := by
  have hm := ThreeArcSharedDifference.model_of_canonical C active e htype
  apply SharedSevenCertificate.no_model
  exact ⟨_, by rwa [spec_eq]⟩

theorem no_family {V : Type*} (C : ThreeArcSharedCanonicalModel V)
    (hcore : ∀ i ∈ active, ∃ v, C.type v = i) : False := by
  classical
  let fallback : V := Classical.choose (hcore 10 (by decide))
  let e (i : Fin 20) : V := if hi : i ∈ active then Classical.choose (hcore i hi) else fallback
  apply no_labelled_family C e
  intro i hi
  change C.type (if hj : i ∈ active then Classical.choose (hcore i hj) else fallback) = i
  rw [dif_pos hi]
  exact Classical.choose_spec (hcore i hi)

end Prize.JSP404.SharedSevenExclusion
