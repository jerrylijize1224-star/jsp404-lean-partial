import Mathlib.Data.List.Basic
import Mathlib.Init
import Mathlib.Basic.Real.Basic

/-! Certificates for disjunctive integer difference constraints. Each edge
means either `x u ≤ x v + offset` or its strict version. A checked cycle has
negative total offset, or nonpositive offset with at least one strict edge.
Branch nodes cover every choice of a selected clause. Indexed dependencies
are stored in a tree and must refer to smaller indices. -/
namespace Prize.JSP404.DifferenceCertificate

structure Edge where
  u : ℕ
  v : ℕ
  offset : ℤ
  strict : Bool
  deriving DecidableEq

abbrev Choice := List Edge
abbrev Clause := List Choice

structure Spec where
  initial : List Edge
  clauses : Array Clause

def Bound (strict : Bool) (left right : ℝ) : Prop :=
  if strict then left < right else left ≤ right

def Satisfies (x : ℕ → ℝ) (edge : Edge) : Prop :=
  Bound edge.strict (x edge.u) (x edge.v + edge.offset)

def Holds (x : ℕ → ℝ) (edges : List Edge) : Prop :=
  ∀ edge ∈ edges, Satisfies x edge

def Model (S : Spec) (x : ℕ → ℝ) : Prop :=
  Holds x S.initial ∧
    ∀ (index : ℕ) (clause : Clause), S.clauses[index]? = some clause →
      ∃ choice ∈ clause, Holds x choice

def edgeSubset (required supplied : List Edge) : Bool :=
  required.all (fun edge => decide (edge ∈ supplied))

def offsetSum : List Edge → ℤ
  | [] => 0
  | edge :: rest => edge.offset + offsetSum rest

def hasStrict : List Edge → Bool
  | [] => false
  | edge :: rest => edge.strict || hasStrict rest

def chainCheck (first : ℕ) : ℕ → List Edge → Bool
  | current, [] => decide (current = first)
  | current, edge :: rest =>
      decide (edge.u = current) && chainCheck first edge.v rest

def badOffset (path : List Edge) : Bool :=
  decide (offsetSum path < 0) ||
    (decide (offsetSum path ≤ 0) && hasStrict path)

def cycleCheck (required : List Edge) : List Edge → Bool
  | [] => false
  | first :: rest =>
      edgeSubset (first :: rest) required &&
        (chainCheck first.u first.u (first :: rest) && badOffset (first :: rest))

inductive Step where
  | cycle (path : List Edge)
  | branch (clauseIndex : ℕ) (children : List (Choice × ℕ))

structure DagNode where
  required : List Edge
  step : Step

inductive NodeTree where
  | empty
  | node (index : ℕ) (value : DagNode) (left right : NodeTree)

structure Certificate where
  root : ℕ
  tree : NodeTree

def lookup : NodeTree → ℕ → Option DagNode
  | .empty, _ => none
  | .node key value left right, index =>
      if index = key then some value
      else if index < key then lookup left index else lookup right index

def allNodes (predicate : ℕ → DagNode → Bool) : NodeTree → Bool
  | .empty => true
  | .node index value left right =>
      predicate index value && (allNodes predicate left && allNodes predicate right)

def childCheck (nodes : NodeTree) (index : ℕ) (required : List Edge)
    (choice : Choice) (child : Choice × ℕ) : Bool :=
  decide (child.1 = choice ∧ child.2 < index) &&
    (match lookup nodes child.2 with
     | none => false
     | some node => edgeSubset node.required (required ++ choice))

def nodeCheck (S : Spec) (nodes : NodeTree) (index : ℕ) (node : DagNode) : Bool :=
  match node.step with
  | .cycle path => cycleCheck node.required path
  | .branch clauseIndex children =>
      match S.clauses[clauseIndex]? with
      | none => false
      | some clause =>
          clause.all (fun choice => children.any (childCheck nodes index node.required choice))

def accepted (S : Spec) (certificate : Certificate) : Bool :=
  match lookup certificate.tree certificate.root with
  | none => false
  | some node =>
      edgeSubset node.required S.initial &&
        allNodes (nodeCheck S certificate.tree) certificate.tree

theorem bound_le {strict : Bool} {left right : ℝ} (h : Bound strict left right) :
    left ≤ right := by
  cases strict with
  | false => exact h
  | true => exact le_of_lt h

theorem bound_trans_add {firstStrict secondStrict : Bool} {a b c t : ℝ}
    (hab : Bound firstStrict a (b + t)) (hbc : Bound secondStrict b c) :
    Bound (firstStrict || secondStrict) a (c + t) := by
  cases firstStrict <;> cases secondStrict <;> simp [Bound] at hab hbc ⊢
  · exact le_trans hab (by simpa only [add_comm] using add_le_add_right hbc t)
  · exact lt_of_le_of_lt hab (by simpa only [add_comm] using add_lt_add_right hbc t)
  · exact lt_of_lt_of_le hab (by simpa only [add_comm] using add_le_add_right hbc t)
  · exact lt_trans hab (by simpa only [add_comm] using add_lt_add_right hbc t)

theorem holds_append {x : ℕ → ℝ} {left right : List Edge}
    (hl : Holds x left) (hr : Holds x right) : Holds x (left ++ right) := by
  intro edge he
  rcases List.mem_append.mp he with he | he
  · exact hl edge he
  · exact hr edge he

theorem edgeSubset_holds {x : ℕ → ℝ} {required supplied : List Edge}
    (hsub : edgeSubset required supplied = true) (hsup : Holds x supplied) :
    Holds x required := by
  unfold edgeSubset at hsub
  intro edge he
  exact hsup edge (of_decide_eq_true (List.all_eq_true.mp hsub edge he))

theorem path_bound (x : ℕ → ℝ) (required : List Edge) (hreq : Holds x required)
    (first current : ℕ) (path : List Edge)
    (hmem : edgeSubset path required = true)
    (hchain : chainCheck first current path = true) :
    Bound (hasStrict path) (x current) (x first + offsetSum path) := by
  induction path generalizing current with
  | nil =>
    have he : current = first := of_decide_eq_true hchain
    simp [Bound, hasStrict, offsetSum, he]
  | cons edge rest ih =>
    change (decide (edge ∈ required) && edgeSubset rest required) = true at hmem
    obtain ⟨heMem, hrestMem⟩ := Bool.and_eq_true_iff.mp hmem
    change (decide (edge.u = current) && chainCheck first edge.v rest) = true at hchain
    obtain ⟨heStart, hrestChain⟩ := Bool.and_eq_true_iff.mp hchain
    have hstart : edge.u = current := of_decide_eq_true heStart
    have hedge := hreq edge (of_decide_eq_true heMem)
    have hrest := ih edge.v hrestMem hrestChain
    subst current
    have hbound := bound_trans_add hedge hrest
    simpa only [hasStrict, offsetSum, Int.cast_add, add_assoc, add_comm, add_left_comm]
      using hbound

theorem cycleCheck_false (x : ℕ → ℝ) (required : List Edge) (hreq : Holds x required)
    (path : List Edge) (hcheck : cycleCheck required path = true) : False := by
  cases path with
  | nil => simp [cycleCheck] at hcheck
  | cons first rest =>
    obtain ⟨hmem, htail⟩ := Bool.and_eq_true_iff.mp hcheck
    obtain ⟨hchain, hbad⟩ := Bool.and_eq_true_iff.mp htail
    have hbound := path_bound x required hreq first.u first.u (first :: rest) hmem hchain
    change (decide (offsetSum (first :: rest) < 0) ||
      (decide (offsetSum (first :: rest) ≤ 0) && hasStrict (first :: rest))) = true at hbad
    rcases Bool.or_eq_true_iff.mp hbad with hnegative | hstrict
    · have hs : (offsetSum (first :: rest) : ℝ) < 0 :=
        Int.cast_lt_zero.mpr (of_decide_eq_true hnegative)
      have hlt : x first.u + offsetSum (first :: rest) < x first.u := by
        simpa only [add_zero, zero_add, add_comm] using add_lt_add_left hs (x first.u)
      exact (not_lt_of_ge (bound_le hbound)) hlt
    · obtain ⟨hnonpos, hstrict⟩ := Bool.and_eq_true_iff.mp hstrict
      have hs : (offsetSum (first :: rest) : ℝ) ≤ 0 :=
        Int.cast_nonpos.mpr (of_decide_eq_true hnonpos)
      have hlt : x first.u < x first.u + offsetSum (first :: rest) := by
        simpa [Bound, hstrict] using hbound
      have hle : x first.u + offsetSum (first :: rest) ≤ x first.u := by
        simpa only [add_zero, zero_add, add_comm] using add_le_add_left hs (x first.u)
      exact (not_lt_of_ge hle) hlt

theorem lookup_some_checked (predicate : ℕ → DagNode → Bool) (tree : NodeTree)
    (hall : allNodes predicate tree = true) (index : ℕ) (node : DagNode)
    (hget : lookup tree index = some node) : predicate index node = true := by
  induction tree generalizing index node with
  | empty => simp [lookup] at hget
  | node key value left right ihleft ihright =>
    obtain ⟨hvalue, hbranches⟩ := Bool.and_eq_true_iff.mp hall
    obtain ⟨hleft, hright⟩ := Bool.and_eq_true_iff.mp hbranches
    by_cases he : index = key
    · have hv : value = node := by
        exact Option.some.inj (by simpa only [lookup, ite_eq_left he] using hget)
      simpa only [he, hv] using hvalue
    · by_cases hlt : index < key
      · exact ihleft hleft index node
          (by simpa only [lookup, ite_eq_right he, ite_eq_left hlt] using hget)
      · exact ihright hright index node
          (by simpa only [lookup, ite_eq_right he, ite_eq_right hlt] using hget)

theorem checked_node_false (S : Spec) (nodes : NodeTree) (x : ℕ → ℝ) (hm : Model S x)
    (hall : allNodes (nodeCheck S nodes) nodes = true)
    (index : ℕ) (node : DagNode) (hget : lookup nodes index = some node)
    (hreq : Holds x node.required) : False := by
  induction index using Nat.strongRecOn generalizing node with
  | ind index ih =>
    have hchecked := lookup_some_checked (nodeCheck S nodes) nodes hall index node hget
    cases node with
    | mk required step =>
      cases step with
      | cycle path =>
        exact cycleCheck_false x required hreq path (by simpa only [nodeCheck] using hchecked)
      | branch clauseIndex children =>
        cases hclause : S.clauses[clauseIndex]? with
        | none => simp [nodeCheck, hclause] at hchecked
        | some clause =>
          have hchoices : clause.all (fun choice =>
              children.any (childCheck nodes index required choice)) = true := by
            simpa only [nodeCheck, hclause] using hchecked
          obtain ⟨choice, hchoice, hxchoice⟩ := hm.2 clauseIndex clause hclause
          obtain ⟨child, _, hchild⟩ :=
            List.any_eq_true.mp (List.all_eq_true.mp hchoices choice hchoice)
          unfold childCheck at hchild
          obtain ⟨hguard, hsub⟩ := Bool.and_eq_true_iff.mp hchild
          have hg : child.1 = choice ∧ child.2 < index := of_decide_eq_true hguard
          cases hnext : lookup nodes child.2 with
          | none => simp [hnext] at hsub
          | some next =>
            have hs : edgeSubset next.required (required ++ choice) = true := by
              simpa only [hnext] using hsub
            exact ih child.2 hg.2 next hnext
              (edgeSubset_holds hs (holds_append hreq hxchoice))

theorem accepted_false (S : Spec) (certificate : Certificate)
    (h : accepted S certificate = true) : ¬ ∃ x, Model S x := by
  rintro ⟨x, hx⟩
  cases hroot : lookup certificate.tree certificate.root with
  | none => simp [accepted, hroot] at h
  | some root =>
    have hc : (edgeSubset root.required S.initial &&
        allNodes (nodeCheck S certificate.tree) certificate.tree) = true := by
      simpa only [accepted, hroot] using h
    obtain ⟨hs, hall⟩ := Bool.and_eq_true_iff.mp hc
    exact checked_node_false S certificate.tree x hx hall _ root hroot
      (edgeSubset_holds hs hx.1)

end Prize.JSP404.DifferenceCertificate
