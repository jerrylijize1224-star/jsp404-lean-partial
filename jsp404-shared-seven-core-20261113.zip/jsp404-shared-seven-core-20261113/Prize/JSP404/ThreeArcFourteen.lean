import Prize.JSP404.ThreeArcOrder15Checks
import Prize.JSP404.ThreeArcOrder15Coverage
import Prize.JSP404.ThreeArcOrderCoreHelpers
import Prize.JSP404.ThreeArcOrderModelFive
import Prize.JSP404.ThreeArcOrderFiniteSpec

namespace Prize.JSP404.ThreeArcOrderFiniteSpec

theorem spec_eq_original : spec = ThreeArcOrderData.spec := by
  rfl

end Prize.JSP404.ThreeArcOrderFiniteSpec

/-! Every set of fifteen active labels contains a checked contradictory core.
The continuous model bridge then bounds compatible three-arc families by fourteen. -/
namespace Prize.JSP404.ThreeArcTwenty
open ContinuousDirection ThreeArcOrderCertificate

theorem no_fifteen_family {d : ℝ} (hd : d < 36 / 5)
    (R : Fin 15 → ThreeArcRow d)
    (hpair : ∀ i j, i ≠ j → ∃ x y : ℝ, ∃ z : ℤ,
      (R i).Mem x ∧ (R j).Mem y ∧ y = x + 9 + 18 * z) : False := by
  obtain ⟨t, ht, x, hx⟩ := ThreeArcOrderModelGeneral.exists_order_model R hd hpair
  obtain ⟨a, b, c, e, f, hab, hbc, hce, hef, ha⟩ :=
    ThreeArcOrderModelGeneralFive.active_erase_quintuple t ht
  obtain ⟨i, hi⟩ := ThreeArcOrder15Coverage.all_covered a b c e f hab hbc hce hef
  have hcore : ThreeArcOrder15Data.core i ⊆ ThreeArcOrderModelGeneral.active t := by
    rw [ha]
    exact hi
  have hxCore : Model ThreeArcOrder15Data.spec (ThreeArcOrder15Data.core i) x := by
    change Model ThreeArcOrderFiniteSpec.spec (ThreeArcOrder15Data.core i) x
    rw [ThreeArcOrderFiniteSpec.spec_eq_original]
    exact hx.mono hcore
  exact ThreeArcOrderDagCertificate.accepted_false ThreeArcOrder15Data.spec _
    (ThreeArcOrder15Data.certificate i) (ThreeArcOrder15Data.all_accepted i)
    ⟨x, hxCore⟩

theorem family_card_le_fourteen {V : Type*} [Fintype V] {d : ℝ}
    (hd : d < 36 / 5) (R : V → ThreeArcRow d)
    (hpair : ∀ i j, i ≠ j → ∃ x y : ℝ, ∃ z : ℤ,
      (R i).Mem x ∧ (R j).Mem y ∧ y = x + 9 + 18 * z) :
    Fintype.card V ≤ 14 := by
  by_contra hn
  have h15 : 15 ≤ Fintype.card V := by omega
  let e : Fin 15 → V := fun i => (Fintype.equivFin V).symm (Fin.castLE h15 i)
  have he : Function.Injective e := by
    intro i j h
    apply Fin.ext
    have hval := congrArg Fin.val ((Fintype.equivFin V).symm.injective h)
    exact hval
  exact no_fifteen_family hd (fun i => R (e i))
    (fun i j hij => hpair (e i) (e j) (he.ne hij))

end Prize.JSP404.ThreeArcTwenty
