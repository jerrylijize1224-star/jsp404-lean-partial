import Prize.JSP404.ThreeArcOrderModelGeneral

/-! Fifteen occupied type labels leave five omitted labels. -/
namespace Prize.JSP404.ThreeArcOrderModelGeneralFive
open ThreeArcOrderCertificate

set_option maxHeartbeats 4000000 in
/-- List the five omitted labels in increasing order. -/
theorem active_erase_quintuple (t : Fin 15 → Label) (ht : Function.Injective t) :
    ∃ a b c d e : Label, a < b ∧ b < c ∧ c < d ∧ d < e ∧
      ThreeArcOrderModelGeneral.active t =
        (((((Finset.univ : Finset Label).erase a).erase b).erase c).erase d).erase e := by
  classical
  let missing := (Finset.univ : Finset Label) \ ThreeArcOrderModelGeneral.active t
  have hc : missing.card = 5 := by
    dsimp [missing]
    rw [Finset.card_sdiff_of_subset (Finset.subset_univ _),
      ThreeArcOrderModelGeneral.active_card t ht]
    norm_num
  let order : Fin 5 ≃o missing := missing.orderIsoOfFin hc
  let a : Label := (order 0).val
  let b : Label := (order 1).val
  let c : Label := (order 2).val
  let d : Label := (order 3).val
  let e : Label := (order 4).val
  have hab : a < b := order.strictMono (by decide : (0 : Fin 5) < 1)
  have hbc : b < c := order.strictMono (by decide : (1 : Fin 5) < 2)
  have hcd : c < d := order.strictMono (by decide : (2 : Fin 5) < 3)
  have hde : d < e := order.strictMono (by decide : (3 : Fin 5) < 4)
  have hmissing (i : Label) :
      i ∈ missing ↔ i = a ∨ i = b ∨ i = c ∨ i = d ∨ i = e := by
    constructor
    · intro hi
      obtain ⟨j, hj⟩ := order.surjective ⟨i, hi⟩
      have hv := congrArg Subtype.val hj
      fin_cases j
      · exact Or.inl hv.symm
      · exact Or.inr (Or.inl hv.symm)
      · exact Or.inr (Or.inr (Or.inl hv.symm))
      · exact Or.inr (Or.inr (Or.inr (Or.inl hv.symm)))
      · exact Or.inr (Or.inr (Or.inr (Or.inr hv.symm)))
    · intro hi
      rcases hi with rfl | rfl | rfl | rfl | rfl
      · exact (order 0).property
      · exact (order 1).property
      · exact (order 2).property
      · exact (order 3).property
      · exact (order 4).property
  have hmem (i : Label) : i ∈ ThreeArcOrderModelGeneral.active t ↔
      i ≠ a ∧ i ≠ b ∧ i ≠ c ∧ i ≠ d ∧ i ≠ e := by
    have hn : i ∉ ThreeArcOrderModelGeneral.active t ↔
        i = a ∨ i = b ∨ i = c ∨ i = d ∨ i = e := by
      simpa [missing] using hmissing i
    have he := not_congr hn
    simpa only [not_not, not_or] using he
  refine ⟨a, b, c, d, e, hab, hbc, hcd, hde, ?_⟩
  ext i
  rw [hmem]
  simp only [Finset.mem_erase, Finset.mem_univ, and_true]
  constructor
  · rintro ⟨ha, hb, hc, hd, he⟩
    exact ⟨he, hd, hc, hb, ha⟩
  · rintro ⟨he, hd, hc, hb, ha⟩
    exact ⟨ha, hb, hc, hd, he⟩

end Prize.JSP404.ThreeArcOrderModelGeneralFive
