import Prize.JSP404.DifferenceCertificate
import Mathlib.Tactic.Sat.FromLRAT
import Mathlib.Tactic.Linarith

/-! A semantic bridge from checked difference constraints to ordinary CNF.
Theory clauses are accepted only after their negated atoms form a checked bad
cycle. Propositional refutations use mathlib's existing LRAT proof importer. -/
namespace Prize.JSP404.DifferenceSat
open DifferenceCertificate

/-- Negation of a mixed strict/non-strict difference edge. -/
def complement (e : Edge) : Edge :=
  ⟨e.v, e.u, -e.offset, !e.strict⟩

theorem complement_satisfies_iff (x : ℕ → ℝ) (e : Edge) :
    Satisfies x (complement e) ↔ ¬ Satisfies x e := by
  rcases e with ⟨u, v, offset, strict⟩
  cases strict <;> simp [complement, Satisfies, Bound] <;>
    constructor <;> intro h <;> linarith

inductive Formula where
  | atom (edge : Edge)
  | top
  | bot
  | neg (a : Formula)
  | conj (a b : Formula)
  | disj (a b : Formula)
  deriving DecidableEq

def eval (x : ℕ → ℝ) : Formula → Prop
  | .atom e => Satisfies x e
  | .top => True
  | .bot => False
  | .neg a => ¬ eval x a
  | .conj a b => eval x a ∧ eval x b
  | .disj a b => eval x a ∨ eval x b

/-- Strict sources are expressed as negations of complementary weak atoms. -/
def edgeFormula (e : Edge) : Formula :=
  if e.strict then .neg (.atom (complement e)) else .atom e

def choiceFormula : Choice → Formula
  | [] => .top
  | e :: rest => .conj (edgeFormula e) (choiceFormula rest)

def clauseFormula : DifferenceCertificate.Clause → Formula
  | [] => .bot
  | choice :: rest => .disj (choiceFormula choice) (clauseFormula rest)

/-- An untrusted lookup tree for formula values. No ordering assumption is
needed: the semantic valuation uses exactly the function returned by get. -/
inductive FormTree where
  | empty
  | node (index : ℕ) (value : Formula) (left right : FormTree)

def FormTree.get : FormTree → ℕ → Formula
  | .empty, _ => .bot
  | .node key value left right, index =>
      if index = key then value
      else if index < key then left.get index else right.get index

def form (forms : ℕ → Formula) (index : ℕ) : Formula :=
  forms index

def val (x : ℕ → ℝ) (forms : ℕ → Formula) : Sat.Valuation :=
  fun index => eval x (form forms index)

theorem edgeFormula_sound (x : ℕ → ℝ) (e : Edge) :
    eval x (edgeFormula e) ↔ Satisfies x e := by
  classical
  by_cases hs : e.strict = true
  · simp [edgeFormula, hs, eval, complement_satisfies_iff]
  · simp [edgeFormula, hs, eval]

theorem choiceFormula_sound (x : ℕ → ℝ) (choice : Choice) :
    eval x (choiceFormula choice) ↔ Holds x choice := by
  induction choice with
  | nil => simp [choiceFormula, eval, Holds]
  | cons e rest ih =>
    change (eval x (edgeFormula e) ∧ eval x (choiceFormula rest)) ↔ Holds x (e :: rest)
    constructor
    · rintro ⟨he, hr⟩ edge hmem
      rcases List.mem_cons.mp hmem with heq | hmem
      · subst edge
        exact (edgeFormula_sound x e).mp he
      · exact ih.mp hr edge hmem
    · intro h
      refine ⟨(edgeFormula_sound x e).mpr (h e (by simp)), ih.mpr ?_⟩
      intro edge hmem
      exact h edge (List.mem_cons_of_mem e hmem)

theorem clauseFormula_sound (x : ℕ → ℝ) (clause : DifferenceCertificate.Clause) :
    eval x (clauseFormula clause) ↔ ∃ choice ∈ clause, Holds x choice := by
  induction clause with
  | nil => simp [clauseFormula, eval]
  | cons choice rest ih =>
    change (eval x (choiceFormula choice) ∨ eval x (clauseFormula rest)) ↔
      ∃ c ∈ choice :: rest, Holds x c
    constructor
    · rintro (hc | hr)
      · exact ⟨choice, by simp, (choiceFormula_sound x choice).mp hc⟩
      · obtain ⟨c, hc, hh⟩ := ih.mp hr
        exact ⟨c, List.mem_cons_of_mem choice hc, hh⟩
    · rintro ⟨c, hc, hh⟩
      rcases List.mem_cons.mp hc with heq | hc
      · subst c
        exact Or.inl ((choiceFormula_sound x choice).mpr hh)
      · exact Or.inr (ih.mpr ⟨c, hc, hh⟩)

structure Lit where
  index : ℕ
  positive : Bool
  deriving DecidableEq

def Lit.toSat (lit : Lit) : Sat.Literal :=
  if lit.positive then .pos lit.index else .neg lit.index

def isAtom (forms : ℕ → Formula) (index : ℕ) : Bool :=
  match form forms index with
  | .atom _ => true
  | _ => false

def atomOf (forms : ℕ → Formula) (index : ℕ) : Edge :=
  match form forms index with
  | .atom e => e
  | _ => ⟨0, 0, 0, false⟩

def negatedEdge (forms : ℕ → Formula) (lit : Lit) : Edge :=
  if lit.positive then complement (atomOf forms lit.index) else atomOf forms lit.index

theorem form_eq_atom_of_isAtom {forms : ℕ → Formula} {index : ℕ}
    (h : isAtom forms index = true) : form forms index = .atom (atomOf forms index) := by
  cases hf : form forms index <;> simp [isAtom, atomOf, hf] at h ⊢

theorem negatedEdge_holds (x : ℕ → ℝ) (forms : ℕ → Formula) (lit : Lit)
    (hatom : isAtom forms lit.index = true)
    (hneg : (val x forms).neg lit.toSat) : Satisfies x (negatedEdge forms lit) := by
  have hv : val x forms lit.index ↔ Satisfies x (atomOf forms lit.index) := by
    change eval x (form forms lit.index) ↔ _
    rw [form_eq_atom_of_isAtom hatom]
    rfl
  rcases lit with ⟨index, positive⟩
  cases positive with
  | false =>
    change val x forms index at hneg
    change Satisfies x (atomOf forms index)
    exact hv.mp hneg
  | true =>
    change ¬ val x forms index at hneg
    change Satisfies x (complement (atomOf forms index))
    exact (complement_satisfies_iff _ _).mpr (fun h => hneg (hv.mpr h))

/-- This matches mathlib's implication-based encoding of clause satisfaction. -/
theorem satisfies_of_not_all_neg (v : Sat.Valuation) (clause : List Lit)
    (h : (∀ lit ∈ clause, v.neg lit.toSat) → False) :
    v.satisfies (clause.map Lit.toSat) := by
  induction clause with
  | nil => exact h (by simp)
  | cons lit rest ih =>
    change v.neg lit.toSat → v.satisfies (rest.map Lit.toSat)
    intro hlit
    apply ih
    intro hrest
    apply h
    intro l hl
    rcases List.mem_cons.mp hl with rfl | hl
    · exact hlit
    · exact hrest l hl

inductive Support where
  | initial (index p : ℕ)
  | source (index p : ℕ)
  | andLeft (p a b : ℕ)
  | andRight (p a b : ℕ)
  | andBack (p a b : ℕ)
  | orLeft (p a b : ℕ)
  | orRight (p a b : ℕ)
  | orBack (p a b : ℕ)
  | negForward (p a : ℕ)
  | negBack (p a : ℕ)
  | truth (p : ℕ)
  | falsity (p : ℕ)
  | theory (lits : List Lit) (cycle : List Edge)

/-- The order and polarity agree with the input DIMACS clauses. -/
def Support.clause : Support → Sat.Clause
  | .initial _ p | .source _ p | .truth p => [.pos p]
  | .falsity p => [.neg p]
  | .andLeft p a _ => [.neg p, .pos a]
  | .andRight p _ b => [.neg p, .pos b]
  | .andBack p a b => [.pos p, .neg a, .neg b]
  | .orLeft p a _ => [.pos p, .neg a]
  | .orRight p _ b => [.pos p, .neg b]
  | .orBack p a b => [.neg p, .pos a, .pos b]
  | .negForward p a => [.neg p, .neg a]
  | .negBack p a => [.pos p, .pos a]
  | .theory lits _ => lits.map Lit.toSat

def Support.check (S : Spec) (forms : ℕ → Formula) : Support → Bool
  | .initial index p =>
      match S.initial[index]? with
      | none => false
      | some edge => decide (form forms p = edgeFormula edge)
  | .source index p =>
      match S.clauses[index]? with
      | none => false
      | some clause => decide (form forms p = clauseFormula clause)
  | .andLeft p a b | .andRight p a b | .andBack p a b =>
      decide (form forms p = .conj (form forms a) (form forms b))
  | .orLeft p a b | .orRight p a b | .orBack p a b =>
      decide (form forms p = .disj (form forms a) (form forms b))
  | .negForward p a | .negBack p a => decide (form forms p = .neg (form forms a))
  | .truth p => decide (form forms p = .top)
  | .falsity p => decide (form forms p = .bot)
  | .theory lits cycle =>
      lits.all (fun lit => isAtom forms lit.index) &&
        cycleCheck (lits.map (negatedEdge forms)) cycle

theorem Support.sound (S : Spec) (forms : ℕ → Formula) (x : ℕ → ℝ)
    (hm : Model S x) (support : Support) (hcheck : support.check S forms = true) :
    (val x forms).satisfies support.clause := by
  cases support with
  | initial index p =>
    cases hi : S.initial[index]? with
    | none => simp [Support.check, hi] at hcheck
    | some edge =>
      have hshape : form forms p = edgeFormula edge := of_decide_eq_true
        (by simpa only [Support.check, hi] using hcheck)
      have he : Satisfies x edge := hm.1 edge (List.mem_of_getElem? hi)
      change ¬ val x forms p → False
      intro hn
      apply hn
      change eval x (form forms p)
      rw [hshape]
      exact (edgeFormula_sound x edge).mpr he
  | source index p =>
    cases hi : S.clauses[index]? with
    | none => simp [Support.check, hi] at hcheck
    | some clause =>
      have hshape : form forms p = clauseFormula clause := of_decide_eq_true
        (by simpa only [Support.check, hi] using hcheck)
      have he := (clauseFormula_sound x clause).mpr (hm.2 index clause hi)
      change ¬ val x forms p → False
      intro hn
      apply hn
      change eval x (form forms p)
      rw [hshape]
      exact he
  | andLeft p a b =>
    have hs : form forms p = .conj (form forms a) (form forms b) := of_decide_eq_true hcheck
    have hv : val x forms p ↔ val x forms a ∧ val x forms b := by
      change eval x (form forms p) ↔ _
      rw [hs]
      rfl
    change val x forms p → ¬ val x forms a → False
    intro hp ha
    exact ha (hv.mp hp).1
  | andRight p a b =>
    have hs : form forms p = .conj (form forms a) (form forms b) := of_decide_eq_true hcheck
    have hv : val x forms p ↔ val x forms a ∧ val x forms b := by
      change eval x (form forms p) ↔ _
      rw [hs]
      rfl
    change val x forms p → ¬ val x forms b → False
    intro hp hb
    exact hb (hv.mp hp).2
  | andBack p a b =>
    have hs : form forms p = .conj (form forms a) (form forms b) := of_decide_eq_true hcheck
    have hv : val x forms p ↔ val x forms a ∧ val x forms b := by
      change eval x (form forms p) ↔ _
      rw [hs]
      rfl
    change ¬ val x forms p → val x forms a → val x forms b → False
    intro hp ha hb
    exact hp (hv.mpr ⟨ha, hb⟩)
  | orLeft p a b =>
    have hs : form forms p = .disj (form forms a) (form forms b) := of_decide_eq_true hcheck
    have hv : val x forms p ↔ val x forms a ∨ val x forms b := by
      change eval x (form forms p) ↔ _
      rw [hs]
      rfl
    change ¬ val x forms p → val x forms a → False
    intro hp ha
    exact hp (hv.mpr (Or.inl ha))
  | orRight p a b =>
    have hs : form forms p = .disj (form forms a) (form forms b) := of_decide_eq_true hcheck
    have hv : val x forms p ↔ val x forms a ∨ val x forms b := by
      change eval x (form forms p) ↔ _
      rw [hs]
      rfl
    change ¬ val x forms p → val x forms b → False
    intro hp hb
    exact hp (hv.mpr (Or.inr hb))
  | orBack p a b =>
    have hs : form forms p = .disj (form forms a) (form forms b) := of_decide_eq_true hcheck
    have hv : val x forms p ↔ val x forms a ∨ val x forms b := by
      change eval x (form forms p) ↔ _
      rw [hs]
      rfl
    change val x forms p → ¬ val x forms a → ¬ val x forms b → False
    intro hp ha hb
    exact (hv.mp hp).elim ha hb
  | negForward p a =>
    have hs : form forms p = .neg (form forms a) := of_decide_eq_true hcheck
    have hv : val x forms p ↔ ¬ val x forms a := by
      change eval x (form forms p) ↔ _
      rw [hs]
      rfl
    change val x forms p → val x forms a → False
    intro hp ha
    exact (hv.mp hp) ha
  | negBack p a =>
    have hs : form forms p = .neg (form forms a) := of_decide_eq_true hcheck
    have hv : val x forms p ↔ ¬ val x forms a := by
      change eval x (form forms p) ↔ _
      rw [hs]
      rfl
    change ¬ val x forms p → ¬ val x forms a → False
    intro hp ha
    exact hp (hv.mpr ha)
  | truth p =>
    have hs : form forms p = .top := of_decide_eq_true hcheck
    change ¬ val x forms p → False
    intro hp
    apply hp
    change eval x (form forms p)
    rw [hs]
    trivial
  | falsity p =>
    have hs : form forms p = .bot := of_decide_eq_true hcheck
    change val x forms p → False
    intro hp
    change eval x (form forms p) at hp
    rw [hs] at hp
    exact hp
  | theory lits cycle =>
    obtain ⟨hatoms, hcycle⟩ := Bool.and_eq_true_iff.mp hcheck
    apply satisfies_of_not_all_neg
    intro hneg
    have hedge : Holds x (lits.map (negatedEdge forms)) := by
      intro edge he
      obtain ⟨lit, hlit, rfl⟩ := List.mem_map.mp he
      exact negatedEdge_holds x forms lit (List.all_eq_true.mp hatoms lit hlit) (hneg lit hlit)
    exact cycleCheck_false x _ hedge cycle hcycle

def formula (supports : Array Support) : Sat.Fmla :=
  supports.toList.map Support.clause

def accepted (S : Spec) (forms : ℕ → Formula) (supports : Array Support) : Bool :=
  supports.toList.all (Support.check S forms)

theorem accepted_sound (S : Spec) (forms : ℕ → Formula) (supports : Array Support)
    (x : ℕ → ℝ) (hm : Model S x) (hcheck : accepted S forms supports = true) :
    (val x forms).satisfies_fmla (formula supports) := by
  constructor
  intro clause hclause
  change clause ∈ supports.toList.map Support.clause at hclause
  obtain ⟨support, hsupport, rfl⟩ := List.mem_map.mp hclause
  exact Support.sound S forms x hm support (List.all_eq_true.mp hcheck support hsupport)

theorem accepted_false (S : Spec) (forms : ℕ → Formula) (supports : Array Support)
    (hcheck : accepted S forms supports = true) (hproof : (formula supports).proof []) :
    ¬ ∃ x, Model S x := by
  rintro ⟨x, hx⟩
  exact hproof (val x forms) (accepted_sound S forms supports x hx hcheck)

end Prize.JSP404.DifferenceSat

open Lean Elab Term

/-- Import the existing LRAT kernel proof without the optional DNF reification.
The public context is `name.ctx`; the public theorem is `name.unsat`. -/
elab "difference_lrat " n:ident ppSpace cnf:term:max ppSpace lrat:term:max : command => do
  let name := (← getCurrNamespace) ++ n.getId
  Command.liftTermElabM do
    let cnf ← unsafe evalTerm String (mkConst ``String) cnf
    let lrat ← unsafe evalTerm String (mkConst ``String) lrat
    let (_, ctx, _, proof) ← Mathlib.Tactic.Sat.fromLRATAux cnf lrat (name ++ `internal)
    let ctxName := name ++ `ctx
    addDecl <| Declaration.defnDecl {
      name := ctxName, levelParams := [], type := mkConst ``Sat.Fmla,
      value := ctx, hints := ReducibilityHints.regular 0, safety := DefinitionSafety.safe }
    addDecl <| Declaration.thmDecl {
      name := name ++ `unsat, levelParams := [],
      type := mkApp2 (mkConst ``Sat.Fmla.proof) (mkConst ctxName)
        (Mathlib.Tactic.Sat.buildClause #[]),
      value := proof }
