import Prize.JSP404.ThreeArcCanonical
import Prize.JSP404.PlanarReduction144

/-! Shared edge directions survive the canonical row normalization. The rows
are only cyclically renamed and shifted by whole periods. These necessary
conditions are not an exclusion of fourteen rows or a planar realization claim. -/
namespace Prize.JSP404.ContinuousDirection

structure ThreeArcSharedFamily (V : Type*) (d : ℝ) where
  row : V → ThreeArcRow d
  direction : V → V → ℝ
  reverse : ∀ i j, i ≠ j → ∃ z : ℤ,
    direction j i = direction i j + 9 + 18 * z
  triangle : ∀ i j k, i ≠ j → i ≠ k → j ≠ k →
    TriangleCompatible (direction i j) (direction i k) (direction j k)
  covered : ∀ i j, i ≠ j → ∃ z : ℤ, (row i).Mem (direction i j + 18 * z)

def ThreeArcSharedFamily.comap {V W : Type*} {d : ℝ}
    (F : ThreeArcSharedFamily V d) (e : W → V) (he : Function.Injective e) :
    ThreeArcSharedFamily W d where
  row i := F.row (e i)
  direction i j := F.direction (e i) (e j)
  reverse i j hij := F.reverse _ _ (he.ne hij)
  triangle i j k hij hik hjk := F.triangle _ _ _ (he.ne hij) (he.ne hik) (he.ne hjk)
  covered i j hij := F.covered _ _ (he.ne hij)

theorem ThreeArcSharedFamily.pair {V : Type*} {d : ℝ}
    (F : ThreeArcSharedFamily V d) (i j : V) (hij : i ≠ j) :
    ∃ x y : ℝ, ∃ z : ℤ,
      (F.row i).Mem x ∧ (F.row j).Mem y ∧ y = x + 9 + 18 * z := by
  obtain ⟨k, hk⟩ := F.covered i j hij
  obtain ⟨l, hl⟩ := F.covered j i hij.symm
  obtain ⟨z, hz⟩ := F.reverse i j hij
  refine ⟨_, _, z + l - k, hk, hl, ?_⟩
  push_cast
  linarith

/-- The stronger interface retains the cover map omitted from the older
pairwise-only normalization theorem. No row is independently perturbed. -/
theorem exists_canonical_with_covers {V : Type*} {d : ℝ}
    (R : V → ThreeArcRow d) (hd : d < 36 / 5)
    (hpair : ∀ i j, i ≠ j → ∃ x y : ℝ, ∃ z : ℤ,
      (R i).Mem x ∧ (R j).Mem y ∧ y = x + 9 + 18 * z) :
    ∃ S : V → ThreeArcRow d, ∃ t : V → Fin 20,
      (∀ i, 0 ≤ (S i).a ∧ (S i).c < 18 ∧ ThreeArcCanonical.Covers (R i) (S i)) ∧
      (∀ i k, ⌊5 * (S i).start k / 9⌋ = ThreeArcCanonical.starts (t i) k) ∧
      Function.Injective t := by
  classical
  let S (i : V) := Classical.choose (ThreeArcCanonical.exists_normalized (R i))
  have hS (i : V) := Classical.choose_spec (ThreeArcCanonical.exists_normalized (R i))
  have hex (i : V) := ThreeArcCanonical.normalized_row_floors (S i) hd (hS i).1 (hS i).2.1
  let t (i : V) := Classical.choose (hex i)
  have hf (i : V) : ∀ k, ⌊5 * (S i).start k / 9⌋ = ThreeArcCanonical.starts (t i) k :=
    Classical.choose_spec (hex i)
  have hp := ThreeArcCanonical.covers_pair_transfer R S (fun i => (hS i).2.2) hpair
  refine ⟨S, t, hS, hf, ?_⟩
  intro i j he
  apply ThreeArcTwenty.family_masks_injective hd S hp
  change ThreeArcTwenty.rowShape (S i) = ThreeArcTwenty.rowShape (S j)
  rw [ThreeArcCanonical.shape_of_floors (S i) (t i) (hf i),
    ThreeArcCanonical.shape_of_floors (S j) (t j) (hf j), he]

noncomputable def sharedNormal18 (x : ℝ) : ℝ := x - 18 * (⌊x / 18⌋ : ℤ)
noncomputable def sharedNormal10 (x : ℝ) : ℝ := 5 * sharedNormal18 x / 9

theorem sharedNormal18_bounds (x : ℝ) :
    0 ≤ sharedNormal18 x ∧ sharedNormal18 x < 18 := by
  have hlo := Int.floor_le (x / 18)
  have hhi := Int.lt_floor_add_one (x / 18)
  unfold sharedNormal18
  constructor <;> linarith

theorem sharedNormal10_bounds (x : ℝ) :
    0 ≤ sharedNormal10 x ∧ sharedNormal10 x < 10 := by
  obtain ⟨hlo, hhi⟩ := sharedNormal18_bounds x
  unfold sharedNormal10
  constructor <;> linarith

def SharedTurn10 (x y : ℝ) : Prop :=
  (0 < y - x ∧ y - x < 5) ∨ (-10 < y - x ∧ y - x < -5)

def SharedTriangle10 (u v w : ℝ) : Prop :=
  (SharedTurn10 u v ∧ SharedTurn10 u w ∧ SharedTurn10 v w) ∨
  (SharedTurn10 v u ∧ SharedTurn10 w u ∧ SharedTurn10 w v)

theorem sharedTurn10_of_positiveTurn {x y : ℝ}
    (hx : 0 ≤ x ∧ x < 18) (hy : 0 ≤ y ∧ y < 18) (h : PositiveTurn x y) :
    SharedTurn10 (5 * x / 9) (5 * y / 9) := by
  rcases (positiveTurn_iff_of_normalized hx hy).mp h with h | h
  · left; constructor <;> linarith [h.1, h.2]
  · right; constructor <;> linarith [h.1, h.2]

theorem sharedTriangle10_of_triangleCompatible {u v w : ℝ}
    (hu : 0 ≤ u ∧ u < 18) (hv : 0 ≤ v ∧ v < 18) (hw : 0 ≤ w ∧ w < 18)
    (h : TriangleCompatible u v w) :
    SharedTriangle10 (5 * u / 9) (5 * v / 9) (5 * w / 9) := by
  rcases h with h | h
  · exact Or.inl ⟨sharedTurn10_of_positiveTurn hu hv h.1,
      sharedTurn10_of_positiveTurn hu hw h.2.1, sharedTurn10_of_positiveTurn hv hw h.2.2⟩
  · exact Or.inr ⟨sharedTurn10_of_positiveTurn hv hu h.1,
      sharedTurn10_of_positiveTurn hw hu h.2.1, sharedTurn10_of_positiveTurn hw hv h.2.2⟩

def SharedRowMem10 (a : Fin 3 → ℝ) (x : ℝ) : Prop :=
  (a 0 ≤ x ∧ x < a 2 + 4 - 10) ∨
  (a 1 ≤ x ∧ x < a 0 + 4) ∨ (a 2 ≤ x ∧ x < a 1 + 4)

/-- Three shifts times three arcs give the nine membership alternatives. -/
def SharedMember10 (a : Fin 3 → ℝ) (x : ℝ) : Prop :=
  SharedRowMem10 a (x - 10) ∨ SharedRowMem10 a x ∨ SharedRowMem10 a (x + 10)

theorem sharedRowMem10_of_mem {d : ℝ} (R : ThreeArcRow d) (hd : d < 36 / 5)
    {x : ℝ} (hx : R.Mem x) :
    SharedRowMem10 (fun k => 5 * R.start k / 9) (5 * x / 9) := by
  change (5 * R.a / 9 ≤ 5 * x / 9 ∧ 5 * x / 9 < 5 * R.c / 9 + 4 - 10) ∨
    (5 * R.b / 9 ≤ 5 * x / 9 ∧ 5 * x / 9 < 5 * R.a / 9 + 4) ∨
    (5 * R.c / 9 ≤ 5 * x / 9 ∧ 5 * x / 9 < 5 * R.b / 9 + 4)
  rcases hx with hx | hx | hx
  · left; constructor <;> linarith [hx.1, hx.2]
  · right; left; constructor <;> linarith [hx.1, hx.2]
  · right; right; constructor <;> linarith [hx.1, hx.2]

theorem sharedRowMem10_bounds {a : Fin 3 → ℝ}
    (ha : 0 ≤ a 0) (hab : a 0 < a 1) (hbc : a 1 < a 2) (hc : a 2 < 10)
    {x : ℝ} (hx : SharedRowMem10 a x) : 0 ≤ x ∧ x < 20 := by
  rcases hx with hx | hx | hx <;> constructor <;> linarith [hx.1, hx.2]

theorem sharedMember10_of_periodic {a : Fin 3 → ℝ}
    (ha : 0 ≤ a 0) (hab : a 0 < a 1) (hbc : a 1 < a 2) (hc : a 2 < 10)
    {x : ℝ} (hx : 0 ≤ x ∧ x < 15)
    (hm : ∃ z : ℤ, SharedRowMem10 a (x + 10 * z)) : SharedMember10 a x := by
  obtain ⟨z, hz⟩ := hm
  obtain ⟨hl, hh⟩ := sharedRowMem10_bounds ha hab hbc hc hz
  have hzlo : (-1 : ℤ) ≤ z := by
    by_contra hn
    have he : z ≤ -2 := by omega
    have he' : (z : ℝ) ≤ -2 := by exact_mod_cast he
    linarith [hx.2]
  have hzhi : z ≤ (1 : ℤ) := by
    by_contra hn
    have he : 2 ≤ z := by omega
    have he' : (2 : ℝ) ≤ z := by exact_mod_cast he
    linarith [hx.1]
  have hcases : z = -1 ∨ z = 0 ∨ z = 1 := by omega
  rcases hcases with rfl | rfl | rfl
  · left; simpa [sub_eq_add_neg] using hz
  · right; left; simpa using hz
  · right; right; simpa using hz

structure ThreeArcSharedCanonicalModel (V : Type*) where
  type : V → Fin 20
  injective : Function.Injective type
  start : V → Fin 3 → ℝ
  direction : V → V → ℝ
  cell : ∀ i k, (ThreeArcCanonical.starts (type i) k : ℝ) ≤ start i k ∧
    start i k < (ThreeArcCanonical.starts (type i) k : ℝ) + 1
  normalized : ∀ i, 0 ≤ start i 0 ∧ start i 2 < 10
  order01 : ∀ i, start i 0 < start i 1
  order12 : ∀ i, start i 1 < start i 2
  period : ∀ i, start i 2 < start i 0 + 10
  width0 : ∀ i, start i 0 < start i 2 - 6
  width1 : ∀ i, start i 1 < start i 0 + 4
  width2 : ∀ i, start i 2 < start i 1 + 4
  direction_bounds : ∀ i j, i ≠ j → 0 ≤ direction i j ∧ direction i j < 10
  covered_left : ∀ i j, i ≠ j → SharedMember10 (start i) (direction i j)
  covered_right : ∀ i j, i ≠ j → SharedMember10 (start j) (direction i j + 5)
  triangle : ∀ i j k, i ≠ j → i ≠ k → j ≠ k →
    SharedTriangle10 (direction i j) (direction i k) (direction j k)

theorem ThreeArcSharedFamily.exists_canonical {V : Type*} {d : ℝ}
    (F : ThreeArcSharedFamily V d) (hd : d < 36 / 5) :
    Nonempty (ThreeArcSharedCanonicalModel V) := by
  obtain ⟨S, t, hS, hf, ht⟩ := exists_canonical_with_covers F.row hd F.pair
  let A (i : V) (k : Fin 3) := 5 * (S i).start k / 9
  let q (i j : V) := sharedNormal10 (F.direction i j)
  have hnorm (i : V) : 0 ≤ A i 0 ∧ A i 2 < 10 := by
    change 0 ≤ 5 * (S i).a / 9 ∧ 5 * (S i).c / 9 < 10
    constructor <;> linarith [(hS i).1, (hS i).2.1]
  have h01 (i : V) : A i 0 < A i 1 := by
    change 5 * (S i).a / 9 < 5 * (S i).b / 9
    linarith [(S i).ab]
  have h12 (i : V) : A i 1 < A i 2 := by
    change 5 * (S i).b / 9 < 5 * (S i).c / 9
    linarith [(S i).bc]
  refine ⟨{
    type := t, injective := ht, start := A, direction := q
    cell := ?_, normalized := hnorm, order01 := h01, order12 := h12
    period := ?_, width0 := ?_, width1 := ?_, width2 := ?_
    direction_bounds := ?_, covered_left := ?_, covered_right := ?_, triangle := ?_ }⟩
  · intro i k
    have hlo := Int.floor_le (A i k)
    have hhi := Int.lt_floor_add_one (A i k)
    change ((⌊5 * (S i).start k / 9⌋ : ℤ) : ℝ) ≤ A i k at hlo
    change A i k < ((⌊5 * (S i).start k / 9⌋ : ℤ) : ℝ) + 1 at hhi
    rw [hf i k] at hlo hhi
    exact ⟨hlo, hhi⟩
  · intro i
    change 5 * (S i).c / 9 < 5 * (S i).a / 9 + 10
    linarith [(S i).ca]
  · intro i
    change 5 * (S i).a / 9 < 5 * (S i).c / 9 - 6
    linarith [(S i).width0]
  · intro i
    change 5 * (S i).b / 9 < 5 * (S i).a / 9 + 4
    linarith [(S i).width1]
  · intro i
    change 5 * (S i).c / 9 < 5 * (S i).b / 9 + 4
    linarith [(S i).width2]
  · intro i j _
    exact sharedNormal10_bounds _
  · intro i j hij
    have hq : 0 ≤ q i j ∧ q i j < 10 := sharedNormal10_bounds _
    apply sharedMember10_of_periodic (hnorm i).1 (h01 i) (h12 i) (hnorm i).2
      ⟨hq.1, by linarith [hq.2]⟩
    obtain ⟨k, hk⟩ := F.covered i j hij
    obtain ⟨m, hm⟩ := (hS i).2.2 _ hk
    have hmem := sharedRowMem10_of_mem (S i) hd hm
    refine ⟨k + m + ⌊F.direction i j / 18⌋, ?_⟩
    have he : 5 * ((F.direction i j + 18 * k) + 18 * m) / 9 =
        q i j + 10 * ((k + m + ⌊F.direction i j / 18⌋ : ℤ) : ℝ) := by
      dsimp [q, sharedNormal10, sharedNormal18]
      push_cast
      ring
    rw [he] at hmem
    exact hmem
  · intro i j hij
    have hq := sharedNormal10_bounds (F.direction i j)
    apply sharedMember10_of_periodic (hnorm j).1 (h01 j) (h12 j) (hnorm j).2
      ⟨by dsimp [q]; linarith [hq.1], by dsimp [q]; linarith [hq.2]⟩
    obtain ⟨l, hl⟩ := F.covered j i hij.symm
    obtain ⟨m, hm⟩ := (hS j).2.2 _ hl
    obtain ⟨z, hz⟩ := F.reverse i j hij
    have hmem := sharedRowMem10_of_mem (S j) hd hm
    refine ⟨z + l + m + ⌊F.direction i j / 18⌋, ?_⟩
    have he : 5 * ((F.direction j i + 18 * l) + 18 * m) / 9 =
        (q i j + 5) + 10 * ((z + l + m + ⌊F.direction i j / 18⌋ : ℤ) : ℝ) := by
      rw [hz]
      dsimp [q, sharedNormal10, sharedNormal18]
      push_cast
      ring
    rw [he] at hmem
    exact hmem
  · intro i j k hij hik hjk
    have h := triangleCompatible_translate (F.triangle i j k hij hik hjk)
      (-⌊F.direction i j / 18⌋) (-⌊F.direction i k / 18⌋) (-⌊F.direction j k / 18⌋)
    have hn : TriangleCompatible (sharedNormal18 (F.direction i j))
        (sharedNormal18 (F.direction i k)) (sharedNormal18 (F.direction j k)) := by
      simpa [sharedNormal18, sub_eq_add_neg] using h
    exact sharedTriangle10_of_triangleCompatible (sharedNormal18_bounds _)
      (sharedNormal18_bounds _) (sharedNormal18_bounds _) hn

noncomputable def TriangleCoverModel.threeSharedFamily {V : Type*} [Fintype V] {d : ℝ}
    (M : TriangleCoverModel V d) : ThreeArcSharedFamily M.threeVertices d := by
  classical
  have hex (i : M.threeVertices) : ∃ R : ThreeArcRow d, M.cover i.val = Sum.inr R := by
    have hi : ¬ M.IsOne i.val := (Finset.mem_filter.mp i.property).2
    cases he : M.cover i.val with
    | inl a => exact False.elim (hi ⟨a, he⟩)
    | inr R => exact ⟨R, rfl⟩
  let R (i : M.threeVertices) := Classical.choose (hex i)
  have hR (i : M.threeVertices) : M.cover i.val = Sum.inr (R i) := Classical.choose_spec (hex i)
  refine {
    row := R, direction := fun i j => M.direction i.val j.val
    reverse := ?_, triangle := ?_, covered := ?_ }
  · intro i j hij
    exact M.reverse i.val j.val (fun he => hij (Subtype.ext he))
  · intro i j k hij hik hjk
    exact M.triangle i.val j.val k.val (fun he => hij (Subtype.ext he))
      (fun he => hik (Subtype.ext he)) (fun he => hjk (Subtype.ext he))
  · intro i j hij
    obtain ⟨z, hz⟩ := M.covered i.val j.val (fun he => hij (Subtype.ext he))
    rw [hR i] at hz
    exact ⟨z, hz⟩

theorem TriangleCoverModel.exists_fourteen_sharedCanonical
    {V : Type*} [Fintype V] {d : ℝ} (M : TriangleCoverModel V d)
    (hd : d < 36 / 5) (h14 : 14 ≤ M.threeVertices.card) :
    Nonempty (ThreeArcSharedCanonicalModel (Fin 14)) := by
  classical
  let S := M.threeVertices
  have hc : 14 ≤ Fintype.card S := by simpa only [Fintype.card_coe] using h14
  let e : Fin 14 → S := fun i => (Fintype.equivFin S).symm (Fin.castLE hc i)
  have he : Function.Injective e := by
    intro i j h
    apply Fin.ext
    have hcast := (Fintype.equivFin S).symm.injective h
    exact congrArg (fun z : Fin (Fintype.card S) => z.val) hcast
  exact ((M.threeSharedFamily).comap e he).exists_canonical hd

end Prize.JSP404.ContinuousDirection
