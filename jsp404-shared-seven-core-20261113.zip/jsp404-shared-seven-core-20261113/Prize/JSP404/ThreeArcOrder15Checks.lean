import Prize.JSP404.ThreeArcOrder15Data
import Mathlib.Tactic.FinCases
import Mathlib.Data.Fintype.Fin

set_option maxRecDepth 8192

/-! Each explicit tree certificate is checked by the Lean kernel. -/
namespace Prize.JSP404.ThreeArcOrder15Data

set_option maxHeartbeats 4000000 in
theorem accepted_000 :
    ThreeArcOrderDagCertificate.accepted spec (core 0) (certificate 0) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_001 :
    ThreeArcOrderDagCertificate.accepted spec (core 1) (certificate 1) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_002 :
    ThreeArcOrderDagCertificate.accepted spec (core 2) (certificate 2) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_003 :
    ThreeArcOrderDagCertificate.accepted spec (core 3) (certificate 3) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_004 :
    ThreeArcOrderDagCertificate.accepted spec (core 4) (certificate 4) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_005 :
    ThreeArcOrderDagCertificate.accepted spec (core 5) (certificate 5) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_006 :
    ThreeArcOrderDagCertificate.accepted spec (core 6) (certificate 6) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_007 :
    ThreeArcOrderDagCertificate.accepted spec (core 7) (certificate 7) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_008 :
    ThreeArcOrderDagCertificate.accepted spec (core 8) (certificate 8) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_009 :
    ThreeArcOrderDagCertificate.accepted spec (core 9) (certificate 9) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_010 :
    ThreeArcOrderDagCertificate.accepted spec (core 10) (certificate 10) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_011 :
    ThreeArcOrderDagCertificate.accepted spec (core 11) (certificate 11) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_012 :
    ThreeArcOrderDagCertificate.accepted spec (core 12) (certificate 12) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_013 :
    ThreeArcOrderDagCertificate.accepted spec (core 13) (certificate 13) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_014 :
    ThreeArcOrderDagCertificate.accepted spec (core 14) (certificate 14) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_015 :
    ThreeArcOrderDagCertificate.accepted spec (core 15) (certificate 15) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_016 :
    ThreeArcOrderDagCertificate.accepted spec (core 16) (certificate 16) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_017 :
    ThreeArcOrderDagCertificate.accepted spec (core 17) (certificate 17) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_018 :
    ThreeArcOrderDagCertificate.accepted spec (core 18) (certificate 18) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_019 :
    ThreeArcOrderDagCertificate.accepted spec (core 19) (certificate 19) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_020 :
    ThreeArcOrderDagCertificate.accepted spec (core 20) (certificate 20) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_021 :
    ThreeArcOrderDagCertificate.accepted spec (core 21) (certificate 21) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_022 :
    ThreeArcOrderDagCertificate.accepted spec (core 22) (certificate 22) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_023 :
    ThreeArcOrderDagCertificate.accepted spec (core 23) (certificate 23) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_024 :
    ThreeArcOrderDagCertificate.accepted spec (core 24) (certificate 24) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_025 :
    ThreeArcOrderDagCertificate.accepted spec (core 25) (certificate 25) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_026 :
    ThreeArcOrderDagCertificate.accepted spec (core 26) (certificate 26) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_027 :
    ThreeArcOrderDagCertificate.accepted spec (core 27) (certificate 27) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_028 :
    ThreeArcOrderDagCertificate.accepted spec (core 28) (certificate 28) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_029 :
    ThreeArcOrderDagCertificate.accepted spec (core 29) (certificate 29) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_030 :
    ThreeArcOrderDagCertificate.accepted spec (core 30) (certificate 30) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_031 :
    ThreeArcOrderDagCertificate.accepted spec (core 31) (certificate 31) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_032 :
    ThreeArcOrderDagCertificate.accepted spec (core 32) (certificate 32) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_033 :
    ThreeArcOrderDagCertificate.accepted spec (core 33) (certificate 33) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_034 :
    ThreeArcOrderDagCertificate.accepted spec (core 34) (certificate 34) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_035 :
    ThreeArcOrderDagCertificate.accepted spec (core 35) (certificate 35) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_036 :
    ThreeArcOrderDagCertificate.accepted spec (core 36) (certificate 36) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_037 :
    ThreeArcOrderDagCertificate.accepted spec (core 37) (certificate 37) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_038 :
    ThreeArcOrderDagCertificate.accepted spec (core 38) (certificate 38) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_039 :
    ThreeArcOrderDagCertificate.accepted spec (core 39) (certificate 39) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_040 :
    ThreeArcOrderDagCertificate.accepted spec (core 40) (certificate 40) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_041 :
    ThreeArcOrderDagCertificate.accepted spec (core 41) (certificate 41) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_042 :
    ThreeArcOrderDagCertificate.accepted spec (core 42) (certificate 42) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_043 :
    ThreeArcOrderDagCertificate.accepted spec (core 43) (certificate 43) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_044 :
    ThreeArcOrderDagCertificate.accepted spec (core 44) (certificate 44) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_045 :
    ThreeArcOrderDagCertificate.accepted spec (core 45) (certificate 45) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_046 :
    ThreeArcOrderDagCertificate.accepted spec (core 46) (certificate 46) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_047 :
    ThreeArcOrderDagCertificate.accepted spec (core 47) (certificate 47) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_048 :
    ThreeArcOrderDagCertificate.accepted spec (core 48) (certificate 48) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_049 :
    ThreeArcOrderDagCertificate.accepted spec (core 49) (certificate 49) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_050 :
    ThreeArcOrderDagCertificate.accepted spec (core 50) (certificate 50) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_051 :
    ThreeArcOrderDagCertificate.accepted spec (core 51) (certificate 51) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_052 :
    ThreeArcOrderDagCertificate.accepted spec (core 52) (certificate 52) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_053 :
    ThreeArcOrderDagCertificate.accepted spec (core 53) (certificate 53) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_054 :
    ThreeArcOrderDagCertificate.accepted spec (core 54) (certificate 54) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_055 :
    ThreeArcOrderDagCertificate.accepted spec (core 55) (certificate 55) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_056 :
    ThreeArcOrderDagCertificate.accepted spec (core 56) (certificate 56) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_057 :
    ThreeArcOrderDagCertificate.accepted spec (core 57) (certificate 57) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_058 :
    ThreeArcOrderDagCertificate.accepted spec (core 58) (certificate 58) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_059 :
    ThreeArcOrderDagCertificate.accepted spec (core 59) (certificate 59) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_060 :
    ThreeArcOrderDagCertificate.accepted spec (core 60) (certificate 60) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_061 :
    ThreeArcOrderDagCertificate.accepted spec (core 61) (certificate 61) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_062 :
    ThreeArcOrderDagCertificate.accepted spec (core 62) (certificate 62) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_063 :
    ThreeArcOrderDagCertificate.accepted spec (core 63) (certificate 63) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_064 :
    ThreeArcOrderDagCertificate.accepted spec (core 64) (certificate 64) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_065 :
    ThreeArcOrderDagCertificate.accepted spec (core 65) (certificate 65) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_066 :
    ThreeArcOrderDagCertificate.accepted spec (core 66) (certificate 66) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_067 :
    ThreeArcOrderDagCertificate.accepted spec (core 67) (certificate 67) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_068 :
    ThreeArcOrderDagCertificate.accepted spec (core 68) (certificate 68) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_069 :
    ThreeArcOrderDagCertificate.accepted spec (core 69) (certificate 69) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_070 :
    ThreeArcOrderDagCertificate.accepted spec (core 70) (certificate 70) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_071 :
    ThreeArcOrderDagCertificate.accepted spec (core 71) (certificate 71) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_072 :
    ThreeArcOrderDagCertificate.accepted spec (core 72) (certificate 72) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_073 :
    ThreeArcOrderDagCertificate.accepted spec (core 73) (certificate 73) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_074 :
    ThreeArcOrderDagCertificate.accepted spec (core 74) (certificate 74) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_075 :
    ThreeArcOrderDagCertificate.accepted spec (core 75) (certificate 75) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_076 :
    ThreeArcOrderDagCertificate.accepted spec (core 76) (certificate 76) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_077 :
    ThreeArcOrderDagCertificate.accepted spec (core 77) (certificate 77) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_078 :
    ThreeArcOrderDagCertificate.accepted spec (core 78) (certificate 78) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_079 :
    ThreeArcOrderDagCertificate.accepted spec (core 79) (certificate 79) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_080 :
    ThreeArcOrderDagCertificate.accepted spec (core 80) (certificate 80) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_081 :
    ThreeArcOrderDagCertificate.accepted spec (core 81) (certificate 81) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_082 :
    ThreeArcOrderDagCertificate.accepted spec (core 82) (certificate 82) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_083 :
    ThreeArcOrderDagCertificate.accepted spec (core 83) (certificate 83) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_084 :
    ThreeArcOrderDagCertificate.accepted spec (core 84) (certificate 84) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_085 :
    ThreeArcOrderDagCertificate.accepted spec (core 85) (certificate 85) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_086 :
    ThreeArcOrderDagCertificate.accepted spec (core 86) (certificate 86) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_087 :
    ThreeArcOrderDagCertificate.accepted spec (core 87) (certificate 87) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_088 :
    ThreeArcOrderDagCertificate.accepted spec (core 88) (certificate 88) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_089 :
    ThreeArcOrderDagCertificate.accepted spec (core 89) (certificate 89) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_090 :
    ThreeArcOrderDagCertificate.accepted spec (core 90) (certificate 90) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_091 :
    ThreeArcOrderDagCertificate.accepted spec (core 91) (certificate 91) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_092 :
    ThreeArcOrderDagCertificate.accepted spec (core 92) (certificate 92) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_093 :
    ThreeArcOrderDagCertificate.accepted spec (core 93) (certificate 93) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_094 :
    ThreeArcOrderDagCertificate.accepted spec (core 94) (certificate 94) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_095 :
    ThreeArcOrderDagCertificate.accepted spec (core 95) (certificate 95) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_096 :
    ThreeArcOrderDagCertificate.accepted spec (core 96) (certificate 96) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_097 :
    ThreeArcOrderDagCertificate.accepted spec (core 97) (certificate 97) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_098 :
    ThreeArcOrderDagCertificate.accepted spec (core 98) (certificate 98) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_099 :
    ThreeArcOrderDagCertificate.accepted spec (core 99) (certificate 99) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_100 :
    ThreeArcOrderDagCertificate.accepted spec (core 100) (certificate 100) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_101 :
    ThreeArcOrderDagCertificate.accepted spec (core 101) (certificate 101) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_102 :
    ThreeArcOrderDagCertificate.accepted spec (core 102) (certificate 102) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_103 :
    ThreeArcOrderDagCertificate.accepted spec (core 103) (certificate 103) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_104 :
    ThreeArcOrderDagCertificate.accepted spec (core 104) (certificate 104) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_105 :
    ThreeArcOrderDagCertificate.accepted spec (core 105) (certificate 105) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_106 :
    ThreeArcOrderDagCertificate.accepted spec (core 106) (certificate 106) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_107 :
    ThreeArcOrderDagCertificate.accepted spec (core 107) (certificate 107) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_108 :
    ThreeArcOrderDagCertificate.accepted spec (core 108) (certificate 108) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_109 :
    ThreeArcOrderDagCertificate.accepted spec (core 109) (certificate 109) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_110 :
    ThreeArcOrderDagCertificate.accepted spec (core 110) (certificate 110) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_111 :
    ThreeArcOrderDagCertificate.accepted spec (core 111) (certificate 111) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_112 :
    ThreeArcOrderDagCertificate.accepted spec (core 112) (certificate 112) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_113 :
    ThreeArcOrderDagCertificate.accepted spec (core 113) (certificate 113) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_114 :
    ThreeArcOrderDagCertificate.accepted spec (core 114) (certificate 114) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_115 :
    ThreeArcOrderDagCertificate.accepted spec (core 115) (certificate 115) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_116 :
    ThreeArcOrderDagCertificate.accepted spec (core 116) (certificate 116) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_117 :
    ThreeArcOrderDagCertificate.accepted spec (core 117) (certificate 117) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_118 :
    ThreeArcOrderDagCertificate.accepted spec (core 118) (certificate 118) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_119 :
    ThreeArcOrderDagCertificate.accepted spec (core 119) (certificate 119) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_120 :
    ThreeArcOrderDagCertificate.accepted spec (core 120) (certificate 120) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_121 :
    ThreeArcOrderDagCertificate.accepted spec (core 121) (certificate 121) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_122 :
    ThreeArcOrderDagCertificate.accepted spec (core 122) (certificate 122) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_123 :
    ThreeArcOrderDagCertificate.accepted spec (core 123) (certificate 123) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_124 :
    ThreeArcOrderDagCertificate.accepted spec (core 124) (certificate 124) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_125 :
    ThreeArcOrderDagCertificate.accepted spec (core 125) (certificate 125) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_126 :
    ThreeArcOrderDagCertificate.accepted spec (core 126) (certificate 126) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_127 :
    ThreeArcOrderDagCertificate.accepted spec (core 127) (certificate 127) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_128 :
    ThreeArcOrderDagCertificate.accepted spec (core 128) (certificate 128) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_129 :
    ThreeArcOrderDagCertificate.accepted spec (core 129) (certificate 129) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_130 :
    ThreeArcOrderDagCertificate.accepted spec (core 130) (certificate 130) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_131 :
    ThreeArcOrderDagCertificate.accepted spec (core 131) (certificate 131) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_132 :
    ThreeArcOrderDagCertificate.accepted spec (core 132) (certificate 132) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_133 :
    ThreeArcOrderDagCertificate.accepted spec (core 133) (certificate 133) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_134 :
    ThreeArcOrderDagCertificate.accepted spec (core 134) (certificate 134) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_135 :
    ThreeArcOrderDagCertificate.accepted spec (core 135) (certificate 135) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_136 :
    ThreeArcOrderDagCertificate.accepted spec (core 136) (certificate 136) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_137 :
    ThreeArcOrderDagCertificate.accepted spec (core 137) (certificate 137) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_138 :
    ThreeArcOrderDagCertificate.accepted spec (core 138) (certificate 138) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_139 :
    ThreeArcOrderDagCertificate.accepted spec (core 139) (certificate 139) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_140 :
    ThreeArcOrderDagCertificate.accepted spec (core 140) (certificate 140) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_141 :
    ThreeArcOrderDagCertificate.accepted spec (core 141) (certificate 141) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_142 :
    ThreeArcOrderDagCertificate.accepted spec (core 142) (certificate 142) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_143 :
    ThreeArcOrderDagCertificate.accepted spec (core 143) (certificate 143) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_144 :
    ThreeArcOrderDagCertificate.accepted spec (core 144) (certificate 144) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_145 :
    ThreeArcOrderDagCertificate.accepted spec (core 145) (certificate 145) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_146 :
    ThreeArcOrderDagCertificate.accepted spec (core 146) (certificate 146) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_147 :
    ThreeArcOrderDagCertificate.accepted spec (core 147) (certificate 147) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_148 :
    ThreeArcOrderDagCertificate.accepted spec (core 148) (certificate 148) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_149 :
    ThreeArcOrderDagCertificate.accepted spec (core 149) (certificate 149) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_150 :
    ThreeArcOrderDagCertificate.accepted spec (core 150) (certificate 150) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_151 :
    ThreeArcOrderDagCertificate.accepted spec (core 151) (certificate 151) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_152 :
    ThreeArcOrderDagCertificate.accepted spec (core 152) (certificate 152) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_153 :
    ThreeArcOrderDagCertificate.accepted spec (core 153) (certificate 153) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_154 :
    ThreeArcOrderDagCertificate.accepted spec (core 154) (certificate 154) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_155 :
    ThreeArcOrderDagCertificate.accepted spec (core 155) (certificate 155) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_156 :
    ThreeArcOrderDagCertificate.accepted spec (core 156) (certificate 156) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_157 :
    ThreeArcOrderDagCertificate.accepted spec (core 157) (certificate 157) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_158 :
    ThreeArcOrderDagCertificate.accepted spec (core 158) (certificate 158) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_159 :
    ThreeArcOrderDagCertificate.accepted spec (core 159) (certificate 159) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_160 :
    ThreeArcOrderDagCertificate.accepted spec (core 160) (certificate 160) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_161 :
    ThreeArcOrderDagCertificate.accepted spec (core 161) (certificate 161) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_162 :
    ThreeArcOrderDagCertificate.accepted spec (core 162) (certificate 162) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_163 :
    ThreeArcOrderDagCertificate.accepted spec (core 163) (certificate 163) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_164 :
    ThreeArcOrderDagCertificate.accepted spec (core 164) (certificate 164) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_165 :
    ThreeArcOrderDagCertificate.accepted spec (core 165) (certificate 165) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_166 :
    ThreeArcOrderDagCertificate.accepted spec (core 166) (certificate 166) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_167 :
    ThreeArcOrderDagCertificate.accepted spec (core 167) (certificate 167) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_168 :
    ThreeArcOrderDagCertificate.accepted spec (core 168) (certificate 168) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_169 :
    ThreeArcOrderDagCertificate.accepted spec (core 169) (certificate 169) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_170 :
    ThreeArcOrderDagCertificate.accepted spec (core 170) (certificate 170) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_171 :
    ThreeArcOrderDagCertificate.accepted spec (core 171) (certificate 171) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_172 :
    ThreeArcOrderDagCertificate.accepted spec (core 172) (certificate 172) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_173 :
    ThreeArcOrderDagCertificate.accepted spec (core 173) (certificate 173) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_174 :
    ThreeArcOrderDagCertificate.accepted spec (core 174) (certificate 174) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_175 :
    ThreeArcOrderDagCertificate.accepted spec (core 175) (certificate 175) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_176 :
    ThreeArcOrderDagCertificate.accepted spec (core 176) (certificate 176) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_177 :
    ThreeArcOrderDagCertificate.accepted spec (core 177) (certificate 177) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_178 :
    ThreeArcOrderDagCertificate.accepted spec (core 178) (certificate 178) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_179 :
    ThreeArcOrderDagCertificate.accepted spec (core 179) (certificate 179) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_180 :
    ThreeArcOrderDagCertificate.accepted spec (core 180) (certificate 180) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_181 :
    ThreeArcOrderDagCertificate.accepted spec (core 181) (certificate 181) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_182 :
    ThreeArcOrderDagCertificate.accepted spec (core 182) (certificate 182) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_183 :
    ThreeArcOrderDagCertificate.accepted spec (core 183) (certificate 183) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_184 :
    ThreeArcOrderDagCertificate.accepted spec (core 184) (certificate 184) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_185 :
    ThreeArcOrderDagCertificate.accepted spec (core 185) (certificate 185) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_186 :
    ThreeArcOrderDagCertificate.accepted spec (core 186) (certificate 186) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_187 :
    ThreeArcOrderDagCertificate.accepted spec (core 187) (certificate 187) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_188 :
    ThreeArcOrderDagCertificate.accepted spec (core 188) (certificate 188) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_189 :
    ThreeArcOrderDagCertificate.accepted spec (core 189) (certificate 189) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_190 :
    ThreeArcOrderDagCertificate.accepted spec (core 190) (certificate 190) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_191 :
    ThreeArcOrderDagCertificate.accepted spec (core 191) (certificate 191) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_192 :
    ThreeArcOrderDagCertificate.accepted spec (core 192) (certificate 192) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_193 :
    ThreeArcOrderDagCertificate.accepted spec (core 193) (certificate 193) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_194 :
    ThreeArcOrderDagCertificate.accepted spec (core 194) (certificate 194) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_195 :
    ThreeArcOrderDagCertificate.accepted spec (core 195) (certificate 195) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_196 :
    ThreeArcOrderDagCertificate.accepted spec (core 196) (certificate 196) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_197 :
    ThreeArcOrderDagCertificate.accepted spec (core 197) (certificate 197) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_198 :
    ThreeArcOrderDagCertificate.accepted spec (core 198) (certificate 198) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_199 :
    ThreeArcOrderDagCertificate.accepted spec (core 199) (certificate 199) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_200 :
    ThreeArcOrderDagCertificate.accepted spec (core 200) (certificate 200) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_201 :
    ThreeArcOrderDagCertificate.accepted spec (core 201) (certificate 201) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_202 :
    ThreeArcOrderDagCertificate.accepted spec (core 202) (certificate 202) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_203 :
    ThreeArcOrderDagCertificate.accepted spec (core 203) (certificate 203) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_204 :
    ThreeArcOrderDagCertificate.accepted spec (core 204) (certificate 204) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_205 :
    ThreeArcOrderDagCertificate.accepted spec (core 205) (certificate 205) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_206 :
    ThreeArcOrderDagCertificate.accepted spec (core 206) (certificate 206) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_207 :
    ThreeArcOrderDagCertificate.accepted spec (core 207) (certificate 207) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_208 :
    ThreeArcOrderDagCertificate.accepted spec (core 208) (certificate 208) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_209 :
    ThreeArcOrderDagCertificate.accepted spec (core 209) (certificate 209) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_210 :
    ThreeArcOrderDagCertificate.accepted spec (core 210) (certificate 210) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_211 :
    ThreeArcOrderDagCertificate.accepted spec (core 211) (certificate 211) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_212 :
    ThreeArcOrderDagCertificate.accepted spec (core 212) (certificate 212) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_213 :
    ThreeArcOrderDagCertificate.accepted spec (core 213) (certificate 213) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_214 :
    ThreeArcOrderDagCertificate.accepted spec (core 214) (certificate 214) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_215 :
    ThreeArcOrderDagCertificate.accepted spec (core 215) (certificate 215) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_216 :
    ThreeArcOrderDagCertificate.accepted spec (core 216) (certificate 216) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_217 :
    ThreeArcOrderDagCertificate.accepted spec (core 217) (certificate 217) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_218 :
    ThreeArcOrderDagCertificate.accepted spec (core 218) (certificate 218) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_219 :
    ThreeArcOrderDagCertificate.accepted spec (core 219) (certificate 219) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_220 :
    ThreeArcOrderDagCertificate.accepted spec (core 220) (certificate 220) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_221 :
    ThreeArcOrderDagCertificate.accepted spec (core 221) (certificate 221) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_222 :
    ThreeArcOrderDagCertificate.accepted spec (core 222) (certificate 222) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_223 :
    ThreeArcOrderDagCertificate.accepted spec (core 223) (certificate 223) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_224 :
    ThreeArcOrderDagCertificate.accepted spec (core 224) (certificate 224) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_225 :
    ThreeArcOrderDagCertificate.accepted spec (core 225) (certificate 225) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_226 :
    ThreeArcOrderDagCertificate.accepted spec (core 226) (certificate 226) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_227 :
    ThreeArcOrderDagCertificate.accepted spec (core 227) (certificate 227) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_228 :
    ThreeArcOrderDagCertificate.accepted spec (core 228) (certificate 228) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_229 :
    ThreeArcOrderDagCertificate.accepted spec (core 229) (certificate 229) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_230 :
    ThreeArcOrderDagCertificate.accepted spec (core 230) (certificate 230) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_231 :
    ThreeArcOrderDagCertificate.accepted spec (core 231) (certificate 231) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_232 :
    ThreeArcOrderDagCertificate.accepted spec (core 232) (certificate 232) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_233 :
    ThreeArcOrderDagCertificate.accepted spec (core 233) (certificate 233) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_234 :
    ThreeArcOrderDagCertificate.accepted spec (core 234) (certificate 234) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_235 :
    ThreeArcOrderDagCertificate.accepted spec (core 235) (certificate 235) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_236 :
    ThreeArcOrderDagCertificate.accepted spec (core 236) (certificate 236) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_237 :
    ThreeArcOrderDagCertificate.accepted spec (core 237) (certificate 237) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_238 :
    ThreeArcOrderDagCertificate.accepted spec (core 238) (certificate 238) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_239 :
    ThreeArcOrderDagCertificate.accepted spec (core 239) (certificate 239) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_240 :
    ThreeArcOrderDagCertificate.accepted spec (core 240) (certificate 240) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_241 :
    ThreeArcOrderDagCertificate.accepted spec (core 241) (certificate 241) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_242 :
    ThreeArcOrderDagCertificate.accepted spec (core 242) (certificate 242) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_243 :
    ThreeArcOrderDagCertificate.accepted spec (core 243) (certificate 243) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_244 :
    ThreeArcOrderDagCertificate.accepted spec (core 244) (certificate 244) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_245 :
    ThreeArcOrderDagCertificate.accepted spec (core 245) (certificate 245) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_246 :
    ThreeArcOrderDagCertificate.accepted spec (core 246) (certificate 246) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_247 :
    ThreeArcOrderDagCertificate.accepted spec (core 247) (certificate 247) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_248 :
    ThreeArcOrderDagCertificate.accepted spec (core 248) (certificate 248) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_249 :
    ThreeArcOrderDagCertificate.accepted spec (core 249) (certificate 249) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_250 :
    ThreeArcOrderDagCertificate.accepted spec (core 250) (certificate 250) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_251 :
    ThreeArcOrderDagCertificate.accepted spec (core 251) (certificate 251) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_252 :
    ThreeArcOrderDagCertificate.accepted spec (core 252) (certificate 252) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_253 :
    ThreeArcOrderDagCertificate.accepted spec (core 253) (certificate 253) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_254 :
    ThreeArcOrderDagCertificate.accepted spec (core 254) (certificate 254) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_255 :
    ThreeArcOrderDagCertificate.accepted spec (core 255) (certificate 255) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_256 :
    ThreeArcOrderDagCertificate.accepted spec (core 256) (certificate 256) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_257 :
    ThreeArcOrderDagCertificate.accepted spec (core 257) (certificate 257) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_258 :
    ThreeArcOrderDagCertificate.accepted spec (core 258) (certificate 258) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_259 :
    ThreeArcOrderDagCertificate.accepted spec (core 259) (certificate 259) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_260 :
    ThreeArcOrderDagCertificate.accepted spec (core 260) (certificate 260) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_261 :
    ThreeArcOrderDagCertificate.accepted spec (core 261) (certificate 261) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_262 :
    ThreeArcOrderDagCertificate.accepted spec (core 262) (certificate 262) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_263 :
    ThreeArcOrderDagCertificate.accepted spec (core 263) (certificate 263) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_264 :
    ThreeArcOrderDagCertificate.accepted spec (core 264) (certificate 264) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_265 :
    ThreeArcOrderDagCertificate.accepted spec (core 265) (certificate 265) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_266 :
    ThreeArcOrderDagCertificate.accepted spec (core 266) (certificate 266) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_267 :
    ThreeArcOrderDagCertificate.accepted spec (core 267) (certificate 267) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_268 :
    ThreeArcOrderDagCertificate.accepted spec (core 268) (certificate 268) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_269 :
    ThreeArcOrderDagCertificate.accepted spec (core 269) (certificate 269) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_270 :
    ThreeArcOrderDagCertificate.accepted spec (core 270) (certificate 270) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_271 :
    ThreeArcOrderDagCertificate.accepted spec (core 271) (certificate 271) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_272 :
    ThreeArcOrderDagCertificate.accepted spec (core 272) (certificate 272) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_273 :
    ThreeArcOrderDagCertificate.accepted spec (core 273) (certificate 273) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_274 :
    ThreeArcOrderDagCertificate.accepted spec (core 274) (certificate 274) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_275 :
    ThreeArcOrderDagCertificate.accepted spec (core 275) (certificate 275) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_276 :
    ThreeArcOrderDagCertificate.accepted spec (core 276) (certificate 276) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_277 :
    ThreeArcOrderDagCertificate.accepted spec (core 277) (certificate 277) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_278 :
    ThreeArcOrderDagCertificate.accepted spec (core 278) (certificate 278) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_279 :
    ThreeArcOrderDagCertificate.accepted spec (core 279) (certificate 279) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_280 :
    ThreeArcOrderDagCertificate.accepted spec (core 280) (certificate 280) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_281 :
    ThreeArcOrderDagCertificate.accepted spec (core 281) (certificate 281) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_282 :
    ThreeArcOrderDagCertificate.accepted spec (core 282) (certificate 282) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_283 :
    ThreeArcOrderDagCertificate.accepted spec (core 283) (certificate 283) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_284 :
    ThreeArcOrderDagCertificate.accepted spec (core 284) (certificate 284) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_285 :
    ThreeArcOrderDagCertificate.accepted spec (core 285) (certificate 285) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_286 :
    ThreeArcOrderDagCertificate.accepted spec (core 286) (certificate 286) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_287 :
    ThreeArcOrderDagCertificate.accepted spec (core 287) (certificate 287) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_288 :
    ThreeArcOrderDagCertificate.accepted spec (core 288) (certificate 288) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_289 :
    ThreeArcOrderDagCertificate.accepted spec (core 289) (certificate 289) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_290 :
    ThreeArcOrderDagCertificate.accepted spec (core 290) (certificate 290) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_291 :
    ThreeArcOrderDagCertificate.accepted spec (core 291) (certificate 291) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_292 :
    ThreeArcOrderDagCertificate.accepted spec (core 292) (certificate 292) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_293 :
    ThreeArcOrderDagCertificate.accepted spec (core 293) (certificate 293) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_294 :
    ThreeArcOrderDagCertificate.accepted spec (core 294) (certificate 294) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_295 :
    ThreeArcOrderDagCertificate.accepted spec (core 295) (certificate 295) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_296 :
    ThreeArcOrderDagCertificate.accepted spec (core 296) (certificate 296) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_297 :
    ThreeArcOrderDagCertificate.accepted spec (core 297) (certificate 297) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_298 :
    ThreeArcOrderDagCertificate.accepted spec (core 298) (certificate 298) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_299 :
    ThreeArcOrderDagCertificate.accepted spec (core 299) (certificate 299) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_300 :
    ThreeArcOrderDagCertificate.accepted spec (core 300) (certificate 300) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_301 :
    ThreeArcOrderDagCertificate.accepted spec (core 301) (certificate 301) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_302 :
    ThreeArcOrderDagCertificate.accepted spec (core 302) (certificate 302) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_303 :
    ThreeArcOrderDagCertificate.accepted spec (core 303) (certificate 303) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_304 :
    ThreeArcOrderDagCertificate.accepted spec (core 304) (certificate 304) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_305 :
    ThreeArcOrderDagCertificate.accepted spec (core 305) (certificate 305) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_306 :
    ThreeArcOrderDagCertificate.accepted spec (core 306) (certificate 306) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_307 :
    ThreeArcOrderDagCertificate.accepted spec (core 307) (certificate 307) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_308 :
    ThreeArcOrderDagCertificate.accepted spec (core 308) (certificate 308) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_309 :
    ThreeArcOrderDagCertificate.accepted spec (core 309) (certificate 309) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_310 :
    ThreeArcOrderDagCertificate.accepted spec (core 310) (certificate 310) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_311 :
    ThreeArcOrderDagCertificate.accepted spec (core 311) (certificate 311) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_312 :
    ThreeArcOrderDagCertificate.accepted spec (core 312) (certificate 312) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_313 :
    ThreeArcOrderDagCertificate.accepted spec (core 313) (certificate 313) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_314 :
    ThreeArcOrderDagCertificate.accepted spec (core 314) (certificate 314) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_315 :
    ThreeArcOrderDagCertificate.accepted spec (core 315) (certificate 315) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_316 :
    ThreeArcOrderDagCertificate.accepted spec (core 316) (certificate 316) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_317 :
    ThreeArcOrderDagCertificate.accepted spec (core 317) (certificate 317) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_318 :
    ThreeArcOrderDagCertificate.accepted spec (core 318) (certificate 318) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_319 :
    ThreeArcOrderDagCertificate.accepted spec (core 319) (certificate 319) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_320 :
    ThreeArcOrderDagCertificate.accepted spec (core 320) (certificate 320) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_321 :
    ThreeArcOrderDagCertificate.accepted spec (core 321) (certificate 321) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_322 :
    ThreeArcOrderDagCertificate.accepted spec (core 322) (certificate 322) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_323 :
    ThreeArcOrderDagCertificate.accepted spec (core 323) (certificate 323) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_324 :
    ThreeArcOrderDagCertificate.accepted spec (core 324) (certificate 324) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_325 :
    ThreeArcOrderDagCertificate.accepted spec (core 325) (certificate 325) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_326 :
    ThreeArcOrderDagCertificate.accepted spec (core 326) (certificate 326) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_327 :
    ThreeArcOrderDagCertificate.accepted spec (core 327) (certificate 327) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_328 :
    ThreeArcOrderDagCertificate.accepted spec (core 328) (certificate 328) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_329 :
    ThreeArcOrderDagCertificate.accepted spec (core 329) (certificate 329) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_330 :
    ThreeArcOrderDagCertificate.accepted spec (core 330) (certificate 330) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_331 :
    ThreeArcOrderDagCertificate.accepted spec (core 331) (certificate 331) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_332 :
    ThreeArcOrderDagCertificate.accepted spec (core 332) (certificate 332) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_333 :
    ThreeArcOrderDagCertificate.accepted spec (core 333) (certificate 333) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_334 :
    ThreeArcOrderDagCertificate.accepted spec (core 334) (certificate 334) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_335 :
    ThreeArcOrderDagCertificate.accepted spec (core 335) (certificate 335) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_336 :
    ThreeArcOrderDagCertificate.accepted spec (core 336) (certificate 336) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_337 :
    ThreeArcOrderDagCertificate.accepted spec (core 337) (certificate 337) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_338 :
    ThreeArcOrderDagCertificate.accepted spec (core 338) (certificate 338) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_339 :
    ThreeArcOrderDagCertificate.accepted spec (core 339) (certificate 339) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_340 :
    ThreeArcOrderDagCertificate.accepted spec (core 340) (certificate 340) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_341 :
    ThreeArcOrderDagCertificate.accepted spec (core 341) (certificate 341) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_342 :
    ThreeArcOrderDagCertificate.accepted spec (core 342) (certificate 342) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_343 :
    ThreeArcOrderDagCertificate.accepted spec (core 343) (certificate 343) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_344 :
    ThreeArcOrderDagCertificate.accepted spec (core 344) (certificate 344) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_345 :
    ThreeArcOrderDagCertificate.accepted spec (core 345) (certificate 345) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_346 :
    ThreeArcOrderDagCertificate.accepted spec (core 346) (certificate 346) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_347 :
    ThreeArcOrderDagCertificate.accepted spec (core 347) (certificate 347) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_348 :
    ThreeArcOrderDagCertificate.accepted spec (core 348) (certificate 348) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_349 :
    ThreeArcOrderDagCertificate.accepted spec (core 349) (certificate 349) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_350 :
    ThreeArcOrderDagCertificate.accepted spec (core 350) (certificate 350) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_351 :
    ThreeArcOrderDagCertificate.accepted spec (core 351) (certificate 351) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_352 :
    ThreeArcOrderDagCertificate.accepted spec (core 352) (certificate 352) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_353 :
    ThreeArcOrderDagCertificate.accepted spec (core 353) (certificate 353) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_354 :
    ThreeArcOrderDagCertificate.accepted spec (core 354) (certificate 354) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_355 :
    ThreeArcOrderDagCertificate.accepted spec (core 355) (certificate 355) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_356 :
    ThreeArcOrderDagCertificate.accepted spec (core 356) (certificate 356) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_357 :
    ThreeArcOrderDagCertificate.accepted spec (core 357) (certificate 357) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_358 :
    ThreeArcOrderDagCertificate.accepted spec (core 358) (certificate 358) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_359 :
    ThreeArcOrderDagCertificate.accepted spec (core 359) (certificate 359) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_360 :
    ThreeArcOrderDagCertificate.accepted spec (core 360) (certificate 360) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_361 :
    ThreeArcOrderDagCertificate.accepted spec (core 361) (certificate 361) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_362 :
    ThreeArcOrderDagCertificate.accepted spec (core 362) (certificate 362) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_363 :
    ThreeArcOrderDagCertificate.accepted spec (core 363) (certificate 363) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_364 :
    ThreeArcOrderDagCertificate.accepted spec (core 364) (certificate 364) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_365 :
    ThreeArcOrderDagCertificate.accepted spec (core 365) (certificate 365) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_366 :
    ThreeArcOrderDagCertificate.accepted spec (core 366) (certificate 366) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_367 :
    ThreeArcOrderDagCertificate.accepted spec (core 367) (certificate 367) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_368 :
    ThreeArcOrderDagCertificate.accepted spec (core 368) (certificate 368) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_369 :
    ThreeArcOrderDagCertificate.accepted spec (core 369) (certificate 369) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_370 :
    ThreeArcOrderDagCertificate.accepted spec (core 370) (certificate 370) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_371 :
    ThreeArcOrderDagCertificate.accepted spec (core 371) (certificate 371) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_372 :
    ThreeArcOrderDagCertificate.accepted spec (core 372) (certificate 372) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_373 :
    ThreeArcOrderDagCertificate.accepted spec (core 373) (certificate 373) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_374 :
    ThreeArcOrderDagCertificate.accepted spec (core 374) (certificate 374) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_375 :
    ThreeArcOrderDagCertificate.accepted spec (core 375) (certificate 375) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_376 :
    ThreeArcOrderDagCertificate.accepted spec (core 376) (certificate 376) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_377 :
    ThreeArcOrderDagCertificate.accepted spec (core 377) (certificate 377) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_378 :
    ThreeArcOrderDagCertificate.accepted spec (core 378) (certificate 378) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_379 :
    ThreeArcOrderDagCertificate.accepted spec (core 379) (certificate 379) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_380 :
    ThreeArcOrderDagCertificate.accepted spec (core 380) (certificate 380) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_381 :
    ThreeArcOrderDagCertificate.accepted spec (core 381) (certificate 381) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_382 :
    ThreeArcOrderDagCertificate.accepted spec (core 382) (certificate 382) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_383 :
    ThreeArcOrderDagCertificate.accepted spec (core 383) (certificate 383) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_384 :
    ThreeArcOrderDagCertificate.accepted spec (core 384) (certificate 384) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_385 :
    ThreeArcOrderDagCertificate.accepted spec (core 385) (certificate 385) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem accepted_386 :
    ThreeArcOrderDagCertificate.accepted spec (core 386) (certificate 386) = true := by
  decide +kernel

set_option maxHeartbeats 4000000 in
theorem all_accepted (i : Index) :
    ThreeArcOrderDagCertificate.accepted spec (core i) (certificate i) = true := by
  fin_cases i
  · exact accepted_000
  · exact accepted_001
  · exact accepted_002
  · exact accepted_003
  · exact accepted_004
  · exact accepted_005
  · exact accepted_006
  · exact accepted_007
  · exact accepted_008
  · exact accepted_009
  · exact accepted_010
  · exact accepted_011
  · exact accepted_012
  · exact accepted_013
  · exact accepted_014
  · exact accepted_015
  · exact accepted_016
  · exact accepted_017
  · exact accepted_018
  · exact accepted_019
  · exact accepted_020
  · exact accepted_021
  · exact accepted_022
  · exact accepted_023
  · exact accepted_024
  · exact accepted_025
  · exact accepted_026
  · exact accepted_027
  · exact accepted_028
  · exact accepted_029
  · exact accepted_030
  · exact accepted_031
  · exact accepted_032
  · exact accepted_033
  · exact accepted_034
  · exact accepted_035
  · exact accepted_036
  · exact accepted_037
  · exact accepted_038
  · exact accepted_039
  · exact accepted_040
  · exact accepted_041
  · exact accepted_042
  · exact accepted_043
  · exact accepted_044
  · exact accepted_045
  · exact accepted_046
  · exact accepted_047
  · exact accepted_048
  · exact accepted_049
  · exact accepted_050
  · exact accepted_051
  · exact accepted_052
  · exact accepted_053
  · exact accepted_054
  · exact accepted_055
  · exact accepted_056
  · exact accepted_057
  · exact accepted_058
  · exact accepted_059
  · exact accepted_060
  · exact accepted_061
  · exact accepted_062
  · exact accepted_063
  · exact accepted_064
  · exact accepted_065
  · exact accepted_066
  · exact accepted_067
  · exact accepted_068
  · exact accepted_069
  · exact accepted_070
  · exact accepted_071
  · exact accepted_072
  · exact accepted_073
  · exact accepted_074
  · exact accepted_075
  · exact accepted_076
  · exact accepted_077
  · exact accepted_078
  · exact accepted_079
  · exact accepted_080
  · exact accepted_081
  · exact accepted_082
  · exact accepted_083
  · exact accepted_084
  · exact accepted_085
  · exact accepted_086
  · exact accepted_087
  · exact accepted_088
  · exact accepted_089
  · exact accepted_090
  · exact accepted_091
  · exact accepted_092
  · exact accepted_093
  · exact accepted_094
  · exact accepted_095
  · exact accepted_096
  · exact accepted_097
  · exact accepted_098
  · exact accepted_099
  · exact accepted_100
  · exact accepted_101
  · exact accepted_102
  · exact accepted_103
  · exact accepted_104
  · exact accepted_105
  · exact accepted_106
  · exact accepted_107
  · exact accepted_108
  · exact accepted_109
  · exact accepted_110
  · exact accepted_111
  · exact accepted_112
  · exact accepted_113
  · exact accepted_114
  · exact accepted_115
  · exact accepted_116
  · exact accepted_117
  · exact accepted_118
  · exact accepted_119
  · exact accepted_120
  · exact accepted_121
  · exact accepted_122
  · exact accepted_123
  · exact accepted_124
  · exact accepted_125
  · exact accepted_126
  · exact accepted_127
  · exact accepted_128
  · exact accepted_129
  · exact accepted_130
  · exact accepted_131
  · exact accepted_132
  · exact accepted_133
  · exact accepted_134
  · exact accepted_135
  · exact accepted_136
  · exact accepted_137
  · exact accepted_138
  · exact accepted_139
  · exact accepted_140
  · exact accepted_141
  · exact accepted_142
  · exact accepted_143
  · exact accepted_144
  · exact accepted_145
  · exact accepted_146
  · exact accepted_147
  · exact accepted_148
  · exact accepted_149
  · exact accepted_150
  · exact accepted_151
  · exact accepted_152
  · exact accepted_153
  · exact accepted_154
  · exact accepted_155
  · exact accepted_156
  · exact accepted_157
  · exact accepted_158
  · exact accepted_159
  · exact accepted_160
  · exact accepted_161
  · exact accepted_162
  · exact accepted_163
  · exact accepted_164
  · exact accepted_165
  · exact accepted_166
  · exact accepted_167
  · exact accepted_168
  · exact accepted_169
  · exact accepted_170
  · exact accepted_171
  · exact accepted_172
  · exact accepted_173
  · exact accepted_174
  · exact accepted_175
  · exact accepted_176
  · exact accepted_177
  · exact accepted_178
  · exact accepted_179
  · exact accepted_180
  · exact accepted_181
  · exact accepted_182
  · exact accepted_183
  · exact accepted_184
  · exact accepted_185
  · exact accepted_186
  · exact accepted_187
  · exact accepted_188
  · exact accepted_189
  · exact accepted_190
  · exact accepted_191
  · exact accepted_192
  · exact accepted_193
  · exact accepted_194
  · exact accepted_195
  · exact accepted_196
  · exact accepted_197
  · exact accepted_198
  · exact accepted_199
  · exact accepted_200
  · exact accepted_201
  · exact accepted_202
  · exact accepted_203
  · exact accepted_204
  · exact accepted_205
  · exact accepted_206
  · exact accepted_207
  · exact accepted_208
  · exact accepted_209
  · exact accepted_210
  · exact accepted_211
  · exact accepted_212
  · exact accepted_213
  · exact accepted_214
  · exact accepted_215
  · exact accepted_216
  · exact accepted_217
  · exact accepted_218
  · exact accepted_219
  · exact accepted_220
  · exact accepted_221
  · exact accepted_222
  · exact accepted_223
  · exact accepted_224
  · exact accepted_225
  · exact accepted_226
  · exact accepted_227
  · exact accepted_228
  · exact accepted_229
  · exact accepted_230
  · exact accepted_231
  · exact accepted_232
  · exact accepted_233
  · exact accepted_234
  · exact accepted_235
  · exact accepted_236
  · exact accepted_237
  · exact accepted_238
  · exact accepted_239
  · exact accepted_240
  · exact accepted_241
  · exact accepted_242
  · exact accepted_243
  · exact accepted_244
  · exact accepted_245
  · exact accepted_246
  · exact accepted_247
  · exact accepted_248
  · exact accepted_249
  · exact accepted_250
  · exact accepted_251
  · exact accepted_252
  · exact accepted_253
  · exact accepted_254
  · exact accepted_255
  · exact accepted_256
  · exact accepted_257
  · exact accepted_258
  · exact accepted_259
  · exact accepted_260
  · exact accepted_261
  · exact accepted_262
  · exact accepted_263
  · exact accepted_264
  · exact accepted_265
  · exact accepted_266
  · exact accepted_267
  · exact accepted_268
  · exact accepted_269
  · exact accepted_270
  · exact accepted_271
  · exact accepted_272
  · exact accepted_273
  · exact accepted_274
  · exact accepted_275
  · exact accepted_276
  · exact accepted_277
  · exact accepted_278
  · exact accepted_279
  · exact accepted_280
  · exact accepted_281
  · exact accepted_282
  · exact accepted_283
  · exact accepted_284
  · exact accepted_285
  · exact accepted_286
  · exact accepted_287
  · exact accepted_288
  · exact accepted_289
  · exact accepted_290
  · exact accepted_291
  · exact accepted_292
  · exact accepted_293
  · exact accepted_294
  · exact accepted_295
  · exact accepted_296
  · exact accepted_297
  · exact accepted_298
  · exact accepted_299
  · exact accepted_300
  · exact accepted_301
  · exact accepted_302
  · exact accepted_303
  · exact accepted_304
  · exact accepted_305
  · exact accepted_306
  · exact accepted_307
  · exact accepted_308
  · exact accepted_309
  · exact accepted_310
  · exact accepted_311
  · exact accepted_312
  · exact accepted_313
  · exact accepted_314
  · exact accepted_315
  · exact accepted_316
  · exact accepted_317
  · exact accepted_318
  · exact accepted_319
  · exact accepted_320
  · exact accepted_321
  · exact accepted_322
  · exact accepted_323
  · exact accepted_324
  · exact accepted_325
  · exact accepted_326
  · exact accepted_327
  · exact accepted_328
  · exact accepted_329
  · exact accepted_330
  · exact accepted_331
  · exact accepted_332
  · exact accepted_333
  · exact accepted_334
  · exact accepted_335
  · exact accepted_336
  · exact accepted_337
  · exact accepted_338
  · exact accepted_339
  · exact accepted_340
  · exact accepted_341
  · exact accepted_342
  · exact accepted_343
  · exact accepted_344
  · exact accepted_345
  · exact accepted_346
  · exact accepted_347
  · exact accepted_348
  · exact accepted_349
  · exact accepted_350
  · exact accepted_351
  · exact accepted_352
  · exact accepted_353
  · exact accepted_354
  · exact accepted_355
  · exact accepted_356
  · exact accepted_357
  · exact accepted_358
  · exact accepted_359
  · exact accepted_360
  · exact accepted_361
  · exact accepted_362
  · exact accepted_363
  · exact accepted_364
  · exact accepted_365
  · exact accepted_366
  · exact accepted_367
  · exact accepted_368
  · exact accepted_369
  · exact accepted_370
  · exact accepted_371
  · exact accepted_372
  · exact accepted_373
  · exact accepted_374
  · exact accepted_375
  · exact accepted_376
  · exact accepted_377
  · exact accepted_378
  · exact accepted_379
  · exact accepted_380
  · exact accepted_381
  · exact accepted_382
  · exact accepted_383
  · exact accepted_384
  · exact accepted_385
  · exact accepted_386

end Prize.JSP404.ThreeArcOrder15Data
