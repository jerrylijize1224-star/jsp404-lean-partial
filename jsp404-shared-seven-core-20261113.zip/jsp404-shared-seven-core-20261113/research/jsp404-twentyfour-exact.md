# 24 点精确值为 144°

2026-11-12。Lean 已证明 `alpha 24 = 4*Real.pi/5`，并给出 24～32 点完整 `IsSharpBound`。
整库构建 3300 项、公理审计 4839 项全部通过，其中 4 项不依赖公理。
其余项仅使用 `propext`、`Classical.choice`、`Quot.sound`。

## 有限模型与连续几何

规范化和小数部分的严格序约化沿用既有证明。若存在 15 行三弧，则它们占据 20 个规范类型中的 15 个，
留下五个递增缺失编号。`ThreeArcOrderModelFive.lean` 证明这一缺失集表达式。
387 份具体矛盾核心覆盖所有 15504 个缺失五元组。
轻量规格副本由 `spec_eq_original` 通过 `rfl` 证明与原规格相等。
`ThreeArcOrder15Coverage.lean` 用 136 组非空首对检查核验覆盖表，只枚举合法后缀。
`ThreeArcFourteen.lean` 把连续模型限制到所选核心，排除 15 行相容三弧。

单弧容量为 9，三弧容量为 14，因此所有角严格小于 144° 的平面点集至多有 23 个点。
`TwentyfourExact.lean` 结合已有的二进制构造完成尖锐上界和精确值。
定理量化原题中的任意有限平面点集。

## 共享节点的证书检查

新检查器给每个节点记录所需的比较边。循环叶子必须闭合非空严格循环。
每个分支覆盖该行对的全部选项，子节点编号严格小于父节点。
子节点需要的边必须由父节点的边或当前选项提供，根节点的边必须来自行宽条件。
对节点编号做强归纳，得到任意被接受证书均排除相应实数模型。
局部边检查用过滤及子序列判断，其可靠性另有证明。节点引用用显式平衡树查找。
大型证书定义使用 `noncomputable` 跳过可执行代码生成，定义值保存在内核环境中，
387 项逐例接受性定理均用 `decide +kernel` 检查，`all_accepted` 汇总这些结果。

证书有 37867 个节点和 712405 条需求边引用，最大单份 931 个节点。
240 个边常量、60 个变量常量和 20 个标签常量复用同一数值，降低重复数据的编译开销。
八个新模块共有 563 个审计定理，其中大多数核验或汇总有限情况。

以下命令从保存的具体证书重建源码。生成器使用 Python 标准库。
复现记录见 `logs/jsp404-order-certificate-15-reproduction-20261112.json`。

```sh
python3 scripts/export_three_arc_order15_certificate.py --library research/jsp404-order15-certificate-input.json --out /tmp/jsp404-order15-reproduced
python3 scripts/export_three_arc_order15_coverage.py --library research/jsp404-order15-certificate-input.json --output /tmp/jsp404-order15-reproduced/ThreeArcOrder15Coverage.lean
```

## 后续缺口与来源

21～23 点目前仍在 [140°,144°]，任意点数主命题仍未证明。
精确有理数诊断中，14 行三弧可以与 9 行单弧两两相容，直径为 8766/61 度，小于 144 度。
它表明两两交叠约束允许容量 23。推进到 23 点需要更多三角形一致性或平面几何约束。
该诊断是抽象覆盖模型的独立分数计算，和上述 Lean 数值定理分别记录。
数据在 `logs/jsp404-three-arc-144-fourteen-rational-20261108.json`，可运行
`python3 scripts/verify_fourteen_three_arc_model.py research/logs/jsp404-three-arc-144-fourteen-rational-20261108.json` 复核全部 253 对。

数值目标来自 Sendov 的论文 *Minimax of the angles in a plane configuration of points*，
Acta Mathematica Hungarica 69 (1995), 27–46。[原论文 DOI](https://doi.org/10.1007/BF01874605)
本轮检索范围为有限证书验证及有理数诊断。文献和优先权检索的既有覆盖见 `jsp404-english-source.md` 与 `jsp404-proof-map.md`。
