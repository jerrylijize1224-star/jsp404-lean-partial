# 七个规范类型的共享方向排除

2026-11-13。精确值仍为已证明的 alpha(24)=144°；21～23 点仍在 [140°,144°]。
本轮证明的范围是：任何 `ThreeArcSharedCanonicalModel V`，都不可能同时含有
规范类型 **[10,12,13,14,15,16,19]**。端点在各自的整数单元内自由变化，边方向也为变量。
它排除一个完整连续参数族，没有证明所有 14 类型族均不可能，亦没有证明 alpha(23)。

## 从几何到具体证书

`ThreeArcSharedDirections.lean` 把真实 `TriangleCoverModel` 的三弧子族规范化，并保留
覆盖映射、共享边方向和所有三角形方向条件。周期平移与循环重命名不独立微移每一行。
方向归一化后周期为 10，反向差为 5，直径放宽为 4。规范类型仍是原来经核验的 20 类型。

`ThreeArcSharedDifference.lean` 给出有限差分规格及实数赋值。下界仍是非严格不等式。
变量编码为 anchor=0、start(i,k)=1+3*i+k、direction(i,j)=61+20*i+j。
七行规格含 126 条初始边与 77 个选项子句，分别表达起点单元、行宽、方向界、
42 个端点覆盖条件和 35 个三角形条件。`model_of_canonical` 把规范模型连接到这个规格。

`SharedSevenCertificate.lean` 内核核验 572 条理论子句的循环证书，并导入一份纯命题 LRAT
反驳。`SharedSevenExclusion.spec_eq` 用定义相等证明字面规格就是上述几何接口的计算结果。
`no_family` 随后排除所有含有该核心的规范共享方向模型，没有加入一般位置、凸性或实现性假设。

## 核验边界与复现

`DifferenceCertificate.lean` 的边表示 x[u]≤x[v]+k 或严格版本。坏循环的偏移和小于零，
或偏移和非正且含严格边。`DifferenceSat.lean` 证明源约束和 Tseitin 子句在相应语义赋值下成立；
每个理论子句在全假假设下必须给出一条内核检查的坏循环。

Z3 4.15.4 用于发现理论子句，CaDiCaL 2.1.2 重求命题问题并输出仅含 RUP 的 LRAT。
这两个程序的 UNSAT 状态均不是数学前提。LRAT 导入调用固定 mathlib 的
`Mathlib/Tactic/Sat/FromLRAT.lean`（Mario Carneiro 的既有实现），构造普通内核证明项，跳过额外的 DNF 展开。
命题变量共 6680 个，CNF 共 14343 个子句。支持项的语义核验使用 `decide +kernel`。
公式查找采用显式树，输入无序也不影响可靠性，因为赋值使用同一查找函数。

保存的包在 `research/jsp404-shared-seven-sat/`，含 packet.json、case.cnf 和 case.lrat。
从保存的包重建 Lean 源码只需 Python 标准库：

```sh
python3 scripts/render_shared_difference_sat.py --packet-directory research/jsp404-shared-seven-sat --output /tmp/SharedSevenCertificate.lean
```

字节级复现见 `logs/jsp404-shared-seven-reproduction-20261113.json`。原来 232 个非 Audit Lean 源文件
与封存的 24 点快照逐字节一致；原题定义和依赖锁定没有改动。重新发现证书可运行
`scripts/export_shared_difference_sat.py`，需要上述求解器；证明不依赖重跑求解器得到相同轨迹。

完整构建 **3307 项**、公理审计 **4893 项**通过，其中 **5 项不依赖公理**。
其余仅用 `propext`、`Classical.choice`、`Quot.sound`。六个新模块共 54 个公开审计声明，
多数为检查器或模型连接，不代表 54 个独立数学发现。最终数学结果为上述单核心排除。

## 剩余数值任务与来源

23 点的一条充分路线是把三弧容量从 14 降到 13，结合单弧容量 9 得到总容量 22。
目前的七类型核心并未覆盖全部 14 类型集合。批量脚本枚举 38760 个 14 子集，旧证书直接覆盖
31699 个，其余 7061 个触及 389 个二面对称轨道。该对称压缩仍属于探索，未作为 Lean 证明使用。
初查为 280 UNSAT、109 unknown；独立复查四个超时项后，合计发现 284 UNSAT、105 unknown，无 SAT。
这些求解器状态须逐项转换为核验过的证书，并完成覆盖或对称传输证明，才能用于普通点数精确值。

目标仍来自 Sendov 的最大角数值分类；文献来源、访问情况及既有检索覆盖见
`jsp404-english-source.md` 与 `jsp404-proof-map.md`。本轮没有新的文献或全网优先权检索，
不声称首次形式化、数学新发现或完整解决 JSP-000404。
