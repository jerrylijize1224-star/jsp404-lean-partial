#!/usr/bin/env python3
"""Export a Lean coverage table for the five omitted labels of a size-15 set."""

import argparse
from itertools import combinations
import json
from pathlib import Path


def export_coverage(records):
    supports = [frozenset(record['core']) for record in records]
    if not supports or any(not support or not support <= set(range(20))
                           for support in supports):
        raise ValueError('expected nonempty supports on labels 0..19')

    lines = [
        'import Prize.JSP404.ThreeArcOrder15Data',
        'import Mathlib.Tactic.FinCases',
        'import Mathlib.Data.Fintype.Fin',
        'import Lean.Elab.Tactic.Omega',
        '',
        '/-! Explicit core witnesses for the 15504 increasing omission quintuples.',
        'Each finite check enumerates only valid suffixes of its first pair. -/',
        'namespace Prize.JSP404.ThreeArcOrder15Coverage',
        'open ThreeArcOrderCertificate ThreeArcOrder15Data',
        '',
        'set_option maxRecDepth 4096',
        'set_option maxHeartbeats 2000000',
        '',
        'def witnessRows (a b : Label) : Array (Array Index) :=',
        '  match a.val, b.val with',
    ]

    covered = 0
    for a, b in combinations(range(17), 2):
        lines.append(f'  | {a}, {b} => #[')
        for c in range(b + 1, 18):
            witnesses = []
            for e in range(c + 2, 20):
                for d in range(c + 1, e):
                    missing = {a, b, c, d, e}
                    index = next((i for i, support in enumerate(supports)
                                  if support.isdisjoint(missing)), None)
                    if index is None:
                        raise ValueError(f'no core for missing labels {sorted(missing)}')
                    witnesses.append(str(index))
            comma = ',' if c < 17 else ''
            lines.append(f'      #[{", ".join(witnesses)}]{comma}')
            covered += len(witnesses)
        lines.append('    ]')
    if covered != 15504:
        raise ValueError(f'expected 15504 increasing quintuples, found {covered}')

    lines.extend('''  | _, _ => #[]

def witness (a b c d e : Label) : Index :=
  let row := (witnessRows a b)[c.val - (b.val + 1)]?.getD #[]
  let d' := d.val - (c.val + 1)
  let e' := e.val - (c.val + 1)
  row[e' * (e' - 1) / 2 + d']?.getD 0

def avoids (i : Index) (a b c d e : Label) : Bool :=
  (coreList i).all (fun x => decide (x ≠ a ∧ x ≠ b ∧ x ≠ c ∧ x ≠ d ∧ x ≠ e))

/-- Labels above `x` with room for `room` further labels. -/
def later (x : Label) (room : ℕ) : List Label :=
  (List.range' (x.val + 1) (20 - room - (x.val + 1))).map
    (fun k => ⟨k % 20, Nat.mod_lt _ (by decide)⟩)

theorem mem_later {x y : Label} {room : ℕ}
    (hxy : x < y) (hy : y.val + room < 20) : y ∈ later x room := by
  have hxy' : x.val < y.val := hxy
  unfold later
  refine List.mem_map.mpr ⟨y.val, List.mem_range'_1.mpr ?_, ?_⟩
  · constructor <;> omega
  · exact Fin.ext (Nat.mod_eq_of_lt y.isLt)

def pairChecked (a b : Label) : Bool :=
  (later b 2).all (fun c =>
    (later c 1).all (fun d =>
      (later d 0).all (fun e => avoids (witness a b c d e) a b c d e)))

theorem pairChecked_of_late (a b : Label) (hb : 17 ≤ b.val) :
    pairChecked a b = true := by
  have hn : 20 - 2 - (b.val + 1) = 0 := by omega
  simp [pairChecked, later, hn]
'''.splitlines())

    for a, b in combinations(range(17), 2):
        lines.extend([
            '',
            f'theorem checked{a:02d}_{b:02d} : pairChecked {a} {b} = true := by',
            '  decide +kernel',
        ])
    for a in range(20):
        lines.extend([
            '',
            f'theorem row{a:02d}_checked (b : Label) (hab : {a} < b) :',
            f'    pairChecked {a} b = true := by',
            '  fin_cases b',
        ])
        for b in range(20):
            if b <= a:
                tactic = 'norm_num at hab'
            elif b >= 17:
                tactic = f'exact pairChecked_of_late {a} {b} (by decide)'
            else:
                tactic = f'exact checked{a:02d}_{b:02d}'
            lines.append(f'  · {tactic}')

    lines.extend([
        '',
        'theorem all_pairs_checked (a b : Label) (hab : a < b) :',
        '    pairChecked a b = true := by',
        '  fin_cases a',
    ])
    lines.extend(f'  · exact row{a:02d}_checked b hab' for a in range(20))

    lines.extend('''

theorem all_covered (a b c d e : Label) (hab : a < b) (hbc : b < c)
    (hcd : c < d) (hde : d < e) :
    ∃ i : Index, core i ⊆ ((((Finset.univ.erase a).erase b).erase c).erase d).erase e := by
  have hcd' : c.val < d.val := hcd
  have hde' : d.val < e.val := hde
  have he_lt : e.val < 20 := e.isLt
  have hcmem : c ∈ later b 2 := mem_later hbc (by omega)
  have hdmem : d ∈ later c 1 := mem_later hcd (by omega)
  have hemem : e ∈ later d 0 := mem_later hde (by omega)
  have h := all_pairs_checked a b hab
  unfold pairChecked at h
  have hc := List.all_eq_true.mp h c hcmem
  have hd := List.all_eq_true.mp hc d hdmem
  have he := List.all_eq_true.mp hd e hemem
  refine ⟨witness a b c d e, ?_⟩
  intro x hx
  have hx' : x ∈ coreList (witness a b c d e) := List.mem_toFinset.mp hx
  unfold avoids at he
  have hne : x ≠ a ∧ x ≠ b ∧ x ≠ c ∧ x ≠ d ∧ x ≠ e :=
    of_decide_eq_true (List.all_eq_true.mp he x hx')
  obtain ⟨ha, hb, hc', hd', he'⟩ := hne
  exact Finset.mem_erase.mpr ⟨he', Finset.mem_erase.mpr ⟨hd', Finset.mem_erase.mpr ⟨hc',
    Finset.mem_erase.mpr ⟨hb, Finset.mem_erase.mpr ⟨ha, Finset.mem_univ x⟩⟩⟩⟩⟩

end Prize.JSP404.ThreeArcOrder15Coverage
'''.splitlines())
    return '\n'.join(lines) + '\n'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--library', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    data = json.loads(args.library.read_text())
    records = data['greedy'] if isinstance(data, dict) else data
    args.output.write_text(export_coverage(records))


if __name__ == '__main__':
    main()
