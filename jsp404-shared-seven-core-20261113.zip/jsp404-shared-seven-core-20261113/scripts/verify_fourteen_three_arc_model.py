"""Verify a saved rational witness for the abstract fourteen-row model.

This checks periodic intervals and pairwise antipodal intersections using exact
fractions. The input describes abstract direction covers, without planar points.
"""

import argparse
from fractions import Fraction
from itertools import combinations
import json
from pathlib import Path


def verify(path):
    model = json.loads(path.read_text())["exact_model"]
    labels = model["active"]
    diameter = Fraction(model["scaled_diameter"])
    assert len(labels) == len(set(labels)) == 14
    assert 0 < diameter < 4
    assert model["scaled_period"] == 10
    assert Fraction(model["diameter_degrees"]) == 36 * diameter
    starts = {
        label: tuple(Fraction(value) for value in model["scaled_starts"][str(label)])
        for label in labels
    }
    intervals = {}
    for label, (a, b, c) in starts.items():
        assert 0 <= a < b < c < 10
        intervals[label] = (
            (a, c + diameter - 10),
            (b, a + diameter),
            (c, b + diameter),
        )
        assert all(low <= high for low, high in intervals[label])

    pairs = 0
    for first, second in combinations(labels, 2):
        overlaps = (
            max(low, other_low + shift) <= min(high, other_high + shift)
            for low, high in intervals[first]
            for other_low, other_high in intervals[second]
            for shift in (-5, 5)
        )
        assert any(overlaps), (first, second)
        pairs += 1

    combined = list(intervals.values())
    combined += [((Fraction(10 * i, 9), Fraction(10 * i, 9) + diameter),)
                 for i in range(9)]
    combined_pairs = 0
    for first, second in combinations(combined, 2):
        overlaps = (
            max(low, other_low + shift) <= min(high, other_high + shift)
            for low, high in first
            for other_low, other_high in second
            for shift in (-15, -5, 5, 15)
        )
        assert any(overlaps)
        combined_pairs += 1
    return {
        "scope": "Exact fraction check of abstract three-arc rows",
        "rows": len(labels),
        "antipodal_pairs": pairs,
        "diameter_degrees": str(36 * diameter),
        "pairwise_extension_one_rows": 9,
        "pairwise_extension_total_rows": len(combined),
        "pairwise_extension_pairs": combined_pairs,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    args = parser.parse_args()
    print(json.dumps(verify(args.input), indent=2))


if __name__ == "__main__":
    main()
