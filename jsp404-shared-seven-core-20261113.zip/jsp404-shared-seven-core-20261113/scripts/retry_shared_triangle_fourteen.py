"""Retry four saved unknown cases, preserving the parent discovery record."""

import argparse
import ast
from concurrent.futures import ProcessPoolExecutor, as_completed
from fractions import Fraction
import hashlib
from itertools import combinations, permutations
import json
from pathlib import Path
import runpy
import time

import z3


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_candidate(candidate, starts, timeout_ms, deadline, batch_script):
    module = runpy.run_path(batch_script)
    return module["solve_candidate"](candidate, starts, timeout_ms, deadline)


def check_saved_rationals(model, starts):
    diameter = Fraction(model["diameter"])
    rows = {int(label): list(map(Fraction, row))
            for label, row in model["starts"].items()}
    edges = {tuple(ast.literal_eval(pair)): Fraction(value)
             for pair, value in model["edge_directions"].items()}
    assert 0 <= diameter < 4
    assert len(rows) == 14 and len(edges) == 91
    for label, row in rows.items():
        a, b, c = row
        assert 0 <= a < b < c < a + 10
        assert a <= c + diameter - 10 and b <= a + diameter and c <= b + diameter
        assert all(starts[label][k] <= row[k] < starts[label][k] + 1 for k in range(3))

    def member(value, row):
        a, b, c = row
        intervals = [(a, c + diameter - 10), (b, a + diameter), (c, b + diameter)]
        return any(lower <= value + shift <= upper
                   for lower, upper in intervals for shift in (-10, 0, 10))

    def direction(i, j):
        return edges[i, j] if i < j else (edges[j, i] + 5) % 10

    def positive_turn(x, y):
        return 0 < (y - x) % 10 < 5

    for (i, j), value in edges.items():
        assert 0 <= value < 10
        assert member(value, rows[i]) and member(value + 5, rows[j])
    labels = sorted(rows)
    for vertex in labels:
        for i, j in combinations([label for label in labels if label != vertex], 2):
            delta = (direction(vertex, i) - direction(vertex, j)) % 10
            assert min(delta, 10 - delta) <= diameter
    for i, j, k in permutations(labels, 3):
        u, v, w = direction(i, j), direction(i, k), direction(j, k)
        assert ((positive_turn(u, v) and positive_turn(u, w) and positive_turn(v, w))
                or (positive_turn(v, u) and positive_turn(w, u) and positive_turn(w, v)))
    return {"width_rows": 14, "antipodal_pairs": 91,
            "ordered_triangle_checks": 2184, "small_direction_pairs": 1092,
            "passed": True}


def save(path, output):
    output["result_counts"] = {
        status: sum(row["status"] == status for row in output["results"])
        for status in ("unsat", "sat", "unknown", "error")
    }
    temporary = path.with_name(path.name + ".partial")
    temporary.write_text(json.dumps(output, indent=2) + "\n")
    temporary.replace(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--parent", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output already exists")
    parent_hash = sha256(args.parent)
    parent = json.loads(args.parent.read_text())
    selected = [row for row in parent["results"] if row["status"] == "unknown"][:4]
    assert len(selected) == 4
    batch_script = args.root / "scripts/explore_shared_triangle_fourteen_batch.py"
    canonical_source = args.root / "scripts/export_three_arc_order_certificate.py"
    assert sha256(batch_script) == parent["script_sha256"]
    assert sha256(canonical_source) == parent["source_hashes"]["canonical_types"]
    starts = runpy.run_path(str(canonical_source))["STARTS"]
    candidates = {row["index"]: row for row in parent["candidates"]}
    output = {
        "scope": "Exploratory separate retries of four earliest unknown representatives",
        "proof_certificate_exported": False,
        "parent_sha256": parent_hash,
        "batch_script_sha256": sha256(batch_script),
        "retry_script_sha256": sha256(Path(__file__)),
        "model_revision": parent["model_revision"],
        "solver_version": z3.get_version_string(),
        "jobs": 2,
        "timeout_ms": 60000,
        "soft_wall_budget_seconds": 145,
        "selected_parent_records": selected,
        "results": [],
        "complete": False,
    }
    started = time.monotonic()
    deadline = started + 145
    save(args.output, output)
    with ProcessPoolExecutor(max_workers=2) as executor:
        futures = {
            executor.submit(run_candidate, candidates[row["index"]], starts,
                            60000, deadline, str(batch_script)): row
            for row in selected
        }
        for future in as_completed(futures):
            previous = futures[future]
            try:
                result = future.result()
                if result["status"] == "sat":
                    result["second_fraction_verification"] = check_saved_rationals(
                        result["rational_model"], starts)
            except Exception as error:
                result = dict(candidates[previous["index"]], status="error", reason=repr(error))
            result["parent_status"] = previous["status"]
            result["parent_timeout_ms"] = previous["timeout_ms"]
            output["results"].append(result)
            output["results"].sort(key=lambda row: row["index"])
            output["wall_seconds"] = time.monotonic() - started
            save(args.output, output)
            print(json.dumps({key: result[key] for key in
                              ("index", "missing", "status", "solve_seconds", "reason")
                              if key in result}), flush=True)
    assert sha256(args.parent) == parent_hash
    output["wall_seconds"] = time.monotonic() - started
    output["complete"] = len(output["results"]) == 4
    output["parent_preserved"] = True
    save(args.output, output)
    print(json.dumps({"counts": output["result_counts"],
                      "wall_seconds": output["wall_seconds"],
                      "parent_preserved": True}), flush=True)


if __name__ == "__main__":
    main()
