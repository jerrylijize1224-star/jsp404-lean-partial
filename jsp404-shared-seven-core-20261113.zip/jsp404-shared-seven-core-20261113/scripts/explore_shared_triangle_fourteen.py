"""Exploratory shared-direction relaxation; solver status is not a Lean proof.

Run from the project root with a Python environment containing z3-solver.
This script checks one canonical fourteen-row family, with all endpoints free.
"""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
import argparse,hashlib,json,runpy,time
import z3
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--timeout-ms',type=int,default=18000)
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args()
if args.timeout_ms<=0:parser.error('timeout must be positive')
root=Path.cwd()
A=runpy.run_path(str(root/'scripts/export_three_arc_order_certificate.py'))['STARTS']
source=json.loads((root/'research/logs/jsp404-three-arc-144-fourteen-rational-20261108.json').read_text())
active=source['exact_model']['active']
s=z3.SolverFor('QF_RDL');s.set(timeout=args.timeout_ms,random_seed=0)
a={i:[z3.Real(f'a_{i}_{k}') for k in range(3)] for i in active}
q={ij:z3.Real('q_%s_%s'%ij) for ij in combinations(active,2)}
for i in active:
 for k in range(3):s.add(A[i][k]<=a[i][k],a[i][k]<A[i][k]+1)
 x,y,z=a[i];s.add(x<y,y<z,z<x+10,x<z-6,y<x+4,z<y+4)

def intervals(row,D):
 x,y,z=row;return [(x,z+D-10),(y,x+D),(z,y+D)]
def member(x,rows):
 return z3.Or([z3.And(lo<=x+shift,x+shift<hi) for lo,hi in rows for shift in (-10,0,10)])
def turn(x,y):return z3.Or(z3.And(0<y-x,y-x<5),z3.And(-10<y-x,y-x< -5))
for (i,j),x in q.items():s.add(0<=x,x<10,member(x,intervals(a[i],4)),member(x+5,intervals(a[j],4)))
for i,j,k in combinations(active,3):
 u,v,w=q[i,j],q[i,k],q[j,k]
 s.add(z3.Or(z3.And(turn(u,v),turn(u,w),turn(v,w)),z3.And(turn(v,u),turn(w,u),turn(w,v))))
t=time.monotonic();ans=s.check()
out={'solver_version':z3.get_version_string(),'timeout_ms':args.timeout_ms,'proof_certificate_exported':False,'input_sha256':hashlib.sha256((root/'research/logs/jsp404-three-arc-144-fourteen-rational-20261108.json').read_bytes()).hexdigest(),'scope':'Exploratory 14-row variable endpoint and shared edge-direction model, with all triangle clauses','active':active,'status':str(ans),'seconds':time.monotonic()-t,'constraints':len(s.assertions())}
if ans==z3.unknown:out['reason']=s.reason_unknown()
if ans==z3.sat:
 m=s.model();av={i:[m.eval(x).as_fraction() for x in a[i]] for i in active};qv={ij:m.eval(x).as_fraction() for ij,x in q.items()}
 sl=[]
 for row in av.values():sl += [hi-lo for lo,hi in intervals(row,F(4))]
 for (i,j),x in qv.items():
  for y,row in [(x,av[i]),(x+5,av[j])]:
   sl.append(max(hi-y-sh for lo,hi in intervals(row,F(4)) for sh in (-10,0,10) if lo<=y+sh<hi))
 D=F(4)-min(sl)/2
 def mem(x,row):return any(lo<=x+shift<=hi for lo,hi in intervals(row,D) for shift in (-10,0,10))
 def pos(x,y):return 0<(y-x)%10<5
 for i,row in av.items():
  assert all(A[i][k]<=row[k]<A[i][k]+1 for k in range(3))
  assert all(lo<=hi for lo,hi in intervals(row,D))
 for (i,j),x in qv.items():assert 0<=x<10 and mem(x,av[i]) and mem(x+5,av[j])
 for i,j,k in combinations(active,3):
  u,v,w=qv[i,j],qv[i,k],qv[j,k]
  assert ((pos(u,v) and pos(u,w) and pos(v,w)) or(pos(v,u) and pos(w,u) and pos(w,v)))
 out.update(diameter=str(D),starts={str(i):list(map(str,row)) for i,row in av.items()},edges={str(ij):str(x) for ij,x in qv.items()},independent_fraction_check=True)
args.output.parent.mkdir(parents=True,exist_ok=True)
args.output.write_text(json.dumps(out,indent=2)+'\n')
print({k:v for k,v in out.items() if k not in ('starts','edges')})
