"""Render an untrusted concrete SAT packet into fully checked Lean declarations.
No solver result is assumed. The generated acceptance theorem reduces in the
kernel and the LRAT command produces ordinary proof terms through mathlib.
"""
from pathlib import Path
import argparse,json
parser=argparse.ArgumentParser(description='Render transparent data, checked theory clauses and a kernel LRAT refutation.')
parser.add_argument('--packet-directory',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args()
folder=args.packet_directory
p=json.loads((folder/'packet.json').read_text())
def edge(e):return f'⟨{e[0]}, {e[1]}, {e[2]}, {str(e[3]).lower()}⟩'
def elist(es):return '['+', '.join(edge(e) for e in es)+']'
lines=['import Prize.JSP404.DifferenceSat','', 'namespace Prize.JSP404.SharedSevenCertificate','open DifferenceCertificate DifferenceSat','set_option maxRecDepth 65536','set_option maxHeartbeats 20000000','','noncomputable def spec : DifferenceCertificate.Spec := {', '  initial := '+elist(p['initial']), '  clauses := #[']
for c in p['clauses']:lines.append('    ['+', '.join(elist(choice) for choice in c)+'],')
lines+=['  ]','}']
for n,f in enumerate(p['forms']):
 kind=f[0]
 if kind=='atom':value='.atom '+edge(f[1])
 elif kind in ('top','bot'):value='.'+kind
 elif kind=='neg':value=f'.neg f{f[1]}'
 else:value=f'.{kind} f{f[1]} f{f[2]}'
 lines.append(f'private noncomputable def f{n} : Formula := {value}')
def tree(lo,hi):
 if lo>=hi:return '.empty'
 mid=(lo+hi)//2
 return f'(.node {mid} f{mid} {tree(lo,mid)} {tree(mid+1,hi)})'
lines.append('private noncomputable def formTree : FormTree := '+tree(0,len(p['forms'])))
lines.append('noncomputable def forms : ℕ → Formula := formTree.get')
lines.append('noncomputable def supports : Array Support := #[')
for s in p['supports']:
 if s[0]=='theory':
  lits='['+', '.join(f'⟨{abs(l)-1}, {str(l>0).lower()}⟩' for l in s[1])+']'
  value='.theory '+lits+' '+elist(s[2])
 else:value='.'+s[0]+' '+' '.join(map(str,s[1:]))
 lines.append('  '+value+',')
lines+= [']','', 'theorem checked : DifferenceSat.accepted spec forms supports = true := by','  decide +kernel','', 'difference_lrat cnfRefutation '+json.dumps((folder/'case.cnf').read_text())+' '+json.dumps((folder/'case.lrat').read_text()),'', 'theorem context_eq : cnfRefutation.ctx = DifferenceSat.formula supports := by','  rfl','', 'theorem no_model : ¬ ∃ x, DifferenceCertificate.Model spec x := by','  apply DifferenceSat.accepted_false spec forms supports checked','  exact (congrArg (fun f : Sat.Fmla => f.proof []) context_eq).mp cnfRefutation.unsat','','end Prize.JSP404.SharedSevenCertificate']
out=args.output;out.parent.mkdir(parents=True,exist_ok=True);out.write_text('\n'.join(lines)+'\n');print(out.stat().st_size)
