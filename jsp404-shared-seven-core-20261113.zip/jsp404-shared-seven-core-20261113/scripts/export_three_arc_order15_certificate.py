"""Render concrete contradiction cores with checked DAG edge requirements.

Core indices follow the input `greedy` array. The renderer replays the original
proof trees and the annotated DAG before emitting Lean source. Lean checks each
annotated certificate with ThreeArcOrderDagCertificate.accepted.
"""

import argparse
import hashlib
from itertools import combinations
import json
from pathlib import Path
import runpy


def lean_list(values):
    return '[' + ', '.join(map(str, values)) + ']'


def is_sublist(required, supplied):
    cursor = iter(supplied)
    return all(any(candidate == edge for candidate in cursor) for edge in required)


def annotate(row, options, widths):
    """Compute minimal edge supports for the exact exported branch choices."""
    active = frozenset(row['core'])
    assert row['core'] == sorted(active)
    assert all(0 <= i < 20 for i in active)
    assert row['core_mask'] == sum(1 << i for i in active)
    nodes = row['nodes']
    assert row['root'] == len(nodes) - 1
    supports, annotated = [], []

    for index, node in enumerate(nodes):
        if 'cycle' in node:
            path = node['cycle']
            assert len(path) >= 2 and path[0] == path[-1]
            assert all(0 <= v < 60 for v in path)
            required = frozenset(zip(path, path[1:]))
            step = {'cycle': path}
        else:
            i, j = node['pair']
            children = node['children']
            assert i in active and j in active and i < j
            assert len(children) == len(options[i, j])
            assert all(0 <= child < index for child in children)
            required = frozenset(
                edge
                for choice, child in zip(options[i, j], children)
                for edge in supports[child] - frozenset(choice)
            )
            step = {'pair': [i, j], 'children': children}
        supports.append(required)
        annotated.append({'required': sorted(required), 'step': step})

    initial = frozenset(edge for i in active for edge in widths[i])
    assert supports[-1] <= initial

    # Replay the annotated nodes with the final checker's actual sequence test.
    for index, node in enumerate(annotated):
        required = node['required']
        assert required == sorted(set(required))
        step = node['step']
        if 'cycle' in step:
            path = step['cycle']
            assert len(path) >= 2 and path[0] == path[-1]
            assert all(edge in required for edge in zip(path, path[1:]))
        else:
            i, j = step['pair']
            assert i in active and j in active and i < j
            choices = options[i, j]
            assert len(choices) == len(step['children'])
            for choice, child in zip(choices, step['children']):
                assert child < index
                remaining = [edge for edge in annotated[child]['required'] if edge not in choice]
                assert is_sublist(remaining, required)

    # Independently replay the original context semantics from the root.
    def replay(index, supplied):
        step = nodes[index]
        if 'cycle' in step:
            path = step['cycle']
            assert all(edge in supplied for edge in zip(path, path[1:]))
            return 1
        i, j = step['pair']
        return 1 + sum(
            replay(child, supplied | frozenset(choice))
            for choice, child in zip(options[i, j], step['children'])
        )

    visits = replay(row['root'], initial)
    assert visits == row['expanded_visits']
    return annotated


def balanced_tree(lo, hi):
    if lo >= hi:
        return None
    mid = (lo + hi) // 2
    return mid, balanced_tree(lo, mid), balanced_tree(mid + 1, hi)


def lookup(tree, index):
    while tree is not None:
        key, left, right = tree
        if index == key:
            return key
        tree = left if index < key else right
    return None


def tree_keys(tree):
    if tree is None:
        return []
    key, left, right = tree
    return [key] + tree_keys(left) + tree_keys(right)


def tree_depth(tree):
    if tree is None:
        return 0
    _, left, right = tree
    return 1 + max(tree_depth(left), tree_depth(right))


def validate_tree(row, annotation, options, widths):
    tree = balanced_tree(0, len(annotation))
    assert sorted(tree_keys(tree)) == list(range(len(annotation)))
    for index, node in enumerate(annotation):
        assert lookup(tree, index) == index
        step = node['step']
        if 'pair' in step:
            i, j = step['pair']
            for choice, child in zip(options[i, j], step['children']):
                found = lookup(tree, child)
                assert found is not None and child < index
                remainder = [edge for edge in annotation[found]['required'] if edge not in choice]
                assert is_sublist(remainder, node['required'])
    assert lookup(tree, len(annotation)) is None
    assert lookup(tree, len(annotation) + 100) is None
    found_root = lookup(tree, row['root'])
    assert found_root is not None
    initial = {edge for label in row['core'] for edge in widths[label]}
    assert set(annotation[found_root]['required']) <= initial
    return tree


def marker(prefix, phase):
    return [
        '#eval (show IO Unit from do',
        '  let stamp ← IO.monoMsNow',
        f'  IO.FS.writeFile "{prefix}-{phase}.marker" (toString stamp))',
        '',
    ]


def render_data(rows, annotations, options, namespace='ThreeArcOrder15Data', marker_prefix=None):
    def variable(v):
        return f'variable_{v:02d}'

    def label(i):
        return f'label_{i:02d}'

    def edge(pair):
        return f'edge_{pair[0]:02d}_{pair[1]:02d}'

    def edges(items):
        return lean_list(edge(pair) for pair in items)

    lines = [
        'import Prize.JSP404.ThreeArcOrderFiniteSpec',
        'import Mathlib.Data.Finset.Dedup',
        '',
        'set_option maxRecDepth 8192',
        '',
    ]
    if marker_prefix:
        lines += ['set_option Elab.async false', '']
        lines += marker(marker_prefix, 'imports')
    lines += [
        '/-! Balanced node lookup for concrete contradiction cores with explicit edge requirements. -/',
        f'namespace Prize.JSP404.{namespace}',
        'open ThreeArcOrderCertificate ThreeArcOrderDagCertificate',
        '',
        f'abbrev Index := Fin {len(rows)}',
        'abbrev spec : Spec := ThreeArcOrderFiniteSpec.spec',
        '',
    ]
    used_edges, used_variables = set(), set()
    used_labels = {i for row in rows for i in row['core']}
    for annotation in annotations:
        for node in annotation:
            used_edges.update(node['required'])
            step = node['step']
            if 'cycle' in step:
                used_variables.update(step['cycle'])
            else:
                i, j = step['pair']
                used_labels.update((i, j))
                for choice in options[i, j]:
                    used_edges.update(choice)
    used_variables.update(v for pair in used_edges for v in pair)
    lines += [f'private def {variable(v)} : Var := {v}' for v in sorted(used_variables)] + ['']
    lines += [f'private def {label(i)} : Label := {i}' for i in sorted(used_labels)] + ['']
    lines += [f'private def {edge((a, b))} : Edge := ({variable(a)}, {variable(b)})' for a, b in sorted(used_edges)] + ['']
    if marker_prefix:
        lines += marker(marker_prefix, 'aliases')

    lines += ['def coreList (i : Index) : List Label :=', '  match i.val with']
    lines += [f'  | {i} => {lean_list(label(j) for j in row["core"])}' for i, row in enumerate(rows)]
    lines += ['  | _ => []', '', 'def core (i : Index) : Finset Label := (coreList i).toFinset', '']
    if marker_prefix:
        lines += marker(marker_prefix, 'core')

    for i, annotation in enumerate(annotations):
        values = []
        for node in annotation:
            step = node['step']
            if 'cycle' in step:
                term = f'.cycle {lean_list(variable(v) for v in step["cycle"])}'
            else:
                a, b = step['pair']
                children = lean_list(
                    f'({edges(choice)}, {child})'
                    for choice, child in zip(options[a, b], step['children'])
                )
                term = f'.branch {label(a)} {label(b)} {children}'
            values.append(f'⟨{edges(node["required"])}, {term}⟩')

        def render_tree(tree, indent):
            if tree is None:
                return '.empty'
            key, left, right = tree
            padding = ' ' * indent
            return (
                f'(.node {key} {values[key]}\n'
                f'{padding}  {render_tree(left, indent + 2)}\n'
                f'{padding}  {render_tree(right, indent + 2)})'
            )

        tree = balanced_tree(0, len(annotation))
        lines += [
            f'private noncomputable def certificate_{i:03d} : Certificate :=',
            f'  ⟨{rows[i]["root"]}, {render_tree(tree, 2)}⟩',
            '',
        ]
        if marker_prefix:
            lines += marker(marker_prefix, f'tree{i}')

    lines += ['noncomputable def certificate (i : Index) : Certificate :=', '  match i.val with']
    lines += [f'  | {i} => certificate_{i:03d}' for i in range(len(rows))]
    lines += ['  | _ => ⟨0, .empty⟩', '']
    if marker_prefix:
        lines += marker(marker_prefix, 'dispatch')
    lines += [f'end Prize.JSP404.{namespace}', '']
    return '\n'.join(lines)


def render_checks(count):
    lines = [
        'import Prize.JSP404.ThreeArcOrder15Data',
        'import Mathlib.Tactic.FinCases',
        'import Mathlib.Data.Fintype.Fin',
        '',
        'set_option maxRecDepth 8192',
        '',
        '/-! Each explicit tree certificate is checked by the Lean kernel. -/',
        'namespace Prize.JSP404.ThreeArcOrder15Data',
        '',
    ]
    for i in range(count):
        lines += [
            'set_option maxHeartbeats 4000000 in',
            f'theorem accepted_{i:03d} :',
            f'    ThreeArcOrderDagCertificate.accepted spec (core {i}) (certificate {i}) = true := by',
            '  decide +kernel',
            '',
        ]
    lines += [
        'set_option maxHeartbeats 4000000 in',
        'theorem all_accepted (i : Index) :',
        '    ThreeArcOrderDagCertificate.accepted spec (core i) (certificate i) = true := by',
        '  fin_cases i',
    ]
    lines += [f'  · exact accepted_{i:03d}' for i in range(count)]
    lines += ['', 'end Prize.JSP404.ThreeArcOrder15Data', '']
    return '\n'.join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path.cwd())
    parser.add_argument('--library', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--selected-library', type=Path)
    parser.add_argument('--profile-index', type=int)
    args = parser.parse_args()

    rows = json.loads(args.library.read_text())['greedy']
    assert len(rows) == 387
    tools = runpy.run_path(str(args.root / 'scripts/export_three_arc_order17_certificate.py'))
    options, widths = tools['prepare'](args.root)
    annotations = [annotate(row, options, widths) for row in rows]
    trees = [validate_tree(row, annotation, options, widths) for row, annotation in zip(rows, annotations)]
    for missing in combinations(range(20), 5):
        assert any(set(missing).isdisjoint(row['core']) for row in rows), missing

    args.out.mkdir(parents=True, exist_ok=True)
    if args.profile_index is not None:
        i = args.profile_index
        assert 0 <= i < len(rows)
        prefix = f'/tmp/jsp40415tree-{i}'
        namespace = 'ThreeArcOrder15TreeProfile'
        source = render_data([rows[i]], [annotations[i]], options, namespace, prefix)
        source += '\n'.join([
            '', f'namespace Prize.JSP404.{namespace}',
            *marker(prefix, 'before-accept'),
            'set_option maxHeartbeats 4000000 in',
            'theorem worst_core :',
            '    ThreeArcOrderDagCertificate.accepted spec (core 0) (certificate 0) = true := by',
            '  decide +kernel',
            *marker(prefix, 'after-accept'),
            '#print axioms worst_core',
            f'end Prize.JSP404.{namespace}', '',
        ])
        path = args.out / 'profile.lean'
        path.write_text(source)
        print(json.dumps({'profile': str(path), 'index': i, 'nodes': len(annotations[i]), 'depth': tree_depth(trees[i]), 'bytes': path.stat().st_size}))
        return

    outputs = {
        'ThreeArcOrder15Data.lean': render_data(rows, annotations, options),
        'ThreeArcOrder15Checks.lean': render_checks(len(rows)),
    }
    hashes = {}
    for name, source in outputs.items():
        content = source.encode('utf-8')
        (args.out / name).write_bytes(content)
        hashes[name] = {'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()}
    packet = json.dumps({'greedy': rows}, separators=(',', ':')).encode('utf-8') + b'\n'
    if args.selected_library:
        args.selected_library.write_bytes(packet)
    summary = {
        'scope': 'Concrete tree lookup, local requirements and original contexts replayed in Python',
        'cores': len(rows),
        'nodes': sum(len(annotation) for annotation in annotations),
        'old_expanded_visits': sum(row['expanded_visits'] for row in rows),
        'required_edges': sum(len(node['required']) for annotation in annotations for node in annotation),
        'max_tree_depth': max(map(tree_depth, trees)),
        'checked_omissions': 15504,
        'packet': {'bytes': len(packet), 'sha256': hashlib.sha256(packet).hexdigest()},
        'outputs': hashes,
    }
    (args.out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
