"""Explore canonical fourteen-row families with shared triangle directions.

Solver UNSAT is discovery evidence. This script exports no Lean proof.
The dihedral label quotient is recorded as an exploratory symmetry reduction.
"""

import argparse
from concurrent.futures import FIRST_COMPLETED, ProcessPoolExecutor, wait
from fractions import Fraction
import hashlib
from itertools import combinations
import json
from pathlib import Path
import runpy
import time

import z3


MODEL_REVISION = "shared-direction-fourteen-strict-upper-four-v1"
ALL_LABELS = frozenset(range(20))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def enumerate_orbits(types, records):
    lookup = {frozenset(mask): index for index, mask in enumerate(types)}
    maps = [
        tuple(lookup[frozenset((rotation + sign * cell) % 10 for cell in mask)]
              for mask in types)
        for sign in (1, -1)
        for rotation in range(10)
    ]
    assert len(lookup) == 20 and len(set(maps)) == 20
    core_masks = []
    for record in records:
        core = record["core"]
        assert core == sorted(set(core)) and set(core) <= ALL_LABELS
        mask = sum(1 << label for label in core)
        assert record["core_mask"] == mask
        core_masks.append(mask)

    catalog = {}
    directly_covered = 0
    for missing in combinations(range(20), 6):
        active_mask = (1 << 20) - 1 - sum(1 << label for label in missing)
        covered = any(active_mask & core == core for core in core_masks)
        representative = min(tuple(sorted(mapping[label] for label in missing))
                             for mapping in maps)
        row = catalog.setdefault(representative, {"total": 0, "covered": 0})
        row["total"] += 1
        row["covered"] += int(covered)
        directly_covered += int(covered)

    candidates = []
    for missing, row in sorted(catalog.items()):
        uncovered = row["total"] - row["covered"]
        if uncovered:
            candidates.append({
                "index": len(candidates),
                "missing": list(missing),
                "active": sorted(ALL_LABELS - set(missing)),
                "orbit_size": row["total"],
                "directly_covered_in_orbit": row["covered"],
                "direct_uncovered_in_orbit": uncovered,
            })
    summary = {
        "active_sets_total": 38760,
        "core_count": len(records),
        "dihedral_maps": len(set(maps)),
        "all_dihedral_orbits": len(catalog),
        "directly_core_covered_sets": directly_covered,
        "direct_uncovered_sets": 38760 - directly_covered,
        "touched_orbits": len(candidates),
        "partly_core_covered_orbits": sum(
            row["directly_covered_in_orbit"] > 0 for row in candidates),
    }
    assert summary["direct_uncovered_sets"] == sum(
        row["direct_uncovered_in_orbit"] for row in candidates)
    return summary, candidates


def intervals(row, diameter):
    a, b, c = row
    return [(a, c + diameter - 10), (b, a + diameter), (c, b + diameter)]


def verify_rational_model(model, starts, row_variables, directions):
    rows = {label: [model.eval(value).as_fraction() for value in row]
            for label, row in row_variables.items()}
    edges = {pair: model.eval(value).as_fraction() for pair, value in directions.items()}
    margins = [Fraction(2, 3)]
    for row in rows.values():
        margins.extend(upper - lower for lower, upper in intervals(row, Fraction(4)))
    for (i, j), direction in edges.items():
        for value, row in [(direction, rows[i]), (direction + 5, rows[j])]:
            margins.append(max(
                upper - value - shift
                for lower, upper in intervals(row, Fraction(4))
                for shift in (-10, 0, 10)
                if lower <= value + shift < upper
            ))
    assert min(margins) > 0
    diameter = Fraction(4) - min(margins) / 2

    def member(value, row):
        return any(lower <= value + shift <= upper
                   for lower, upper in intervals(row, diameter)
                   for shift in (-10, 0, 10))

    def positive_turn(x, y):
        return 0 < (y - x) % 10 < 5

    for label, row in rows.items():
        assert all(starts[label][k] <= row[k] < starts[label][k] + 1 for k in range(3))
        assert all(lower <= upper for lower, upper in intervals(row, diameter))
    for (i, j), direction in edges.items():
        assert 0 <= direction < 10
        assert member(direction, rows[i]) and member(direction + 5, rows[j])
    for i, j, k in combinations(sorted(rows), 3):
        u, v, w = edges[i, j], edges[i, k], edges[j, k]
        assert ((positive_turn(u, v) and positive_turn(u, w) and positive_turn(v, w))
                or (positive_turn(v, u) and positive_turn(w, u) and positive_turn(w, v)))
    return {
        "diameter": str(diameter),
        "starts": {str(label): list(map(str, row)) for label, row in rows.items()},
        "edge_directions": {str(pair): str(value) for pair, value in edges.items()},
        "independent_fraction_check": True,
    }


def solve_candidate(candidate, starts, timeout_ms, deadline):
    started = time.monotonic()
    active = candidate["active"]
    solver = z3.SolverFor("QF_RDL")
    rows = {label: [z3.Real(f"a_{label}_{k}") for k in range(3)] for label in active}
    directions = {pair: z3.Real("q_%s_%s" % pair) for pair in combinations(active, 2)}
    for label, row in rows.items():
        for k, value in enumerate(row):
            solver.add(starts[label][k] <= value, value < starts[label][k] + 1)
        a, b, c = row
        solver.add(a < b, b < c, c < a + 10, a < c - 6, b < a + 4, c < b + 4)

    def member(value, row):
        return z3.Or([z3.And(lower <= value + shift, value + shift < upper)
                      for lower, upper in intervals(row, 4)
                      for shift in (-10, 0, 10)])

    def turn(x, y):
        return z3.Or(z3.And(0 < y - x, y - x < 5),
                     z3.And(-10 < y - x, y - x < -5))

    for (i, j), direction in directions.items():
        solver.add(0 <= direction, direction < 10,
                   member(direction, rows[i]), member(direction + 5, rows[j]))
    for i, j, k in combinations(active, 3):
        u, v, w = directions[i, j], directions[i, k], directions[j, k]
        solver.add(z3.Or(z3.And(turn(u, v), turn(u, w), turn(v, w)),
                         z3.And(turn(v, u), turn(w, u), turn(w, v))))

    remaining_ms = max(1, int(1000 * (deadline - time.monotonic())))
    actual_timeout = min(timeout_ms, remaining_ms)
    solver.set(timeout=actual_timeout, random_seed=0)
    solve_started = time.monotonic()
    answer = solver.check()
    result = dict(candidate)
    result.update(status=str(answer), constraints=len(solver.assertions()),
                  timeout_ms=actual_timeout, solve_seconds=time.monotonic() - solve_started)
    if answer == z3.unknown:
        result["reason"] = solver.reason_unknown()
    elif answer == z3.sat:
        result["rational_model"] = verify_rational_model(
            solver.model(), starts, rows, directions)
    result["wall_seconds"] = time.monotonic() - started
    return result


def save_output(path, output):
    records = output["results"]
    output["result_counts"] = {
        status: sum(row["status"] == status for row in records)
        for status in ("unsat", "sat", "unknown", "error")
    }
    output["untested_orbits"] = len(output["candidates"]) - len(records)
    output["all_representatives_checked"] = not output["untested_orbits"]
    output["all_representatives_unsat"] = (
        output["all_representatives_checked"]
        and output["result_counts"]["unsat"] == len(output["candidates"]))
    temporary = path.with_name(path.name + ".partial")
    temporary.write_text(json.dumps(output, indent=2) + "\n")
    temporary.replace(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--library", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--timeout-ms", type=int, default=5000)
    parser.add_argument("--budget-seconds", type=float, default=240)
    parser.add_argument("--jobs", type=int, choices=(1, 2), default=2)
    parser.add_argument("--limit", type=int)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    if args.timeout_ms <= 0 or args.budget_seconds <= 0 or args.limit is not None and args.limit < 1:
        parser.error("timeouts, budgets, and limits must be positive")
    if args.output.exists() and not args.resume:
        parser.error("output already exists; pass --resume or choose a new path")
    if args.resume and not args.output.exists():
        parser.error("--resume requires an existing output")

    run_started = time.monotonic()
    deadline = run_started + args.budget_seconds
    library = args.library or args.root / "research/jsp404-order15-certificate-input.json"
    original_source = args.root / "scripts/export_three_arc_order_certificate.py"
    original = runpy.run_path(str(original_source))
    payload = json.loads(library.read_text())
    records = payload["greedy"] if isinstance(payload, dict) else payload
    enumeration, candidates = enumerate_orbits(original["TYPES"], records)
    source_hashes = {"library": digest(library), "canonical_types": digest(original_source)}
    if args.resume:
        output = json.loads(args.output.read_text())
        assert output["model_revision"] == MODEL_REVISION
        assert output["source_hashes"] == source_hashes
        assert output["candidates"] == candidates
    else:
        output = {
            "scope": "Exploratory shared-direction necessary-condition search; no Lean proof",
            "model_revision": MODEL_REVISION,
            "proof_certificate_exported": False,
            "symmetry_transport_lean_proved": False,
            "solver_version": z3.get_version_string(),
            "source_hashes": source_hashes,
            "script_sha256": digest(Path(__file__)),
            "enumeration": enumeration,
            "candidates": candidates,
            "results": [],
            "runs": [],
        }
    completed = {row["index"] for row in output["results"]}
    pending = [row for row in candidates if row["index"] not in completed]
    if args.limit is not None:
        pending = pending[:args.limit]
    run = {"jobs": args.jobs, "timeout_ms": args.timeout_ms,
           "budget_seconds": args.budget_seconds, "initial_completed": len(completed)}
    output["runs"].append(run)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    save_output(args.output, output)
    print(json.dumps({"enumeration": enumeration, "already_checked": len(completed),
                      "scheduled_limit": len(pending)}), flush=True)

    cursor = 0
    stop_on_sat = False
    with ProcessPoolExecutor(max_workers=args.jobs) as executor:
        running = {}
        while running or cursor < len(pending):
            while (len(running) < args.jobs and cursor < len(pending)
                   and time.monotonic() < deadline and not stop_on_sat):
                row = pending[cursor]
                cursor += 1
                future = executor.submit(solve_candidate, row, original["STARTS"],
                                         args.timeout_ms, deadline)
                running[future] = row
            if not running:
                break
            done, _ = wait(running, timeout=1, return_when=FIRST_COMPLETED)
            for future in done:
                row = running.pop(future)
                try:
                    result = future.result()
                except Exception as error:
                    result = dict(row, status="error", reason=repr(error))
                output["results"].append(result)
                output["results"].sort(key=lambda item: item["index"])
                stop_on_sat |= result["status"] == "sat"
                run["wall_seconds"] = time.monotonic() - run_started
                save_output(args.output, output)
                print(json.dumps({key: result[key] for key in
                                  ("index", "missing", "status", "solve_seconds")
                                  if key in result}), flush=True)
    run["wall_seconds"] = time.monotonic() - run_started
    run["completed"] = len(output["results"]) - run["initial_completed"]
    save_output(args.output, output)
    print(json.dumps({"result_counts": output["result_counts"],
                      "untested_orbits": output["untested_orbits"], "run": run}), flush=True)


if __name__ == "__main__":
    main()
