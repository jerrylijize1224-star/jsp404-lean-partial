"""Exact rational check of the s=4 candidate described in the research note.

Angles are in units of pi. This checks an abstract hierarchical direction table,
not a Lean proof that nested Euclidean disks realize that table.
"""

from fractions import Fraction as F
from itertools import permutations
import json


def check():
    t = F(15, 4)
    gaps = [
        [F(1, 7), F(1, 42), F(5, 6)],
        [F(1, 7), F(1, 42), F(5, 6)],
        [F(5, 14), F(5, 14), F(2, 7)],
        [F(1, 3), F(1, 3), F(1, 3)],
    ]
    assert all(sum(row) == 1 for row in gaps)
    exponents = [sum(max((t * x).__floor__() - 1, 0) for x in row) for row in gaps]
    # Four leaves in A and B; C and D are primitive one-leaf clusters.
    leaves = [(c, a, b) for c in range(2) for a in range(2) for b in range(2)]
    leaves += [(2, 0, 0), (3, 0, 0)]
    centre_direction = {
        (0, 1): F(0), (0, 2): F(1, 7), (0, 3): F(1, 6),
        (1, 2): F(6, 7), (1, 3): F(5, 6), (2, 3): F(1, 2),
    }
    centre_direction.update({(b, a): (d + 1) % 2
                             for (a, b), d in list(centre_direction.items())})
    branches = {0: (F(13, 30), F(7, 10)), 1: (F(17, 30), F(3, 10))}

    def direction(p, q):
        assert p != q
        if p[0] != q[0]:
            return centre_direction[p[0], q[0]]
        level = 1 if p[1] != q[1] else 2
        return (branches[p[0]][level - 1] + (0 if p[level] < q[level] else 1)) % 2

    def angle(p, q, r):
        difference = (direction(q, p) - direction(q, r)) % 2
        return min(difference, 2 - difference)

    angles = [angle(p, q, r) for p, q, r in permutations(leaves, 3)]
    assert max(angles) == F(11, 15)
    assert exponents == [2, 2, 0, 0]
    assert sum(2 ** k for k in exponents) == len(leaves) == 10
    return {
        "arithmetic": "exact fractions; no floating point",
        "scope": "abstract direction model; Euclidean realization not formally verified",
        "u_over_2": str(t),
        "n": 3,
        "delta": "3/4",
        "gap_profiles_pi_units": [[str(x) for x in row] for row in gaps],
        "slot_exponents": exponents,
        "leaf_count": len(leaves),
        "ordered_distinct_triples_checked": len(angles),
        "maximum_generalized_angle_over_pi": str(max(angles)),
        "paper_s4_subcase_value": 9,
        "paper_main_bound": 10,
    }


if __name__ == "__main__":
    print(json.dumps(check(), indent=2))
