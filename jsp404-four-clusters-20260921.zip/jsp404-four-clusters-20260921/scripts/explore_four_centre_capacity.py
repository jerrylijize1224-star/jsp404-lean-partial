"""Reproducible floating-point exploration, not a proof or exact certificate.

Search actual plane configurations to guide a replacement for Sendov's
four-centre counting argument. All reported bounds are observed maxima only.
"""
import json
import numpy as np


def inspect(points):
    m = len(points)
    gaps = np.zeros((m, 4, 3))
    maximum = np.zeros(m)
    interior = np.zeros(m, dtype=bool)
    for i in range(4):
        others = [j for j in range(4) if j != i]
        vectors = points[:, others] - points[:, i, None]
        angles = np.arctan2(vectors[:, :, 1], vectors[:, :, 0]) / np.pi
        lines = np.sort(angles % 1, axis=1)
        gaps[:, i, :2] = np.diff(lines, axis=1)
        gaps[:, i, 2] = 1 + lines[:, 0] - lines[:, 2]
        for j in range(3):
            for k in range(j):
                delta = (angles[:, j] - angles[:, k]) % 2
                maximum = np.maximum(maximum, np.minimum(delta, 2 - delta))
        corners = points[:, others]
        crosses = []
        for j in range(3):
            u = corners[:, (j + 1) % 3] - corners[:, j]
            v = points[:, i] - corners[:, j]
            crosses.append(u[:, 0] * v[:, 1] - u[:, 1] * v[:, 0])
        crosses = np.array(crosses)
        interior |= np.all(crosses > 0, axis=0) | np.all(crosses < 0, axis=0)
    return gaps, maximum, interior


def main():
    rng = np.random.default_rng(404)
    # Include ordinary configurations and configurations with two nearby pairs.
    ordinary = rng.normal(size=(120000, 4, 2))
    paired = rng.normal(size=(120000, 4, 2))
    scale = 10 ** rng.uniform(-5, 0, size=(120000, 1))
    paired[:, 1] = paired[:, 0] + scale * paired[:, 1]
    paired[:, 3] = paired[:, 2] + scale * paired[:, 3]
    points = np.concatenate([ordinary, paired])
    gaps, angles, interior = inspect(points)
    rows = []
    for n in range(2, 9):
        for delta in (0.49, 0.99):
            t = n + delta
            allowed = angles < 1 - 1 / t - 1e-9
            exponents = np.maximum(np.floor(t * gaps).astype(int) - 1, 0).sum(axis=2)
            weights = (2 ** exponents).sum(axis=1)
            for kind, mask in [('convex', ~interior), ('one_interior', interior)]:
                ids = np.flatnonzero(allowed & mask)
                if not len(ids):
                    continue
                best = ids[np.argmax(weights[ids])]
                rows.append(dict(n=n, delta=delta, kind=kind, accepted=int(len(ids)),
                    observed_capacity=int(weights[best]), exponents=exponents[best].tolist(),
                    maximum_angle_over_pi=float(angles[best]),
                    points=points[best].tolist(), gaps=gaps[best].tolist()))
    print(json.dumps(dict(scope='floating-point search only, not a proof', seed=404,
                          samples=len(points), results=rows), indent=2))


if __name__ == '__main__':
    main()
