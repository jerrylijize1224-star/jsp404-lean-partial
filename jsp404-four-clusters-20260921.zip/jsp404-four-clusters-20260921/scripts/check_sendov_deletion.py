"""Exact direction-model obstruction to a naive capacity-preserving deletion.

The direction formula is that of a regular pentagon; geometric realization is
not formalized here. This is an experiment about a proposed repair, not a
counterexample to Sendov's main bound.
"""

from fractions import Fraction as F
from itertools import permutations
import json


def direction(i, j):
    assert i != j
    return (F(i + j, 5) + F(1, 2) + (1 if i > j else 0)) % 2


def gaps_at(i, points):
    angles = sorted(direction(i, j) % 1 for j in points if j != i)
    return [b - a for a, b in zip(angles, angles[1:])] + [1 + angles[0] - angles[-1]]


def capacity(points):
    t = F(13, 5)
    exponents = [sum(max((t * x).__floor__() - 1, 0) for x in gaps_at(i, points))
                 for i in points]
    return exponents, sum(2 ** k for k in exponents)


def check():
    points = list(range(5))
    angles = []
    for i, j, k in permutations(points, 3):
        delta = (direction(j, i) - direction(j, k)) % 2
        angles.append(min(delta, 2 - delta))
    before = capacity(points)
    after = [capacity([i for i in points if i != deleted]) for deleted in points]
    assert max(angles) == F(3, 5) < F(8, 13)
    assert before == ([0] * 5, 5)
    assert all(item == ([0] * 4, 4) for item in after)
    return {
        "arithmetic": "exact fractions",
        "scope": "regular-pentagon direction model; not a formal geometric proof",
        "u_over_2": "13/5",
        "permitted_maximum_angle_over_pi": "8/13",
        "actual_maximum_angle_over_pi": str(max(angles)),
        "before_exponents": before[0],
        "before_capacity": before[1],
        "after_each_of_five_deletions": [{"exponents": ks, "capacity": w} for ks, w in after],
        "conclusion": "Deleting a centre while holding all other centres fixed need not preserve capacity.",
    }


if __name__ == "__main__":
    print(json.dumps(check(), indent=2))
