import Mathlib.Geometry.Euclidean.Triangle
import Mathlib.Analysis.InnerProductSpace.PiL2
import Mathlib.Data.Finset.Card

/-!
# JSP-000404 / Erdős 504: Blumenthal's angle problem

This file defines the original extremal quantity and proves elementary infrastructure.
It does not prove Sendov's formula. Points are distinct; collinear configurations are
allowed. Angles are unoriented and measured in radians.

Mathematical reference: Bl. Sendov, Acta Math. Hungar. 69 (1995), 27–46,
https://doi.org/10.1007/BF01874605.
-/

namespace Prize.JSP404

open EuclideanGeometry

abbrev Plane := EuclideanSpace ℝ (Fin 2)

/-- The finite configuration contains an angle at least `a`, with three distinct points. -/
def HasLargeAngle (s : Finset Plane) (a : ℝ) : Prop :=
  ∃ x ∈ s, ∃ y ∈ s, ∃ z ∈ s,
    x ≠ y ∧ x ≠ z ∧ y ≠ z ∧ a ≤ angle x y z

/-- Every configuration of exactly `n` distinct points contains such an angle. -/
def GuaranteedAngle (n : ℕ) (a : ℝ) : Prop :=
  ∀ s : Finset Plane, s.card = n → HasLargeAngle s a

/-- Restrict to the angle range appearing in the informal supremum definition. -/
def admissibleAngles (n : ℕ) : Set ℝ :=
  {a | 0 ≤ a ∧ a ≤ Real.pi ∧ GuaranteedAngle n a}

noncomputable def alpha (n : ℕ) : ℝ := sSup (admissibleAngles n)

/-- A sharp value includes both a universal bound and failure of every larger bound. -/
def IsSharpBound (n : ℕ) (a : ℝ) : Prop :=
  0 ≤ a ∧ a ≤ Real.pi ∧ GuaranteedAngle n a ∧
    ∀ b : ℝ, a < b → ¬ GuaranteedAngle n b

/-- Specification only: a proposed full answer must cover every n ≥ 3. -/
def FullSolution (f : ℕ → ℝ) : Prop :=
  ∀ n, 3 ≤ n → IsSharpBound n (f n)

theorem HasLargeAngle.mono_set {s t : Finset Plane} {a : ℝ}
    (h : HasLargeAngle s a) (hst : s ⊆ t) : HasLargeAngle t a := by
  obtain ⟨x, hx, y, hy, z, hz, hxy, hxz, hyz, ha⟩ := h
  exact ⟨x, hst hx, y, hst hy, z, hst hz, hxy, hxz, hyz, ha⟩

theorem HasLargeAngle.mono_bound {s : Finset Plane} {a b : ℝ}
    (h : HasLargeAngle s a) (hba : b ≤ a) : HasLargeAngle s b := by
  obtain ⟨x, hx, y, hy, z, hz, hxy, hxz, hyz, ha⟩ := h
  exact ⟨x, hx, y, hy, z, hz, hxy, hxz, hyz, hba.trans ha⟩

theorem GuaranteedAngle.mono_card {m n : ℕ} {a : ℝ}
    (h : GuaranteedAngle m a) (hmn : m ≤ n) : GuaranteedAngle n a := by
  intro s hs
  obtain ⟨t, hts, ht⟩ := Finset.exists_subset_card_eq (hs ▸ hmn)
  exact (h t ht).mono_set hts

/-- The elementary lower bound follows from the sum of the three triangle angles. -/
theorem hasLargeAngle_pi_div_three {s : Finset Plane} (hs : 3 ≤ s.card) :
    HasLargeAngle s (Real.pi / 3) := by
  obtain ⟨x, y, z, hx, hy, hz, hxy, hxz, hyz⟩ :=
    Finset.two_lt_card_iff.mp (by omega : 2 < s.card)
  have hsum := angle_add_angle_add_angle_eq_pi z hxy.symm
  by_cases h₁ : Real.pi / 3 ≤ angle x y z
  · exact ⟨x, hx, y, hy, z, hz, hxy, hxz, hyz, h₁⟩
  by_cases h₂ : Real.pi / 3 ≤ angle y z x
  · exact ⟨y, hy, z, hz, x, hx, hyz, hxy.symm, hxz.symm, h₂⟩
  exact ⟨z, hz, x, hx, y, hy, hxz.symm, hyz.symm, hxy, by linarith⟩

theorem guaranteedAngle_pi_div_three {n : ℕ} (hn : 3 ≤ n) :
    GuaranteedAngle n (Real.pi / 3) := by
  intro s hs
  exact hasLargeAngle_pi_div_three (hs ▸ hn)

theorem admissibleAngles_bddAbove (n : ℕ) : BddAbove (admissibleAngles n) :=
  ⟨Real.pi, fun _ ha => ha.2.1⟩

theorem pi_div_three_mem_admissibleAngles {n : ℕ} (hn : 3 ≤ n) :
    Real.pi / 3 ∈ admissibleAngles n := by
  exact ⟨by positivity, by linarith [Real.pi_pos], guaranteedAngle_pi_div_three hn⟩

theorem alpha_bounds {n : ℕ} (hn : 3 ≤ n) :
    Real.pi / 3 ≤ alpha n ∧ alpha n ≤ Real.pi := by
  have hmem := pi_div_three_mem_admissibleAngles hn
  exact ⟨le_csSup (admissibleAngles_bddAbove n) hmem,
    csSup_le ⟨_, hmem⟩ (fun _ ha => ha.2.1)⟩

theorem alpha_mono {m n : ℕ} (hm : 3 ≤ m) (hmn : m ≤ n) :
    alpha m ≤ alpha n := by
  apply csSup_le_csSup (admissibleAngles_bddAbove n)
    ⟨_, pi_div_three_mem_admissibleAngles hm⟩
  intro a ha
  exact ⟨ha.1, ha.2.1, ha.2.2.mono_card hmn⟩

theorem IsSharpBound.alpha_eq {n : ℕ} {a : ℝ} (h : IsSharpBound n a) :
    alpha n = a := by
  have hmem : a ∈ admissibleAngles n := ⟨h.1, h.2.1, h.2.2.1⟩
  apply le_antisymm
  · apply csSup_le ⟨a, hmem⟩
    intro b hb
    by_contra hba
    exact h.2.2.2 b (lt_of_not_ge hba) hb.2.2
  · exact le_csSup (admissibleAngles_bddAbove n) hmem

end Prize.JSP404
