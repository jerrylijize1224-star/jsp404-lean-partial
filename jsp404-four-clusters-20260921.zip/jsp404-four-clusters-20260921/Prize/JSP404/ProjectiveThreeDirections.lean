import Prize.JSP404.FourCentreLocalIndex

/-! Relating the symmetric local index to three ordered projective directions.
The sorted-coordinate representation is explicit; existence of such coordinates
for every actual centre is a separate geometric step. -/

namespace Prize.JSP404

open scoped RealInnerProductSpace

noncomputable def signedPairAngle (t x : ℝ) (a b : Bool) : ℝ :=
  if a = b then x else t - x

/-- The three successive gaps of sorted unoriented directions at coordinates
0, u, v in a circle of length t. Choosing either ray on each line gives the
same local index. -/
theorem threeRayIndex_sorted_signed {t u v : ℝ} (hu : 0 < u)
    (huv : u < v) (hv : v < t) (a b c : Bool) :
    threeRayIndex t (signedPairAngle t u a b)
      (signedPairAngle t (v - u) b c) (signedPairAngle t v c a) =
      gapBits u + gapBits (v - u) + gapBits (t - v) := by
  have hbase : threeRayIndex t u (v - u) v =
      gapBits u + gapBits (v - u) + gapBits (t - v) := by
    have h := threeRayIndex_of_split hu.le (sub_pos.mpr huv).le
      (show u + (v - u) < t by linarith)
    simpa [splitVertexBits, show u + (v - u) = v by ring,
      show t - u - (v - u) = t - v by ring] using h
  have hmiddle : threeRayIndex t (t - u) (t - (v - u)) v =
      gapBits u + gapBits (v - u) + gapBits (t - v) := by
    rw [threeRayIndex_of_full_turn (by ring : (t - u) + (t - (v - u)) + v = 2 * t)]
    simp
  have hfirst : threeRayIndex t (t - u) (v - u) (t - v) =
      gapBits u + gapBits (v - u) + gapBits (t - v) := by
    rw [← threeRayIndex_rotate t (t - u) (v - u) (t - v)]
    have h := threeRayIndex_of_split (sub_pos.mpr huv).le (sub_pos.mpr hv).le
      (show (v - u) + (t - v) < t by linarith)
    rw [show (v - u) + (t - v) = t - u by ring] at h
    rw [h]
    unfold splitVertexBits
    rw [show t - (v - u) - (t - v) = u by ring]
    omega
  have hlast : threeRayIndex t u (t - (v - u)) (t - v) =
      gapBits u + gapBits (v - u) + gapBits (t - v) := by
    rw [threeRayIndex_swap_last t u (t - v) (t - (v - u))]
    have h := threeRayIndex_of_split hu.le (sub_pos.mpr hv).le
      (show u + (t - v) < t by linarith)
    rw [show u + (t - v) = t - (v - u) by ring] at h
    rw [h]
    unfold splitVertexBits
    rw [show t - u - (t - v) = v - u by ring]
    omega
  cases a <;> cases b <;> cases c <;>
    simp only [signedPairAngle, Bool.false_eq_true, Bool.true_eq_false, ite_true, ite_false] <;>
    first | exact hbase | exact hmiddle | exact hfirst | exact hlast

/-- Explicit unit directions, so the sorted-angle calculation can be checked
against actual vectors rather than only a numeric model. -/
noncomputable def unitDirection (θ : ℝ) : Plane := !₂[Real.cos θ, Real.sin θ]

theorem unitDirection_norm (θ : ℝ) : ‖unitDirection θ‖ = 1 := by
  rw [norm_eq_sqrt_real_inner]
  have h : ⟪unitDirection θ, unitDirection θ⟫ = 1 := by
    rw [PiLp.inner_apply, Fin.sum_univ_two]
    change Real.cos θ * Real.cos θ + Real.sin θ * Real.sin θ = 1
    nlinarith [Real.cos_sq_add_sin_sq θ]
  rw [h]
  simp

theorem unitDirection_angle {θ φ : ℝ} (hθφ : θ ≤ φ) (hwidth : φ - θ ≤ Real.pi) :
    InnerProductGeometry.angle (unitDirection θ) (unitDirection φ) = φ - θ := by
  rw [InnerProductGeometry.angle, unitDirection_norm, unitDirection_norm, mul_one, div_one]
  have hinner : ⟪unitDirection θ, unitDirection φ⟫ = Real.cos (φ - θ) := by
    simp [unitDirection, PiLp.inner_apply, Fin.sum_univ_two, Real.cos_sub, mul_comm]
  rw [hinner]
  exact Real.arccos_cos (sub_nonneg.mpr hθφ) hwidth

noncomputable def signedDirection (θ : ℝ) (b : Bool) : Plane :=
  if b then -unitDirection θ else unitDirection θ

theorem signedDirection_angle {θ φ : ℝ} (hθφ : θ ≤ φ)
    (hwidth : φ - θ ≤ Real.pi) (a b : Bool) :
    InnerProductGeometry.angle (signedDirection θ a) (signedDirection φ b) =
      signedPairAngle Real.pi (φ - θ) a b := by
  cases a <;> cases b <;>
    simp [signedDirection, signedPairAngle, InnerProductGeometry.angle_neg_left,
      InnerProductGeometry.angle_neg_right,
      unitDirection_angle hθφ hwidth]

theorem scaled_signedPairAngle (t x : ℝ) (a b : Bool) :
    t * (signedPairAngle Real.pi x a b / Real.pi) =
      signedPairAngle t (t * (x / Real.pi)) a b := by
  by_cases h : a = b
  · simp [signedPairAngle, h]
  · simp only [signedPairAngle, ite_eq_right h]
    field_simp

noncomputable def vectorThreeRayIndex (t : ℝ) (U V W : Plane) : ℕ :=
  threeRayIndex t
    (t * (InnerProductGeometry.angle U V / Real.pi))
    (t * (InnerProductGeometry.angle V W / Real.pi))
    (t * (InnerProductGeometry.angle W U / Real.pi))

/-- Actual unit vectors on three sorted lines (either orientation allowed)
have precisely the sum of the three cyclic gap contributions. -/
theorem vectorThreeRayIndex_signed_sorted {t u v : ℝ} (ht : 0 < t)
    (hu : 0 < u) (huv : u < v) (hv : v < Real.pi) (a b c : Bool) :
    vectorThreeRayIndex t (signedDirection 0 a) (signedDirection u b) (signedDirection v c) =
      gapBits (t * (u / Real.pi)) + gapBits (t * ((v - u) / Real.pi)) +
        gapBits (t * ((Real.pi - v) / Real.pi)) := by
  have huv0 : 0 < v := hu.trans huv
  have hup : u < Real.pi := huv.trans hv
  unfold vectorThreeRayIndex
  rw [InnerProductGeometry.angle_comm (signedDirection v c) (signedDirection 0 a)]
  rw [signedDirection_angle hu.le (by simpa using hup.le) a b,
    signedDirection_angle huv.le (by linarith) b c,
    signedDirection_angle huv0.le (by simpa using hv.le) a c]
  simp only [sub_zero, scaled_signedPairAngle]
  have hsym : signedPairAngle t (t * (v / Real.pi)) a c =
      signedPairAngle t (t * (v / Real.pi)) c a := by
    simp only [signedPairAngle, eq_comm]
  rw [hsym, show t * ((v - u) / Real.pi) = t * (v / Real.pi) - t * (u / Real.pi) by ring]
  rw [threeRayIndex_sorted_signed
    (mul_pos ht (div_pos hu Real.pi_pos))
    (mul_lt_mul_of_pos_left ((div_lt_div_iff_of_pos_right Real.pi_pos).mpr huv) ht)
    (show t * (v / Real.pi) < t by
      have h := mul_lt_mul_of_pos_left ((div_lt_one Real.pi_pos).mpr hv) ht
      simpa using h)]
  rw [show t * (v / Real.pi) - t * (u / Real.pi) = t * ((v - u) / Real.pi) by ring,
    show t - t * (v / Real.pi) = t * ((Real.pi - v) / Real.pi) by
      field_simp [Real.pi_ne_zero]]

end Prize.JSP404
