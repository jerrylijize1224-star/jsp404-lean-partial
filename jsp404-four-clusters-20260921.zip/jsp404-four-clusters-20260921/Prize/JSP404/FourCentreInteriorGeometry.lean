import Prize.JSP404.FourCentreInterior
import Mathlib.Geometry.Euclidean.Angle.Unoriented.TriangleInequality

/-! Connecting the interior-centre capacity inequalities to actual Euclidean
angles. This concerns the capacity expression; the generalized-cluster point
count and the convex-four-centre case remain separate. -/

namespace Prize.JSP404

open EuclideanGeometry
open scoped NNReal

noncomputable def scaledAngle (t : ℝ) (A B C : Plane) : ℝ :=
  t * (angle A B C / Real.pi)

theorem scaledAngle_nonneg {t : ℝ} (ht : 0 ≤ t) (A B C : Plane) :
    0 ≤ scaledAngle t A B C :=
  mul_nonneg ht (div_nonneg (angle_nonneg A B C) Real.pi_pos.le)

theorem scaledAngle_triangle_sum (t : ℝ) {A B : Plane} (C : Plane) (hAB : A ≠ B) :
    scaledAngle t B A C + scaledAngle t A B C + scaledAngle t A C B = t := by
  have h := angle_add_angle_add_angle_eq_pi C hAB.symm
  rw [angle_comm B C A, angle_comm C A B] at h
  unfold scaledAngle
  calc
    _ = t * ((angle B A C + angle A B C + angle A C B) / Real.pi) := by ring
    _ = t := by
      rw [show angle B A C + angle A B C + angle A C B = Real.pi by linarith]
      simp [Real.pi_ne_zero]

theorem scaledAngle_le_sub_one {t : ℝ} {A B C : Plane} (ht : 0 < t)
    (h : angle A B C ≤ (1 - 1 / t) * Real.pi) :
    scaledAngle t A B C ≤ t - 1 := by
  have hdiv : angle A B C / Real.pi ≤ 1 - 1 / t :=
    (div_le_iff₀ Real.pi_pos).mpr h
  have hmul := mul_le_mul_of_nonneg_left hdiv ht.le
  have heq : t * (1 - 1 / t) = t - 1 := by field_simp [ne_of_gt ht]
  rwa [heq] at hmul

/-- A point given by nonnegative barycentric coordinates splits the angle at A,
provided it does not coincide with A. -/
theorem angle_split_of_barycentric {A B C D : Plane} {a b c : ℝ}
    (hb : 0 ≤ b) (hc : 0 ≤ c) (hs : a + b + c = 1)
    (hD : D = a • A + b • B + c • C) (hDA : D ≠ A) :
    angle B A C = angle B A D + angle D A C := by
  change InnerProductGeometry.angle (B - A) (C - A) =
    InnerProductGeometry.angle (B - A) (D - A) +
      InnerProductGeometry.angle (D - A) (C - A)
  apply InnerProductGeometry.angle_eq_angle_add_add_angle_add_of_mem_span
    (sub_ne_zero.mpr hDA)
  rw [Submodule.mem_span_pair]
  refine ⟨(⟨b, hb⟩ : ℝ≥0), (⟨c, hc⟩ : ℝ≥0), ?_⟩
  change b • (B - A) + c • (C - A) = D - A
  rw [hD, show a = 1 - b - c by linarith]
  module

noncomputable def interiorFourCapacity (t : ℝ) (A B C D : Plane) : ℕ :=
  2 ^ splitVertexBits t (scaledAngle t B A D) (scaledAngle t D A C) +
  2 ^ splitVertexBits t (scaledAngle t A B D) (scaledAngle t D B C) +
  2 ^ splitVertexBits t (scaledAngle t A C D) (scaledAngle t D C B) +
  2 ^ (gapBits (scaledAngle t B A D + scaledAngle t A B D) +
       gapBits (scaledAngle t D A C + scaledAngle t A C D) +
       gapBits (scaledAngle t D B C + scaledAngle t D C B))

/-- Geometric hypotheses only: a barycentric interior point and six actual
angle bounds. The angle-data identities are derived, not assumed. -/
structure InteriorFourGeometry (t : ℝ) where
  A : Plane
  B : Plane
  C : Plane
  D : Plane
  a : ℝ
  b : ℝ
  c : ℝ
  a_nonneg : 0 ≤ a
  b_nonneg : 0 ≤ b
  c_nonneg : 0 ≤ c
  weights_sum : a + b + c = 1
  barycentric : D = a • A + b • B + c • C
  ab_ne : A ≠ B
  ac_ne : A ≠ C
  bc_ne : B ≠ C
  da_ne : D ≠ A
  db_ne : D ≠ B
  dc_ne : D ≠ C
  angle_a : angle B A C ≤ (1 - 1 / t) * Real.pi
  angle_b : angle A B C ≤ (1 - 1 / t) * Real.pi
  angle_c : angle A C B ≤ (1 - 1 / t) * Real.pi
  angle_dab : angle A D B ≤ (1 - 1 / t) * Real.pi
  angle_dac : angle A D C ≤ (1 - 1 / t) * Real.pi
  angle_dbc : angle B D C ≤ (1 - 1 / t) * Real.pi

namespace InteriorFourGeometry

variable {t : ℝ}

noncomputable def angleData (v : InteriorFourGeometry t) (ht : 0 < t) :
    InteriorAngleData t := by
  have hA := angle_split_of_barycentric v.b_nonneg v.c_nonneg v.weights_sum
    v.barycentric v.da_ne
  have hB : angle v.A v.B v.C = angle v.A v.B v.D + angle v.D v.B v.C :=
    angle_split_of_barycentric (a := v.b) v.a_nonneg v.c_nonneg (by linarith [v.weights_sum])
      (by rw [v.barycentric]; module) v.db_ne
  have hC : angle v.A v.C v.B = angle v.A v.C v.D + angle v.D v.C v.B :=
    angle_split_of_barycentric (a := v.c) v.a_nonneg v.b_nonneg (by linarith [v.weights_sum])
      (by rw [v.barycentric]; module) v.dc_ne
  have hsA : scaledAngle t v.B v.A v.C =
      scaledAngle t v.B v.A v.D + scaledAngle t v.D v.A v.C := by
    simp only [scaledAngle, hA, add_div, mul_add]
  have hsB : scaledAngle t v.A v.B v.C =
      scaledAngle t v.A v.B v.D + scaledAngle t v.D v.B v.C := by
    simp only [scaledAngle, hB, add_div, mul_add]
  have hsC : scaledAngle t v.A v.C v.B =
      scaledAngle t v.A v.C v.D + scaledAngle t v.D v.C v.B := by
    simp only [scaledAngle, hC, add_div, mul_add]
  have hsum := scaledAngle_triangle_sum t v.C v.ab_ne
  have hab := scaledAngle_triangle_sum t v.D v.ab_ne
  have hac := scaledAngle_triangle_sum t v.D v.ac_ne
  have hbc := scaledAngle_triangle_sum t v.D v.bc_ne
  have hDA : scaledAngle t v.D v.A v.C = scaledAngle t v.C v.A v.D := by
    simp only [scaledAngle, angle_comm v.D v.A v.C]
  have hDB : scaledAngle t v.D v.B v.C = scaledAngle t v.C v.B v.D := by
    simp only [scaledAngle, angle_comm v.D v.B v.C]
  have hDC : scaledAngle t v.D v.C v.B = scaledAngle t v.B v.C v.D := by
    simp only [scaledAngle, angle_comm v.D v.C v.B]
  exact {
    a1 := scaledAngle t v.B v.A v.D
    a2 := scaledAngle t v.D v.A v.C
    b1 := scaledAngle t v.A v.B v.D
    b2 := scaledAngle t v.D v.B v.C
    c1 := scaledAngle t v.A v.C v.D
    c2 := scaledAngle t v.D v.C v.B
    a1_nonneg := scaledAngle_nonneg ht.le _ _ _
    a2_nonneg := scaledAngle_nonneg ht.le _ _ _
    b1_nonneg := scaledAngle_nonneg ht.le _ _ _
    b2_nonneg := scaledAngle_nonneg ht.le _ _ _
    c1_nonneg := scaledAngle_nonneg ht.le _ _ _
    c2_nonneg := scaledAngle_nonneg ht.le _ _ _
    total := by linarith
    ab := by linarith [scaledAngle_le_sub_one ht v.angle_dab]
    ac := by linarith [scaledAngle_le_sub_one ht v.angle_dac]
    bc := by linarith [scaledAngle_le_sub_one ht v.angle_dbc]
    comp_a := by linarith [scaledAngle_le_sub_one ht v.angle_a]
    comp_b := by linarith [scaledAngle_le_sub_one ht v.angle_b]
    comp_c := by linarith [scaledAngle_le_sub_one ht v.angle_c] }

theorem capacity_low (v : InteriorFourGeometry t) {n : ℕ}
    (hn : 2 ≤ n) (ht : (n : ℝ) ≤ t) (ht' : t < n + 1 / 2) :
    interiorFourCapacity t v.A v.B v.C v.D ≤ 2 ^ n := by
  have htpos : 0 < t := by
    have : (2 : ℝ) ≤ n := by exact_mod_cast hn
    linarith
  let d := v.angleData htpos
  have hn3 : 3 ≤ n := by
    by_contra h
    have hn2 : (n : ℝ) ≤ 2 := by exact_mod_cast (show n ≤ 2 by omega)
    linarith [d.three_le_parameter]
  exact d.capacity_low hn3 ht'

theorem capacity_high (v : InteriorFourGeometry t) {n : ℕ}
    (hn : 2 ≤ n) (ht : (n : ℝ) ≤ t) (ht' : t < n + 1) :
    interiorFourCapacity t v.A v.B v.C v.D ≤ 2 ^ n + 2 ^ (n - 2) := by
  have htpos : 0 < t := by
    have : (2 : ℝ) ≤ n := by exact_mod_cast hn
    linarith
  let d := v.angleData htpos
  have hn3 : 3 ≤ n := by
    by_contra h
    have hn2 : (n : ℝ) ≤ 2 := by exact_mod_cast (show n ≤ 2 by omega)
    linarith [d.three_le_parameter]
  exact d.capacity_high hn3 ht'

end InteriorFourGeometry

end Prize.JSP404
