import Prize.JSP404.Basic

/-!
# Removing the source paper's general-position restriction

The original problem allows collinear triples. A triple of distinct collinear
points contains a straight angle, so restricting a universal lower-bound proof
to general position loses nothing for bounds at most pi.
-/

namespace Prize.JSP404

open EuclideanGeometry

/-- Every triple of distinct points of the configuration is noncollinear. -/
def GeneralPosition (s : Finset Plane) : Prop :=
  ∀ x ∈ s, ∀ y ∈ s, ∀ z ∈ s,
    x ≠ y → x ≠ z → y ≠ z → ¬ Collinear ℝ ({x, y, z} : Set Plane)

theorem hasLargeAngle_pi_of_collinear {s : Finset Plane} {x y z : Plane}
    (hx : x ∈ s) (hy : y ∈ s) (hz : z ∈ s)
    (hxy : x ≠ y) (hxz : x ≠ z) (hyz : y ≠ z)
    (hc : Collinear ℝ ({x, y, z} : Set Plane)) :
    HasLargeAngle s Real.pi := by
  rcases hc.wbtw_or_wbtw_or_wbtw with h | h | h
  · have ha := (show Sbtw ℝ x y z from ⟨h, hxy.symm, hyz⟩).angle₁₂₃_eq_pi
    exact ⟨x, hx, y, hy, z, hz, hxy, hxz, hyz, ha.ge⟩
  · have ha := (show Sbtw ℝ y z x from ⟨h, hyz.symm, hxz.symm⟩).angle₁₂₃_eq_pi
    exact ⟨y, hy, z, hz, x, hx, hyz, hxy.symm, hxz.symm, ha.ge⟩
  · have ha := (show Sbtw ℝ z x y from ⟨h, hxz, hxy⟩).angle₁₂₃_eq_pi
    exact ⟨z, hz, x, hx, y, hy, hxz.symm, hyz.symm, hxy, ha.ge⟩

theorem hasLargeAngle_pi_of_not_generalPosition {s : Finset Plane}
    (h : ¬ GeneralPosition s) : HasLargeAngle s Real.pi := by
  classical
  simp only [GeneralPosition, not_forall] at h
  push Not at h
  obtain ⟨x, hx, y, hy, z, hz, hxy, hxz, hyz, hc⟩ := h
  exact hasLargeAngle_pi_of_collinear hx hy hz hxy hxz hyz hc

/-- Exact equivalence with the restricted universal statement, for a ≤ pi. -/
theorem guaranteedAngle_iff_generalPosition {n : ℕ} {a : ℝ} (ha : a ≤ Real.pi) :
    GuaranteedAngle n a ↔
      ∀ s : Finset Plane, s.card = n → GeneralPosition s → HasLargeAngle s a := by
  constructor
  · intro h s hs _
    exact h s hs
  · intro h s hs
    by_cases hg : GeneralPosition s
    · exact h s hs hg
    · exact (hasLargeAngle_pi_of_not_generalPosition hg).mono_bound ha

/-- A counterexample to any bound at most pi is automatically in general position. -/
theorem generalPosition_of_not_hasLargeAngle {s : Finset Plane} {a : ℝ}
    (ha : a ≤ Real.pi) (h : ¬ HasLargeAngle s a) : GeneralPosition s := by
  by_contra hg
  exact h ((hasLargeAngle_pi_of_not_generalPosition hg).mono_bound ha)

end Prize.JSP404
