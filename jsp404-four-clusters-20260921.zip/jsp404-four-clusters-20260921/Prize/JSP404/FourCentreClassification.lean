import Prize.JSP404.FourCentreConvexGeometry
import Prize.JSP404.GeneralPosition
import Mathlib.Analysis.Convex.Radon

/-! Classification of four actual plane points. This supplies the missing
incidence classification, not the uniform projective-gap capacity definition. -/

namespace Prize.JSP404

open EuclideanGeometry

/-- Membership in a triangle's convex hull gives the barycentric data used by
the interior-centre geometry interface. -/
theorem barycentric_of_mem_triangle {A B C D : Plane}
    (hAB : A ≠ B) (hAC : A ≠ C) (hBC : B ≠ C)
    (hD : D ∈ convexHull ℝ ({A, B, C} : Set Plane)) :
    ∃ a b c : ℝ, 0 ≤ a ∧ 0 ≤ b ∧ 0 ≤ c ∧ a + b + c = 1 ∧
      D = a • A + b • B + c • C := by
  classical
  have hm : D ∈ convexHull ℝ (↑({A, B, C} : Finset Plane) : Set Plane) := by
    simpa using hD
  obtain ⟨w, hw, hs, he⟩ := Finset.mem_convexHull'.mp hm
  refine ⟨w A, w B, w C, hw A (by simp), hw B (by simp), hw C (by simp), ?_, ?_⟩
  · simpa [Finset.sum_insert, hAB, hAC, hBC, add_assoc] using hs
  · simpa [Finset.sum_insert, hAB, hAC, hBC, add_assoc] using he.symm

/-- A labelling of four distinct points, with either a point in the other
three's convex hull, or two crossing closed segments. -/
theorem four_point_radon_cases (p : Fin 4 → Plane) (hinj : Function.Injective p) :
    ∃ A B C D : Plane,
      A ≠ B ∧ A ≠ C ∧ A ≠ D ∧ B ≠ C ∧ B ≠ D ∧ C ≠ D ∧
      Set.range p = {A, B, C, D} ∧
      (D ∈ convexHull ℝ ({A, B, C} : Set Plane) ∨
        ∃ O : Plane, Wbtw ℝ A O C ∧ Wbtw ℝ B O D) := by
  classical
  have hdep : ¬ AffineIndependent ℝ p := by
    intro h
    have hc := h.card_le_finrank_succ
    have hd := Submodule.finrank_le (vectorSpan ℝ (Set.range p))
    have hp : Module.finrank ℝ Plane = 2 := by simp [Plane]
    rw [hp] at hd
    simp only [Fintype.card_fin] at hc
    omega
  obtain ⟨I, O, hI, hIc⟩ := Convex.radon_partition hdep
  have hsmall : ∃ J : Set (Fin 4),
      O ∈ convexHull ℝ (p '' J) ∧ O ∈ convexHull ℝ (p '' Jᶜ) ∧
      J.toFinset.card ≤ 2 := by
    by_cases h : I.toFinset.card ≤ 2
    · exact ⟨I, hI, hIc, h⟩
    · refine ⟨Iᶜ, hIc, by simpa using hI, ?_⟩
      rw [Set.toFinset_compl, Finset.card_compl]
      simp only [Fintype.card_fin]
      omega
  obtain ⟨J, hJ, hJc, hcard⟩ := hsmall
  have hne : J.Nonempty := Set.image_nonempty.mp
    (convexHull_nonempty_iff.mp ⟨O, hJ⟩)
  have hpos : 0 < J.toFinset.card := Finset.card_pos.mpr (by simpa using hne)
  have hcross : ∀ i ∈ J, ∀ j ∈ Jᶜ, p i ≠ p j := by
    intro i hi j hj he
    exact hj (hinj he ▸ hi)
  have hrange : Set.range p = p '' J ∪ p '' Jᶜ := by
    rw [← Set.image_union, Set.union_compl_self, Set.image_univ]
  have hcases : J.toFinset.card = 1 ∨ J.toFinset.card = 2 := by omega
  rcases hcases with hsingle | hpair
  · obtain ⟨d, hd⟩ := Finset.card_eq_one.mp hsingle
    have hJs : J = {d} := by
      have := congrArg (fun s : Finset (Fin 4) => (s : Set (Fin 4))) hd
      simpa using this
    have hc : Jᶜ.toFinset.card = 3 := by
      rw [Set.toFinset_compl, Finset.card_compl, hsingle]
      decide
    obtain ⟨a, b, c, hab, hac, hbc, habc⟩ := Finset.card_eq_three.mp hc
    have hJcs : Jᶜ = {a, b, c} := by
      have := congrArg (fun s : Finset (Fin 4) => (s : Set (Fin 4))) habc
      simpa using this
    have hda := hcross d (by simp [hJs]) a (by simp [hJcs])
    have hdb := hcross d (by simp [hJs]) b (by simp [hJcs])
    have hdc := hcross d (by simp [hJs]) c (by simp [hJcs])
    refine ⟨p a, p b, p c, p d, hinj.ne hab, hinj.ne hac, hda.symm,
      hinj.ne hbc, hdb.symm, hdc.symm, ?_, Or.inl ?_⟩
    · rw [hrange, hJcs, hJs]
      ext x
      simp only [Set.image_insert_eq, Set.image_singleton, Set.mem_union,
        Set.mem_insert_iff, Set.mem_singleton_iff]
      tauto
    · have hO : O = p d := by simpa [hJs] using hJ
      simpa [hO, hJcs, Set.image_insert_eq] using hJc
  · have hc : Jᶜ.toFinset.card = 2 := by
      rw [Set.toFinset_compl, Finset.card_compl, hpair]
      decide
    obtain ⟨a, c, hac, hacs⟩ := Finset.card_eq_two.mp hpair
    obtain ⟨b, d, hbd, hbds⟩ := Finset.card_eq_two.mp hc
    have hJs : J = {a, c} := by
      have := congrArg (fun s : Finset (Fin 4) => (s : Set (Fin 4))) hacs
      simpa using this
    have hJcs : Jᶜ = {b, d} := by
      have := congrArg (fun s : Finset (Fin 4) => (s : Set (Fin 4))) hbds
      simpa using this
    have hab := hcross a (by simp [hJs]) b (by simp [hJcs])
    have had := hcross a (by simp [hJs]) d (by simp [hJcs])
    have hcb := hcross c (by simp [hJs]) b (by simp [hJcs])
    have hcd := hcross c (by simp [hJs]) d (by simp [hJcs])
    refine ⟨p a, p b, p c, p d, hab, hinj.ne hac, had, hcb.symm,
      hinj.ne hbd, hcd, ?_, Or.inr ⟨O, ?_, ?_⟩⟩
    · rw [hrange, hJcs, hJs]
      ext x
      simp only [Set.image_pair, Set.mem_union, Set.mem_insert_iff,
        Set.mem_singleton_iff]
      tauto
    · apply mem_segment_iff_wbtw.mp
      simpa [hJs, Set.image_pair, convexHull_pair] using hJ
    · apply mem_segment_iff_wbtw.mp
      simpa [hJcs, Set.image_pair, convexHull_pair] using hJc

/-- In general position a Radon 2+2 intersection is strictly inside both
diagonals: an endpoint intersection would make three points collinear. -/
theorem strict_crossing_of_generalPosition {s : Finset Plane} (hg : GeneralPosition s)
    {A B C D O : Plane} (hA : A ∈ s) (hB : B ∈ s) (hC : C ∈ s) (hD : D ∈ s)
    (hAB : A ≠ B) (hAC : A ≠ C) (hAD : A ≠ D)
    (hBC : B ≠ C) (hBD : B ≠ D) (hCD : C ≠ D)
    (hACo : Wbtw ℝ A O C) (hBDo : Wbtw ℝ B O D) :
    Sbtw ℝ A O C ∧ Sbtw ℝ B O D := by
  have hOA : O ≠ A := by
    intro h
    subst O
    exact hg B hB A hA D hD hAB.symm hBD hAD hBDo.collinear
  have hOC : O ≠ C := by
    intro h
    subst O
    exact hg B hB C hC D hD hBC hBD hCD hBDo.collinear
  have hOB : O ≠ B := by
    intro h
    subst O
    exact hg A hA B hB C hC hAB hAC hBC hACo.collinear
  have hOD : O ≠ D := by
    intro h
    subst O
    exact hg A hA D hD C hC hAD hAC hCD.symm hACo.collinear
  exact ⟨⟨hACo, hOA, hOC⟩, ⟨hBDo, hOB, hOD⟩⟩

/-- Every four-point general-position configuration whose angles obey the
specified bound has one of the two already verified geometric models.
The equality of point sets records that no point was dropped or added. -/
theorem four_centre_geometry_cases {s : Finset Plane} (hs : s.card = 4)
    (hg : GeneralPosition s) (t : ℝ)
    (ha : ∀ A ∈ s, ∀ B ∈ s, ∀ C ∈ s, A ≠ B → A ≠ C → B ≠ C →
      angle A B C ≤ (1 - 1 / t) * Real.pi) :
    (∃ v : InteriorFourGeometry t, (s : Set Plane) = {v.A, v.B, v.C, v.D}) ∨
    (∃ v : ConvexFourGeometry t, (s : Set Plane) = {v.A, v.B, v.C, v.D}) := by
  classical
  let e : Fin 4 ≃ s := (Finset.equivFinOfCardEq hs).symm
  let p : Fin 4 → Plane := fun i => (e i : Plane)
  have hp : Function.Injective p := Subtype.coe_injective.comp e.injective
  have hr : Set.range p = (s : Set Plane) := by
    ext x
    constructor
    · rintro ⟨i, rfl⟩
      exact (e i).property
    · intro hx
      refine ⟨e.symm ⟨x, hx⟩, ?_⟩
      simp [p]
  obtain ⟨A, B, C, D, hAB, hAC, hAD, hBC, hBD, hCD, he, hcase⟩ :=
    four_point_radon_cases p hp
  rw [hr] at he
  have hA : A ∈ s := by change A ∈ (s : Set Plane); rw [he]; simp
  have hB : B ∈ s := by change B ∈ (s : Set Plane); rw [he]; simp
  have hC : C ∈ s := by change C ∈ (s : Set Plane); rw [he]; simp
  have hD : D ∈ s := by change D ∈ (s : Set Plane); rw [he]; simp
  rcases hcase with hi | ⟨O, hOAC, hOBD⟩
  · obtain ⟨a, b, c, ha0, hb0, hc0, hw, hv⟩ := barycentric_of_mem_triangle hAB hAC hBC hi
    exact Or.inl ⟨{
      A := A, B := B, C := C, D := D, a := a, b := b, c := c
      a_nonneg := ha0, b_nonneg := hb0, c_nonneg := hc0
      weights_sum := hw, barycentric := hv
      ab_ne := hAB, ac_ne := hAC, bc_ne := hBC
      da_ne := hAD.symm, db_ne := hBD.symm, dc_ne := hCD.symm
      angle_a := ha B hB A hA C hC hAB.symm hBC hAC
      angle_b := ha A hA B hB C hC hAB hAC hBC
      angle_c := ha A hA C hC B hB hAC hAB hBC.symm
      angle_dab := ha A hA D hD B hB hAD hAB hBD.symm
      angle_dac := ha A hA D hD C hC hAD hAC hCD.symm
      angle_dbc := ha B hB D hD C hC hBD hBC hCD.symm }, he⟩
  · obtain ⟨hACo, hBDo⟩ := strict_crossing_of_generalPosition hg hA hB hC hD
      hAB hAC hAD hBC hBD hCD hOAC hOBD
    exact Or.inr ⟨{
      A := A, B := B, C := C, D := D, O := O
      ab_ne := hAB, bc_ne := hBC, cd_ne := hCD, da_ne := hAD.symm
      diagonal_ac := hACo, diagonal_bd := hBDo
      angle_a := ha B hB A hA D hD hAB.symm hBD hAD
      angle_b := ha A hA B hB C hC hAB hAC hBC
      angle_c := ha B hB C hC D hD hBC hBD hCD
      angle_d := ha A hA D hD C hC hAD hAC hCD.symm }, he⟩

/-- An actual strict upper bound below pi already forces general position. -/
theorem generalPosition_of_angle_bound {s : Finset Plane} {a : ℝ} (ha : a < Real.pi)
    (hb : ∀ A ∈ s, ∀ B ∈ s, ∀ C ∈ s, A ≠ B → A ≠ C → B ≠ C →
      angle A B C ≤ a) : GeneralPosition s := by
  by_contra hg
  obtain ⟨A, hA, B, hB, C, hC, hAB, hAC, hBC, hangle⟩ :=
    hasLargeAngle_pi_of_not_generalPosition hg
  exact (not_le_of_gt ha) (hangle.trans (hb A hA B hB C hC hAB hAC hBC))

/-- No general-position hypothesis is needed when the actual angle cap has
the form used by the capacity theorem with positive parameter. -/
theorem four_centre_geometry_cases_of_angle_bound {s : Finset Plane}
    (hs : s.card = 4) {t : ℝ} (ht : 0 < t)
    (ha : ∀ A ∈ s, ∀ B ∈ s, ∀ C ∈ s, A ≠ B → A ≠ C → B ≠ C →
      angle A B C ≤ (1 - 1 / t) * Real.pi) :
    (∃ v : InteriorFourGeometry t, (s : Set Plane) = {v.A, v.B, v.C, v.D}) ∨
    (∃ v : ConvexFourGeometry t, (s : Set Plane) = {v.A, v.B, v.C, v.D}) := by
  apply four_centre_geometry_cases hs _ t ha
  apply generalPosition_of_angle_bound (a := (1 - 1 / t) * Real.pi) _ ha
  have h : 0 < 1 / t := one_div_pos.mpr ht
  nlinarith [Real.pi_pos, mul_pos h Real.pi_pos]

/-- The low-band capacity bound for an exhaustive geometric model of any
four-point configuration with the stated actual angle cap. -/
theorem four_centre_capacity_low_cases {s : Finset Plane} (hs : s.card = 4)
    {n : ℕ} (hn : 2 ≤ n) {t : ℝ} (ht : (n : ℝ) ≤ t) (ht' : t < n + 1 / 2)
    (ha : ∀ A ∈ s, ∀ B ∈ s, ∀ C ∈ s, A ≠ B → A ≠ C → B ≠ C →
      angle A B C ≤ (1 - 1 / t) * Real.pi) :
    (∃ v : InteriorFourGeometry t, (s : Set Plane) = {v.A, v.B, v.C, v.D} ∧
      interiorFourCapacity t v.A v.B v.C v.D ≤ 2 ^ n) ∨
    (∃ v : ConvexFourGeometry t, (s : Set Plane) = {v.A, v.B, v.C, v.D} ∧
      convexFourCapacity t v.A v.B v.C v.D ≤ 2 ^ n) := by
  have htpos : 0 < t := by
    have : (2 : ℝ) ≤ n := by exact_mod_cast hn
    linarith
  rcases four_centre_geometry_cases_of_angle_bound hs htpos ha with ⟨v, hv⟩ | ⟨v, hv⟩
  · exact Or.inl ⟨v, hv, v.capacity_low hn ht ht'⟩
  · exact Or.inr ⟨v, hv, v.capacity_low hn ht ht'⟩

theorem four_centre_capacity_high_cases {s : Finset Plane} (hs : s.card = 4)
    {n : ℕ} (hn : 2 ≤ n) {t : ℝ} (ht : (n : ℝ) ≤ t) (ht' : t < n + 1)
    (ha : ∀ A ∈ s, ∀ B ∈ s, ∀ C ∈ s, A ≠ B → A ≠ C → B ≠ C →
      angle A B C ≤ (1 - 1 / t) * Real.pi) :
    (∃ v : InteriorFourGeometry t, (s : Set Plane) = {v.A, v.B, v.C, v.D} ∧
      interiorFourCapacity t v.A v.B v.C v.D ≤ 2 ^ n + 2 ^ (n - 2)) ∨
    (∃ v : ConvexFourGeometry t, (s : Set Plane) = {v.A, v.B, v.C, v.D} ∧
      convexFourCapacity t v.A v.B v.C v.D ≤ 2 ^ n + 2 ^ (n - 2)) := by
  have htpos : 0 < t := by
    have : (2 : ℝ) ≤ n := by exact_mod_cast hn
    linarith
  rcases four_centre_geometry_cases_of_angle_bound hs htpos ha with ⟨v, hv⟩ | ⟨v, hv⟩
  · exact Or.inl ⟨v, hv, v.capacity_high hn ht ht'⟩
  · exact Or.inr ⟨v, hv, v.capacity_high hn ht ht'⟩

end Prize.JSP404
