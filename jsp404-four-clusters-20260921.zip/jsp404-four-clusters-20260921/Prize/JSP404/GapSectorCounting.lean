import Prize.JSP404.GeneralizedDirectionCover
import Prize.JSP404.GapIntervalCover
import Prize.JSP404.ProjectiveThreeDirections

/-!
# From allowed gap coordinates to a bound on the number of leaves

The coordinate-cover assumption is explicit: each internal line must lie in
the allowed portion of one of the given gaps. This file constructs all the
thin sectors and proves their counting bound. Deriving the allowed coordinates
from arbitrary external anchor directions is not assumed proved here.
-/

namespace Prize.JSP404

open InnerProductGeometry

theorem unitDirection_angle_abs {θ φ : ℝ} (h : |θ - φ| ≤ Real.pi) :
    angle (unitDirection θ) (unitDirection φ) = |θ - φ| := by
  by_cases hle : θ ≤ φ
  · rw [abs_of_nonpos (sub_nonpos.mpr hle)] at h ⊢
    rw [unitDirection_angle hle (by linarith)]
    ring
  · have hle' : φ ≤ θ := le_of_not_ge hle
    rw [abs_of_nonneg (sub_nonneg.mpr hle')] at h ⊢
    rw [angle_comm, unitDirection_angle hle' h]

/-- Positive rays whose angle parameters lie in a real set. -/
def parameterSector (left w : ℝ) (C : Set ℝ) : Set Plane :=
  {p | ∃ x ∈ C, ∃ r : ℝ, 0 < r ∧ p = r • unitDirection (left + w * x)}

theorem parameterSector_thin {left w : ℝ} (hw : 0 < w) (hwpi : w ≤ Real.pi)
    {C : Set ℝ} (hthin : ∀ x ∈ C, ∀ y ∈ C, |x - y| < 1)
    {p q : Plane} (hp : p ∈ parameterSector left w C)
    (hq : q ∈ parameterSector left w C) : angle p q < w := by
  rcases hp with ⟨x, hx, r, hr, rfl⟩
  rcases hq with ⟨y, hy, s, hs, rfl⟩
  have hdist : |(left + w * x) - (left + w * y)| < w := by
    rw [show (left + w * x) - (left + w * y) = w * (x - y) by ring,
      abs_mul, abs_of_pos hw]
    simpa using mul_lt_mul_of_pos_left (hthin x hx y hy) hw
  rw [angle_smul_left_of_pos _ _ hr, angle_smul_right_of_pos _ _ hs,
    unitDirection_angle_abs (hdist.le.trans hwpi)]
  exact hdist

/-- All interval and sector covers are constructed. Only membership of the
internal projective directions in the prescribed allowed gaps is a hypothesis. -/
theorem GeneralizedDirections.card_le_of_allowed_gap_coordinates
    {V J : Type*} [Fintype V] [Fintype J] (D : GeneralizedDirections V)
    (left z : J → ℝ) {w : ℝ} (hw : 0 < w) (hwpi : w ≤ Real.pi)
    (hbound : D.AngleBound (Real.pi - w))
    (hallowed : ∀ u v, u ≠ v → ∃ j x, x ∈ Set.Icc 1 (z j - 1) ∧
      ∃ r : ℝ, 0 < r ∧
        (D.direction u v = r • unitDirection (left j + w * x) ∨
         D.direction v u = r • unitDirection (left j + w * x))) :
    Fintype.card V ≤ 2 ^ (∑ j, sectorCapacity 1 (z j)) := by
  classical
  choose C hcover hthin using fun j => exists_gap_interval_cover (z j)
  let S : (Σ j, Fin (sectorCapacity 1 (z j))) → Set Plane :=
    fun ji => parameterSector (left ji.1) w (C ji.1 ji.2)
  have hcount := D.card_le_two_pow_of_indexed_cover
    (sub_nonneg.mpr hwpi) S ?_ ?_ hbound
  · simpa only [Fintype.card_sigma, Fintype.card_fin] using hcount
  · intro u v huv
    obtain ⟨j, x, hx, r, hr, hdir⟩ := hallowed u v huv
    obtain ⟨i, hi⟩ := hcover j x hx
    refine ⟨⟨j, i⟩, ?_⟩
    exact hdir.elim (fun h => Or.inl ⟨x, hi, r, hr, h⟩)
      (fun h => Or.inr ⟨x, hi, r, hr, h⟩)
  · intro ji p hp q hq
    have h := parameterSector_thin hw hwpi (hthin ji.1 ji.2) hp hq
    linarith

end Prize.JSP404
