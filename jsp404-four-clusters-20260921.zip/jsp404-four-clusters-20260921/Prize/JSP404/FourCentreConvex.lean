import Prize.JSP404.FourCentreInterior

/-! Four-centre capacity for a convex quadrilateral. The data consists of
scaled corner angles split by the diagonals; the identities come from its four
triangles. The geometric construction of this data is separate. -/

namespace Prize.JSP404

structure ConvexFourAngleData (t : ℝ) where
  a1 : ℝ
  a2 : ℝ
  b1 : ℝ
  b2 : ℝ
  c1 : ℝ
  c2 : ℝ
  d1 : ℝ
  d2 : ℝ
  a1_nonneg : 0 ≤ a1
  a2_nonneg : 0 ≤ a2
  b1_nonneg : 0 ≤ b1
  b2_nonneg : 0 ≤ b2
  c1_nonneg : 0 ≤ c1
  c2_nonneg : 0 ≤ c2
  d1_nonneg : 0 ≤ d1
  d2_nonneg : 0 ≤ d2
  total : a1 + a2 + b1 + b2 + c1 + c2 + d1 + d2 = 2 * t
  gap_a : t - a1 - a2 = b1 + d2
  gap_b : t - b1 - b2 = a1 + c1
  gap_c : t - c1 - c2 = b2 + d1
  gap_d : t - d1 - d2 = a2 + c2
  comp_a : 1 ≤ t - a1 - a2
  comp_b : 1 ≤ t - b1 - b2
  comp_c : 1 ≤ t - c1 - c2
  comp_d : 1 ≤ t - d1 - d2

namespace ConvexFourAngleData

variable {t : ℝ}

noncomputable def KA (v : ConvexFourAngleData t) := splitVertexBits t v.a1 v.a2
noncomputable def KB (v : ConvexFourAngleData t) := splitVertexBits t v.b1 v.b2
noncomputable def KC (v : ConvexFourAngleData t) := splitVertexBits t v.c1 v.c2
noncomputable def KD (v : ConvexFourAngleData t) := splitVertexBits t v.d1 v.d2
noncomputable def capacity (v : ConvexFourAngleData t) : ℕ :=
  2 ^ v.KA + 2 ^ v.KB + 2 ^ v.KC + 2 ^ v.KD

def rotate (v : ConvexFourAngleData t) : ConvexFourAngleData t where
  a1 := v.b2
  a2 := v.b1
  b1 := v.c1
  b2 := v.c2
  c1 := v.d1
  c2 := v.d2
  d1 := v.a2
  d2 := v.a1
  a1_nonneg := v.b2_nonneg
  a2_nonneg := v.b1_nonneg
  b1_nonneg := v.c1_nonneg
  b2_nonneg := v.c2_nonneg
  c1_nonneg := v.d1_nonneg
  c2_nonneg := v.d2_nonneg
  d1_nonneg := v.a2_nonneg
  d2_nonneg := v.a1_nonneg
  total := by linarith [v.total]
  gap_a := by linarith [v.gap_b]
  gap_b := v.gap_c
  gap_c := by linarith [v.gap_d]
  gap_d := by linarith [v.gap_a]
  comp_a := by linarith [v.comp_b]
  comp_b := v.comp_c
  comp_c := v.comp_d
  comp_d := by linarith [v.comp_a]

@[simp] theorem KA_rotate (v : ConvexFourAngleData t) : v.rotate.KA = v.KB :=
  splitVertexBits_comm t v.b2 v.b1
@[simp] theorem KB_rotate (v : ConvexFourAngleData t) : v.rotate.KB = v.KC := rfl
@[simp] theorem KC_rotate (v : ConvexFourAngleData t) : v.rotate.KC = v.KD := rfl
@[simp] theorem KD_rotate (v : ConvexFourAngleData t) : v.rotate.KD = v.KA :=
  splitVertexBits_comm t v.a2 v.a1
@[simp] theorem capacity_rotate (v : ConvexFourAngleData t) : v.rotate.capacity = v.capacity := by
  simp only [capacity, KA_rotate, KB_rotate, KC_rotate, KD_rotate]
  omega

theorem controls (v : ConvexFourAngleData t) {n : ℕ} (hn : 2 ≤ n) (ht : t < n + 1) :
    (v.KA ≤ n - 1 ∧ (n - 1 ≤ v.KA → v.a1 + v.a2 ≤ t - n)) ∧
    (v.KB ≤ n - 1 ∧ (n - 1 ≤ v.KB → v.b1 + v.b2 ≤ t - n)) ∧
    (v.KC ≤ n - 1 ∧ (n - 1 ≤ v.KC → v.c1 + v.c2 ≤ t - n)) ∧
    (v.KD ≤ n - 1 ∧ (n - 1 ≤ v.KD → v.d1 + v.d2 ≤ t - n)) :=
  ⟨splitVertexBits_control hn ht v.a1_nonneg v.a2_nonneg v.comp_a,
   splitVertexBits_control hn ht v.b1_nonneg v.b2_nonneg v.comp_b,
   splitVertexBits_control hn ht v.c1_nonneg v.c2_nonneg v.comp_c,
   splitVertexBits_control hn ht v.d1_nonneg v.d2_nonneg v.comp_d⟩

/-- Convexity's angle sum rules out two top exponents throughout the whole band. -/
theorem drop_of_A_high (v : ConvexFourAngleData t) {n : ℕ}
    (hn : 2 ≤ n) (ht : t < n + 1) (hA : n - 1 ≤ v.KA) :
    v.KB ≤ n - 2 ∧ v.KC ≤ n - 2 ∧ v.KD ≤ n - 2 := by
  obtain ⟨hca, hcb, hcc, hcd⟩ := v.controls hn ht
  have hsmallA := hca.2 hA
  refine ⟨?_, ?_, ?_⟩
  · by_contra h
    have := hcb.2 (by omega)
    linarith [v.total, v.comp_c, v.comp_d]
  · by_contra h
    have := hcc.2 (by omega)
    linarith [v.total, v.comp_b, v.comp_d]
  · by_contra h
    have := hcd.2 (by omega)
    linarith [v.total, v.comp_b, v.comp_c]

/-- A top exponent in the lower band forces the opposite vertex and at least
one adjacent vertex down to n-3. -/
theorem low_drop (v : ConvexFourAngleData t) {n : ℕ}
    (hn : 3 ≤ n) (ht : t < n + 1 / 2) (hA : n - 1 ≤ v.KA) :
    v.KC ≤ n - 3 ∧ (v.KB ≤ n - 3 ∨ v.KD ≤ n - 3) := by
  have ht1 : t < n + 1 := by linarith
  obtain ⟨hca, hcb, hcc, hcd⟩ := v.controls (by omega) ht1
  have hsmallA := hca.2 hA
  have hgB : t - v.b1 - v.b2 < n - 1 := by
    linarith [v.total, v.comp_c, v.comp_d]
  have hgC : t - v.c1 - v.c2 < n - 1 := by
    linarith [v.total, v.comp_b, v.comp_d]
  have hgD : t - v.d1 - v.d2 < n - 1 := by
    linarith [v.total, v.comp_b, v.comp_c]
  have hc1 : t - n < v.c1 := by linarith [v.gap_b, v.comp_b, v.a2_nonneg]
  have hc2 : t - n < v.c2 := by linarith [v.gap_d, v.comp_d, v.a1_nonneg]
  constructor
  · by_contra h
    have hm : n - 2 ≤ v.KC := by omega
    rcases splitVertexBits_middle_dichotomy hn ht1 v.c1_nonneg v.c2_nonneg
      v.comp_c hc1 hm with h | h <;> linarith
  · by_contra h
    have hmB : n - 2 ≤ v.KB := by omega
    have hmD : n - 2 ≤ splitVertexBits t v.d2 v.d1 := by
      rw [splitVertexBits_comm]
      change n - 2 ≤ v.KD
      omega
    have hb1 : t - n < v.b1 := by linarith [v.gap_a, v.comp_d, v.d1_nonneg]
    have hd2 : t - n < v.d2 := by linarith [v.gap_a, v.comp_b, v.b2_nonneg]
    have hB := splitVertexBits_middle_dichotomy hn ht1 v.b1_nonneg v.b2_nonneg
      v.comp_b hb1 hmB
    have hD := splitVertexBits_middle_dichotomy hn ht1 v.d2_nonneg v.d1_nonneg
      (by linarith [v.comp_d]) hd2 hmD
    rcases hB with h | hB
    · linarith
    · rcases hD with h | hD
      · linarith
      · linarith [v.gap_c, v.comp_c]

private theorem capacity_low_of_A_high (v : ConvexFourAngleData t) {n : ℕ}
    (hn : 2 ≤ n) (ht : t < n + 1 / 2) (hA : n - 1 ≤ v.KA) :
    v.capacity ≤ 2 ^ n := by
  have ht1 : t < n + 1 := by linarith
  obtain ⟨hca, hcb, hcc, hcd⟩ := v.controls hn ht1
  have hsmallA := hca.2 hA
  have hn3 : 3 ≤ n := by
    by_contra h
    have hn2 : n = 2 := by omega
    subst n
    norm_num at ht hsmallA
    linarith [v.total, v.comp_b, v.comp_c, v.comp_d]
  obtain ⟨hB, _, hD⟩ := v.drop_of_A_high hn ht1 hA
  obtain ⟨hC, hlow⟩ := v.low_drop hn3 ht hA
  rcases hlow with hB' | hD'
  · have := InteriorAngleData.pow_low_pattern hn3 hca.1 hD hB' hC
    unfold capacity
    omega
  · exact InteriorAngleData.pow_low_pattern hn3 hca.1 hB hC hD'

theorem capacity_low (v : ConvexFourAngleData t) {n : ℕ}
    (hn : 2 ≤ n) (ht : t < n + 1 / 2) : v.capacity ≤ 2 ^ n := by
  by_cases hA : n - 1 ≤ v.KA
  · exact v.capacity_low_of_A_high hn ht hA
  by_cases hB : n - 1 ≤ v.KB
  · simpa using v.rotate.capacity_low_of_A_high hn ht (by simpa using hB)
  by_cases hC : n - 1 ≤ v.KC
  · simpa using v.rotate.rotate.capacity_low_of_A_high hn ht (by simpa using hC)
  by_cases hD : n - 1 ≤ v.KD
  · simpa using v.rotate.rotate.rotate.capacity_low_of_A_high hn ht (by simpa using hD)
  exact InteriorAngleData.pow_four_mid hn (by omega) (by omega) (by omega) (by omega)

private theorem capacity_high_of_A_high (v : ConvexFourAngleData t) {n : ℕ}
    (hn : 2 ≤ n) (ht : t < n + 1) (hA : n - 1 ≤ v.KA) :
    v.capacity ≤ 2 ^ n + 2 ^ (n - 2) := by
  obtain ⟨hca, _, _, _⟩ := v.controls hn ht
  obtain ⟨hB, hC, hD⟩ := v.drop_of_A_high hn ht hA
  exact InteriorAngleData.pow_one_high hn hca.1 hB hC hD

theorem capacity_high (v : ConvexFourAngleData t) {n : ℕ}
    (hn : 2 ≤ n) (ht : t < n + 1) : v.capacity ≤ 2 ^ n + 2 ^ (n - 2) := by
  by_cases hA : n - 1 ≤ v.KA
  · exact v.capacity_high_of_A_high hn ht hA
  by_cases hB : n - 1 ≤ v.KB
  · simpa using v.rotate.capacity_high_of_A_high hn ht (by simpa using hB)
  by_cases hC : n - 1 ≤ v.KC
  · simpa using v.rotate.rotate.capacity_high_of_A_high hn ht (by simpa using hC)
  by_cases hD : n - 1 ≤ v.KD
  · simpa using v.rotate.rotate.rotate.capacity_high_of_A_high hn ht (by simpa using hD)
  have h : v.capacity ≤ 2 ^ n :=
    InteriorAngleData.pow_four_mid hn (by omega) (by omega) (by omega) (by omega)
  exact h.trans (Nat.le_add_right _ _)

end ConvexFourAngleData

end Prize.JSP404
