import Mathlib.Combinatorics.SimpleGraph.Coloring.Constructions
import Mathlib.Data.Fintype.Pi

/-!
# The binary counting step in Sendov's argument

Reference: Sendov, Compulsory configurations of points in the plane (1995),
Lemma 4.4, p. 506. We use binary labels rather than the paper's induction.
The graph theorem assumes bipartiteness explicitly. A separate directed-relation
version is intended for the sector argument of Lemma 4.6; it does not establish
the geometric hypotheses of that lemma, or the sharp bound in Lemma 4.12.
-/

namespace Prize.JSP404

variable {V : Type*} [Fintype V] {k : ℕ}

/-- Covering every distinct pair by one of k bipartite graphs gives at most 2^k
vertices. Edge-disjointness is unnecessary. -/
theorem card_le_two_pow_of_bipartite_cover
    (G : Fin k → SimpleGraph V)
    (hbip : ∀ i, (G i).IsBipartite)
    (hcover : ∀ u v : V, u ≠ v → ∃ i, (G i).Adj u v) :
    Fintype.card V ≤ 2 ^ k := by
  classical
  let c : ∀ i, (G i).Coloring (Fin 2) := fun i => (hbip i).some
  let code : V → (Fin k → Fin 2) := fun v i => c i v
  have hinj : Function.Injective code := by
    intro u v huv
    by_contra hne
    obtain ⟨i, hi⟩ := hcover u v hne
    exact (c i).valid hi (congrFun huv i)
  simpa using Fintype.card_le_of_injective code hinj

/-- The version using even closed walks, with the conversion to bipartiteness
supplied by mathlib. No assertion about geometric sectors is built into it. -/
theorem card_le_two_pow_of_even_walk_cover
    (G : Fin k → SimpleGraph V)
    (heven : ∀ i u, ∀ w : (G i).Walk u u, Even w.length)
    (hcover : ∀ u v : V, u ≠ v → ∃ i, (G i).Adj u v) :
    Fintype.card V ≤ 2 ^ k := by
  apply card_le_two_pow_of_bipartite_cover G ?_ hcover
  intro i
  exact SimpleGraph.two_colorable_iff_forall_loop_even.mpr (heven i)

/-- If oriented relations cover every pair and none admits two consecutive
arrows, an outgoing-arrow bit in each relation separates every pair of vertices.
This avoids any graph-cycle machinery when applying the sector method. -/
theorem card_le_two_pow_of_no_two_step_cover
    (R : Fin k → V → V → Prop)
    (hcover : ∀ u v : V, u ≠ v → ∃ i, R i u v ∨ R i v u)
    (hstep : ∀ i u v w, R i u v → R i v w → False) :
    Fintype.card V ≤ 2 ^ k := by
  classical
  let code : V → (Fin k → Bool) := fun v i => decide (∃ w, R i v w)
  have hdifferent : ∀ i u v, R i u v → code u i ≠ code v i := by
    intro i u v huv heq
    have hu : (∃ w, R i u w) := ⟨v, huv⟩
    have hv : ¬ (∃ w, R i v w) := by
      rintro ⟨w, hvw⟩
      exact hstep i u v w huv hvw
    simp [code, hu, hv] at heq
  have hinj : Function.Injective code := by
    intro u v huv
    by_contra hne
    obtain ⟨i, hi⟩ := hcover u v hne
    rcases hi with hi | hi
    · exact hdifferent i u v hi (congrFun huv i)
    · exact hdifferent i v u hi (congrFun huv i).symm
  simpa using Fintype.card_le_of_injective code hinj

end Prize.JSP404
