import Prize.JSP404.SectorCapacity

/-!
# Independent proof of the three-centre capacity bound

Reference: Sendov (1995), English Lemma 4.1(b), pp. 38–39; Russian Lemma
4.12(b), pp. 511–512. We prove inequalities directly, without relying on the
source's intermediate equalities or its asserted maximizing exponent sequence.

For a normalized triangle angle x, its two projective angular gaps are x and
1-x. Put t = u/2. The maximum-angle restriction is t*(1-x) >= 1.
This file proves the capacity inequalities, not the reduction of arbitrary
configurations to three centres.
-/

namespace Prize.JSP404

open EuclideanGeometry

noncomputable def triangleVertexCapacity (t x : ℝ) : ℕ :=
  sectorCapacity t x + sectorCapacity t (1 - x)

/-- The exponent is at most n-1. Reaching that value forces a small triangle
angle: t*x <= t-n. This replaces the questionable equalities in the source. -/
theorem triangleVertexCapacity_control {n : ℕ} {t x : ℝ}
    (hn : 2 ≤ n) (ht : (n : ℝ) ≤ t) (ht' : t < n + 1)
    (hx : 0 ≤ x) (hcomp : 1 ≤ t * (1 - x)) :
    triangleVertexCapacity t x ≤ n - 1 ∧
      (n - 1 ≤ triangleVertexCapacity t x → t * x ≤ t - n) := by
  have ht0 : 0 ≤ t := (Nat.cast_nonneg n).trans ht
  have hfa : (0 : ℤ) ≤ ⌊t * x⌋ := Int.floor_nonneg.mpr (mul_nonneg ht0 hx)
  have hfb : (1 : ℤ) ≤ ⌊t * (1 - x)⌋ := Int.le_floor.mpr (by simpa using hcomp)
  have hfloor : ⌊t⌋ = (n : ℤ) := by
    apply Int.floor_eq_iff.mpr
    exact ⟨by simpa using ht, by simpa using ht'⟩
  have hsum : ⌊t * x⌋ + ⌊t * (1 - x)⌋ ≤ (n : ℤ) := by
    have h := Int.le_floor_add (t * x) (t * (1 - x))
    rw [show t * x + t * (1 - x) = t by ring, hfloor] at h
    exact h
  constructor
  · unfold triangleVertexCapacity sectorCapacity
    omega
  · intro hhigh
    have hfbn : (n : ℤ) ≤ ⌊t * (1 - x)⌋ := by
      unfold triangleVertexCapacity sectorCapacity at hhigh
      omega
    have hnr : (n : ℝ) ≤ t * (1 - x) := by
      have hcast : (n : ℝ) ≤ (⌊t * (1 - x)⌋ : ℝ) := by exact_mod_cast hfbn
      exact hcast.trans (Int.floor_le (t * (1 - x)))
    nlinarith

private theorem pow_one_high {n i j k : ℕ} (hn : 2 ≤ n)
    (hi : i ≤ n - 1) (hj : j ≤ n - 2) (hk : k ≤ n - 2) :
    2 ^ i + 2 ^ j + 2 ^ k ≤ 2 ^ n := by
  calc
    _ ≤ 2 ^ (n - 1) + 2 ^ (n - 2) + 2 ^ (n - 2) := by gcongr
    _ = 2 ^ ((n - 2) + 2) := by
      rw [show n - 1 = (n - 2) + 1 by omega, pow_succ, pow_add]
      ring
    _ = 2 ^ n := by congr 1; omega

private theorem pow_two_high {n i j k : ℕ} (hn : 2 ≤ n)
    (hi : i ≤ n - 1) (hj : j ≤ n - 1) (hk : k ≤ n - 2) :
    2 ^ i + 2 ^ j + 2 ^ k ≤ 2 ^ n + 2 ^ (n - 2) := by
  calc
    _ ≤ 2 ^ (n - 1) + 2 ^ (n - 1) + 2 ^ (n - 2) := by gcongr
    _ = 2 ^ ((n - 1) + 1) + 2 ^ (n - 2) := by rw [pow_succ]; ring
    _ = 2 ^ n + 2 ^ (n - 2) := by rw [show n - 1 + 1 = n by omega]

/-- In the lower half-band, no two exponents can attain n-1. -/
theorem threeCentre_capacity_low {n : ℕ} {t x y z : ℝ}
    (hn : 2 ≤ n) (ht : (n : ℝ) ≤ t) (ht' : t < n + 1 / 2)
    (hx : 0 ≤ x) (hy : 0 ≤ y) (hz : 0 ≤ z) (hsum : x + y + z = 1)
    (hcx : 1 ≤ t * (1 - x)) (hcy : 1 ≤ t * (1 - y)) (hcz : 1 ≤ t * (1 - z)) :
    2 ^ triangleVertexCapacity t x + 2 ^ triangleVertexCapacity t y +
      2 ^ triangleVertexCapacity t z ≤ 2 ^ n := by
  have ht1 : t < n + 1 := by linarith
  obtain ⟨hKx, hX⟩ := triangleVertexCapacity_control hn ht ht1 hx hcx
  obtain ⟨hKy, hY⟩ := triangleVertexCapacity_control hn ht ht1 hy hcy
  obtain ⟨hKz, hZ⟩ := triangleVertexCapacity_control hn ht ht1 hz hcz
  have hscaled : t * x + t * y + t * z = t := by
    calc
      _ = t * (x + y + z) := by ring
      _ = t := by rw [hsum, mul_one]
  by_cases hkx : n - 1 ≤ triangleVertexCapacity t x
  · have hsmallx := hX hkx
    have hlowy : triangleVertexCapacity t y ≤ n - 2 := by
      by_contra h
      have hsmally := hY (by omega)
      nlinarith
    have hlowz : triangleVertexCapacity t z ≤ n - 2 := by
      by_contra h
      have hsmallz := hZ (by omega)
      nlinarith
    exact pow_one_high hn hKx hlowy hlowz
  · have hlowx : triangleVertexCapacity t x ≤ n - 2 := by omega
    by_cases hky : n - 1 ≤ triangleVertexCapacity t y
    · have hsmally := hY hky
      have hlowz : triangleVertexCapacity t z ≤ n - 2 := by
        by_contra h
        have hsmallz := hZ (by omega)
        nlinarith
      have h := pow_one_high hn hKy hlowx hlowz
      simpa only [add_comm] using h
    · have hlowy : triangleVertexCapacity t y ≤ n - 2 := by omega
      have h := pow_one_high hn hKz hlowx hlowy
      omega

/-- Throughout n <= t < n+1, at most two exponents can attain n-1.
In particular this gives the upper half-band bound. -/
theorem threeCentre_capacity_high {n : ℕ} {t x y z : ℝ}
    (hn : 2 ≤ n) (ht : (n : ℝ) ≤ t) (ht' : t < n + 1)
    (hx : 0 ≤ x) (hy : 0 ≤ y) (hz : 0 ≤ z) (hsum : x + y + z = 1)
    (hcx : 1 ≤ t * (1 - x)) (hcy : 1 ≤ t * (1 - y)) (hcz : 1 ≤ t * (1 - z)) :
    2 ^ triangleVertexCapacity t x + 2 ^ triangleVertexCapacity t y +
      2 ^ triangleVertexCapacity t z ≤ 2 ^ n + 2 ^ (n - 2) := by
  obtain ⟨hKx, hX⟩ := triangleVertexCapacity_control hn ht ht' hx hcx
  obtain ⟨hKy, hY⟩ := triangleVertexCapacity_control hn ht ht' hy hcy
  obtain ⟨hKz, hZ⟩ := triangleVertexCapacity_control hn ht ht' hz hcz
  have hscaled : t * x + t * y + t * z = t := by
    calc
      _ = t * (x + y + z) := by ring
      _ = t := by rw [hsum, mul_one]
  by_cases hkx : n - 1 ≤ triangleVertexCapacity t x
  · by_cases hky : n - 1 ≤ triangleVertexCapacity t y
    · have hlowz : triangleVertexCapacity t z ≤ n - 2 := by
        by_contra h
        have hsmallx := hX hkx
        have hsmally := hY hky
        have hsmallz := hZ (by omega)
        have hnR : (2 : ℝ) ≤ n := by exact_mod_cast hn
        nlinarith
      exact pow_two_high hn hKx hKy hlowz
    · have hlowy : triangleVertexCapacity t y ≤ n - 2 := by omega
      have h := pow_two_high hn hKx hKz hlowy
      omega
  · have hlowx : triangleVertexCapacity t x ≤ n - 2 := by omega
    have h := pow_two_high hn hKy hKz hlowx
    omega

/-- The two-centre base case has the exact capacity 2^n. -/
theorem twoCentre_capacity {n : ℕ} {t : ℝ} (hn : 1 ≤ n)
    (ht : (n : ℝ) ≤ t) (ht' : t < n + 1) :
    2 ^ sectorCapacity t 1 + 2 ^ sectorCapacity t 1 = 2 ^ n := by
  have hfloor : ⌊t⌋ = (n : ℤ) :=
    Int.floor_eq_iff.mpr ⟨by simpa using ht, by simpa using ht'⟩
  have hcap : sectorCapacity t 1 = n - 1 := by
    unfold sectorCapacity
    rw [mul_one, hfloor]
    omega
  rw [hcap, ← mul_two, ← pow_succ, show n - 1 + 1 = n by omega]

private theorem normalized_complement {t b : ℝ} (ht : 0 < t)
    (hb : b ≤ (1 - 1 / t) * Real.pi) :
    1 ≤ t * (1 - b / Real.pi) := by
  have hdiv : b / Real.pi ≤ 1 - 1 / t := (div_le_iff₀ Real.pi_pos).mpr hb
  have hrecip : 1 / t ≤ 1 - b / Real.pi := by linarith
  have := (div_le_iff₀ ht).mp hrecip
  simpa only [mul_comm] using this

private theorem normalized_angle_sum {A B : Plane} (C : Plane) (hAB : A ≠ B) :
    angle A B C / Real.pi + angle B C A / Real.pi + angle C A B / Real.pi = 1 := by
  rw [← add_div, ← add_div, angle_add_angle_add_angle_eq_pi C hAB.symm,
    div_self Real.pi_ne_zero]

/-- The lower half-band capacity inequality applied to actual Euclidean triangle
angles. This is a three-centre statement, not a reduction of arbitrary centres. -/
theorem threeCentre_capacity_low_of_angles {n : ℕ} {t : ℝ} {A B C : Plane}
    (hn : 2 ≤ n) (ht : (n : ℝ) ≤ t) (ht' : t < n + 1 / 2) (hAB : A ≠ B)
    (hB : angle A B C ≤ (1 - 1 / t) * Real.pi)
    (hC : angle B C A ≤ (1 - 1 / t) * Real.pi)
    (hA : angle C A B ≤ (1 - 1 / t) * Real.pi) :
    2 ^ triangleVertexCapacity t (angle A B C / Real.pi) +
      2 ^ triangleVertexCapacity t (angle B C A / Real.pi) +
      2 ^ triangleVertexCapacity t (angle C A B / Real.pi) ≤ 2 ^ n := by
  have htpos : 0 < t := lt_of_lt_of_le
    (by exact_mod_cast (show 0 < n by omega)) ht
  exact threeCentre_capacity_low hn ht ht'
    (div_nonneg (angle_nonneg A B C) Real.pi_pos.le)
    (div_nonneg (angle_nonneg B C A) Real.pi_pos.le)
    (div_nonneg (angle_nonneg C A B) Real.pi_pos.le)
    (normalized_angle_sum C hAB)
    (normalized_complement htpos hB) (normalized_complement htpos hC)
    (normalized_complement htpos hA)

/-- The upper half-band capacity bound applied to actual Euclidean triangle
angles; the conclusion in fact holds throughout n <= t < n+1. -/
theorem threeCentre_capacity_high_of_angles {n : ℕ} {t : ℝ} {A B C : Plane}
    (hn : 2 ≤ n) (ht : (n : ℝ) ≤ t) (ht' : t < n + 1) (hAB : A ≠ B)
    (hB : angle A B C ≤ (1 - 1 / t) * Real.pi)
    (hC : angle B C A ≤ (1 - 1 / t) * Real.pi)
    (hA : angle C A B ≤ (1 - 1 / t) * Real.pi) :
    2 ^ triangleVertexCapacity t (angle A B C / Real.pi) +
      2 ^ triangleVertexCapacity t (angle B C A / Real.pi) +
      2 ^ triangleVertexCapacity t (angle C A B / Real.pi) ≤
      2 ^ n + 2 ^ (n - 2) := by
  have htpos : 0 < t := lt_of_lt_of_le
    (by exact_mod_cast (show 0 < n by omega)) ht
  exact threeCentre_capacity_high hn ht ht'
    (div_nonneg (angle_nonneg A B C) Real.pi_pos.le)
    (div_nonneg (angle_nonneg B C A) Real.pi_pos.le)
    (div_nonneg (angle_nonneg C A B) Real.pi_pos.le)
    (normalized_angle_sum C hAB)
    (normalized_complement htpos hB) (normalized_complement htpos hC)
    (normalized_complement htpos hA)

/-- Equality in the upper band is attainable in the normalized angle model.
This supplies angle data, not yet a Euclidean cluster realization. -/
theorem threeCentre_capacity_high_attained {n : ℕ} {t : ℝ}
    (hn : 2 ≤ n) (ht : (n : ℝ) + 1 / 2 ≤ t) (ht' : t < n + 1) :
    ∃ x y z : ℝ, 0 < x ∧ 0 < y ∧ 0 < z ∧ x + y + z = 1 ∧
      1 ≤ t * (1 - x) ∧ 1 ≤ t * (1 - y) ∧ 1 ≤ t * (1 - z) ∧
      2 ^ triangleVertexCapacity t x + 2 ^ triangleVertexCapacity t y +
        2 ^ triangleVertexCapacity t z = 2 ^ n + 2 ^ (n - 2) := by
  have hnR : (2 : ℝ) ≤ n := by exact_mod_cast hn
  have htpos : 0 < t := by linarith
  have htne : t ≠ 0 := ne_of_gt htpos
  let x : ℝ := 1 / (2 * t)
  let z : ℝ := 1 - 1 / t
  have hxpos : 0 < x := by dsimp [x]; positivity
  have hzpos : 0 < z := by
    dsimp [z]
    have : 1 / t < 1 := (div_lt_iff₀ htpos).mpr (by linarith)
    linarith
  have htx : t * x = 1 / 2 := by dsimp [x]; field_simp [htne]
  have htz : t * z = t - 1 := by dsimp [z]; field_simp [htne]
  have hcx : t * (1 - x) = t - 1 / 2 := by nlinarith [htx]
  have hcz : t * (1 - z) = 1 := by nlinarith [htz]
  have hsum : x + x + z = 1 := by
    have : t * (x + x + z - 1) = 0 := by nlinarith [htx, htz]
    rcases mul_eq_zero.mp this with h | h
    · exact (htne h).elim
    · linarith
  have hfloorx : ⌊t * x⌋ = (0 : ℤ) := by rw [htx]; norm_num
  have hfloorcx : ⌊t * (1 - x)⌋ = (n : ℤ) := by
    rw [hcx]
    apply Int.floor_eq_iff.mpr
    constructor <;> push_cast <;> linarith
  have hfloorz : ⌊t * z⌋ = (n : ℤ) - 1 := by
    rw [htz]
    apply Int.floor_eq_iff.mpr
    constructor <;> push_cast <;> linarith
  have hfloorcz : ⌊t * (1 - z)⌋ = (1 : ℤ) := by rw [hcz]; norm_num
  have hKx : triangleVertexCapacity t x = n - 1 := by
    unfold triangleVertexCapacity sectorCapacity
    rw [hfloorx, hfloorcx]
    omega
  have hKz : triangleVertexCapacity t z = n - 2 := by
    unfold triangleVertexCapacity sectorCapacity
    rw [hfloorz, hfloorcz]
    omega
  refine ⟨x, x, z, hxpos, hxpos, hzpos, hsum, ?_, ?_, ?_, ?_⟩
  · rw [hcx]; linarith
  · rw [hcx]; linarith
  · rw [hcz]
  · rw [hKx, hKz, ← mul_two, ← pow_succ, show n - 1 + 1 = n by omega]

end Prize.JSP404
