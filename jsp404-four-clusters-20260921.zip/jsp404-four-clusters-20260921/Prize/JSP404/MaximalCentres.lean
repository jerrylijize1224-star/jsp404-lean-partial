import Prize.JSP404.ThreeCentreCapacity

/-!
# Restrictions on maximal exponents for arbitrarily many centres

The geometric theorems here explicitly assume that the full local exponent is
bounded by the exponent obtained after retaining any two other centres. This is
the restriction-to-a-triangle interface; constructing the projective gaps and
proving that interface for Sendov configurations remains separate work.

These are necessary restrictions, not a bound on the total weighted capacity.
-/

namespace Prize.JSP404

open EuclideanGeometry

/-- Two blocks of local gaps with totals x and 1-x give at most the triangle
exponent. This is the arithmetic part of the restriction interface. -/
theorem capacity_le_triangle_of_gap_blocks {ι κ : Type*}
    (s : Finset ι) (r : Finset κ) (d : ι → ℝ) (e : κ → ℝ)
    {t x : ℝ} (ht : 0 ≤ t)
    (hd : ∀ i ∈ s, 0 ≤ d i) (he : ∀ j ∈ r, 0 ≤ e j)
    (hs : ∑ i ∈ s, d i = x) (hr : ∑ j ∈ r, e j = 1 - x) :
    (∑ i ∈ s, sectorCapacity t (d i)) + (∑ j ∈ r, sectorCapacity t (e j)) ≤
      triangleVertexCapacity t x := by
  have h := Nat.add_le_add (sectorCapacity_sum_le s d ht hd)
    (sectorCapacity_sum_le r e ht he)
  simpa [hs, hr, triangleVertexCapacity] using h

/-- A family of positive power-of-two weights whose every triple is at most
2^n has at most one weight as large as 2^(n-1), provided it has three members. -/
theorem maximal_exponents_card_low {ι : Type*} [DecidableEq ι]
    (s : Finset ι) (K : ι → ℕ) {n : ℕ} (hn : 1 ≤ n) (hs : 3 ≤ s.card)
    (htriple : ∀ a ∈ s, ∀ b ∈ s, ∀ c ∈ s,
      a ≠ b → a ≠ c → b ≠ c → 2 ^ K a + 2 ^ K b + 2 ^ K c ≤ 2 ^ n) :
    (s.filter fun a => n - 1 ≤ K a).card ≤ 1 := by
  apply Finset.card_le_one.mpr
  intro a ha b hb
  obtain ⟨ha, hKa⟩ := Finset.mem_filter.mp ha
  obtain ⟨hb, hKb⟩ := Finset.mem_filter.mp hb
  by_contra hab
  have hcard : ({a, b} : Finset ι).card < s.card := by
    simp only [Finset.card_insert_of_notMem (show a ∉ ({b} : Finset ι) by simpa using hab),
      Finset.card_singleton]
    omega
  obtain ⟨c, hc, hcab⟩ := Finset.exists_mem_notMem_of_card_lt_card hcard
  have hca : c ≠ a := by intro h; subst c; simp at hcab
  have hcb : c ≠ b := by intro h; subst c; simp at hcab
  have h := htriple a ha b hb c hc hab hca.symm hcb.symm
  have hpowA : 2 ^ (n - 1) ≤ 2 ^ K a := by gcongr
  have hpowB : 2 ^ (n - 1) ≤ 2 ^ K b := by gcongr
  have hpowC : 0 < (2 : ℕ) ^ K c := by positivity
  have hsplit : (2 : ℕ) ^ n = 2 ^ (n - 1) + 2 ^ (n - 1) := by
    conv_lhs => rw [show n = (n - 1) + 1 by omega, pow_succ]
    omega
  omega

/-- If every triple is bounded by the upper-band capacity, at most two local
exponents can reach n-1. No bound on the number of smaller exponents follows. -/
theorem maximal_exponents_card_high {ι : Type*} [DecidableEq ι]
    (s : Finset ι) (K : ι → ℕ) {n : ℕ} (hn : 2 ≤ n)
    (htriple : ∀ a ∈ s, ∀ b ∈ s, ∀ c ∈ s,
      a ≠ b → a ≠ c → b ≠ c →
      2 ^ K a + 2 ^ K b + 2 ^ K c ≤ 2 ^ n + 2 ^ (n - 2)) :
    (s.filter fun a => n - 1 ≤ K a).card ≤ 2 := by
  by_contra hcard
  obtain ⟨a, b, c, ha, hb, hc, hab, hac, hbc⟩ :=
    Finset.two_lt_card_iff.mp (by omega :
      2 < (s.filter fun a => n - 1 ≤ K a).card)
  obtain ⟨ha, hKa⟩ := Finset.mem_filter.mp ha
  obtain ⟨hb, hKb⟩ := Finset.mem_filter.mp hb
  obtain ⟨hc, hKc⟩ := Finset.mem_filter.mp hc
  have h := htriple a ha b hb c hc hab hac hbc
  have hpowA : 2 ^ (n - 1) ≤ 2 ^ K a := by gcongr
  have hpowB : 2 ^ (n - 1) ≤ 2 ^ K b := by gcongr
  have hpowC : 2 ^ (n - 1) ≤ 2 ^ K c := by gcongr
  have hpos : 0 < (2 : ℕ) ^ (n - 2) := by positivity
  have hprev : (2 : ℕ) ^ (n - 1) = 2 * 2 ^ (n - 2) := by
    rw [show n - 1 = (n - 2) + 1 by omega, pow_succ, mul_comm]
  have hsplit : (2 : ℕ) ^ n = 4 * 2 ^ (n - 2) := by
    conv_lhs => rw [show n = (n - 2) + 2 by omega, pow_add]
    ring
  omega

/-- Lower-band restriction on maximal exponents in a finite Euclidean centre
set, conditional on the explicitly stated triangle-restriction interface. -/
theorem maximal_centres_low {s : Finset Plane} (K : Plane → ℕ) {n : ℕ} {t : ℝ}
    (hn : 2 ≤ n) (ht : (n : ℝ) ≤ t) (ht' : t < n + 1 / 2) (hs : 3 ≤ s.card)
    (hangle : ∀ a ∈ s, ∀ b ∈ s, ∀ c ∈ s,
      a ≠ b → a ≠ c → b ≠ c → angle a b c ≤ (1 - 1 / t) * Real.pi)
    (hrestrict : ∀ a ∈ s, ∀ b ∈ s, ∀ c ∈ s,
      a ≠ b → a ≠ c → b ≠ c →
      K b ≤ triangleVertexCapacity t (angle a b c / Real.pi)) :
    (s.filter fun a => n - 1 ≤ K a).card ≤ 1 := by
  classical
  apply maximal_exponents_card_low s K (by omega) hs
  intro a ha b hb c hc hab hac hbc
  have h := threeCentre_capacity_low_of_angles hn ht ht' hab
    (hangle a ha b hb c hc hab hac hbc)
    (hangle b hb c hc a ha hbc hab.symm hac.symm)
    (hangle c hc a ha b hb hac.symm hbc.symm hab)
  have hA := hrestrict c hc a ha b hb hac.symm hbc.symm hab
  have hB := hrestrict a ha b hb c hc hab hac hbc
  have hC := hrestrict b hb c hc a ha hbc hab.symm hac.symm
  calc
    _ ≤ 2 ^ triangleVertexCapacity t (angle c a b / Real.pi) +
        2 ^ triangleVertexCapacity t (angle a b c / Real.pi) +
        2 ^ triangleVertexCapacity t (angle b c a / Real.pi) := by gcongr
    _ ≤ 2 ^ n := by omega

/-- Upper-band counterpart, valid throughout n <= t < n+1. -/
theorem maximal_centres_high {s : Finset Plane} (K : Plane → ℕ) {n : ℕ} {t : ℝ}
    (hn : 2 ≤ n) (ht : (n : ℝ) ≤ t) (ht' : t < n + 1)
    (hangle : ∀ a ∈ s, ∀ b ∈ s, ∀ c ∈ s,
      a ≠ b → a ≠ c → b ≠ c → angle a b c ≤ (1 - 1 / t) * Real.pi)
    (hrestrict : ∀ a ∈ s, ∀ b ∈ s, ∀ c ∈ s,
      a ≠ b → a ≠ c → b ≠ c →
      K b ≤ triangleVertexCapacity t (angle a b c / Real.pi)) :
    (s.filter fun a => n - 1 ≤ K a).card ≤ 2 := by
  classical
  apply maximal_exponents_card_high s K hn
  intro a ha b hb c hc hab hac hbc
  have h := threeCentre_capacity_high_of_angles hn ht ht' hab
    (hangle a ha b hb c hc hab hac hbc)
    (hangle b hb c hc a ha hbc hab.symm hac.symm)
    (hangle c hc a ha b hb hac.symm hbc.symm hab)
  have hA := hrestrict c hc a ha b hb hac.symm hbc.symm hab
  have hB := hrestrict a ha b hb c hc hab hac hbc
  have hC := hrestrict b hb c hc a ha hbc hab.symm hac.symm
  calc
    _ ≤ 2 ^ triangleVertexCapacity t (angle c a b / Real.pi) +
        2 ^ triangleVertexCapacity t (angle a b c / Real.pi) +
        2 ^ triangleVertexCapacity t (angle b c a / Real.pi) := by gcongr
    _ ≤ 2 ^ n + 2 ^ (n - 2) := by omega

end Prize.JSP404
