import Prize.JSP404.Basic

/-!
# Local capacity under merging angular gaps

Deleting a direction merges its two neighboring angular gaps. The local exponent
cannot decrease. This alone does not show that deleting a centre preserves the
total weighted capacity: see research/jsp404-repair-route.md.
-/

namespace Prize.JSP404

/-- The positive part of floor(t * x) - 1, with angular gaps normalized by pi. -/
noncomputable def sectorCapacity (t x : ℝ) : ℕ := (⌊t * x⌋ - 1).toNat

theorem sectorCapacity_merge {t a b : ℝ}
    (ht : 0 ≤ t) (ha : 0 ≤ a) (hb : 0 ≤ b) :
    sectorCapacity t a + sectorCapacity t b ≤ sectorCapacity t (a + b) := by
  have hfa := Int.floor_nonneg.mpr (mul_nonneg ht ha)
  have hfb := Int.floor_nonneg.mpr (mul_nonneg ht hb)
  have hadd := Int.le_floor_add (t * a) (t * b)
  rw [← mul_add] at hadd
  unfold sectorCapacity
  omega

/-- If both adjacent gaps span at least one unit, merging gains at least one
capacity bit. These local hypotheses still need a geometric existence argument. -/
theorem sectorCapacity_merge_gain {t a b : ℝ}
    (ha : 1 ≤ t * a) (hb : 1 ≤ t * b) :
    sectorCapacity t a + sectorCapacity t b + 1 ≤ sectorCapacity t (a + b) := by
  have hfa : (1 : ℤ) ≤ ⌊t * a⌋ := Int.le_floor.mpr (by simpa using ha)
  have hfb : (1 : ℤ) ≤ ⌊t * b⌋ := Int.le_floor.mpr (by simpa using hb)
  have hadd := Int.le_floor_add (t * a) (t * b)
  rw [← mul_add] at hadd
  unfold sectorCapacity
  omega

/-- Merging any finite collection of nonnegative angular gaps cannot decrease
its total capacity. -/
theorem sectorCapacity_sum_le {ι : Type*} (s : Finset ι) (d : ι → ℝ)
    {t : ℝ} (ht : 0 ≤ t) (hd : ∀ i ∈ s, 0 ≤ d i) :
    ∑ i ∈ s, sectorCapacity t (d i) ≤ sectorCapacity t (∑ i ∈ s, d i) := by
  classical
  induction s using Finset.induction_on with
  | empty => simp [sectorCapacity]
  | @insert i s hi ih =>
    rw [Finset.sum_insert hi, Finset.sum_insert hi]
    have hdi := hd i (Finset.mem_insert_self i s)
    have hds : ∀ j ∈ s, 0 ≤ d j := fun j hj => hd j (Finset.mem_insert_of_mem hj)
    exact (Nat.add_le_add_left (ih hds) _).trans
      (sectorCapacity_merge ht hdi (Finset.sum_nonneg hds))

end Prize.JSP404
