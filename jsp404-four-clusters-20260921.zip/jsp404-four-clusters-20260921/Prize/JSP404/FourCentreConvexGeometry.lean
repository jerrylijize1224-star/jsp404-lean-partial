import Prize.JSP404.FourCentreConvex
import Prize.JSP404.FourCentreInteriorGeometry

/-! Actual quadrilateral geometry for the four-centre capacity bound. -/

namespace Prize.JSP404

open EuclideanGeometry

noncomputable def convexFourCapacity (t : ℝ) (A B C D : Plane) : ℕ :=
  2 ^ splitVertexBits t (scaledAngle t B A C) (scaledAngle t C A D) +
  2 ^ splitVertexBits t (scaledAngle t A B D) (scaledAngle t D B C) +
  2 ^ splitVertexBits t (scaledAngle t B C A) (scaledAngle t A C D) +
  2 ^ splitVertexBits t (scaledAngle t C D B) (scaledAngle t B D A)

/-- A quadrilateral with diagonals meeting strictly inside both segments.
The four stated bounds concern its actual corner angles. -/
structure ConvexFourGeometry (t : ℝ) where
  A : Plane
  B : Plane
  C : Plane
  D : Plane
  O : Plane
  ab_ne : A ≠ B
  bc_ne : B ≠ C
  cd_ne : C ≠ D
  da_ne : D ≠ A
  diagonal_ac : Sbtw ℝ A O C
  diagonal_bd : Sbtw ℝ B O D
  angle_a : angle B A D ≤ (1 - 1 / t) * Real.pi
  angle_b : angle A B C ≤ (1 - 1 / t) * Real.pi
  angle_c : angle B C D ≤ (1 - 1 / t) * Real.pi
  angle_d : angle A D C ≤ (1 - 1 / t) * Real.pi

namespace ConvexFourGeometry

variable {t : ℝ}

noncomputable def angleData (v : ConvexFourGeometry t) (ht : 0 < t) :
    ConvexFourAngleData t := by
  have hA := angle_add_angle_eq_of_sbtw (p := v.A) v.diagonal_bd
  rw [v.diagonal_ac.angle_eq_right v.B, v.diagonal_ac.angle_eq_left v.D] at hA
  have hB := angle_add_angle_eq_of_sbtw (p := v.B) v.diagonal_ac
  rw [v.diagonal_bd.angle_eq_right v.A, v.diagonal_bd.angle_eq_left v.C] at hB
  have hC := angle_add_angle_eq_of_sbtw (p := v.C) v.diagonal_bd
  rw [v.diagonal_ac.symm.angle_eq_right v.B, v.diagonal_ac.symm.angle_eq_left v.D] at hC
  have hD := angle_add_angle_eq_of_sbtw (p := v.D) v.diagonal_ac
  rw [v.diagonal_bd.symm.angle_eq_right v.A, v.diagonal_bd.symm.angle_eq_left v.C,
    angle_comm v.A v.D v.B, angle_comm v.B v.D v.C] at hD
  have hsA : scaledAngle t v.B v.A v.C + scaledAngle t v.C v.A v.D =
      scaledAngle t v.B v.A v.D := by
    simp only [scaledAngle, ← mul_add, ← add_div, hA]
  have hsB : scaledAngle t v.A v.B v.D + scaledAngle t v.D v.B v.C =
      scaledAngle t v.A v.B v.C := by
    simp only [scaledAngle, ← mul_add, ← add_div, hB]
  have hsC : scaledAngle t v.B v.C v.A + scaledAngle t v.A v.C v.D =
      scaledAngle t v.B v.C v.D := by
    simp only [scaledAngle, ← mul_add, ← add_div, hC]
  have hsD : scaledAngle t v.C v.D v.B + scaledAngle t v.B v.D v.A =
      scaledAngle t v.A v.D v.C := by
    have hd' : angle v.C v.D v.B + angle v.B v.D v.A = angle v.A v.D v.C := by
      linarith
    simp only [scaledAngle, ← mul_add, ← add_div, hd']
  have habd := scaledAngle_triangle_sum t v.D v.ab_ne
  have habc := scaledAngle_triangle_sum t v.C v.ab_ne
  have hbcd := scaledAngle_triangle_sum t v.D v.bc_ne
  have hacd := scaledAngle_triangle_sum t v.D v.diagonal_ac.left_ne_right
  have hc1 : scaledAngle t v.A v.C v.B = scaledAngle t v.B v.C v.A := by
    simp only [scaledAngle, angle_comm v.A v.C v.B]
  have hd1 : scaledAngle t v.B v.D v.C = scaledAngle t v.C v.D v.B := by
    simp only [scaledAngle, angle_comm v.B v.D v.C]
  have hd2 : scaledAngle t v.A v.D v.B = scaledAngle t v.B v.D v.A := by
    simp only [scaledAngle, angle_comm v.A v.D v.B]
  have hb2 : scaledAngle t v.C v.B v.D = scaledAngle t v.D v.B v.C := by
    simp only [scaledAngle, angle_comm v.C v.B v.D]
  exact {
    a1 := scaledAngle t v.B v.A v.C
    a2 := scaledAngle t v.C v.A v.D
    b1 := scaledAngle t v.A v.B v.D
    b2 := scaledAngle t v.D v.B v.C
    c1 := scaledAngle t v.B v.C v.A
    c2 := scaledAngle t v.A v.C v.D
    d1 := scaledAngle t v.C v.D v.B
    d2 := scaledAngle t v.B v.D v.A
    a1_nonneg := scaledAngle_nonneg ht.le _ _ _
    a2_nonneg := scaledAngle_nonneg ht.le _ _ _
    b1_nonneg := scaledAngle_nonneg ht.le _ _ _
    b2_nonneg := scaledAngle_nonneg ht.le _ _ _
    c1_nonneg := scaledAngle_nonneg ht.le _ _ _
    c2_nonneg := scaledAngle_nonneg ht.le _ _ _
    d1_nonneg := scaledAngle_nonneg ht.le _ _ _
    d2_nonneg := scaledAngle_nonneg ht.le _ _ _
    total := by linarith
    gap_a := by linarith
    gap_b := by linarith
    gap_c := by linarith
    gap_d := by linarith
    comp_a := by linarith [scaledAngle_le_sub_one ht v.angle_a]
    comp_b := by linarith [scaledAngle_le_sub_one ht v.angle_b]
    comp_c := by linarith [scaledAngle_le_sub_one ht v.angle_c]
    comp_d := by linarith [scaledAngle_le_sub_one ht v.angle_d] }

theorem capacity_low (v : ConvexFourGeometry t) {n : ℕ}
    (hn : 2 ≤ n) (ht : (n : ℝ) ≤ t) (ht' : t < n + 1 / 2) :
    convexFourCapacity t v.A v.B v.C v.D ≤ 2 ^ n := by
  have htpos : 0 < t := by
    have : (2 : ℝ) ≤ n := by exact_mod_cast hn
    linarith
  exact (v.angleData htpos).capacity_low hn ht'

theorem capacity_high (v : ConvexFourGeometry t) {n : ℕ}
    (hn : 2 ≤ n) (ht : (n : ℝ) ≤ t) (ht' : t < n + 1) :
    convexFourCapacity t v.A v.B v.C v.D ≤ 2 ^ n + 2 ^ (n - 2) := by
  have htpos : 0 < t := by
    have : (2 : ℝ) ≤ n := by exact_mod_cast hn
    linarith
  exact (v.angleData htpos).capacity_high hn ht'

end ConvexFourGeometry

end Prize.JSP404
