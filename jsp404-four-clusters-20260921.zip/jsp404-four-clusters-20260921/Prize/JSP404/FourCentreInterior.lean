import Prize.JSP404.ThreeCentreCapacity

/-!
# Four-centre capacity with one interior centre

Angles in this file are scaled by t/pi. We first isolate the floor arithmetic;
geometric realization of the angle data is handled separately.
-/

namespace Prize.JSP404

noncomputable def gapBits (x : ℝ) : ℕ := sectorCapacity 1 x

noncomputable def splitVertexBits (t x y : ℝ) : ℕ :=
  gapBits x + gapBits y + gapBits (t - x - y)

theorem splitVertexBits_comm (t x y : ℝ) :
    splitVertexBits t x y = splitVertexBits t y x := by
  unfold splitVertexBits
  rw [show t - x - y = t - y - x by ring]
  omega

private theorem floor_three_le {n : ℕ} {t x y z : ℝ}
    (ht : t < n + 1) (hs : x + y + z = t) :
    ⌊x⌋ + ⌊y⌋ + ⌊z⌋ ≤ (n : ℤ) := by
  have h := Int.le_floor_add x y
  have h' := Int.le_floor_add (x + y) z
  have hn : ⌊t⌋ ≤ (n : ℤ) := Int.floor_le_iff.mpr (by simpa using ht)
  rw [hs] at h'
  omega

/-- A split vertex obeys the same top-exponent constraint as its unsplit angle. -/
theorem splitVertexBits_control {n : ℕ} {t x y : ℝ}
    (hn : 2 ≤ n) (ht : t < n + 1) (hx : 0 ≤ x) (hy : 0 ≤ y)
    (hg : 1 ≤ t - x - y) :
    splitVertexBits t x y ≤ n - 1 ∧
      (n - 1 ≤ splitVertexBits t x y → x + y ≤ t - n) := by
  have hfx := Int.floor_nonneg.mpr hx
  have hfy := Int.floor_nonneg.mpr hy
  have hfg : (1 : ℤ) ≤ ⌊t - x - y⌋ := Int.le_floor.mpr (by simpa using hg)
  have hsum := floor_three_le ht (show x + y + (t - x - y) = t by ring)
  constructor
  · unfold splitVertexBits gapBits sectorCapacity
    simp only [one_mul]
    omega
  · intro hhigh
    have hfloor : (n : ℤ) ≤ ⌊t - x - y⌋ := by
      unfold splitVertexBits gapBits sectorCapacity at hhigh
      simp only [one_mul] at hhigh
      omega
    have hcast : (n : ℝ) ≤ (⌊t - x - y⌋ : ℝ) := by exact_mod_cast hfloor
    have := Int.floor_le (t - x - y)
    linarith

/-- Three gaps each at least one consume three units of floor budget. -/
theorem three_gapBits_le {n : ℕ} {t x y z : ℝ}
    (hn : 3 ≤ n) (ht : t < n + 1) (hs : x + y + z = t)
    (hx : 1 ≤ x) (hy : 1 ≤ y) (hz : 1 ≤ z) :
    gapBits x + gapBits y + gapBits z ≤ n - 3 := by
  have hfx : (1 : ℤ) ≤ ⌊x⌋ := Int.le_floor.mpr (by simpa using hx)
  have hfy : (1 : ℤ) ≤ ⌊y⌋ := Int.le_floor.mpr (by simpa using hy)
  have hfz : (1 : ℤ) ≤ ⌊z⌋ := Int.le_floor.mpr (by simpa using hz)
  have hsum := floor_three_le ht hs
  unfold gapBits sectorCapacity
  simp only [one_mul]
  omega

/-- A complement below two, together with the interior-point bounds on each
split angle, forces a further drop in exponent. -/
theorem splitVertexBits_le_of_small_complement {n : ℕ} {t x y : ℝ}
    (hn : 3 ≤ n) (ht : t < n + 1) (hx : 0 ≤ x) (hy : 0 ≤ y)
    (hx' : x ≤ t - 2) (hy' : y ≤ t - 2)
    (hg : 1 ≤ t - x - y) (hg' : t - x - y < 2) :
    splitVertexBits t x y ≤ n - 3 := by
  have hfx := Int.floor_nonneg.mpr hx
  have hfy := Int.floor_nonneg.mpr hy
  have hfx' : ⌊x⌋ ≤ (n : ℤ) - 2 := Int.floor_le_iff.mpr (by push_cast; linarith)
  have hfy' : ⌊y⌋ ≤ (n : ℤ) - 2 := Int.floor_le_iff.mpr (by push_cast; linarith)
  have hfg : ⌊t - x - y⌋ = (1 : ℤ) :=
    Int.floor_eq_iff.mpr ⟨by simpa using hg, by norm_num; linarith⟩
  have hsum := floor_three_le ht (show x + y + (t - x - y) = t by ring)
  unfold splitVertexBits gapBits sectorCapacity
  simp only [one_mul]
  omega

/-- The second-largest exponent has a useful dichotomy in a narrow-angle case. -/
theorem splitVertexBits_middle_dichotomy {n : ℕ} {t x y : ℝ}
    (hn : 3 ≤ n) (ht : t < n + 1) (hx : 0 ≤ x) (hy : 0 ≤ y)
    (hg : 1 ≤ t - x - y) (hx' : t - n < x)
    (hmid : n - 2 ≤ splitVertexBits t x y) :
    (n : ℝ) - 1 ≤ t - x - y ∨ y ≤ t - n := by
  have hfx := Int.floor_nonneg.mpr hx
  have hfy := Int.floor_nonneg.mpr hy
  have hfg : (1 : ℤ) ≤ ⌊t - x - y⌋ := Int.le_floor.mpr (by simpa using hg)
  have hsum := floor_three_le ht (show x + y + (t - x - y) = t by ring)
  unfold splitVertexBits gapBits sectorCapacity at hmid
  simp only [one_mul] at hmid
  by_cases hzero : ⌊x⌋ = (0 : ℤ)
  · have hsmall : ⌊y⌋ + ⌊t - x - y⌋ ≤ (n : ℤ) - 1 := by
      have h := Int.le_floor_add y (t - x - y)
      have hb : ⌊y + (t - x - y)⌋ ≤ (n : ℤ) - 1 :=
        Int.floor_le_iff.mpr (by push_cast; linarith)
      omega
    have hf : (n : ℤ) - 1 ≤ ⌊t - x - y⌋ := by omega
    have hcast : (n : ℝ) - 1 ≤ (⌊t - x - y⌋ : ℝ) := by exact_mod_cast hf
    exact Or.inl (hcast.trans (Int.floor_le _))
  · have hf : (n : ℤ) ≤ ⌊x⌋ + ⌊t - x - y⌋ := by omega
    have hcast : (n : ℝ) ≤ (⌊x⌋ : ℝ) + (⌊t - x - y⌋ : ℝ) := by exact_mod_cast hf
    have h₁ := Int.floor_le x
    have h₂ := Int.floor_le (t - x - y)
    right
    linarith

/-- Scaled angular data of a triangle with a fourth point inside it. The three
pair lower bounds come from the three angle bounds at the interior point. -/
structure InteriorAngleData (t : ℝ) where
  a1 : ℝ
  a2 : ℝ
  b1 : ℝ
  b2 : ℝ
  c1 : ℝ
  c2 : ℝ
  a1_nonneg : 0 ≤ a1
  a2_nonneg : 0 ≤ a2
  b1_nonneg : 0 ≤ b1
  b2_nonneg : 0 ≤ b2
  c1_nonneg : 0 ≤ c1
  c2_nonneg : 0 ≤ c2
  total : a1 + a2 + b1 + b2 + c1 + c2 = t
  ab : 1 ≤ a1 + b1
  ac : 1 ≤ a2 + c1
  bc : 1 ≤ b2 + c2
  comp_a : 1 ≤ t - a1 - a2
  comp_b : 1 ≤ t - b1 - b2
  comp_c : 1 ≤ t - c1 - c2

namespace InteriorAngleData

variable {t : ℝ}

noncomputable def KA (v : InteriorAngleData t) := splitVertexBits t v.a1 v.a2
noncomputable def KB (v : InteriorAngleData t) := splitVertexBits t v.b1 v.b2
noncomputable def KC (v : InteriorAngleData t) := splitVertexBits t v.c1 v.c2
noncomputable def KD (v : InteriorAngleData t) :=
  gapBits (v.a1 + v.b1) + gapBits (v.a2 + v.c1) + gapBits (v.b2 + v.c2)

noncomputable def capacity (v : InteriorAngleData t) : ℕ :=
  2 ^ v.KA + 2 ^ v.KB + 2 ^ v.KC + 2 ^ v.KD

def rotate (v : InteriorAngleData t) : InteriorAngleData t where
  a1 := v.b2
  a2 := v.b1
  b1 := v.c2
  b2 := v.c1
  c1 := v.a1
  c2 := v.a2
  a1_nonneg := v.b2_nonneg
  a2_nonneg := v.b1_nonneg
  b1_nonneg := v.c2_nonneg
  b2_nonneg := v.c1_nonneg
  c1_nonneg := v.a1_nonneg
  c2_nonneg := v.a2_nonneg
  total := by linarith [v.total]
  ab := v.bc
  ac := by linarith [v.ab]
  bc := by linarith [v.ac]
  comp_a := by linarith [v.comp_b]
  comp_b := by linarith [v.comp_c]
  comp_c := v.comp_a

private theorem split_comm (t x y : ℝ) : splitVertexBits t x y = splitVertexBits t y x := by
  unfold splitVertexBits
  rw [show t - x - y = t - y - x by ring]
  omega

@[simp] theorem KA_rotate (v : InteriorAngleData t) : v.rotate.KA = v.KB :=
  split_comm t v.b2 v.b1

@[simp] theorem KB_rotate (v : InteriorAngleData t) : v.rotate.KB = v.KC :=
  split_comm t v.c2 v.c1

@[simp] theorem KC_rotate (v : InteriorAngleData t) : v.rotate.KC = v.KA := rfl

@[simp] theorem KD_rotate (v : InteriorAngleData t) : v.rotate.KD = v.KD := by
  simp only [KD, rotate, add_comm v.b1 v.a1, add_comm v.c1 v.a2]
  omega

@[simp] theorem capacity_rotate (v : InteriorAngleData t) : v.rotate.capacity = v.capacity := by
  simp only [capacity, KA_rotate, KB_rotate, KC_rotate, KD_rotate]
  omega

theorem three_le_parameter (v : InteriorAngleData t) : 3 ≤ t := by
  linarith [v.ab, v.ac, v.bc, v.total]

theorem interior_le (v : InteriorAngleData t) {n : ℕ} (hn : 3 ≤ n) (ht : t < n + 1) :
    v.KD ≤ n - 3 :=
  three_gapBits_le hn ht (by linarith [v.total]) v.ab v.ac v.bc

theorem controls (v : InteriorAngleData t) {n : ℕ} (hn : 3 ≤ n) (ht : t < n + 1) :
    (v.KA ≤ n - 1 ∧ (n - 1 ≤ v.KA → v.a1 + v.a2 ≤ t - n)) ∧
    (v.KB ≤ n - 1 ∧ (n - 1 ≤ v.KB → v.b1 + v.b2 ≤ t - n)) ∧
    (v.KC ≤ n - 1 ∧ (n - 1 ≤ v.KC → v.c1 + v.c2 ≤ t - n)) :=
  ⟨splitVertexBits_control (by omega) ht v.a1_nonneg v.a2_nonneg v.comp_a,
   splitVertexBits_control (by omega) ht v.b1_nonneg v.b2_nonneg v.comp_b,
   splitVertexBits_control (by omega) ht v.c1_nonneg v.c2_nonneg v.comp_c⟩

/-- Two top exponents force the remaining outer exponent down by two levels. -/
theorem third_le_of_two_high (v : InteriorAngleData t) {n : ℕ}
    (hn : 3 ≤ n) (ht : t < n + 1) (hA : n - 1 ≤ v.KA) (hB : n - 1 ≤ v.KB) :
    v.KC ≤ n - 3 := by
  obtain ⟨hca, hcb, hcc⟩ := v.controls hn ht
  have hsmallA := hca.2 hA
  have hsmallB := hcb.2 hB
  apply splitVertexBits_le_of_small_complement hn ht v.c1_nonneg v.c2_nonneg
  · linarith [v.total, v.ab, v.bc, v.a2_nonneg]
  · linarith [v.total, v.ab, v.ac, v.b2_nonneg]
  · exact v.comp_c
  · linarith [v.total]

/-- In the lower half-band a top exponent prevents both other outer exponents
from reaching the next level. -/
theorem low_drop (v : InteriorAngleData t) {n : ℕ}
    (hn : 3 ≤ n) (ht : t < n + 1 / 2) (hA : n - 1 ≤ v.KA) :
    v.KB ≤ n - 2 ∧ v.KC ≤ n - 2 ∧ (v.KB ≤ n - 3 ∨ v.KC ≤ n - 3) := by
  have ht1 : t < n + 1 := by linarith
  obtain ⟨hca, hcb, hcc⟩ := v.controls hn ht1
  have hsmallA := hca.2 hA
  have hB : v.KB ≤ n - 2 := by
    by_contra h
    have := hcb.2 (by omega)
    linarith [v.comp_c, v.total]
  have hC : v.KC ≤ n - 2 := by
    by_contra h
    have := hcc.2 (by omega)
    linarith [v.comp_b, v.total]
  refine ⟨hB, hC, ?_⟩
  by_contra h
  have hmidB : n - 2 ≤ v.KB := by omega
  have hmidC : n - 2 ≤ v.KC := by omega
  have hb1 : t - n < v.b1 := by linarith [v.ab, v.a2_nonneg]
  have hc1 : t - n < v.c1 := by linarith [v.ac, v.a1_nonneg]
  have hdb := splitVertexBits_middle_dichotomy hn ht1 v.b1_nonneg v.b2_nonneg
    v.comp_b hb1 hmidB
  have hdc := splitVertexBits_middle_dichotomy hn ht1 v.c1_nonneg v.c2_nonneg
    v.comp_c hc1 hmidC
  rcases hdb with hgb | hsb
  · have hClow : v.KC ≤ n - 3 := by
      apply splitVertexBits_le_of_small_complement hn ht1 v.c1_nonneg v.c2_nonneg
      · linarith [v.total, v.ab, v.bc, v.a2_nonneg]
      · linarith [v.total, v.ab, v.ac, v.b2_nonneg]
      · exact v.comp_c
      · linarith [v.total]
    omega
  · rcases hdc with hgc | hsc
    · have hBlow : v.KB ≤ n - 3 := by
        apply splitVertexBits_le_of_small_complement hn ht1 v.b1_nonneg v.b2_nonneg
        · linarith [v.total, v.ac, v.bc, v.a1_nonneg]
        · linarith [v.total, v.ab, v.ac, v.c2_nonneg]
        · exact v.comp_b
        · linarith [v.total]
      omega
    · linarith [v.bc]

theorem pow_low_pattern {n a b c d : ℕ} (hn : 3 ≤ n)
    (ha : a ≤ n - 1) (hb : b ≤ n - 2) (hc : c ≤ n - 3) (hd : d ≤ n - 3) :
    2 ^ a + 2 ^ b + 2 ^ c + 2 ^ d ≤ 2 ^ n := by
  calc
    _ ≤ 2 ^ (n - 1) + 2 ^ (n - 2) + 2 ^ (n - 3) + 2 ^ (n - 3) := by gcongr
    _ = 2 ^ n := by
      have h1 : n - 1 = (n - 3) + 2 := by omega
      have h2 : n - 2 = (n - 3) + 1 := by omega
      have h3 : n = (n - 3) + 3 := by omega
      conv_rhs => rw [h3, pow_add]
      rw [h1, h2, pow_add, pow_succ]
      ring

theorem pow_four_mid {n a b c d : ℕ} (hn : 2 ≤ n)
    (ha : a ≤ n - 2) (hb : b ≤ n - 2) (hc : c ≤ n - 2) (hd : d ≤ n - 2) :
    2 ^ a + 2 ^ b + 2 ^ c + 2 ^ d ≤ 2 ^ n := by
  calc
    _ ≤ 2 ^ (n - 2) + 2 ^ (n - 2) + 2 ^ (n - 2) + 2 ^ (n - 2) := by gcongr
    _ = 2 ^ n := by
      conv_rhs => rw [show n = (n - 2) + 2 by omega, pow_add]
      ring

theorem pow_one_high {n a b c d : ℕ} (hn : 2 ≤ n)
    (ha : a ≤ n - 1) (hb : b ≤ n - 2) (hc : c ≤ n - 2) (hd : d ≤ n - 2) :
    2 ^ a + 2 ^ b + 2 ^ c + 2 ^ d ≤ 2 ^ n + 2 ^ (n - 2) := by
  calc
    _ ≤ 2 ^ (n - 1) + 2 ^ (n - 2) + 2 ^ (n - 2) + 2 ^ (n - 2) := by gcongr
    _ = 2 ^ n + 2 ^ (n - 2) := by
      conv_rhs => lhs; rw [show n = (n - 2) + 2 by omega, pow_add]
      rw [show n - 1 = (n - 2) + 1 by omega, pow_succ]
      ring

private theorem pow_two_high {n a b c d : ℕ} (hn : 3 ≤ n)
    (ha : a ≤ n - 1) (hb : b ≤ n - 1) (hc : c ≤ n - 3) (hd : d ≤ n - 3) :
    2 ^ a + 2 ^ b + 2 ^ c + 2 ^ d ≤ 2 ^ n + 2 ^ (n - 2) := by
  calc
    _ ≤ 2 ^ (n - 1) + 2 ^ (n - 1) + 2 ^ (n - 3) + 2 ^ (n - 3) := by gcongr
    _ = 2 ^ n + 2 ^ (n - 2) := by
      conv_rhs => lhs; rw [show n = (n - 3) + 3 by omega, pow_add]
      rw [show n - 1 = (n - 3) + 2 by omega, show n - 2 = (n - 3) + 1 by omega,
        pow_add, pow_succ]
      ring

private theorem capacity_low_of_A_high (v : InteriorAngleData t) {n : ℕ}
    (hn : 3 ≤ n) (ht : t < n + 1 / 2) (hA : n - 1 ≤ v.KA) :
    v.capacity ≤ 2 ^ n := by
  have ht1 : t < n + 1 := by linarith
  obtain ⟨hca, _, _⟩ := v.controls hn ht1
  have hD := v.interior_le hn ht1
  obtain ⟨hB, hC, hdrop⟩ := v.low_drop hn ht hA
  rcases hdrop with hB' | hC'
  · have := pow_low_pattern hn hca.1 hC hB' hD
    unfold capacity
    omega
  · exact pow_low_pattern hn hca.1 hB hC' hD

/-- The lower half-band capacity bound for an interior-centre angle model. -/
theorem capacity_low (v : InteriorAngleData t) {n : ℕ}
    (hn : 3 ≤ n) (ht : t < n + 1 / 2) : v.capacity ≤ 2 ^ n := by
  by_cases hA : n - 1 ≤ v.KA
  · exact v.capacity_low_of_A_high hn ht hA
  by_cases hB : n - 1 ≤ v.KB
  · simpa using v.rotate.capacity_low_of_A_high hn ht (by simpa using hB)
  by_cases hC : n - 1 ≤ v.KC
  · simpa using v.rotate.rotate.capacity_low_of_A_high hn ht (by simpa using hC)
  have hD := v.interior_le hn (show t < n + 1 by linarith)
  exact pow_four_mid (by omega) (by omega) (by omega) (by omega) (by omega)

/-- The upper half-band capacity bound; it holds throughout t < n+1 for this
angle model, including its lower half-band. -/
theorem capacity_high (v : InteriorAngleData t) {n : ℕ}
    (hn : 3 ≤ n) (ht : t < n + 1) : v.capacity ≤ 2 ^ n + 2 ^ (n - 2) := by
  obtain ⟨hca, hcb, hcc⟩ := v.controls hn ht
  have hD := v.interior_le hn ht
  by_cases hA : n - 1 ≤ v.KA
  · by_cases hB : n - 1 ≤ v.KB
    · exact pow_two_high hn hca.1 hcb.1 (v.third_le_of_two_high hn ht hA hB) hD
    · by_cases hC : n - 1 ≤ v.KC
      · have hBlow : v.KB ≤ n - 3 := by
          simpa using v.rotate.rotate.third_le_of_two_high hn ht
            (by simpa using hC) (by simpa using hA)
        have := pow_two_high hn hca.1 hcc.1 hBlow hD
        unfold capacity
        omega
      · exact pow_one_high (by omega) hca.1 (by omega) (by omega) (by omega)
  · by_cases hB : n - 1 ≤ v.KB
    · by_cases hC : n - 1 ≤ v.KC
      · have hAlow : v.KA ≤ n - 3 := by
          simpa using v.rotate.third_le_of_two_high hn ht
            (by simpa using hB) (by simpa using hC)
        have := pow_two_high hn hcb.1 hcc.1 hAlow hD
        unfold capacity
        omega
      · have := pow_one_high (by omega) hcb.1
          (show v.KA ≤ n - 2 by omega) (show v.KC ≤ n - 2 by omega)
          (show v.KD ≤ n - 2 by omega)
        unfold capacity
        omega
    · have := pow_one_high (by omega) hcc.1
        (show v.KA ≤ n - 2 by omega) (show v.KB ≤ n - 2 by omega)
        (show v.KD ≤ n - 2 by omega)
      unfold capacity
      omega

end InteriorAngleData

end Prize.JSP404
