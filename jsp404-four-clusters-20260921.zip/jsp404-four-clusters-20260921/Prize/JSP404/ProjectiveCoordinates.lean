import Prize.JSP404.ProjectiveThreeDirections
import Mathlib.Analysis.SpecialFunctions.Complex.Arg

/-! Explicit projective coordinates of nonzero actual plane vectors.
No compactness or generalized-point configuration is assumed. -/

namespace Prize.JSP404

theorem unitDirection_add_pi (θ : ℝ) :
    unitDirection (θ + Real.pi) = -unitDirection θ := by
  ext i
  fin_cases i <;> simp [unitDirection, Real.cos_add_pi, Real.sin_add_pi]

/-- Every nonzero plane vector has a positive length and a ray choice on a
line represented by an angle in the half-open interval [0, pi). -/
theorem exists_projective_coordinates {U : Plane} (hU : U ≠ 0) :
    ∃ θ r : ℝ, ∃ b : Bool, 0 ≤ θ ∧ θ < Real.pi ∧ 0 < r ∧
      U = r • signedDirection θ b := by
  let z : ℂ := (U 0 : ℂ) + (U 1 : ℂ) * Complex.I
  have hz : z ≠ 0 := by
    intro h
    apply hU
    ext i
    fin_cases i
    · have he := congrArg Complex.re h
      simpa [z] using he
    · have he := congrArg Complex.im h
      simpa [z] using he
  have hr : 0 < ‖z‖ := norm_pos_iff.mpr hz
  have hp : U = ‖z‖ • unitDirection z.arg := by
    ext i
    fin_cases i
    · have he := Complex.norm_mul_cos_arg z
      simpa [unitDirection, z] using he.symm
    · have he := Complex.norm_mul_sin_arg z
      simpa [unitDirection, z] using he.symm
  by_cases hneg : z.arg < 0
  · refine ⟨z.arg + Real.pi, ‖z‖, true, ?_, ?_, hr, ?_⟩
    · linarith [Complex.neg_pi_lt_arg z]
    · linarith
    · simpa [signedDirection, unitDirection_add_pi] using hp
  · by_cases hpi : z.arg = Real.pi
    · refine ⟨0, ‖z‖, true, le_rfl, Real.pi_pos, hr, ?_⟩
      rw [hpi, show Real.pi = 0 + Real.pi by ring, unitDirection_add_pi] at hp
      simpa [signedDirection] using hp
    · exact ⟨z.arg, ‖z‖, false, le_of_not_gt hneg,
        lt_of_le_of_ne (Complex.arg_le_pi z) hpi, hr, by simpa [signedDirection] using hp⟩

/-- A common angular origin is allowed; only the differences enter the three
cyclic gaps. All three signed vectors are actual Euclidean plane vectors. -/
theorem vectorThreeRayIndex_signed_interval {t θ φ ψ : ℝ} (ht : 0 < t)
    (hθφ : θ < φ) (hφψ : φ < ψ) (hwidth : ψ - θ < Real.pi) (a b c : Bool) :
    vectorThreeRayIndex t (signedDirection θ a) (signedDirection φ b) (signedDirection ψ c) =
      gapBits (t * ((φ - θ) / Real.pi)) + gapBits (t * ((ψ - φ) / Real.pi)) +
        gapBits (t * ((Real.pi - (ψ - θ)) / Real.pi)) := by
  unfold vectorThreeRayIndex
  rw [InnerProductGeometry.angle_comm (signedDirection ψ c) (signedDirection θ a)]
  rw [signedDirection_angle hθφ.le (by linarith) a b,
    signedDirection_angle hφψ.le (by linarith) b c,
    signedDirection_angle (hθφ.trans hφψ).le hwidth.le a c]
  simp only [scaled_signedPairAngle]
  have hsym : signedPairAngle t (t * ((ψ - θ) / Real.pi)) a c =
      signedPairAngle t (t * ((ψ - θ) / Real.pi)) c a := by
    simp only [signedPairAngle, eq_comm]
  rw [hsym, show t * ((ψ - φ) / Real.pi) =
    t * ((ψ - θ) / Real.pi) - t * ((φ - θ) / Real.pi) by ring]
  rw [threeRayIndex_sorted_signed
    (mul_pos ht (div_pos (sub_pos.mpr hθφ) Real.pi_pos))
    (mul_lt_mul_of_pos_left ((div_lt_div_iff_of_pos_right Real.pi_pos).mpr (by linarith)) ht)
    (show t * ((ψ - θ) / Real.pi) < t by
      have h := mul_lt_mul_of_pos_left ((div_lt_one Real.pi_pos).mpr hwidth) ht
      simpa using h)]
  rw [show t * ((ψ - θ) / Real.pi) - t * ((φ - θ) / Real.pi) =
      t * ((ψ - φ) / Real.pi) by ring,
    show t - t * ((ψ - θ) / Real.pi) = t * ((Real.pi - (ψ - θ)) / Real.pi) by
      field_simp [Real.pi_ne_zero]]

theorem vectorThreeRayIndex_pos_smul (t : ℝ) (U V W : Plane) {r s q : ℝ}
    (hr : 0 < r) (hs : 0 < s) (hq : 0 < q) :
    vectorThreeRayIndex t (r • U) (s • V) (q • W) = vectorThreeRayIndex t U V W := by
  simp [vectorThreeRayIndex, InnerProductGeometry.angle_smul_left_of_pos,
    InnerProductGeometry.angle_smul_right_of_pos, hr, hs, hq]

/-- The gap formula holds for arbitrary positive lengths on the sorted lines. -/
theorem vectorThreeRayIndex_projective_coordinates {t θ φ ψ r s q : ℝ}
    (ht : 0 < t) (hθφ : θ < φ) (hφψ : φ < ψ) (hwidth : ψ - θ < Real.pi)
    (hr : 0 < r) (hs : 0 < s) (hq : 0 < q) (a b c : Bool) :
    vectorThreeRayIndex t (r • signedDirection θ a) (s • signedDirection φ b)
      (q • signedDirection ψ c) =
      gapBits (t * ((φ - θ) / Real.pi)) + gapBits (t * ((ψ - φ) / Real.pi)) +
        gapBits (t * ((Real.pi - (ψ - θ)) / Real.pi)) := by
  rw [vectorThreeRayIndex_pos_smul t _ _ _ hr hs hq]
  exact vectorThreeRayIndex_signed_interval ht hθφ hφψ hwidth a b c

end Prize.JSP404
