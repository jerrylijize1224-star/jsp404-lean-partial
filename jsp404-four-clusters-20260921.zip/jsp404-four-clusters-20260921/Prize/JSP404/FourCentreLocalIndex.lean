import Prize.JSP404.FourCentreConvexGeometry

/-! A symmetric algebraic local index for three rays. Its equality to the
case-specific capacities is proved here; interpreting it as sorted projective
direction gaps remains a separate task. -/

namespace Prize.JSP404

open EuclideanGeometry

/-- Symmetric in the three pairwise angles. The inside-triangle branch is
distinguished by the sum of pairwise angles being a full turn. -/
noncomputable def threeRayIndex (t x y z : ℝ) : ℕ :=
  if x + y + z = 2 * t then
    gapBits (t - x) + gapBits (t - y) + gapBits (t - z)
  else
    gapBits x + gapBits y + gapBits z - gapBits (max x (max y z)) +
      gapBits (t - max x (max y z))

theorem threeRayIndex_swap (t x y z : ℝ) :
    threeRayIndex t y x z = threeRayIndex t x y z := by
  simp [threeRayIndex, add_comm, add_left_comm, add_assoc, max_left_comm]

theorem threeRayIndex_reverse (t x y z : ℝ) :
    threeRayIndex t z y x = threeRayIndex t x y z := by
  simp [threeRayIndex, add_comm, add_left_comm, add_assoc, max_comm, max_left_comm]

theorem threeRayIndex_swap_last (t x y z : ℝ) :
    threeRayIndex t x z y = threeRayIndex t x y z := by
  simp [threeRayIndex, add_comm, add_left_comm, add_assoc, max_comm]

theorem threeRayIndex_rotate (t x y z : ℝ) :
    threeRayIndex t y z x = threeRayIndex t x y z := by
  rw [threeRayIndex_swap_last, threeRayIndex_swap]

theorem threeRayIndex_of_split {t x y : ℝ} (hx : 0 ≤ x) (hy : 0 ≤ y)
    (hxy : x + y < t) :
    threeRayIndex t x y (x + y) = splitVertexBits t x y := by
  have hs : x + y + (x + y) ≠ 2 * t := by linarith
  have hm : max x (max y (x + y)) = x + y := by
    rw [max_eq_right (by linarith : y ≤ x + y), max_eq_right (by linarith : x ≤ x + y)]
  simp only [threeRayIndex, ite_eq_right hs, hm, Nat.add_sub_cancel, splitVertexBits]
  congr 1
  congr 1
  ring

theorem threeRayIndex_of_full_turn {t x y z : ℝ} (hs : x + y + z = 2 * t) :
    threeRayIndex t x y z =
      gapBits (t - x) + gapBits (t - y) + gapBits (t - z) := by
  simp [threeRayIndex, hs]

noncomputable def fourCentreLocalIndex (t : ℝ) (A B C D : Plane) : ℕ :=
  threeRayIndex t (scaledAngle t B A C) (scaledAngle t C A D) (scaledAngle t D A B)

theorem scaledAngle_comm (t : ℝ) (A B C : Plane) :
    scaledAngle t A B C = scaledAngle t C B A := by
  simp [scaledAngle, angle_comm]

/-- Swapping two of the other centres does not change the local index. -/
theorem fourCentreLocalIndex_swap (t : ℝ) (A B C D : Plane) :
    fourCentreLocalIndex t A C B D = fourCentreLocalIndex t A B C D := by
  unfold fourCentreLocalIndex
  rw [scaledAngle_comm t C A B, scaledAngle_comm t B A D, scaledAngle_comm t D A C]
  exact threeRayIndex_swap_last _ _ _ _

theorem fourCentreLocalIndex_rotate (t : ℝ) (A B C D : Plane) :
    fourCentreLocalIndex t A C D B = fourCentreLocalIndex t A B C D := by
  exact threeRayIndex_rotate _ _ _ _

/-- At an exterior vertex, the same symmetric expression recovers the
split-angle formula, without an arbitrary choice of which split comes first. -/
theorem fourCentreLocalIndex_of_split {t : ℝ} (ht : 0 < t) {A B C D : Plane}
    (hs : angle B A C = angle B A D + angle D A C)
    (hc : angle B A C ≤ (1 - 1 / t) * Real.pi) :
    fourCentreLocalIndex t A B C D =
      splitVertexBits t (scaledAngle t B A D) (scaledAngle t D A C) := by
  have hx := scaledAngle_nonneg ht.le B A D
  have hy := scaledAngle_nonneg ht.le D A C
  have he : scaledAngle t B A C = scaledAngle t B A D + scaledAngle t D A C := by
    simp only [scaledAngle, hs, add_div, mul_add]
  have hlt : scaledAngle t B A D + scaledAngle t D A C < t := by
    have h := scaledAngle_le_sub_one ht hc
    rw [he] at h
    linarith
  unfold fourCentreLocalIndex
  rw [show scaledAngle t C A D = scaledAngle t D A C by simp [scaledAngle, angle_comm],
    show scaledAngle t D A B = scaledAngle t B A D by simp [scaledAngle, angle_comm], he,
    threeRayIndex_reverse]
  exact threeRayIndex_of_split hx hy hlt

theorem fourCentreLocalIndex_swap_last (t : ℝ) (A B C D : Plane) :
    fourCentreLocalIndex t A B D C = fourCentreLocalIndex t A B C D := by
  unfold fourCentreLocalIndex
  rw [scaledAngle_comm t B A D, scaledAngle_comm t D A C, scaledAngle_comm t C A B]
  exact threeRayIndex_reverse _ _ _ _

noncomputable def labelledFourCapacity (t : ℝ) (A B C D : Plane) : ℕ :=
  2 ^ fourCentreLocalIndex t A B C D +
  2 ^ fourCentreLocalIndex t B A C D +
  2 ^ fourCentreLocalIndex t C A B D +
  2 ^ fourCentreLocalIndex t D A B C

theorem InteriorFourGeometry.localIndex_at_interior {t : ℝ}
    (v : InteriorFourGeometry t) (ht : 0 < t) :
    fourCentreLocalIndex t v.D v.A v.B v.C =
      gapBits (scaledAngle t v.B v.A v.D + scaledAngle t v.A v.B v.D) +
      gapBits (scaledAngle t v.D v.A v.C + scaledAngle t v.A v.C v.D) +
      gapBits (scaledAngle t v.D v.B v.C + scaledAngle t v.D v.C v.B) := by
  have hab := scaledAngle_triangle_sum t v.D v.ab_ne
  have hac := scaledAngle_triangle_sum t v.D v.ac_ne
  have hbc := scaledAngle_triangle_sum t v.D v.bc_ne
  rw [scaledAngle_comm t v.C v.A v.D] at hac
  rw [scaledAngle_comm t v.C v.B v.D, scaledAngle_comm t v.B v.C v.D] at hbc
  have hs := (v.angleData ht).total
  change scaledAngle t v.B v.A v.D + scaledAngle t v.D v.A v.C +
    scaledAngle t v.A v.B v.D + scaledAngle t v.D v.B v.C +
    scaledAngle t v.A v.C v.D + scaledAngle t v.D v.C v.B = t at hs
  unfold fourCentreLocalIndex
  rw [scaledAngle_comm t v.C v.D v.A]
  rw [threeRayIndex_of_full_turn (by linarith :
    scaledAngle t v.A v.D v.B + scaledAngle t v.B v.D v.C +
      scaledAngle t v.A v.D v.C = 2 * t)]
  rw [show t - scaledAngle t v.A v.D v.B =
      scaledAngle t v.B v.A v.D + scaledAngle t v.A v.B v.D by linarith,
    show t - scaledAngle t v.B v.D v.C =
      scaledAngle t v.D v.B v.C + scaledAngle t v.D v.C v.B by linarith,
    show t - scaledAngle t v.A v.D v.C =
      scaledAngle t v.D v.A v.C + scaledAngle t v.A v.C v.D by linarith]
  omega

theorem InteriorFourGeometry.labelled_capacity_eq {t : ℝ}
    (v : InteriorFourGeometry t) (ht : 0 < t) :
    labelledFourCapacity t v.A v.B v.C v.D = interiorFourCapacity t v.A v.B v.C v.D := by
  have hA := fourCentreLocalIndex_of_split ht
    (angle_split_of_barycentric v.b_nonneg v.c_nonneg v.weights_sum v.barycentric v.da_ne)
    v.angle_a
  have hBsplit : angle v.A v.B v.C = angle v.A v.B v.D + angle v.D v.B v.C :=
    angle_split_of_barycentric (a := v.b) v.a_nonneg v.c_nonneg (by linarith [v.weights_sum])
      (by rw [v.barycentric]; module) v.db_ne
  have hCsplit : angle v.A v.C v.B = angle v.A v.C v.D + angle v.D v.C v.B :=
    angle_split_of_barycentric (a := v.c) v.a_nonneg v.b_nonneg (by linarith [v.weights_sum])
      (by rw [v.barycentric]; module) v.dc_ne
  have hB := fourCentreLocalIndex_of_split ht hBsplit v.angle_b
  have hC := fourCentreLocalIndex_of_split ht hCsplit v.angle_c
  unfold labelledFourCapacity interiorFourCapacity
  rw [hA, hB, hC, v.localIndex_at_interior ht]

theorem ConvexFourGeometry.labelled_capacity_eq {t : ℝ}
    (v : ConvexFourGeometry t) (ht : 0 < t) :
    labelledFourCapacity t v.A v.B v.C v.D = convexFourCapacity t v.A v.B v.C v.D := by
  have hsA := angle_add_angle_eq_of_sbtw (p := v.A) v.diagonal_bd
  rw [v.diagonal_ac.angle_eq_right v.B, v.diagonal_ac.angle_eq_left v.D] at hsA
  have hsB := angle_add_angle_eq_of_sbtw (p := v.B) v.diagonal_ac
  rw [v.diagonal_bd.angle_eq_right v.A, v.diagonal_bd.angle_eq_left v.C] at hsB
  have hsC := angle_add_angle_eq_of_sbtw (p := v.C) v.diagonal_bd
  rw [v.diagonal_ac.symm.angle_eq_right v.B, v.diagonal_ac.symm.angle_eq_left v.D] at hsC
  have hsD := angle_add_angle_eq_of_sbtw (p := v.D) v.diagonal_ac
  rw [v.diagonal_bd.symm.angle_eq_right v.A, v.diagonal_bd.symm.angle_eq_left v.C] at hsD
  have hA := fourCentreLocalIndex_of_split ht hsA.symm v.angle_a
  rw [fourCentreLocalIndex_swap_last] at hA
  have hB := fourCentreLocalIndex_of_split ht hsB.symm v.angle_b
  have hC := fourCentreLocalIndex_of_split ht hsC.symm v.angle_c
  rw [fourCentreLocalIndex_rotate t v.C v.A v.B v.D] at hC
  have hD := fourCentreLocalIndex_of_split ht hsD.symm v.angle_d
  rw [fourCentreLocalIndex_swap_last t v.D v.A v.B v.C,
    scaledAngle_comm t v.A v.D v.B, scaledAngle_comm t v.B v.D v.C,
    splitVertexBits_comm] at hD
  unfold labelledFourCapacity convexFourCapacity
  rw [hA, hB, hC, hD]

/-- The common four-centre expression is unchanged by adjacent transpositions
of its four labels. These transpositions generate all label permutations. -/
theorem labelledFourCapacity_swap_first (t : ℝ) (A B C D : Plane) :
    labelledFourCapacity t B A C D = labelledFourCapacity t A B C D := by
  unfold labelledFourCapacity
  rw [fourCentreLocalIndex_swap t C A B D, fourCentreLocalIndex_swap t D A B C]
  omega

theorem labelledFourCapacity_swap_middle (t : ℝ) (A B C D : Plane) :
    labelledFourCapacity t A C B D = labelledFourCapacity t A B C D := by
  unfold labelledFourCapacity
  rw [fourCentreLocalIndex_swap t A B C D, fourCentreLocalIndex_swap_last t D A B C]
  omega

theorem labelledFourCapacity_swap_last (t : ℝ) (A B C D : Plane) :
    labelledFourCapacity t A B D C = labelledFourCapacity t A B C D := by
  unfold labelledFourCapacity
  rw [fourCentreLocalIndex_swap_last t A B C D, fourCentreLocalIndex_swap_last t B A C D]
  omega

end Prize.JSP404
