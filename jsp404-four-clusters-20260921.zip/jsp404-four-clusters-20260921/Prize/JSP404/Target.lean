import Prize.JSP404.Basic

/-!
# Specification of Sendov's answer (not a proof)

Source: B. Sendov, Compulsory configurations of points in the plane,
Fundamental and Applied Mathematics 1:2 (1995), 491–516, Theorem 4.4, p. 514.
https://www.mathnet.ru/eng/fpm81

The two bands below start at k = 2, so natural subtraction in k - 2 is exact.
The cases N = 3 and N = 4 are stated separately. `IsSharpBound` includes
counterexamples to every strictly larger bound, without requiring an extremizer.
-/

namespace Prize.JSP404

/-- Full target only. This proposition has not been proved in this project. -/
def SendovClaim : Prop :=
  IsSharpBound 3 (Real.pi / 3) ∧
  IsSharpBound 4 (Real.pi / 2) ∧
  ∀ k : ℕ, 2 ≤ k → ∀ N : ℕ,
    (2 ^ k < N → N ≤ 2 ^ k + 2 ^ (k - 2) →
      IsSharpBound N ((1 - 2 / (2 * (k : ℝ) + 1)) * Real.pi)) ∧
    (2 ^ k + 2 ^ (k - 2) < N → N ≤ 2 ^ (k + 1) →
      IsSharpBound N ((1 - 1 / ((k : ℝ) + 1)) * Real.pi))

end Prize.JSP404
