import Prize.JSP404.Basic
import Prize.JSP404.Counting

/-!
# Geometric application of binary counting

An ordinary point configuration with maximum angle at most a has at most 2^k
points if its unoriented differences are covered by k sets of vectors, each
having pairwise angular spread strictly less than pi - a.

This is the ordinary-configuration interface for the sector argument in Sendov's
Lemma 4.6. It does not supply the sector cover or treat generalized directions.
-/

namespace Prize.JSP404

open EuclideanGeometry

theorem card_le_two_pow_of_direction_cover {s : Finset Plane} {k : ℕ} {a : ℝ}
    (ha : 0 ≤ a) (C : Fin k → Set Plane)
    (hcover : ∀ u ∈ s, ∀ v ∈ s, u ≠ v →
      ∃ i, v - u ∈ C i ∨ u - v ∈ C i)
    (hthin : ∀ i, ∀ p ∈ C i, ∀ q ∈ C i,
      InnerProductGeometry.angle p q < Real.pi - a)
    (hbound : ∀ u ∈ s, ∀ v ∈ s, ∀ w ∈ s,
      u ≠ v → u ≠ w → v ≠ w → angle u v w ≤ a) :
    s.card ≤ 2 ^ k := by
  classical
  let R : Fin k → s → s → Prop := fun i u v => u ≠ v ∧ (v : Plane) - u ∈ C i
  have hRcover : ∀ u v : s, u ≠ v → ∃ i, R i u v ∨ R i v u := by
    intro u v huv
    have hne : (u : Plane) ≠ v := fun h => huv (Subtype.ext h)
    obtain ⟨i, hi⟩ := hcover u u.property v v.property hne
    refine ⟨i, ?_⟩
    rcases hi with hi | hi
    · exact Or.inl ⟨huv, hi⟩
    · exact Or.inr ⟨huv.symm, hi⟩
  have hstep : ∀ i u v w, R i u v → R i v w → False := by
    intro i u v w huv hvw
    have hne : (u : Plane) ≠ v := fun h => huv.1 (Subtype.ext h)
    have hsmall := hthin i _ huv.2 _ hvw.2
    have hlarge : a < angle (u : Plane) v w := by
      change a < InnerProductGeometry.angle ((u : Plane) - v) ((w : Plane) - v)
      rw [show (u : Plane) - v = -((v : Plane) - u) by abel,
        InnerProductGeometry.angle_neg_left]
      linarith
    by_cases huw : u = w
    · subst w
      rw [angle_self_of_ne hne] at hlarge
      linarith
    · have hneuw : (u : Plane) ≠ w := fun h => huw (Subtype.ext h)
      have hnevw : (v : Plane) ≠ w := fun h => hvw.1 (Subtype.ext h)
      exact (not_lt_of_ge (hbound u u.property v v.property w w.property hne hneuw hnevw))
        hlarge
  simpa using card_le_two_pow_of_no_two_step_cover R hRcover hstep

end Prize.JSP404
