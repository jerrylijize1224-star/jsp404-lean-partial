import Prize.JSP404.Basic
import Mathlib.Analysis.Convex.Radon

/-! Four-point geometry, independently of the generalized-configuration count. -/

namespace Prize.JSP404

open EuclideanGeometry
open scoped RealInnerProductSpace

private theorem positive_mix {a b x y : ℝ}
    (ha : 0 ≤ a) (hb : 0 ≤ b) (hab : a + b = 1) (hx : 0 < x) (hy : 0 < y) :
    0 < a * x + b * y := by
  by_cases h : a = 0
  · subst a
    have : b = 1 := by linarith
    simpa [this] using hy
  · exact add_pos_of_pos_of_nonneg (mul_pos (lt_of_le_of_ne ha (Ne.symm h)) hx)
      (mul_nonneg hb hy.le)

/-- Intersecting opposite segments force a nonacute angle among their endpoints.
This inner-product form also holds in higher-dimensional ambient spaces. -/
private theorem crossing_segments_not_all_acute {A B C D : Plane}
    {a b c d : ℝ} (ha : 0 ≤ a) (hb : 0 ≤ b) (hc : 0 ≤ c) (hd : 0 ≤ d)
    (hab : a + b = 1) (hcd : c + d = 1)
    (heq : a • A + b • B = c • C + d • D)
    (hA : 0 < ⟪C - A, D - A⟫) (hB : 0 < ⟪C - B, D - B⟫)
    (hC : 0 < ⟪A - C, B - C⟫) (hD : 0 < ⟪A - D, B - D⟫) : False := by
  have hp := positive_mix ha hb hab hA hB
  have hq := positive_mix hc hd hcd hC hD
  have he := congrArg (fun v : Plane => ⟪A + B - C - D, v⟫) heq
  have hb' : b = 1 - a := by linarith
  have hd' : d = 1 - c := by linarith
  simp only [hb', hd'] at he hp hq
  simp only [inner_add_left, inner_add_right, inner_sub_left, inner_sub_right,
    real_inner_smul_right] at he hp hq
  simp only [real_inner_comm B A, real_inner_comm C A, real_inner_comm D A,
    real_inner_comm C B, real_inner_comm D B, real_inner_comm D C] at he hp hq
  nlinarith

private theorem acute_not_mem_hull {ι : Type*} (p : ι → Plane)
    (hinj : Function.Injective p)
    (hacute : ∀ i j k, i ≠ j → i ≠ k → j ≠ k →
      0 < ⟪p i - p j, p k - p j⟫)
    (i : ι) (I : Set ι) (hi : i ∉ I) :
    p i ∉ convexHull ℝ (p '' I) := by
  intro hmem
  have hne : (p '' I).Nonempty := convexHull_nonempty_iff.mp ⟨p i, hmem⟩
  obtain ⟨j, hj⟩ := Set.image_nonempty.mp hne
  have hji : j ≠ i := by intro h; subst j; exact hi hj
  let v := p j - p i
  have hv : v ≠ 0 := sub_ne_zero.mpr (fun h => hji (hinj h))
  have hconv : Convex ℝ {x : Plane | ⟪v, p i⟫ < ⟪v, x⟫} :=
    convex_halfSpace_gt
      (show IsLinearMap ℝ (fun x : Plane => ⟪v, x⟫) from
        ⟨fun x y => inner_add_right v x y, fun r x => real_inner_smul_right v x r⟩) _
  have hsub : p '' I ⊆ {x : Plane | ⟪v, p i⟫ < ⟪v, x⟫} := by
    rintro x ⟨k, hk, rfl⟩
    have hki : k ≠ i := by intro h; subst k; exact hi hk
    have hpos : 0 < ⟪v, p k - p i⟫ := by
      by_cases hjk : j = k
      · subst k
        exact real_inner_self_pos.mpr hv
      · exact hacute j i k hji hjk hki.symm
    simpa only [Set.mem_ofPred_eq, inner_sub_right, sub_pos] using hpos
  have := (convexHull_min hsub hconv) hmem
  change ⟪v, p i⟫ < ⟪v, p i⟫ at this
  exact (lt_irrefl _) this

private theorem four_not_all_acute (p : Fin 4 → Plane) (hinj : Function.Injective p)
    (hacute : ∀ i j k, i ≠ j → i ≠ k → j ≠ k →
      0 < ⟪p i - p j, p k - p j⟫) : False := by
  classical
  have hdep : ¬ AffineIndependent ℝ p := by
    intro h
    have hcard := h.card_le_finrank_succ
    have hdim := Submodule.finrank_le (vectorSpan ℝ (Set.range p))
    have hplane : Module.finrank ℝ Plane = 2 := by simp [Plane]
    rw [hplane] at hdim
    simp only [Fintype.card_fin] at hcard
    omega
  obtain ⟨I, o, ho, ho'⟩ := Convex.radon_partition hdep
  have hside : ∀ (J : Set (Fin 4)),
      o ∈ convexHull ℝ (p '' J) → o ∈ convexHull ℝ (p '' Jᶜ) →
      2 ≤ J.toFinset.card := by
    intro J hJ hJc
    by_contra hcard
    have hsmall : J.toFinset.card ≤ 1 := by omega
    have hnonempty : J.Nonempty := Set.image_nonempty.mp
      (convexHull_nonempty_iff.mp ⟨o, hJ⟩)
    obtain ⟨i, hi⟩ := hnonempty
    have hsub : p '' J ⊆ {p i} := by
      rintro x ⟨j, hj, rfl⟩
      have hji : j = i := Finset.card_le_one.mp hsmall j
        (by simpa using hj) i (by simpa using hi)
      simp [hji]
    have hoi : o = p i := by
      exact (convexHull_min hsub (convex_singleton (p i))) hJ
    rw [hoi] at hJc
    exact acute_not_mem_hull p hinj hacute i Jᶜ (by simpa) hJc
  have hI := hside I ho ho'
  have hIc := hside Iᶜ ho' (by simpa using ho)
  rw [Set.toFinset_compl, Finset.card_compl] at hIc
  simp only [Fintype.card_fin] at hIc
  have hcard : I.toFinset.card = 2 := by omega
  have hcardc : Iᶜ.toFinset.card = 2 := by
    rw [Set.toFinset_compl, Finset.card_compl, hcard]
    decide
  obtain ⟨a, b, hab, hpair⟩ := Finset.card_eq_two.mp hcard
  obtain ⟨c, d, hcd, hpairc⟩ := Finset.card_eq_two.mp hcardc
  have hIpair : I = {a, b} := by
    have := congrArg (fun s : Finset (Fin 4) => (s : Set (Fin 4))) hpair
    simpa using this
  have hIcpair : Iᶜ = {c, d} := by
    have := congrArg (fun s : Finset (Fin 4) => (s : Set (Fin 4))) hpairc
    simpa using this
  have hcross : ∀ i ∈ I, ∀ j ∈ Iᶜ, i ≠ j := by
    intro i hi j hj hij
    subst j
    exact hj hi
  have hac := hcross a (by simp [hIpair]) c (by simp [hIcpair])
  have had := hcross a (by simp [hIpair]) d (by simp [hIcpair])
  have hbc := hcross b (by simp [hIpair]) c (by simp [hIcpair])
  have hbd := hcross b (by simp [hIpair]) d (by simp [hIcpair])
  rw [hIpair, Set.image_pair, convexHull_pair] at ho
  rw [hIcpair, Set.image_pair, convexHull_pair] at ho'
  obtain ⟨u, v, hu, hv, huv, heq⟩ := ho
  obtain ⟨w, z, hw, hz, hwz, heq'⟩ := ho'
  exact crossing_segments_not_all_acute hu hv hw hz huv hwz (heq.trans heq'.symm)
    (hacute c a d hac.symm hcd had) (hacute c b d hbc.symm hcd hbd)
    (hacute a c b hac hab hbc.symm) (hacute a d b had hab hbd.symm)

/-- Every four-point plane configuration contains a right or obtuse angle. -/
theorem hasLargeAngle_pi_div_two {s : Finset Plane} (hs : 4 ≤ s.card) :
    HasLargeAngle s (Real.pi / 2) := by
  classical
  obtain ⟨r, hrs, hr⟩ := Finset.exists_subset_card_eq hs
  let e : Fin 4 ≃ r := (Finset.equivFinOfCardEq hr).symm
  let p : Fin 4 → Plane := fun i => (e i : Plane)
  have hinj : Function.Injective p := Subtype.coe_injective.comp e.injective
  by_contra h
  apply four_not_all_acute p hinj
  intro i j k hij hik hjk
  apply lt_of_not_ge
  intro hinner
  apply h
  refine ⟨p i, hrs (e i).property, p j, hrs (e j).property, p k, hrs (e k).property,
    (fun he => hij (hinj he)), (fun he => hik (hinj he)),
    (fun he => hjk (hinj he)), ?_⟩
  exact InnerProductGeometry.inner_nonpos_iff_pi_div_two_le_angle.mp hinner

theorem guaranteedAngle_pi_div_two {n : ℕ} (hn : 4 ≤ n) :
    GuaranteedAngle n (Real.pi / 2) := by
  intro s hs
  exact hasLargeAngle_pi_div_two (hs ▸ hn)

private noncomputable def squareVertex : Fin 4 → Plane :=
  ![!₂[0, 0], !₂[1, 0], !₂[1, 1], !₂[0, 1]]

private theorem squareVertex_injective : Function.Injective squareVertex := by
  intro i j h
  have h0 := congrArg (fun v : Plane => v 0) h
  have h1 := congrArg (fun v : Plane => v 1) h
  fin_cases i <;> fin_cases j <;> norm_num [squareVertex] at *

private noncomputable def squareSet : Finset Plane := Finset.univ.image squareVertex

private theorem squareSet_card : squareSet.card = 4 := by
  rw [squareSet, Finset.card_image_of_injective _ squareVertex_injective]
  simp

private theorem squareSet_angle {x y z : Plane}
    (hx : x ∈ squareSet) (hy : y ∈ squareSet) (hz : z ∈ squareSet) :
    angle x y z ≤ Real.pi / 2 := by
  obtain ⟨i, _, rfl⟩ := Finset.mem_image.mp hx
  obtain ⟨j, _, rfl⟩ := Finset.mem_image.mp hy
  obtain ⟨k, _, rfl⟩ := Finset.mem_image.mp hz
  have hinner : 0 ≤ ⟪squareVertex i - squareVertex j, squareVertex k - squareVertex j⟫ := by
    fin_cases i <;> fin_cases j <;> fin_cases k <;>
      norm_num [squareVertex, PiLp.inner_apply, Fin.sum_univ_two]
  apply le_of_not_gt
  intro hangle
  exact (not_lt_of_ge hinner)
    (InnerProductGeometry.inner_neg_iff_pi_div_two_lt_angle.mpr hangle)

theorem fourPoints_sharp : IsSharpBound 4 (Real.pi / 2) := by
  refine ⟨by positivity, by linarith [Real.pi_pos],
    guaranteedAngle_pi_div_two (by omega), ?_⟩
  intro b hb h
  obtain ⟨x, hx, y, hy, z, hz, _, _, _, hangle⟩ := h squareSet squareSet_card
  have := squareSet_angle hx hy hz
  linarith

theorem alpha_four : alpha 4 = Real.pi / 2 := fourPoints_sharp.alpha_eq

end Prize.JSP404
