import Prize.JSP404.SectorCapacity

/-!
# Strictly narrow covers of the allowed part of a gap

After excluding a unit interval at each end of a normalized direction gap of
length z, its remaining closed interval has a cover by floor(z)-1 intervals
of width strictly less than one. Boundary points and integral z are included.
Turning these real intervals into sectors of generalized directions is a
separate geometric step.
-/

namespace Prize.JSP404

theorem exists_narrow_interval_cover {l r w : ℝ} {k : ℕ}
    (hlr : l ≤ r) (hk : 0 < k) (hwidth : r - l < k * w) :
    ∃ C : Fin k → Set ℝ,
      (∀ x ∈ Set.Icc l r, ∃ i, x ∈ C i) ∧
      (∀ i, ∀ x ∈ C i, ∀ y ∈ C i, |x - y| < w) := by
  have hkR : (0 : ℝ) < k := by exact_mod_cast hk
  have hdiv : ((r - l) / k) * k = r - l := div_mul_cancel₀ _ (ne_of_gt hkR)
  let d : ℝ := ((r - l) / k + w) / 2
  have hdpos : 0 < d := by dsimp [d]; nlinarith
  have hdlt : d < w := by dsimp [d]; nlinarith
  have hspan : r - l < k * d := by dsimp [d]; nlinarith
  refine ⟨fun i => Set.Icc (l + i.val * d) (l + (i.val + 1) * d), ?_, ?_⟩
  · intro x hx
    have hnonneg : 0 ≤ (x - l) / d := div_nonneg (sub_nonneg.mpr hx.1) hdpos.le
    have hlt : (x - l) / d < k := (div_lt_iff₀ hdpos).mpr (by nlinarith [hx.2])
    have hi : ⌊(x - l) / d⌋₊ < k := (Nat.floor_lt hnonneg).mpr hlt
    refine ⟨⟨⌊(x - l) / d⌋₊, hi⟩, ?_, ?_⟩
    · have h := (le_div_iff₀ hdpos).mp (Nat.floor_le hnonneg)
      dsimp
      linarith
    · have h := (div_lt_iff₀ hdpos).mp (Nat.lt_floor_add_one ((x - l) / d))
      dsimp
      linarith
  · intro i x hx y hy
    apply abs_lt.mpr
    constructor <;> dsimp at hx hy ⊢ <;> nlinarith [hx.1, hx.2, hy.1, hy.2]

theorem exists_gap_interval_cover (z : ℝ) :
    ∃ C : Fin (sectorCapacity 1 z) → Set ℝ,
      (∀ x ∈ Set.Icc 1 (z - 1), ∃ i, x ∈ C i) ∧
      (∀ i, ∀ x ∈ C i, ∀ y ∈ C i, |x - y| < 1) := by
  by_cases hz : 2 ≤ z
  · have hfloor : (2 : ℤ) ≤ ⌊z⌋ := Int.le_floor.mpr (by simpa using hz)
    have hk : 0 < sectorCapacity 1 z := by unfold sectorCapacity; simp only [one_mul]; omega
    have hcast : (sectorCapacity 1 z : ℤ) = ⌊z⌋ - 1 := by
      unfold sectorCapacity
      simp only [one_mul]
      omega
    have hcastR : (sectorCapacity 1 z : ℝ) = (⌊z⌋ : ℝ) - 1 := by exact_mod_cast hcast
    apply exists_narrow_interval_cover (by linarith) hk
    have h := Int.lt_floor_add_one z
    rw [hcastR]
    linarith
  · refine ⟨fun _ => ∅, ?_, ?_⟩
    · intro x hx
      exfalso
      linarith [hx.1, hx.2]
    · intro i x hx
      exact False.elim hx

end Prize.JSP404
