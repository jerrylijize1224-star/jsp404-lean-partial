import Prize.JSP404.ThreeGapAllowed

/-!
# Four occupied clusters with actual centres

This model records only the one-level direction laws needed for counting.
It is not a theorem reducing arbitrary ordinary configurations to four clusters.
-/

namespace Prize.JSP404

structure FourClusterModel (V : Type*) where
  directions : GeneralizedDirections V
  cluster : V → Fin 4
  occupied : Function.Surjective cluster
  centre : Fin 4 → Plane
  distinct : Function.Injective centre
  cross : ∀ u v, cluster u ≠ cluster v →
    directions.direction u v = centre (cluster v) - centre (cluster u)

namespace FourClusterModel

variable {V : Type*} (M : FourClusterModel V)

noncomputable def centres : Finset Plane := Finset.univ.image M.centre

theorem centre_mem (i : Fin 4) : M.centre i ∈ M.centres := by
  classical
  exact Finset.mem_image.mpr ⟨i, Finset.mem_univ i, rfl⟩

theorem centres_card : M.centres.card = 4 := by
  classical
  simp [centres, Finset.card_image_of_injective _ M.distinct]

theorem centres_angle_bound {a : ℝ} (hbound : M.directions.AngleBound a) :
    ∀ A ∈ M.centres, ∀ B ∈ M.centres, ∀ C ∈ M.centres,
      A ≠ B → A ≠ C → B ≠ C → EuclideanGeometry.angle A B C ≤ a := by
  classical
  intro A hA B hB C hC hAB hAC hBC
  obtain ⟨i, _, rfl⟩ := Finset.mem_image.mp hA
  obtain ⟨j, _, rfl⟩ := Finset.mem_image.mp hB
  obtain ⟨k, _, rfl⟩ := Finset.mem_image.mp hC
  have hij : i ≠ j := fun h => hAB (congrArg M.centre h)
  have hik : i ≠ k := fun h => hAC (congrArg M.centre h)
  have hjk : j ≠ k := fun h => hBC (congrArg M.centre h)
  obtain ⟨u, hu⟩ := M.occupied i
  obtain ⟨v, hv⟩ := M.occupied j
  obtain ⟨w, hw⟩ := M.occupied k
  have huv : M.cluster u ≠ M.cluster v := by rwa [hu, hv]
  have huw : M.cluster u ≠ M.cluster w := by rwa [hu, hw]
  have hvw : M.cluster v ≠ M.cluster w := by rwa [hv, hw]
  have h := hbound u v w (fun h => huv (congrArg M.cluster h))
    (fun h => huw (congrArg M.cluster h)) (fun h => hvw (congrArg M.cluster h))
  change InnerProductGeometry.angle (M.directions.direction v u)
    (M.directions.direction v w) ≤ a at h
  rw [M.cross v u huv.symm, M.cross v w hvw, hu, hv, hw] at h
  exact h

theorem centres_generalPosition {t : ℝ} (ht : 0 < t)
    (hbound : M.directions.AngleBound ((1 - 1 / t) * Real.pi)) :
    GeneralPosition M.centres := by
  apply generalPosition_of_angle_bound ?_ (M.centres_angle_bound hbound)
  have h : 0 < Real.pi / t := div_pos Real.pi_pos ht
  have he : (1 - 1 / t) * Real.pi = Real.pi - Real.pi / t := by ring
  rw [he]
  linarith

theorem cluster_card_le_localIndex [Fintype V] {t : ℝ} (ht : 1 ≤ t)
    (hbound : M.directions.AngleBound ((1 - 1 / t) * Real.pi))
    (a b c d : Fin 4) (hab : a ≠ b) (hac : a ≠ c) (had : a ≠ d)
    (hbc : b ≠ c) (hbd : b ≠ d) (hcd : c ≠ d) :
    Fintype.card {u : V // M.cluster u = a} ≤
      2 ^ fourCentreLocalIndex t (M.centre a) (M.centre b) (M.centre c) (M.centre d) := by
  classical
  have htpos : 0 < t := by linarith
  obtain ⟨v⟩ := exists_pointDirectionChart (M.centres_generalPosition htpos hbound)
    (M.centre_mem a) (M.centre_mem b) (M.centre_mem c) (M.centre_mem d)
    (M.distinct.ne hab) (M.distinct.ne hac) (M.distinct.ne had)
    (M.distinct.ne hbc) (M.distinct.ne hbd) (M.distinct.ne hcd)
  let j : Fin 3 → Fin 4 := ![b, c, d]
  have hj : ∀ i, j i ≠ a := by
    intro i
    fin_cases i <;> simp [j, hab.symm, hac.symm, had.symm]
  have hp : pointDirectionTriple (M.centre a) (M.centre b) (M.centre c) (M.centre d) =
      (fun i => M.centre (j i) - M.centre a) := by
    funext i
    fin_cases i <;> rfl
  rw [hp] at v
  have hw : 0 < Real.pi / t := div_pos Real.pi_pos htpos
  have hwπ : Real.pi / t ≤ Real.pi := (div_le_iff₀ htpos).mpr (by nlinarith [Real.pi_pos])
  have he : (1 - 1 / t) * Real.pi = Real.pi - Real.pi / t := by ring
  have hcount := M.directions.cluster_card_le_gap_capacity M.cluster M.centre
    M.occupied M.cross a j hj v hw hwπ (he ▸ hbound)
  have hgap (i : Fin 3) : v.gap i / (Real.pi / t) = t * (v.gap i / Real.pi) := by
    field_simp
  have hexp : (∑ i, sectorCapacity 1 (v.gap i / (Real.pi / t))) = v.gapIndex t := by
    rw [v.gapIndex_eq_sectorCapacity]
    simp only [sectorCapacity, one_mul, hgap]
  have hindex := v.index_eq_gapIndex htpos
  change fourCentreLocalIndex t (M.centre a) (M.centre b) (M.centre c) (M.centre d) =
    v.gapIndex t at hindex
  rwa [hexp, ← hindex] at hcount

theorem centres_eq : M.centres = {M.centre 0, M.centre 1, M.centre 2, M.centre 3} := by
  classical
  unfold centres
  rw [show (Finset.univ : Finset (Fin 4)) = {0, 1, 2, 3} by decide]
  simp

/-- Actual leaf cardinality is bounded by the previously established
four-centre capacity; no sector or coordinate-cover premise remains. -/
theorem card_le_capacity [Fintype V] {t : ℝ} (ht : 1 ≤ t)
    (hbound : M.directions.AngleBound ((1 - 1 / t) * Real.pi)) :
    Fintype.card V ≤ fourCentreCapacity t M.centres := by
  classical
  have hcard : Fintype.card V = ∑ i : Fin 4, Fintype.card {u : V // M.cluster u = i} := by
    have h := Finset.card_eq_sum_card_fiberwise
      (s := (Finset.univ : Finset V)) (t := (Finset.univ : Finset (Fin 4)))
      (f := M.cluster) (by intro u hu; exact Finset.mem_univ _)
    simpa only [Fintype.card_subtype, Finset.card_univ] using h
  rw [M.centres_eq, fourCentreCapacity_eq_labelled t
    (M.distinct.ne (by decide : (0 : Fin 4) ≠ 1))
    (M.distinct.ne (by decide : (0 : Fin 4) ≠ 2))
    (M.distinct.ne (by decide : (0 : Fin 4) ≠ 3))
    (M.distinct.ne (by decide : (1 : Fin 4) ≠ 2))
    (M.distinct.ne (by decide : (1 : Fin 4) ≠ 3))
    (M.distinct.ne (by decide : (2 : Fin 4) ≠ 3))]
  rw [hcard, Fin.sum_univ_four]
  unfold labelledFourCapacity
  have h0 := M.cluster_card_le_localIndex ht hbound 0 1 2 3
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
  have h1 := M.cluster_card_le_localIndex ht hbound 1 0 2 3
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
  have h2 := M.cluster_card_le_localIndex ht hbound 2 0 1 3
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
  have h3 := M.cluster_card_le_localIndex ht hbound 3 0 1 2
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
  omega

theorem card_low [Fintype V] {n : ℕ} (hn : 2 ≤ n) {t : ℝ} (ht : (n : ℝ) ≤ t)
    (ht' : t < n + 1 / 2)
    (hbound : M.directions.AngleBound ((1 - 1 / t) * Real.pi)) :
    Fintype.card V ≤ 2 ^ n := by
  have ht1 : 1 ≤ t := by
    have : (2 : ℝ) ≤ n := by exact_mod_cast hn
    linarith
  exact (M.card_le_capacity ht1 hbound).trans
    (fourCentreCapacity_low M.centres_card hn ht ht' (M.centres_angle_bound hbound))

theorem card_high [Fintype V] {n : ℕ} (hn : 2 ≤ n) {t : ℝ} (ht : (n : ℝ) ≤ t)
    (ht' : t < n + 1)
    (hbound : M.directions.AngleBound ((1 - 1 / t) * Real.pi)) :
    Fintype.card V ≤ 2 ^ n + 2 ^ (n - 2) := by
  have ht1 : 1 ≤ t := by
    have : (2 : ℝ) ≤ n := by exact_mod_cast hn
    linarith
  exact (M.card_le_capacity ht1 hbound).trans
    (fourCentreCapacity_high M.centres_card hn ht ht' (M.centres_angle_bound hbound))

end FourClusterModel
end Prize.JSP404
