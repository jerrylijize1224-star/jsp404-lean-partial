import Prize.JSP404.ThreeDirectionChart
import Prize.JSP404.FourCentreCapacity

/-! The four-centre angle expression is the sum of capacities of actual
cyclic projective gaps. The separate point-cluster cardinality link is not
assumed or proved in this module. -/

namespace Prize.JSP404

namespace SortedThreeDirectionChart

variable {p : Fin 3 → Plane}

noncomputable def gap (v : SortedThreeDirectionChart p) : Fin 3 → ℝ :=
  ![v.theta 1 - v.theta 0, v.theta 2 - v.theta 1,
    Real.pi - (v.theta 2 - v.theta 0)]

theorem gap_pos (v : SortedThreeDirectionChart p) (i : Fin 3) : 0 < v.gap i := by
  have h01 := v.sorted (by decide : (0 : Fin 3) < 1)
  have h12 := v.sorted (by decide : (1 : Fin 3) < 2)
  have h0 := v.nonneg 0
  have h2 := v.lt_pi 2
  fin_cases i <;> dsimp [gap] <;> linarith

theorem gap_sum (v : SortedThreeDirectionChart p) : ∑ i, v.gap i = Real.pi := by
  simp [gap, Fin.sum_univ_succ]
  ring

noncomputable def gapIndex (v : SortedThreeDirectionChart p) (t : ℝ) : ℕ :=
  ∑ i, gapBits (t * (v.gap i / Real.pi))

theorem normalized_gap_sum (v : SortedThreeDirectionChart p) :
    ∑ i, v.gap i / Real.pi = 1 := by
  rw [← Finset.sum_div, v.gap_sum, div_self Real.pi_ne_zero]

/-- The same floor-capacity function already used in the source comparison,
evaluated on normalized cyclic gaps whose sum is one. -/
theorem gapIndex_eq_sectorCapacity (v : SortedThreeDirectionChart p) (t : ℝ) :
    v.gapIndex t = ∑ i, sectorCapacity t (v.gap i / Real.pi) := by
  simp [gapIndex, gapBits, sectorCapacity]

theorem index_eq_gapIndex (v : SortedThreeDirectionChart p) {t : ℝ} (ht : 0 < t) :
    vectorThreeRayIndex t (p 0) (p 1) (p 2) = v.gapIndex t := by
  rw [v.index_eq_gaps ht]
  simp [gapIndex, gap, Fin.sum_univ_succ, add_assoc]

end SortedThreeDirectionChart

/-- The four charts used in the capacity identity all exist for a genuine
general-position configuration; they are not unproved additional assumptions. -/
theorem exists_four_direction_charts {s : Finset Plane} (hg : GeneralPosition s)
    {A B C D : Plane} (hA : A ∈ s) (hB : B ∈ s) (hC : C ∈ s) (hD : D ∈ s)
    (hAB : A ≠ B) (hAC : A ≠ C) (hAD : A ≠ D)
    (hBC : B ≠ C) (hBD : B ≠ D) (hCD : C ≠ D) :
    Nonempty (SortedThreeDirectionChart (pointDirectionTriple A B C D)) ∧
    Nonempty (SortedThreeDirectionChart (pointDirectionTriple B A C D)) ∧
    Nonempty (SortedThreeDirectionChart (pointDirectionTriple C A B D)) ∧
    Nonempty (SortedThreeDirectionChart (pointDirectionTriple D A B C)) := by
  exact ⟨exists_pointDirectionChart hg hA hB hC hD hAB hAC hAD hBC hBD hCD,
    exists_pointDirectionChart hg hB hA hC hD hAB.symm hBC hBD hAC hAD hCD,
    exists_pointDirectionChart hg hC hA hB hD hAC.symm hBC.symm hCD hAB hAD hBD,
    exists_pointDirectionChart hg hD hA hB hC hAD.symm hBD.symm hCD.symm hAB hAC hBC⟩

theorem pointDirectionChart_localIndex_eq_gapIndex {A B C D : Plane}
    (v : SortedThreeDirectionChart (pointDirectionTriple A B C D))
    {t : ℝ} (ht : 0 < t) : fourCentreLocalIndex t A B C D = v.gapIndex t := by
  rw [fourCentreLocalIndex_eq_vectorIndex]
  exact v.index_eq_gapIndex ht

/-- All choices of sorted ray representatives give the same cyclic-gap
index, because they agree with the same actual-vector expression. -/
theorem projective_gapIndex_independent {p : Fin 3 → Plane}
    (v w : SortedThreeDirectionChart p) {t : ℝ} (ht : 0 < t) :
    v.gapIndex t = w.gapIndex t :=
  (v.index_eq_gapIndex ht).symm.trans (w.index_eq_gapIndex ht)

theorem fourCentreCapacity_eq_projectiveGaps {t : ℝ} (ht : 0 < t)
    {A B C D : Plane} (hAB : A ≠ B) (hAC : A ≠ C) (hAD : A ≠ D)
    (hBC : B ≠ C) (hBD : B ≠ D) (hCD : C ≠ D)
    (vA : SortedThreeDirectionChart (pointDirectionTriple A B C D))
    (vB : SortedThreeDirectionChart (pointDirectionTriple B A C D))
    (vC : SortedThreeDirectionChart (pointDirectionTriple C A B D))
    (vD : SortedThreeDirectionChart (pointDirectionTriple D A B C)) :
    fourCentreCapacity t {A, B, C, D} =
      2 ^ vA.gapIndex t + 2 ^ vB.gapIndex t + 2 ^ vC.gapIndex t + 2 ^ vD.gapIndex t := by
  rw [fourCentreCapacity_eq_labelled t hAB hAC hAD hBC hBD hCD]
  unfold labelledFourCapacity
  rw [pointDirectionChart_localIndex_eq_gapIndex vA ht,
    pointDirectionChart_localIndex_eq_gapIndex vB ht,
    pointDirectionChart_localIndex_eq_gapIndex vC ht,
    pointDirectionChart_localIndex_eq_gapIndex vD ht]

end Prize.JSP404
