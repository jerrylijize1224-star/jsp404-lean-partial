import Prize.JSP404.FourCentreClassification
import Prize.JSP404.FourCentreLocalIndex

/-! A label-independent four-centre angle expression and its bounds.
No identification with generalized point-cluster cardinality is assumed. -/

namespace Prize.JSP404

open EuclideanGeometry

/-- Sum over ordered distinct triples at each centre, divided by six to remove
their multiplicity. For a four-point set, each centre has exactly six such
triples and their local indices agree. This definition uses only the point set.
Its interpretation as projective direction-gap capacity is not asserted here. -/
noncomputable def fourCentreCapacity (t : ℝ) (s : Finset Plane) : ℕ := by
  classical
  exact (∑ A ∈ s, ∑ B ∈ s.erase A, ∑ C ∈ (s.erase A).erase B,
    ∑ D ∈ ((s.erase A).erase B).erase C, 2 ^ fourCentreLocalIndex t A B C D) / 6

theorem fourCentreCapacity_eq_labelled (t : ℝ) {A B C D : Plane}
    (hAB : A ≠ B) (hAC : A ≠ C) (hAD : A ≠ D)
    (hBC : B ≠ C) (hBD : B ≠ D) (hCD : C ≠ D) :
    fourCentreCapacity t {A, B, C, D} = labelledFourCapacity t A B C D := by
  classical
  simp [fourCentreCapacity, labelledFourCapacity, Finset.erase_insert_of_ne,
    hAB, hAC, hAD, hBC, hBD, hCD,
    fourCentreLocalIndex_swap, fourCentreLocalIndex_rotate, fourCentreLocalIndex_swap_last]
  omega

theorem InteriorFourGeometry.set_capacity_eq {s : Finset Plane} {t : ℝ}
    (v : InteriorFourGeometry t) (ht : 0 < t)
    (hs : (s : Set Plane) = {v.A, v.B, v.C, v.D}) :
    fourCentreCapacity t s = interiorFourCapacity t v.A v.B v.C v.D := by
  have he : s = {v.A, v.B, v.C, v.D} := by
    apply Finset.coe_injective
    simpa using hs
  rw [he, fourCentreCapacity_eq_labelled t v.ab_ne v.ac_ne v.da_ne.symm
    v.bc_ne v.db_ne.symm v.dc_ne.symm, v.labelled_capacity_eq ht]

theorem ConvexFourGeometry.set_capacity_eq {s : Finset Plane} {t : ℝ}
    (v : ConvexFourGeometry t) (ht : 0 < t)
    (hs : (s : Set Plane) = {v.A, v.B, v.C, v.D}) :
    fourCentreCapacity t s = convexFourCapacity t v.A v.B v.C v.D := by
  have he : s = {v.A, v.B, v.C, v.D} := by
    apply Finset.coe_injective
    simpa using hs
  rw [he, fourCentreCapacity_eq_labelled t v.ab_ne v.diagonal_ac.left_ne_right
    v.da_ne.symm v.bc_ne v.diagonal_bd.left_ne_right v.cd_ne, v.labelled_capacity_eq ht]

/-- An unconditional bound for this explicitly defined four-centre angle
expression, with no convexity or general-position hypothesis. -/
theorem fourCentreCapacity_low {s : Finset Plane} (hs : s.card = 4)
    {n : ℕ} (hn : 2 ≤ n) {t : ℝ} (ht : (n : ℝ) ≤ t) (ht' : t < n + 1 / 2)
    (ha : ∀ A ∈ s, ∀ B ∈ s, ∀ C ∈ s, A ≠ B → A ≠ C → B ≠ C →
      angle A B C ≤ (1 - 1 / t) * Real.pi) :
    fourCentreCapacity t s ≤ 2 ^ n := by
  have htpos : 0 < t := by
    have : (2 : ℝ) ≤ n := by exact_mod_cast hn
    linarith
  rcases four_centre_geometry_cases_of_angle_bound hs htpos ha with ⟨v, hv⟩ | ⟨v, hv⟩
  · rw [v.set_capacity_eq htpos hv]
    exact v.capacity_low hn ht ht'
  · rw [v.set_capacity_eq htpos hv]
    exact v.capacity_low hn ht ht'

theorem fourCentreCapacity_high {s : Finset Plane} (hs : s.card = 4)
    {n : ℕ} (hn : 2 ≤ n) {t : ℝ} (ht : (n : ℝ) ≤ t) (ht' : t < n + 1)
    (ha : ∀ A ∈ s, ∀ B ∈ s, ∀ C ∈ s, A ≠ B → A ≠ C → B ≠ C →
      angle A B C ≤ (1 - 1 / t) * Real.pi) :
    fourCentreCapacity t s ≤ 2 ^ n + 2 ^ (n - 2) := by
  have htpos : 0 < t := by
    have : (2 : ℝ) ≤ n := by exact_mod_cast hn
    linarith
  rcases four_centre_geometry_cases_of_angle_bound hs htpos ha with ⟨v, hv⟩ | ⟨v, hv⟩
  · rw [v.set_capacity_eq htpos hv]
    exact v.capacity_high hn ht ht'
  · rw [v.set_capacity_eq htpos hv]
    exact v.capacity_high hn ht ht'

end Prize.JSP404
