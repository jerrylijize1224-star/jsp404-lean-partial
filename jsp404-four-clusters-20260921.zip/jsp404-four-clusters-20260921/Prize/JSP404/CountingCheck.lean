import Prize.JSP404.Basic
import Mathlib.Data.Rat.Floor

/-!
# Exact arithmetic check on the s = 4 step of Sendov's Lemma 4.12

The geometric interpretation of these lists is explained in
research/jsp404-lemma412-check.md. This file checks only rational gap arithmetic;
it does NOT formalize the realization by a generalized configuration.
-/

namespace Prize.JSP404.CountingCheck

/-- The sector count in formula (4.22), at u/2 = 15/4.
Integer-to-natural conversion implements the positive part. -/
def slots (gaps : List ℚ) : ℕ :=
  (gaps.map fun gap => (⌊(15 / 4 : ℚ) * gap⌋ - 1).toNat).sum

def outerGaps : List ℚ := [1 / 7, 1 / 42, 5 / 6]
def lowerGaps : List ℚ := [5 / 14, 5 / 14, 2 / 7]
def upperGaps : List ℚ := [1 / 3, 1 / 3, 1 / 3]

theorem gap_sums :
    outerGaps.sum = 1 ∧ lowerGaps.sum = 1 ∧ upperGaps.sum = 1 := by
  norm_num [outerGaps, lowerGaps, upperGaps]

theorem slot_counts :
    slots outerGaps = 2 ∧ slots lowerGaps = 0 ∧ slots upperGaps = 0 := by
  norm_num [slots, outerGaps, lowerGaps, upperGaps]

/-- The displayed gap profiles give 10, exceeding the s = 4 subcase's proposed
value 2^3 + 2^(3-3) = 9, but not the main lemma's upper bound 10. -/
theorem capacity_check :
    2 ^ slots outerGaps + 2 ^ slots outerGaps +
      2 ^ slots lowerGaps + 2 ^ slots upperGaps = (10 : ℕ) ∧
    (2 ^ 3 + 2 ^ (3 - 3) : ℕ) < 10 ∧
    (2 ^ 3 + 2 ^ (3 - 2) : ℕ) = 10 := by
  obtain ⟨ha, hc, hd⟩ := slot_counts
  norm_num [ha, hc, hd]

end Prize.JSP404.CountingCheck
