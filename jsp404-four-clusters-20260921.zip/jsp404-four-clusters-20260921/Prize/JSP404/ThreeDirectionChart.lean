import Prize.JSP404.ProjectiveCoordinates
import Prize.JSP404.GeneralPosition
import Mathlib.Data.Finset.Sort

/-! Sorting actual projective directions and identifying their cyclic gaps. -/

namespace Prize.JSP404

theorem exists_strictMono_reindex {n : ℕ} (f : Fin n → ℝ) (hf : Function.Injective f) :
    ∃ e : Equiv.Perm (Fin n), StrictMono (f ∘ e) := by
  classical
  let s : Finset ℝ := Finset.univ.image f
  have hs : s.card = n := by simp [s, Finset.card_image_of_injective _ hf]
  let g : Fin n → s := fun i => ⟨f i, Finset.mem_image.mpr ⟨i, Finset.mem_univ i, rfl⟩⟩
  have hg : Function.Bijective g := by
    constructor
    · intro i j he
      exact hf (congrArg Subtype.val he)
    · rintro ⟨x, hx⟩
      obtain ⟨i, _, hi⟩ := Finset.mem_image.mp hx
      exact ⟨i, Subtype.ext hi⟩
  let q : Fin n ≃ s := Equiv.ofBijective g hg
  let e : Equiv.Perm (Fin n) := (s.orderIsoOfFin hs).toEquiv.trans q.symm
  refine ⟨e, ?_⟩
  have he : ∀ i, f (e i) = s.orderEmbOfFin hs i := by
    intro i
    exact congrArg Subtype.val (q.apply_symm_apply (s.orderIsoOfFin hs i))
  intro i j hij
  change f (e i) < f (e j)
  rw [he, he]
  exact (s.orderEmbOfFin hs).strictMono hij

structure SortedThreeDirectionChart (p : Fin 3 → Plane) where
  reindex : Equiv.Perm (Fin 3)
  theta : Fin 3 → ℝ
  length : Fin 3 → ℝ
  ray : Fin 3 → Bool
  sorted : StrictMono theta
  nonneg : ∀ i, 0 ≤ theta i
  lt_pi : ∀ i, theta i < Real.pi
  length_pos : ∀ i, 0 < length i
  represents : ∀ i, p (reindex i) = length i • signedDirection (theta i) (ray i)

/-- Distinct nonparallel vectors admit sorted representatives of their lines
in a single half-turn, with arbitrary positive lengths and ray choices. -/
theorem exists_sortedThreeDirectionChart (p : Fin 3 → Plane)
    (hne : ∀ i, p i ≠ 0)
    (hparallel : ∀ i j, i ≠ j → InnerProductGeometry.angle (p i) (p j) ≠ 0 ∧
      InnerProductGeometry.angle (p i) (p j) ≠ Real.pi) :
    Nonempty (SortedThreeDirectionChart p) := by
  classical
  choose θ r b hθ hπ hr hp using fun i => exists_projective_coordinates (hne i)
  have hθinj : Function.Injective θ := by
    intro i j hij
    by_contra hneij
    obtain ⟨hzero, hpi⟩ := hparallel i j hneij
    have he : InnerProductGeometry.angle (p i) (p j) =
        signedPairAngle Real.pi 0 (b i) (b j) := by
      rw [hp i, hp j, InnerProductGeometry.angle_smul_left_of_pos _ _ (hr i),
        InnerProductGeometry.angle_smul_right_of_pos _ _ (hr j), hij]
      simpa using signedDirection_angle (θ := θ j) (φ := θ j) le_rfl
        (by simpa using Real.pi_pos.le) (b i) (b j)
    by_cases hb : b i = b j
    · exact hzero (by simpa [signedPairAngle, hb] using he)
    · exact hpi (by simpa [signedPairAngle, hb] using he)
  obtain ⟨e, he⟩ := exists_strictMono_reindex θ hθinj
  exact ⟨{
    reindex := e
    theta := θ ∘ e
    length := r ∘ e
    ray := b ∘ e
    sorted := he
    nonneg := fun i => hθ (e i)
    lt_pi := fun i => hπ (e i)
    length_pos := fun i => hr (e i)
    represents := fun i => hp (e i) }⟩

theorem vectorThreeRayIndex_swap (t : ℝ) (U V W : Plane) :
    vectorThreeRayIndex t V U W = vectorThreeRayIndex t U V W := by
  unfold vectorThreeRayIndex
  rw [InnerProductGeometry.angle_comm V U, InnerProductGeometry.angle_comm U W,
    InnerProductGeometry.angle_comm W V]
  exact threeRayIndex_swap_last _ _ _ _

theorem vectorThreeRayIndex_rotate (t : ℝ) (U V W : Plane) :
    vectorThreeRayIndex t V W U = vectorThreeRayIndex t U V W :=
  threeRayIndex_rotate _ _ _ _

theorem vectorThreeRayIndex_swap_last (t : ℝ) (U V W : Plane) :
    vectorThreeRayIndex t U W V = vectorThreeRayIndex t U V W := by
  unfold vectorThreeRayIndex
  rw [InnerProductGeometry.angle_comm U W, InnerProductGeometry.angle_comm W V,
    InnerProductGeometry.angle_comm V U]
  exact threeRayIndex_reverse _ _ _ _

theorem vectorThreeRayIndex_reindex (t : ℝ) (p : Fin 3 → Plane) (e : Equiv.Perm (Fin 3)) :
    vectorThreeRayIndex t (p (e 0)) (p (e 1)) (p (e 2)) =
      vectorThreeRayIndex t (p 0) (p 1) (p 2) := by
  have h01 : e 0 ≠ e 1 := e.injective.ne (by decide)
  have h02 : e 0 ≠ e 2 := e.injective.ne (by decide)
  have h12 : e 1 ≠ e 2 := e.injective.ne (by decide)
  generalize e 0 = i at *
  generalize e 1 = j at *
  generalize e 2 = k at *
  fin_cases i <;> fin_cases j <;> fin_cases k <;>
    simp_all [vectorThreeRayIndex_swap, vectorThreeRayIndex_rotate, vectorThreeRayIndex_swap_last] <;>
    exact vectorThreeRayIndex_swap _ _ _ _

/-- The three consecutive projective angular gaps, including the wrap-around
gap, determine the local index of the original, unsorted actual vectors. -/
theorem SortedThreeDirectionChart.index_eq_gaps {p : Fin 3 → Plane}
    (v : SortedThreeDirectionChart p) {t : ℝ} (ht : 0 < t) :
    vectorThreeRayIndex t (p 0) (p 1) (p 2) =
      gapBits (t * ((v.theta 1 - v.theta 0) / Real.pi)) +
      gapBits (t * ((v.theta 2 - v.theta 1) / Real.pi)) +
      gapBits (t * ((Real.pi - (v.theta 2 - v.theta 0)) / Real.pi)) := by
  rw [← vectorThreeRayIndex_reindex t p v.reindex, v.represents, v.represents, v.represents]
  exact vectorThreeRayIndex_projective_coordinates ht
    (v.sorted (by decide : (0 : Fin 3) < 1))
    (v.sorted (by decide : (1 : Fin 3) < 2))
    (by linarith [v.nonneg 0, v.lt_pi 2])
    (v.length_pos 0) (v.length_pos 1) (v.length_pos 2) _ _ _

/-- The three actual vectors leaving one of four centres. -/
noncomputable def pointDirectionTriple (A B C D : Plane) : Fin 3 → Plane :=
  fun i => (![B, C, D] : Fin 3 → Plane) i - A

theorem fourCentreLocalIndex_eq_vectorIndex (t : ℝ) (A B C D : Plane) :
    fourCentreLocalIndex t A B C D = vectorThreeRayIndex t (B - A) (C - A) (D - A) := rfl

theorem exists_pointDirectionChart {s : Finset Plane} (hg : GeneralPosition s)
    {A B C D : Plane} (hA : A ∈ s) (hB : B ∈ s) (hC : C ∈ s) (hD : D ∈ s)
    (hAB : A ≠ B) (hAC : A ≠ C) (hAD : A ≠ D)
    (hBC : B ≠ C) (hBD : B ≠ D) (hCD : C ≠ D) :
    Nonempty (SortedThreeDirectionChart (pointDirectionTriple A B C D)) := by
  let q : Fin 3 → Plane := ![B, C, D]
  have hq : Function.Injective q := by
    intro i j he
    fin_cases i <;> fin_cases j <;>
      simp [q, hBC, hBD, hCD, hBC.symm, hBD.symm, hCD.symm] at he ⊢
  have hmem : ∀ i, q i ∈ s := by intro i; fin_cases i <;> simp [q, hB, hC, hD]
  have hneA : ∀ i, q i ≠ A := by
    intro i
    fin_cases i <;> simp [q, Ne.symm hAB, Ne.symm hAC, Ne.symm hAD]
  apply exists_sortedThreeDirectionChart
  · intro i
    change q i - A ≠ 0
    exact sub_ne_zero.mpr (hneA i)
  · intro i j hij
    change EuclideanGeometry.angle (q i) A (q j) ≠ 0 ∧
      EuclideanGeometry.angle (q i) A (q j) ≠ Real.pi
    have hc := hg (q i) (hmem i) A hA (q j) (hmem j)
      (hneA i) (hq.ne hij) (hneA j).symm
    exact ⟨EuclideanGeometry.angle_ne_zero_of_not_collinear hc,
      EuclideanGeometry.angle_ne_pi_of_not_collinear hc⟩

/-- For the actual directions at any centre of a general-position four-point
configuration, the symmetric local index is the sum of the three cyclic
projective gap contributions. The chart's existence is proved above. -/
theorem pointDirectionChart_localIndex_eq {A B C D : Plane}
    (v : SortedThreeDirectionChart (pointDirectionTriple A B C D))
    {t : ℝ} (ht : 0 < t) :
    fourCentreLocalIndex t A B C D =
      gapBits (t * ((v.theta 1 - v.theta 0) / Real.pi)) +
      gapBits (t * ((v.theta 2 - v.theta 1) / Real.pi)) +
      gapBits (t * ((Real.pi - (v.theta 2 - v.theta 0)) / Real.pi)) := by
  rw [fourCentreLocalIndex_eq_vectorIndex]
  exact v.index_eq_gaps ht

end Prize.JSP404
