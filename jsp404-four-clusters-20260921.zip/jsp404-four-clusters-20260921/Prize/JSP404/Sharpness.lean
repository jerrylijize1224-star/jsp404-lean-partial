import Prize.JSP404.Basic
import Mathlib.Data.Finset.Max
import Mathlib.Data.Finset.Prod

/-!
# Threshold and approximation interfaces

Every individual finite configuration has a largest angle. This does not assert
that the infimum over all configurations is attained. Threshold arguments and
arbitrarily close counterexamples suffice for the original sharp-bound target.
-/

namespace Prize.JSP404

open EuclideanGeometry

/-- There is a largest angle among the distinct triples of a finite set with
at least three points. No global minimizing configuration is asserted. -/
theorem exists_largest_angle {s : Finset Plane} (hs : 3 ≤ s.card) :
    ∃ x ∈ s, ∃ y ∈ s, ∃ z ∈ s,
      x ≠ y ∧ x ≠ z ∧ y ≠ z ∧
      ∀ u ∈ s, ∀ v ∈ s, ∀ w ∈ s,
        u ≠ v → u ≠ w → v ≠ w → angle u v w ≤ angle x y z := by
  classical
  let triples := (s.product (s.product s)).filter
    (fun t => t.1 ≠ t.2.1 ∧ t.1 ≠ t.2.2 ∧ t.2.1 ≠ t.2.2)
  have mem_triples (x y z : Plane) :
      (x, y, z) ∈ triples ↔
        x ∈ s ∧ y ∈ s ∧ z ∈ s ∧ x ≠ y ∧ x ≠ z ∧ y ≠ z := by
    simp [triples, Finset.mem_product, and_assoc]
  have hne : triples.Nonempty := by
    obtain ⟨x, hx, y, hy, z, hz, hxy, hxz, hyz, _⟩ := hasLargeAngle_pi_div_three hs
    exact ⟨(x, y, z), (mem_triples x y z).mpr ⟨hx, hy, hz, hxy, hxz, hyz⟩⟩
  obtain ⟨⟨x, y, z⟩, ht, hm⟩ :=
    Finset.exists_max_image triples (fun t => angle t.1 t.2.1 t.2.2) hne
  obtain ⟨hx, hy, hz, hxy, hxz, hyz⟩ := (mem_triples x y z).mp ht
  refine ⟨x, hx, y, hy, z, hz, hxy, hxz, hyz, ?_⟩
  intro u hu v hv w hw huv huw hvw
  exact hm (u, v, w) ((mem_triples u v w).mpr ⟨hu, hv, hw, huv, huw, hvw⟩)

/-- A lower-bound proof may work strictly below the desired threshold.
The finite maximum closes the endpoint. -/
theorem guaranteedAngle_of_forall_lt {n : ℕ} {a : ℝ} (hn : 3 ≤ n)
    (h : ∀ b < a, GuaranteedAngle n b) : GuaranteedAngle n a := by
  intro s hs
  obtain ⟨x, hx, y, hy, z, hz, hxy, hxz, hyz, hm⟩ :=
    exists_largest_angle (hs ▸ hn)
  refine ⟨x, hx, y, hy, z, hz, hxy, hxz, hyz, ?_⟩
  by_contra ha
  have hmid : (angle x y z + a) / 2 < a := by linarith
  obtain ⟨u, hu, v, hv, w, hw, huv, huw, hvw, hab⟩ :=
    h _ hmid s hs
  have := hm u hu v hv w hw huv huw hvw
  linarith

/-- Construction interfaces may provide at least n points: taking a subset
preserves the absence of an angle at least b. -/
theorem not_guaranteedAngle_of_large_counterexample {n : ℕ} {b : ℝ}
    {s : Finset Plane} (hcard : n ≤ s.card) (hbad : ¬ HasLargeAngle s b) :
    ¬ GuaranteedAngle n b := by
  intro h
  obtain ⟨t, hts, ht⟩ := Finset.exists_subset_card_eq hcard
  exact hbad ((h t ht).mono_set hts)

/-- A sharp value needs only arbitrarily close counterexamples. Neither exact
attainment of the infimum nor exact cardinality in the construction is needed. -/
theorem isSharpBound_of_approximation {n : ℕ} {a : ℝ}
    (ha0 : 0 ≤ a) (hapi : a ≤ Real.pi) (hlower : GuaranteedAngle n a)
    (happrox : ∀ ε : ℝ, 0 < ε →
      ∃ s : Finset Plane, n ≤ s.card ∧ ¬ HasLargeAngle s (a + ε)) :
    IsSharpBound n a := by
  refine ⟨ha0, hapi, hlower, ?_⟩
  intro b hb
  obtain ⟨s, hs, hbad⟩ := happrox (b - a) (sub_pos.mpr hb)
  have heq : a + (b - a) = b := by ring
  rw [heq] at hbad
  exact not_guaranteedAngle_of_large_counterexample hs hbad

end Prize.JSP404
