import Prize.JSP404.Basic

/-! The exact three-point case, by an explicit equilateral triangle. -/
namespace Prize.JSP404

open EuclideanGeometry

private noncomputable def A : Plane := !₂[0, 0]
private noncomputable def B : Plane := !₂[2, 0]
private noncomputable def C : Plane := !₂[1, Real.sqrt 3]

private theorem dist_AB : dist A B = 2 := by
  rw [EuclideanSpace.dist_eq]
  norm_num [A, B, Fin.sum_univ_two, Real.dist_eq]
  rw [show (4 : ℝ) = 2 ^ 2 by norm_num, Real.sqrt_sq (by norm_num : (0 : ℝ) ≤ 2)]

private theorem dist_AC : dist A C = 2 := by
  rw [EuclideanSpace.dist_eq]
  norm_num [A, C, Fin.sum_univ_two, Real.dist_eq, Real.sq_sqrt]
  rw [show (4 : ℝ) = 2 ^ 2 by norm_num, Real.sqrt_sq (by norm_num : (0 : ℝ) ≤ 2)]

private theorem dist_BC : dist B C = 2 := by
  rw [EuclideanSpace.dist_eq]
  norm_num [B, C, Fin.sum_univ_two, Real.dist_eq, Real.sq_sqrt]
  rw [show (4 : ℝ) = 2 ^ 2 by norm_num, Real.sqrt_sq (by norm_num : (0 : ℝ) ≤ 2)]

private theorem A_ne_B : A ≠ B := by
  intro h
  have := dist_AB
  rw [h, dist_self] at this
  norm_num at this

private theorem A_ne_C : A ≠ C := by
  intro h
  have := dist_AC
  rw [h, dist_self] at this
  norm_num at this

private theorem B_ne_C : B ≠ C := by
  intro h
  have := dist_BC
  rw [h, dist_self] at this
  norm_num at this

private theorem angle_ABC : angle A B C = Real.pi / 3 := by
  have h₁ := angle_eq_angle_of_dist_eq (dist_AB.trans dist_AC.symm)
  have h₂ := angle_eq_angle_of_dist_eq
    ((dist_comm B A).trans (dist_AB.trans dist_BC.symm))
  have hsum := angle_add_angle_add_angle_eq_pi C A_ne_B.symm
  rw [angle_comm A C B] at h₁
  rw [angle_comm B A C] at h₂
  linarith

private theorem angle_BCA : angle B C A = Real.pi / 3 := by
  have h := angle_eq_angle_of_dist_eq (dist_AB.trans dist_AC.symm)
  rw [angle_comm A C B] at h
  linarith [angle_ABC]

private theorem angle_CAB : angle C A B = Real.pi / 3 := by
  have hsum := angle_add_angle_add_angle_eq_pi C A_ne_B.symm
  linarith [angle_ABC, angle_BCA]

private noncomputable def equilateralSet : Finset Plane := {A, B, C}

private theorem equilateralSet_card : equilateralSet.card = 3 := by
  classical
  simp [equilateralSet, A_ne_B, A_ne_C, B_ne_C]

private theorem equilateralSet_angle {x y z : Plane}
    (hx : x ∈ equilateralSet) (hy : y ∈ equilateralSet) (hz : z ∈ equilateralSet)
    (hxy : x ≠ y) (hxz : x ≠ z) (hyz : y ≠ z) :
    angle x y z = Real.pi / 3 := by
  classical
  have hCBA : angle C B A = Real.pi / 3 := (angle_comm C B A).trans angle_ABC
  have hACB : angle A C B = Real.pi / 3 := (angle_comm A C B).trans angle_BCA
  have hBAC : angle B A C = Real.pi / 3 := (angle_comm B A C).trans angle_CAB
  simp only [equilateralSet, Finset.mem_insert, Finset.mem_singleton] at hx hy hz
  rcases hx with rfl | rfl | rfl <;>
    rcases hy with rfl | rfl | rfl <;>
    rcases hz with rfl | rfl | rfl <;>
    simp_all [angle_ABC, angle_BCA, angle_CAB]

theorem threePoints_sharp : IsSharpBound 3 (Real.pi / 3) := by
  refine ⟨by positivity, by linarith [Real.pi_pos],
    guaranteedAngle_pi_div_three (by omega), ?_⟩
  intro b hb h
  obtain ⟨x, hx, y, hy, z, hz, hxy, hxz, hyz, hangle⟩ :=
    h equilateralSet equilateralSet_card
  rw [equilateralSet_angle hx hy hz hxy hxz hyz] at hangle
  linarith

theorem alpha_three : alpha 3 = Real.pi / 3 := threePoints_sharp.alpha_eq

end Prize.JSP404
