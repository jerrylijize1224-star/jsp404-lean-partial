import Prize.JSP404.FourCentreProjectiveGaps
import Prize.JSP404.GapSectorCounting

/-!
# Allowed coordinates from three actual anchor directions

This fills the coordinate-cover premise of the previous counting interface.
The last gap wraps across a half-turn; changing a representative there also
changes its ray sign. No existence of generalized extremizers is used.
-/

namespace Prize.JSP404

open InnerProductGeometry

theorem exists_projective_coordinates_from {U : Plane} (hU : U ≠ 0)
    {a : ℝ} (ha : 0 ≤ a) (haπ : a < Real.pi) :
    ∃ θ r : ℝ, ∃ b : Bool, a ≤ θ ∧ θ < a + Real.pi ∧ 0 < r ∧
      U = r • signedDirection θ b := by
  obtain ⟨θ, r, b, hθ, hθπ, hr, hUrep⟩ := exists_projective_coordinates hU
  by_cases h : a ≤ θ
  · exact ⟨θ, r, b, h, by linarith, hr, hUrep⟩
  · refine ⟨θ + Real.pi, r, !b, by linarith, by linarith, hr, ?_⟩
    have he : signedDirection (θ + Real.pi) (!b) = signedDirection θ b := by
      cases b <;> simp [signedDirection, unitDirection_add_pi]
    rwa [he]

theorem abs_separation_of_signed_angle_bounds {θ φ r s w : ℝ}
    (hwidth : |θ - φ| ≤ Real.pi) (hr : 0 < r) (hs : 0 < s) (b c : Bool)
    (h : w ≤ angle (r • signedDirection θ b) (s • signedDirection φ c) ∧
      angle (r • signedDirection θ b) (s • signedDirection φ c) ≤ Real.pi - w) :
    w ≤ |θ - φ| ∧ |θ - φ| ≤ Real.pi - w := by
  rw [angle_smul_left_of_pos _ _ hr, angle_smul_right_of_pos _ _ hs] at h
  cases b <;> cases c <;>
    simp [signedDirection, angle_neg_left, angle_neg_right,
      unitDirection_angle_abs hwidth] at h <;> constructor <;> linarith [h.1, h.2]

namespace SortedThreeDirectionChart

variable {p : Fin 3 → Plane} (v : SortedThreeDirectionChart p)

theorem exists_allowed_gap {θ w : ℝ}
    (hθ : v.theta 0 ≤ θ)
    (hsep : ∀ i, w ≤ |θ - v.theta i| ∧ |θ - v.theta i| ≤ Real.pi - w) :
    ∃ i, v.theta i + w ≤ θ ∧ θ ≤ v.theta i + v.gap i - w := by
  have h0 := hsep 0
  rw [abs_of_nonneg (sub_nonneg.mpr hθ)] at h0
  by_cases h1 : θ ≤ v.theta 1
  · have h := hsep 1
    rw [abs_of_nonpos (sub_nonpos.mpr h1)] at h
    refine ⟨0, ?_, ?_⟩ <;> (try dsimp [gap]) <;> linarith [h.1, h0.1]
  · have h1' : v.theta 1 ≤ θ := le_of_not_ge h1
    have hs1 := hsep 1
    rw [abs_of_nonneg (sub_nonneg.mpr h1')] at hs1
    by_cases h2 : θ ≤ v.theta 2
    · have hs2 := hsep 2
      rw [abs_of_nonpos (sub_nonpos.mpr h2)] at hs2
      refine ⟨1, ?_, ?_⟩ <;> (try dsimp [gap]) <;> linarith [hs1.1, hs2.1]
    · have hs2 := hsep 2
      rw [abs_of_nonneg (sub_nonneg.mpr (le_of_not_ge h2))] at hs2
      refine ⟨2, ?_, ?_⟩ <;> (try dsimp [gap]) <;> linarith [hs2.1, h0.2]

/-- Both orientations of an internal line are allowed. The three actual
anchor-angle restrictions suffice, including the cyclic final gap. -/
theorem exists_allowed_coordinates {U : Plane} (hU : U ≠ 0) {w : ℝ} (hw : 0 < w)
    (hsep : ∀ i, w ≤ angle U (p i) ∧ angle U (p i) ≤ Real.pi - w) :
    ∃ i, ∃ x r : ℝ, ∃ b : Bool, x ∈ Set.Icc 1 (v.gap i / w - 1) ∧ 0 < r ∧
      U = r • signedDirection (v.theta i + w * x) b := by
  obtain ⟨θ, r, b, hθ, hθπ, hr, hrep⟩ :=
    exists_projective_coordinates_from hU (v.nonneg 0) (v.lt_pi 0)
  have hs : ∀ i, w ≤ |θ - v.theta i| ∧ |θ - v.theta i| ≤ Real.pi - w := by
    intro i
    have hi : v.theta 0 ≤ v.theta i := v.sorted.monotone (by omega)
    have hwidth : |θ - v.theta i| ≤ Real.pi := by
      apply abs_le.mpr
      constructor <;> linarith [v.lt_pi i, v.nonneg 0]
    have h := hsep (v.reindex i)
    rw [hrep, v.represents i] at h
    exact abs_separation_of_signed_angle_bounds hwidth hr (v.length_pos i) b (v.ray i) h
  obtain ⟨i, hlo, hhi⟩ := v.exists_allowed_gap hθ hs
  refine ⟨i, (θ - v.theta i) / w, r, b, ⟨?_, ?_⟩, hr, ?_⟩
  · apply (le_div_iff₀ hw).mpr
    linarith
  · have he : v.gap i / w - 1 = (v.gap i - w) / w := by
      field_simp
    rw [he]
    apply (div_le_div_iff_of_pos_right hw).mpr
    linarith
  · have he : v.theta i + w * ((θ - v.theta i) / w) = θ := by
      field_simp
      ring
    rwa [he]

end SortedThreeDirectionChart

/-- The previously assumed allowed-coordinate cover is now derived from
separation from three actual anchor vectors. -/
theorem GeneralizedDirections.card_le_of_three_anchor_separation
    {V : Type*} [Fintype V] (D : GeneralizedDirections V)
    {p : Fin 3 → Plane} (v : SortedThreeDirectionChart p)
    {w : ℝ} (hw : 0 < w) (hwπ : w ≤ Real.pi)
    (hbound : D.AngleBound (Real.pi - w))
    (hsep : ∀ u q, u ≠ q → ∀ i,
      w ≤ angle (D.direction u q) (p i) ∧
      angle (D.direction u q) (p i) ≤ Real.pi - w) :
    Fintype.card V ≤ 2 ^ (∑ i, sectorCapacity 1 (v.gap i / w)) := by
  apply D.card_le_of_allowed_gap_coordinates v.theta (fun i => v.gap i / w) hw hwπ hbound
  intro u q huq
  obtain ⟨i, x, r, b, hx, hr, hrep⟩ :=
    v.exists_allowed_coordinates (D.nonzero u q huq) hw (hsep u q huq)
  refine ⟨i, x, hx, r, hr, ?_⟩
  cases b
  · exact Or.inl (by simpa [signedDirection] using hrep)
  · right
    rw [D.reverse u q, hrep]
    simp [signedDirection]

/-- For a cluster with three occupied external centres, the angular exclusion
needed above follows from mixed triples of leaves. -/
theorem GeneralizedDirections.cluster_card_le_gap_capacity
    {V I : Type*} [Fintype V] [DecidableEq I] (D : GeneralizedDirections V)
    (cluster : V → I) (centre : I → Plane) (hsurj : Function.Surjective cluster)
    (hcross : ∀ u q, cluster u ≠ cluster q →
      D.direction u q = centre (cluster q) - centre (cluster u))
    (a : I) (j : Fin 3 → I) (hj : ∀ i, j i ≠ a)
    (v : SortedThreeDirectionChart (fun i => centre (j i) - centre a))
    {w : ℝ} (hw : 0 < w) (hwπ : w ≤ Real.pi)
    (hbound : D.AngleBound (Real.pi - w)) :
    Fintype.card {u : V // cluster u = a} ≤
      2 ^ (∑ i, sectorCapacity 1 (v.gap i / w)) := by
  classical
  apply (D.restrict {u | cluster u = a}).card_le_of_three_anchor_separation
    v hw hwπ (D.angleBound_restrict hbound _) ?_
  intro u q huq i
  obtain ⟨e, he⟩ := hsurj (j i)
  have hout : cluster (u : V) ≠ cluster e := by
    rw [u.property, he]
    exact (hj i).symm
  have h := D.internal_angle_bounds_of_centres cluster centre hcross hbound
    (fun h => huq (Subtype.ext h)) (u.property.trans q.property.symm) hout
  change w ≤ angle (D.direction u q) (centre (j i) - centre a) ∧
    angle (D.direction u q) (centre (j i) - centre a) ≤ Real.pi - w
  have hua : cluster (u : V) = a := u.property
  simpa only [he, hua, sub_sub_cancel] using h

end Prize.JSP404
