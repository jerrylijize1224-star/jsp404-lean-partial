import Prize.JSP404.DirectionCover

/-!
# Counting with generalized directions

The sector counting argument only needs reversal of directions and an angle
bound, not a representation by ordinary point differences. This is an abstract
interface for Sendov's generalized configurations (1995, Lemma 3.3). Realizing
these data by a nested configuration and constructing the sector cover remain
separate obligations.
-/

namespace Prize.JSP404

open InnerProductGeometry

/-- Directions assigned to distinct leaves, with reversal and nondegeneracy. -/
structure GeneralizedDirections (V : Type*) where
  direction : V → V → Plane
  reverse : ∀ u v, direction v u = -direction u v
  nonzero : ∀ u v, u ≠ v → direction u v ≠ 0

namespace GeneralizedDirections

variable {V : Type*} (D : GeneralizedDirections V)

/-- The angle at the middle leaf; no realization theorem is implicit. -/
noncomputable def tripleAngle (u v w : V) : ℝ := angle (D.direction v u) (D.direction v w)

def AngleBound (a : ℝ) : Prop :=
  ∀ u v w, u ≠ v → u ≠ w → v ≠ w → D.tripleAngle u v w ≤ a

theorem card_le_two_pow_of_cover [Fintype V] {k : ℕ} {a : ℝ}
    (ha : 0 ≤ a) (C : Fin k → Set Plane)
    (hcover : ∀ u v, u ≠ v → ∃ i, D.direction u v ∈ C i ∨ D.direction v u ∈ C i)
    (hthin : ∀ i, ∀ p ∈ C i, ∀ q ∈ C i, angle p q < Real.pi - a)
    (hbound : D.AngleBound a) : Fintype.card V ≤ 2 ^ k := by
  classical
  let R : Fin k → V → V → Prop := fun i u v => u ≠ v ∧ D.direction u v ∈ C i
  apply card_le_two_pow_of_no_two_step_cover R
  · intro u v huv
    obtain ⟨i, hi⟩ := hcover u v huv
    exact ⟨i, hi.elim (fun h => Or.inl ⟨huv, h⟩)
      (fun h => Or.inr ⟨huv.symm, h⟩)⟩
  · intro i u v w huv hvw
    have hsmall := hthin i _ huv.2 _ hvw.2
    have hlarge : a < D.tripleAngle u v w := by
      unfold tripleAngle
      rw [D.reverse u v, angle_neg_left]
      linarith
    by_cases huw : u = w
    · subst w
      have hzero : D.tripleAngle u v u = 0 := angle_self (D.nonzero v u huv.1.symm)
      linarith
    · exact (not_lt_of_ge (hbound u v w huv.1 huw hvw.1)) hlarge

/-- Internal directions are separated from a common external direction at
both endpoints. This is the angular exclusion used in the cluster argument. -/
theorem internal_angle_bounds {a : ℝ} (hbound : D.AngleBound a)
    {u v w : V} (huv : u ≠ v) (huw : u ≠ w) (hvw : v ≠ w)
    (hexternal : D.direction u w = D.direction v w) :
    Real.pi - a ≤ angle (D.direction u v) (D.direction u w) ∧
      angle (D.direction u v) (D.direction u w) ≤ a := by
  have hupper := hbound v u w huv.symm hvw huw
  have hlower := hbound u v w huv huw hvw
  change angle (D.direction u v) (D.direction u w) ≤ a at hupper
  change angle (D.direction v u) (D.direction v w) ≤ a at hlower
  rw [D.reverse u v, ← hexternal, angle_neg_left] at hlower
  exact ⟨by linarith, hupper⟩

theorem card_le_two_pow_of_indexed_cover [Fintype V] {J : Type*} [Fintype J]
    {a : ℝ} (ha : 0 ≤ a) (C : J → Set Plane)
    (hcover : ∀ u v, u ≠ v → ∃ i, D.direction u v ∈ C i ∨ D.direction v u ∈ C i)
    (hthin : ∀ i, ∀ p ∈ C i, ∀ q ∈ C i, angle p q < Real.pi - a)
    (hbound : D.AngleBound a) : Fintype.card V ≤ 2 ^ Fintype.card J := by
  classical
  let e := Fintype.equivFin J
  apply D.card_le_two_pow_of_cover ha (fun i => C (e.symm i)) ?_ ?_ hbound
  · intro u v huv
    obtain ⟨i, hi⟩ := hcover u v huv
    exact ⟨e i, by simpa using hi⟩
  · intro i
    exact hthin (e.symm i)

/-- Restricting to a cluster preserves the direction laws. -/
def restrict (S : Set V) : GeneralizedDirections S where
  direction u v := D.direction u v
  reverse u v := D.reverse u v
  nonzero u v huv := D.nonzero u v (fun h => huv (Subtype.ext h))

theorem angleBound_restrict {a : ℝ} (hbound : D.AngleBound a) (S : Set V) :
    (D.restrict S).AngleBound a := by
  intro u v w huv huw hvw
  exact hbound u v w (fun h => huv (Subtype.ext h))
    (fun h => huw (Subtype.ext h)) (fun h => hvw (Subtype.ext h))

/-- If each cluster has its indicated thin-sector cover, sum the resulting
binary bounds. The covers and their sizes are explicit hypotheses. -/
theorem card_le_sum_two_pow_of_cluster_covers [Fintype V]
    {I : Type*} [Fintype I] [DecidableEq I] (cluster : V → I)
    (k : I → ℕ) {a : ℝ} (ha : 0 ≤ a) (hbound : D.AngleBound a)
    (C : ∀ i, Fin (k i) → Set Plane)
    (hcover : ∀ i u v, cluster u = i → cluster v = i → u ≠ v →
      ∃ j, D.direction u v ∈ C i j ∨ D.direction v u ∈ C i j)
    (hthin : ∀ i j, ∀ p ∈ C i j, ∀ q ∈ C i j, angle p q < Real.pi - a) :
    Fintype.card V ≤ ∑ i, 2 ^ k i := by
  classical
  have hfibre (i : I) : Fintype.card {v : V // cluster v = i} ≤ 2 ^ k i := by
    apply (D.restrict {v | cluster v = i}).card_le_two_pow_of_cover ha (C i)
    · intro u v huv
      exact hcover i u v u.property v.property (fun h => huv (Subtype.ext h))
    · exact hthin i
    · exact D.angleBound_restrict hbound _
  have hsum := Finset.card_eq_sum_card_fiberwise
    (s := (Finset.univ : Finset V)) (t := (Finset.univ : Finset I))
    (f := cluster) (by intro v hv; exact Finset.mem_univ _)
  calc
    Fintype.card V = ∑ i, (Finset.univ.filter (fun v => cluster v = i)).card := hsum
    _ ≤ ∑ i, 2 ^ k i := Finset.sum_le_sum (fun i _ => by
      simpa only [Fintype.card_subtype] using hfibre i)

/-- Equal external directions follow directly from a cluster-centre model. -/
theorem internal_angle_bounds_of_centres {I : Type*} (cluster : V → I)
    (centre : I → Plane)
    (hcross : ∀ u w, cluster u ≠ cluster w →
      D.direction u w = centre (cluster w) - centre (cluster u))
    {a : ℝ} (hbound : D.AngleBound a) {u v w : V}
    (huv : u ≠ v) (hsame : cluster u = cluster v)
    (hout : cluster u ≠ cluster w) :
    Real.pi - a ≤ angle (D.direction u v) (centre (cluster w) - centre (cluster u)) ∧
      angle (D.direction u v) (centre (cluster w) - centre (cluster u)) ≤ a := by
  have hvout : cluster v ≠ cluster w := by simpa only [← hsame] using hout
  have hexternal : D.direction u w = D.direction v w := by
    rw [hcross u w hout, hcross v w hvout, hsame]
  have h := D.internal_angle_bounds hbound huv
    (fun h => hout (congrArg cluster h)) (fun h => hvout (congrArg cluster h)) hexternal
  rwa [hcross u w hout] at h

end GeneralizedDirections
end Prize.JSP404
