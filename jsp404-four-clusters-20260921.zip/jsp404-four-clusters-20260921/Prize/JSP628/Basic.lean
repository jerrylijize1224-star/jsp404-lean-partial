import Mathlib.Combinatorics.SimpleGraph.Paths
import Mathlib.Combinatorics.SimpleGraph.Walk.Chord

/-!
Initial feasibility experiment for JSP-000628 / Erdős 767.
The extremal theorem below is only a proposition, not a proved theorem.
The path-fan predicate is separate: its equivalence to incident chords is NOT
assumed. Mathematical reference: Chen--Ning (2026), arXiv:2609.15330v1, Lemma 3.1.
-/

namespace Prize.JSP628

open SimpleGraph

variable {V : Type*} {G : SimpleGraph V}

/-- At least `k` distinct chords incident to the base vertex of a simple cycle. -/
def HasIncidentChords (G : SimpleGraph V) (k : ℕ) : Prop :=
  ∃ (x : V) (c : G.Walk x x), c.IsCycle ∧
    ∃ f : Fin k → V, Function.Injective f ∧ ∀ i, c.IsChord s(x, f i)

/-- A simple path avoiding a center, with at least `r` distinct neighbors of it. -/
def HasPathFan (G : SimpleGraph V) (r : ℕ) : Prop :=
  ∃ (x a b : V) (p : G.Walk a b), p.IsPath ∧ x ∉ p.support ∧
    ∃ f : Fin r → V, Function.Injective f ∧
      ∀ i, f i ∈ p.support ∧ G.Adj x (f i)

/-- The original eventual extremal claim, expressed as an upper bound plus
an attaining graph, avoiding a hidden assumption about existence of a maximum. -/
def EventualExtremalClaim : Prop :=
  ∀ k : ℕ, 0 < k → ∃ N : ℕ, ∀ n : ℕ, N ≤ n →
    (∀ G : SimpleGraph (Fin n), ¬ HasIncidentChords G k →
      G.edgeSet.ncard ≤ (k + 1) * n - (k + 1) ^ 2) ∧
    (∃ G : SimpleGraph (Fin n), ¬ HasIncidentChords G k ∧
      G.edgeSet.ncard = (k + 1) * n - (k + 1) ^ 2)

/-- Jiang's explicit threshold version. This is an unproved target. -/
def JiangClaim : Prop :=
  ∀ k n : ℕ, 0 < k → 3 * k + 3 ≤ n →
    (∀ G : SimpleGraph (Fin n), ¬ HasIncidentChords G k →
      G.edgeSet.ncard ≤ (k + 1) * n - (k + 1) ^ 2) ∧
    (∃ G : SimpleGraph (Fin n), ¬ HasIncidentChords G k ∧
      G.edgeSet.ncard = (k + 1) * n - (k + 1) ^ 2)

/-- Every neighbor of the initial vertex of a longest simple path lies on it.
Proof: an outside neighbor would extend the path by one edge. -/
theorem neighbor_mem_of_longest {a b : V} (p : G.Walk a b) (hp : p.IsPath)
    (hmax : ∀ (u v : V) (q : G.Walk u v), q.IsPath → q.length ≤ p.length)
    {x : V} (hax : G.Adj a x) : x ∈ p.support := by
  classical
  by_contra hx
  have hlong := hmax x b (p.cons hax.symm) (hp.cons hx)
  simp only [Walk.length_cons] at hlong
  omega

/-- No vertex outside a longest path can be adjacent to its initial vertex. -/
theorem no_outside_neighbor_of_longest {a b : V} (p : G.Walk a b) (hp : p.IsPath)
    (hmax : ∀ (u v : V) (q : G.Walk u v), q.IsPath → q.length ≤ p.length)
    {x : V} (hx : x ∉ p.support) : ¬ G.Adj a x := by
  intro hax
  exact hx (neighbor_mem_of_longest p hp hmax hax)

/-- A longest path provides a low-degree endpoint in a graph with no
`(k+2)`-path-fan. No equivalence with the chord formulation is assumed here. -/
theorem degree_start_le_of_no_pathFan [Fintype V] [DecidableRel G.Adj]
    {a b : V} (p : G.Walk a b) (hp : p.IsPath)
    (hmax : ∀ (u v : V) (q : G.Walk u v), q.IsPath → q.length ≤ p.length)
    (k : ℕ) (hfree : ¬ HasPathFan G (k + 2)) : G.degree a ≤ k + 1 := by
  classical
  by_contra hdeg
  have hcard : k + 2 ≤ Fintype.card (G.neighborSet a) := by
    rw [G.card_neighborSet_eq_degree]
    omega
  obtain ⟨f⟩ := Function.Embedding.nonempty_of_card_le
    (show Fintype.card (Fin (k + 2)) ≤ Fintype.card (G.neighborSet a) by
      simpa only [Fintype.card_fin] using hcard)
  cases p with
  | nil =>
      have ha := neighbor_mem_of_longest Walk.nil hp hmax (f 0).property
      simp only [Walk.support_nil, List.mem_singleton] at ha
      exact (G.ne_of_adj (f 0).property) ha.symm
  | @cons a c b hac q =>
      have hparts := (Walk.cons_isPath_iff hac q).mp hp
      apply hfree
      refine ⟨a, c, b, q, hparts.1, hparts.2, fun i => (f i).val, ?_, ?_⟩
      · intro i j hij
        exact f.injective (Subtype.ext hij)
      · intro i
        have hm := neighbor_mem_of_longest (q.cons hac) hp hmax (f i).property
        simp only [Walk.support_cons, List.mem_cons] at hm
        refine ⟨?_, (f i).property⟩
        rcases hm with heq | hm
        · exact ((G.ne_of_adj (f i).property) heq.symm).elim
        · exact hm

/-- In every nonempty finite path-fan-free graph some vertex has degree at most
`k+1`. This is a genuine auxiliary result, not the extremal theorem. -/
theorem exists_low_degree_of_no_pathFan [Fintype V] [Nonempty V]
    [DecidableRel G.Adj] (k : ℕ) (hfree : ¬ HasPathFan G (k + 2)) :
    ∃ a : V, G.degree a ≤ k + 1 := by
  obtain ⟨a, b, p, hp, hmax⟩ := Walk.exists_isPath_forall_isPath_length_le_length G
  exact ⟨a, degree_start_le_of_no_pathFan p hp hmax k hfree⟩

end Prize.JSP628
