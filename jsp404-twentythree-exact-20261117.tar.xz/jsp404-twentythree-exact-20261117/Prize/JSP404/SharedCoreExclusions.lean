import Prize.JSP404.SharedSevenExclusion
import Prize.JSP404.ThreeArcSharedRotationPowers
import Prize.JSP404.SharedCores.Core01
import Prize.JSP404.SharedCores.Core02
import Prize.JSP404.SharedCores.Core03
import Prize.JSP404.SharedCores.Core04
import Prize.JSP404.SharedCores.Core05
import Prize.JSP404.SharedCores.Core06
import Prize.JSP404.SharedCores.Core07
import Prize.JSP404.SharedCores.Core08
import Prize.JSP404.SharedCores.Core09
import Prize.JSP404.SharedCores.Core10
import Prize.JSP404.SharedCores.Core11
import Prize.JSP404.SharedCores.Core12
import Prize.JSP404.SharedCores.Core13
import Prize.JSP404.SharedCores.Core14

/-! The original seven-label exclusion and fourteen further checked cores,
indexed in the selected-core order. Every raw specification is identified
with the unchanged shared-direction necessary conditions. This aggregation
does not itself assert that the cores cover every fourteen-label family. -/
namespace Prize.JSP404.SharedCoreExclusions
open ContinuousDirection
open ContinuousDirection.ThreeArcSharedRotation (Hits)

abbrev Index := Fin 15

/-- Index zero is the original seven-label core; indices one through fourteen
refer respectively to `SharedCores.Core01` through `SharedCores.Core14`. -/
def active : Index → List (Fin 20) := ![
  [10, 12, 13, 14, 15, 16, 19],
  [10, 11, 13, 14, 15, 16, 18, 19],
  [8, 9, 11, 12, 14, 18, 19],
  [3, 10, 11, 13, 14, 15, 16, 19],
  [4, 8, 10, 12, 13, 14, 15],
  [7, 8, 10, 13, 14, 15, 17, 18, 19],
  [9, 11, 12, 13, 14, 15, 16, 18],
  [7, 8, 13, 14, 15, 16, 18],
  [7, 9, 10, 12, 15, 16, 19],
  [4, 8, 9, 10, 11, 12, 13, 15, 16, 17, 18],
  [7, 9, 10, 11, 13, 15, 16, 18, 19],
  [5, 8, 9, 12, 13, 15, 16, 17, 19],
  [8, 9, 10, 12, 13, 14, 16, 18, 19],
  [6, 10, 11, 12, 13, 16, 17, 18, 19],
  [4, 7, 9, 10, 12, 15] ]

noncomputable def rawSpec : Index → DifferenceCertificate.Spec := ![
  SharedSevenCertificate.spec,
  SharedCores.Core01.spec, SharedCores.Core02.spec,
  SharedCores.Core03.spec, SharedCores.Core04.spec,
  SharedCores.Core05.spec, SharedCores.Core06.spec,
  SharedCores.Core07.spec, SharedCores.Core08.spec,
  SharedCores.Core09.spec, SharedCores.Core10.spec,
  SharedCores.Core11.spec, SharedCores.Core12.spec,
  SharedCores.Core13.spec, SharedCores.Core14.spec ]

set_option maxRecDepth 262144 in
set_option maxHeartbeats 50000000 in
theorem rawSpec_eq (index : Index) :
    rawSpec index = ThreeArcSharedDifference.spec (active index) := by
  fin_cases index
  · exact SharedSevenExclusion.spec_eq
  all_goals rfl

theorem no_model (index : Index) :
    ¬ ∃ x, DifferenceCertificate.Model (rawSpec index) x := by
  fin_cases index
  · exact SharedSevenCertificate.no_model
  · exact SharedCores.Core01.no_model
  · exact SharedCores.Core02.no_model
  · exact SharedCores.Core03.no_model
  · exact SharedCores.Core04.no_model
  · exact SharedCores.Core05.no_model
  · exact SharedCores.Core06.no_model
  · exact SharedCores.Core07.no_model
  · exact SharedCores.Core08.no_model
  · exact SharedCores.Core09.no_model
  · exact SharedCores.Core10.no_model
  · exact SharedCores.Core11.no_model
  · exact SharedCores.Core12.no_model
  · exact SharedCores.Core13.no_model
  · exact SharedCores.Core14.no_model

theorem active_nonempty (index : Index) : ∃ i, i ∈ active index := by
  fin_cases index <;> decide

theorem no_labelled_family {V : Type*} (C : ThreeArcSharedCanonicalModel V)
    (index : Index) (e : Fin 20 → V)
    (htype : ∀ i ∈ active index, C.type (e i) = i) : False := by
  have hm := ThreeArcSharedDifference.model_of_canonical C (active index) e htype
  apply no_model index
  exact ⟨_, by rwa [rawSpec_eq index]⟩

theorem no_family {V : Type*} (C : ThreeArcSharedCanonicalModel V)
    (index : Index) (hcore : Hits C (active index)) : False := by
  classical
  obtain ⟨first, hfirst⟩ := active_nonempty index
  let fallback : V := Classical.choose (hcore first hfirst)
  let e (i : Fin 20) : V :=
    if hi : i ∈ active index then Classical.choose (hcore i hi) else fallback
  apply no_labelled_family C index e
  intro i hi
  change C.type
    (if hj : i ∈ active index then Classical.choose (hcore i hj) else fallback) = i
  rw [dite_eq_left hi]
  exact Classical.choose_spec (hcore i hi)

end Prize.JSP404.SharedCoreExclusions
