import Prize.JSP404.SharedCores.Core13Lrat
import Prize.JSP404.CertificateBatch

certificate_batch
set_option Elab.async false
namespace Prize.JSP404.SharedCores.Core13
open DifferenceCertificate DifferenceSat
set_option maxRecDepth 262144
set_option maxHeartbeats 50000000
theorem no_model : ¬ ∃ x, DifferenceCertificate.Model spec x := by
  apply DifferenceSat.accepted_false spec forms supports checked
  exact (congrArg (fun f : Sat.Fmla => f.proof []) context_eq).mp cnfRefutation.unsat

end Prize.JSP404.SharedCores.Core13

end_certificate_batch
