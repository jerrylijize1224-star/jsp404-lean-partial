import Prize.JSP404.ThreeArcShared14Coverage
import Prize.JSP404.ThreeArcOrderModelSix

/-! The checked shared-direction core cover excludes every fourteen-row family.
Only necessary conditions inherited from actual planar configurations are used. -/
namespace Prize.JSP404.ContinuousDirection
open ThreeArcOrderCertificate

theorem no_fourteen_shared_family (C : ThreeArcSharedCanonicalModel (Fin 14)) : False := by
  classical
  obtain ⟨a, b, c, d, e, f, hab, hbc, hcd, hde, hef, ha⟩ :=
    ThreeArcOrderModelGeneralSix.active_erase_sextuple C.type C.injective
  obtain ⟨i, hi⟩ := ThreeArcShared14Coverage.all_covered a b c d e f hab hbc hcd hde hef
  apply ThreeArcShared14Pool.no_family C i
  intro t ht
  have hmem : t ∈ ThreeArcOrderModelGeneral.active C.type := by
    rw [ha]
    exact hi (List.mem_toFinset.mpr ht)
  obtain ⟨v, _, hv⟩ := Finset.mem_image.mp hmem
  exact ⟨v, hv⟩

theorem TriangleCoverModel.three_card_le_thirteen {V : Type*} [Fintype V] {d : ℝ}
    (M : TriangleCoverModel V d) (hd : d < 36 / 5) : M.threeVertices.card ≤ 13 := by
  by_contra hn
  have h14 : 14 ≤ M.threeVertices.card := by omega
  obtain ⟨C⟩ := M.exists_fourteen_sharedCanonical hd h14
  exact no_fourteen_shared_family C

theorem TriangleCoverModel.card_le_twenty_two {V : Type*} [Fintype V] {d : ℝ}
    (M : TriangleCoverModel V d) (hd0 : 0 ≤ d) (hd : d < 36 / 5) :
    Fintype.card V ≤ 22 := by
  have := M.card_le_nine_add_three hd0 hd
  have := M.three_card_le_thirteen hd
  omega

end Prize.JSP404.ContinuousDirection
