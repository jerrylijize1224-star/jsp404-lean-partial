import Prize.JSP404.ThreeArcSharedDirections
import Mathlib.Algebra.Order.Field.Pi
import Mathlib.Data.Fintype.Fin
import Mathlib.Tactic.FinCases

/-! A common interior perturbation of a finite canonical shared-direction
family. Every row moves by eta and every shared direction by 2 eta. The
canonical types are preserved. Strict endpoints then permit a reflection of
half-open cells, with an explicit action on the twenty canonical types. -/
namespace Prize.JSP404.ContinuousDirection.ThreeArcSharedReflection

def StrictRowMem10 (a : Fin 3 → ℝ) (x : ℝ) : Prop :=
  (a 0 < x ∧ x < a 2 + 4 - 10) ∨
  (a 1 < x ∧ x < a 0 + 4) ∨ (a 2 < x ∧ x < a 1 + 4)

def StrictMember10 (a : Fin 3 → ℝ) (x : ℝ) : Prop :=
  StrictRowMem10 a (x - 10) ∨ StrictRowMem10 a x ∨ StrictRowMem10 a (x + 10)

theorem strictRowMem_implies_mem {a : Fin 3 → ℝ} {x : ℝ}
    (h : StrictRowMem10 a x) : SharedRowMem10 a x := by
  rcases h with h | h | h
  · exact Or.inl ⟨h.1.le, h.2⟩
  · exact Or.inr (Or.inl ⟨h.1.le, h.2⟩)
  · exact Or.inr (Or.inr ⟨h.1.le, h.2⟩)

theorem strictMember_implies_mem {a : Fin 3 → ℝ} {x : ℝ}
    (h : StrictMember10 a x) : SharedMember10 a x := by
  rcases h with h | h | h
  · exact Or.inl (strictRowMem_implies_mem h)
  · exact Or.inr (Or.inl (strictRowMem_implies_mem h))
  · exact Or.inr (Or.inr (strictRowMem_implies_mem h))

theorem row_interior_margin (a : Fin 3 → ℝ) (x : ℝ) (h : SharedRowMem10 a x) :
    ∃ r : ℝ, 0 < r ∧ ∀ eta : ℝ, 0 < eta → eta < r →
      StrictRowMem10 (fun k => a k + eta) (x + 2 * eta) := by
  rcases h with h | h | h
  · refine ⟨a 2 + 4 - 10 - x, by linarith [h.2], ?_⟩
    intro eta heta hr
    left
    constructor <;> linarith [h.1, h.2]
  · refine ⟨a 0 + 4 - x, by linarith [h.2], ?_⟩
    intro eta heta hr
    right; left
    constructor <;> linarith [h.1, h.2]
  · refine ⟨a 1 + 4 - x, by linarith [h.2], ?_⟩
    intro eta heta hr
    right; right
    constructor <;> linarith [h.1, h.2]

theorem member_interior_margin (a : Fin 3 → ℝ) (x : ℝ) (h : SharedMember10 a x) :
    ∃ r : ℝ, 0 < r ∧ ∀ eta : ℝ, 0 < eta → eta < r →
      StrictMember10 (fun k => a k + eta) (x + 2 * eta) := by
  rcases h with h | h | h
  · obtain ⟨r, hr, hm⟩ := row_interior_margin a (x - 10) h
    refine ⟨r, hr, ?_⟩
    intro eta heta hsmall
    left
    convert hm eta heta hsmall using 1 <;> ring
  · obtain ⟨r, hr, hm⟩ := row_interior_margin a x h
    exact ⟨r, hr, fun eta heta hsmall => Or.inr (Or.inl (hm eta heta hsmall))⟩
  · obtain ⟨r, hr, hm⟩ := row_interior_margin a (x + 10) h
    refine ⟨r, hr, ?_⟩
    intro eta heta hsmall
    right; right
    convert hm eta heta hsmall using 1 <;> ring

theorem turn_translate {x y : ℝ} (h : SharedTurn10 x y) (a : ℝ) :
    SharedTurn10 (x + a) (y + a) := by
  rcases h with h | h
  · left; constructor <;> linarith [h.1, h.2]
  · right; constructor <;> linarith [h.1, h.2]

theorem triangle_translate {u v w : ℝ} (h : SharedTriangle10 u v w) (a : ℝ) :
    SharedTriangle10 (u + a) (v + a) (w + a) := by
  rcases h with h | h
  · exact Or.inl ⟨turn_translate h.1 a, turn_translate h.2.1 a, turn_translate h.2.2 a⟩
  · exact Or.inr ⟨turn_translate h.1 a, turn_translate h.2.1 a, turn_translate h.2.2 a⟩

structure InteriorModel (V : Type*) extends ThreeArcSharedCanonicalModel V where
  cell_lower : ∀ i k, (ThreeArcCanonical.starts (type i) k : ℝ) < start i k
  direction_pos : ∀ i j, i ≠ j → 0 < direction i j
  covered_left_strict : ∀ i j, i ≠ j → StrictMember10 (start i) (direction i j)
  covered_right_strict : ∀ i j, i ≠ j → StrictMember10 (start j) (direction i j + 5)

/-- The finite simultaneous perturbation preserves the original type function.
No additional mathematical hypothesis is added to the finite-family problem. -/
theorem exists_interior {V : Type*} [Fintype V] (C : ThreeArcSharedCanonicalModel V) :
    ∃ eta : ℝ, 0 < eta ∧ ∃ I : InteriorModel V,
      I.type = C.type ∧
      (∀ i k, I.start i k = C.start i k + eta) ∧
      (∀ i j, I.direction i j = C.direction i j + 2 * eta) := by
  classical
  have hleft (i j : V) : ∃ r : ℝ, 0 < r ∧ ∀ eta : ℝ, 0 < eta → eta < r → i ≠ j →
      StrictMember10 (fun k => C.start i k + eta) (C.direction i j + 2 * eta) := by
    by_cases hij : i = j
    · exact ⟨1, by norm_num, fun _ _ _ hne => (hne hij).elim⟩
    · obtain ⟨r, hr, hm⟩ := member_interior_margin _ _ (C.covered_left i j hij)
      exact ⟨r, hr, fun eta heta hsmall _ => hm eta heta hsmall⟩
  have hright (i j : V) : ∃ r : ℝ, 0 < r ∧ ∀ eta : ℝ, 0 < eta → eta < r → i ≠ j →
      StrictMember10 (fun k => C.start j k + eta) ((C.direction i j + 5) + 2 * eta) := by
    by_cases hij : i = j
    · exact ⟨1, by norm_num, fun _ _ _ hne => (hne hij).elim⟩
    · obtain ⟨r, hr, hm⟩ := member_interior_margin _ _ (C.covered_right i j hij)
      exact ⟨r, hr, fun eta heta hsmall _ => hm eta heta hsmall⟩
  let leftMargin (p : V × V) : ℝ := Classical.choose (hleft p.1 p.2)
  let rightMargin (p : V × V) : ℝ := Classical.choose (hright p.1 p.2)
  have hleftSpec (p : V × V) := Classical.choose_spec (hleft p.1 p.2)
  have hrightSpec (p : V × V) := Classical.choose_spec (hright p.1 p.2)
  let T := (V × Fin 3) ⊕ (V × V) ⊕ (V × V) ⊕ (V × V) ⊕ V
  let slack : T → ℝ := Sum.elim
    (fun p => (ThreeArcCanonical.starts (C.type p.1) p.2 : ℝ) + 1 - C.start p.1 p.2)
    (Sum.elim (fun p => if p.1 = p.2 then 1 else 10 - C.direction p.1 p.2)
      (Sum.elim leftMargin (Sum.elim rightMargin (fun i => 10 - C.start i 2))))
  have hslack : ∀ t : T, 0 < slack t := by
    intro t
    rcases t with p | t
    · change 0 < (ThreeArcCanonical.starts (C.type p.1) p.2 : ℝ) + 1 - C.start p.1 p.2
      linarith [(C.cell p.1 p.2).2]
    · rcases t with p | t
      · by_cases hp : p.1 = p.2
        · simp [slack, hp]
        · change 0 < (if p.1 = p.2 then 1 else 10 - C.direction p.1 p.2)
          rw [if_neg hp]
          linarith [(C.direction_bounds p.1 p.2 hp).2]
      · rcases t with p | t
        · exact (hleftSpec p).1
        · rcases t with p | i
          · exact (hrightSpec p).1
          · change 0 < 10 - C.start i 2
            linarith [(C.normalized i).2]
  obtain ⟨epsilon, hepsilon, hsmall⟩ :=
    Pi.exists_forall_pos_add_lt (x := fun _ : T => (0 : ℝ)) (y := slack) hslack
  have hsmall' (t : T) : epsilon < slack t := by simpa using hsmall t
  let eta := epsilon / 3
  have heta : 0 < eta := by dsimp [eta]; linarith
  have hetaeps : eta < epsilon := by dsimp [eta]; linarith
  have htwo : 2 * eta < epsilon := by dsimp [eta]; linarith
  let a (i : V) (k : Fin 3) := C.start i k + eta
  let q (i j : V) := C.direction i j + 2 * eta
  have hcell (i : V) (k : Fin 3) :
      (ThreeArcCanonical.starts (C.type i) k : ℝ) ≤ a i k ∧
        a i k < (ThreeArcCanonical.starts (C.type i) k : ℝ) + 1 := by
    have h := hsmall' (Sum.inl (i, k))
    change epsilon < (ThreeArcCanonical.starts (C.type i) k : ℝ) + 1 - C.start i k at h
    dsimp [a]
    constructor <;> linarith [(C.cell i k).1]
  have hcellLower (i : V) (k : Fin 3) :
      (ThreeArcCanonical.starts (C.type i) k : ℝ) < a i k := by
    dsimp [a]
    linarith [(C.cell i k).1]
  have hnorm (i : V) : 0 ≤ a i 0 ∧ a i 2 < 10 := by
    have h := hsmall' (Sum.inr (Sum.inr (Sum.inr (Sum.inr i))))
    change epsilon < 10 - C.start i 2 at h
    dsimp [a]
    constructor <;> linarith [(C.normalized i).1]
  have hq (i j : V) (hij : i ≠ j) : 0 < q i j ∧ q i j < 10 := by
    have h := hsmall' (Sum.inr (Sum.inl (i, j)))
    change epsilon < (if i = j then 1 else 10 - C.direction i j) at h
    rw [if_neg hij] at h
    dsimp [q]
    constructor <;> linarith [(C.direction_bounds i j hij).1]
  have hleftStrict (i j : V) (hij : i ≠ j) : StrictMember10 (a i) (q i j) := by
    have h := hsmall' (Sum.inr (Sum.inr (Sum.inl (i, j))))
    change epsilon < leftMargin (i, j) at h
    exact (hleftSpec (i, j)).2 eta heta (lt_trans hetaeps h) hij
  have hrightStrict (i j : V) (hij : i ≠ j) : StrictMember10 (a j) (q i j + 5) := by
    have h := hsmall' (Sum.inr (Sum.inr (Sum.inr (Sum.inl (i, j)))))
    change epsilon < rightMargin (i, j) at h
    have hm := (hrightSpec (i, j)).2 eta heta (lt_trans hetaeps h) hij
    have he : (C.direction i j + 5) + 2 * eta = q i j + 5 := by dsimp [q]; ring
    rwa [he] at hm
  let D : ThreeArcSharedCanonicalModel V := {
    type := C.type, injective := C.injective, start := a, direction := q,
    cell := hcell, normalized := hnorm,
    order01 := by intro i; dsimp [a]; linarith [C.order01 i],
    order12 := by intro i; dsimp [a]; linarith [C.order12 i],
    period := by intro i; dsimp [a]; linarith [C.period i],
    width0 := by intro i; dsimp [a]; linarith [C.width0 i],
    width1 := by intro i; dsimp [a]; linarith [C.width1 i],
    width2 := by intro i; dsimp [a]; linarith [C.width2 i],
    direction_bounds := fun i j hij => ⟨(hq i j hij).1.le, (hq i j hij).2⟩,
    covered_left := fun i j hij => strictMember_implies_mem (hleftStrict i j hij),
    covered_right := fun i j hij => strictMember_implies_mem (hrightStrict i j hij),
    triangle := fun i j k hij hik hjk => triangle_translate (C.triangle i j k hij hik hjk) (2 * eta) }
  refine ⟨eta, heta, {
    toThreeArcSharedCanonicalModel := D,
    cell_lower := hcellLower, direction_pos := fun i j hij => (hq i j hij).1,
    covered_left_strict := hleftStrict, covered_right_strict := hrightStrict }, rfl, ?_, ?_⟩
  · intro i k
    rfl
  · intro i j
    rfl


abbrev Label := Fin 20

def reflectType : Label → Label := ![
  15, 18, 6, 12, 19, 8, 2, 16, 5, 10, 9, 14, 3, 17, 11, 0, 7, 13, 1, 4]

def belowSix (t : Label) : Prop := ThreeArcCanonical.starts t 1 < 6
instance (t : Label) : Decidable (belowSix t) :=
  inferInstanceAs (Decidable (ThreeArcCanonical.starts t 1 < 6))

theorem reflectType_injective : Function.Injective reflectType := by decide +kernel

theorem reflection_starts_bounds : ∀ t : Label,
    ThreeArcCanonical.starts t 0 ≤ 3 ∧ 6 ≤ ThreeArcCanonical.starts t 2 := by
  decide +kernel

theorem reflectType_starts_low : ∀ t : Label, belowSix t →
    ThreeArcCanonical.starts (reflectType t) 0 = 5 - ThreeArcCanonical.starts t 1 ∧
    ThreeArcCanonical.starts (reflectType t) 1 = 5 - ThreeArcCanonical.starts t 0 ∧
    ThreeArcCanonical.starts (reflectType t) 2 = 15 - ThreeArcCanonical.starts t 2 := by
  decide +kernel

theorem reflectType_starts_high : ∀ t : Label, ¬ belowSix t →
    ThreeArcCanonical.starts (reflectType t) 0 = 5 - ThreeArcCanonical.starts t 0 ∧
    ThreeArcCanonical.starts (reflectType t) 1 = 15 - ThreeArcCanonical.starts t 2 ∧
    ThreeArcCanonical.starts (reflectType t) 2 = 15 - ThreeArcCanonical.starts t 1 := by
  decide +kernel

def reflectStart (t : Label) (a : Fin 3 → ℝ) : Fin 3 → ℝ :=
  if belowSix t then ![6 - a 1, 6 - a 0, 16 - a 2]
  else ![6 - a 0, 16 - a 2, 16 - a 1]

theorem reflectStart_cell (t : Label) (a : Fin 3 → ℝ)
    (hcell : ∀ k, (ThreeArcCanonical.starts t k : ℝ) < a k ∧
      a k < (ThreeArcCanonical.starts t k : ℝ) + 1) :
    ∀ k, (ThreeArcCanonical.starts (reflectType t) k : ℝ) < reflectStart t a k ∧
      reflectStart t a k < (ThreeArcCanonical.starts (reflectType t) k : ℝ) + 1 := by
  by_cases ht : belowSix t
  · obtain ⟨h0, h1, h2⟩ := reflectType_starts_low t ht
    intro k
    fin_cases k
    · simp only [reflectStart, if_pos ht]
      change (ThreeArcCanonical.starts (reflectType t) 0 : ℝ) < 6 - a 1 ∧
        6 - a 1 < (ThreeArcCanonical.starts (reflectType t) 0 : ℝ) + 1
      rw [h0]
      push_cast
      constructor <;> linarith [(hcell 1).1, (hcell 1).2]
    · simp only [reflectStart, if_pos ht]
      change (ThreeArcCanonical.starts (reflectType t) 1 : ℝ) < 6 - a 0 ∧
        6 - a 0 < (ThreeArcCanonical.starts (reflectType t) 1 : ℝ) + 1
      rw [h1]
      push_cast
      constructor <;> linarith [(hcell 0).1, (hcell 0).2]
    · simp only [reflectStart, if_pos ht]
      change (ThreeArcCanonical.starts (reflectType t) 2 : ℝ) < 16 - a 2 ∧
        16 - a 2 < (ThreeArcCanonical.starts (reflectType t) 2 : ℝ) + 1
      rw [h2]
      push_cast
      constructor <;> linarith [(hcell 2).1, (hcell 2).2]
  · obtain ⟨h0, h1, h2⟩ := reflectType_starts_high t ht
    intro k
    fin_cases k
    · simp only [reflectStart, if_neg ht]
      change (ThreeArcCanonical.starts (reflectType t) 0 : ℝ) < 6 - a 0 ∧
        6 - a 0 < (ThreeArcCanonical.starts (reflectType t) 0 : ℝ) + 1
      rw [h0]
      push_cast
      constructor <;> linarith [(hcell 0).1, (hcell 0).2]
    · simp only [reflectStart, if_neg ht]
      change (ThreeArcCanonical.starts (reflectType t) 1 : ℝ) < 16 - a 2 ∧
        16 - a 2 < (ThreeArcCanonical.starts (reflectType t) 1 : ℝ) + 1
      rw [h1]
      push_cast
      constructor <;> linarith [(hcell 2).1, (hcell 2).2]
    · simp only [reflectStart, if_neg ht]
      change (ThreeArcCanonical.starts (reflectType t) 2 : ℝ) < 16 - a 1 ∧
        16 - a 1 < (ThreeArcCanonical.starts (reflectType t) 2 : ℝ) + 1
      rw [h2]
      push_cast
      constructor <;> linarith [(hcell 1).1, (hcell 1).2]

theorem reflectStart_properties (t : Label) (a : Fin 3 → ℝ)
    (hcell : ∀ k, (ThreeArcCanonical.starts t k : ℝ) < a k ∧
      a k < (ThreeArcCanonical.starts t k : ℝ) + 1)
    (h01 : a 0 < a 1) (h12 : a 1 < a 2) (hperiod : a 2 < a 0 + 10)
    (hw0 : a 0 < a 2 - 6) (hw1 : a 1 < a 0 + 4) (hw2 : a 2 < a 1 + 4) :
    (0 ≤ reflectStart t a 0 ∧ reflectStart t a 2 < 10) ∧
    reflectStart t a 0 < reflectStart t a 1 ∧
    reflectStart t a 1 < reflectStart t a 2 ∧
    reflectStart t a 2 < reflectStart t a 0 + 10 ∧
    reflectStart t a 0 < reflectStart t a 2 - 6 ∧
    reflectStart t a 1 < reflectStart t a 0 + 4 ∧
    reflectStart t a 2 < reflectStart t a 1 + 4 := by
  have ha4 : a 0 < 4 := by
    have haI := (reflection_starts_bounds t).1
    have haR : (ThreeArcCanonical.starts t 0 : ℝ) ≤ 3 := by exact_mod_cast haI
    linarith [(hcell 0).2]
  have hc6 : 6 < a 2 := by
    have hcI := (reflection_starts_bounds t).2
    have hcR : (6 : ℝ) ≤ ThreeArcCanonical.starts t 2 := by exact_mod_cast hcI
    linarith [(hcell 2).1]
  by_cases ht : belowSix t
  · have hb6 : a 1 < 6 := by
      have hbI : ThreeArcCanonical.starts t 1 + 1 ≤ 6 := by
        change ThreeArcCanonical.starts t 1 < 6 at ht
        omega
      have hbR : (ThreeArcCanonical.starts t 1 : ℝ) + 1 ≤ 6 := by exact_mod_cast hbI
      linarith [(hcell 1).2]
    simp only [reflectStart, if_pos ht]
    change (0 ≤ 6 - a 1 ∧ 16 - a 2 < 10) ∧
      6 - a 1 < 6 - a 0 ∧ 6 - a 0 < 16 - a 2 ∧
      16 - a 2 < (6 - a 1) + 10 ∧
      6 - a 1 < (16 - a 2) - 6 ∧
      6 - a 0 < (6 - a 1) + 4 ∧ 16 - a 2 < (6 - a 0) + 4
    refine ⟨⟨?_, ?_⟩, ?_, ?_, ?_, ?_, ?_, ?_⟩ <;> linarith
  · have hb6 : 6 < a 1 := by
      have hbI : 6 ≤ ThreeArcCanonical.starts t 1 := by
        change ¬ ThreeArcCanonical.starts t 1 < 6 at ht
        omega
      have hbR : (6 : ℝ) ≤ ThreeArcCanonical.starts t 1 := by exact_mod_cast hbI
      linarith [(hcell 1).1]
    simp only [reflectStart, if_neg ht]
    change (0 ≤ 6 - a 0 ∧ 16 - a 1 < 10) ∧
      6 - a 0 < 16 - a 2 ∧ 16 - a 2 < 16 - a 1 ∧
      16 - a 1 < (6 - a 0) + 10 ∧
      6 - a 0 < (16 - a 1) - 6 ∧
      16 - a 2 < (6 - a 0) + 4 ∧ 16 - a 1 < (16 - a 2) + 4
    refine ⟨⟨?_, ?_⟩, ?_, ?_, ?_, ?_, ?_, ?_⟩ <;> linarith

/-- Strict interval endpoints reverse without losing the new strict upper bound. -/
theorem strictRow_reflect (t : Label) (a : Fin 3 → ℝ) {y : ℝ}
    (h : StrictRowMem10 a y) :
    ∃ z : ℤ, StrictRowMem10 (reflectStart t a) (10 - y + 10 * z) := by
  by_cases ht : belowSix t
  · simp only [reflectStart, if_pos ht]
    rcases h with h | h | h
    · refine ⟨0, Or.inr (Or.inr ?_)⟩
      change 16 - a 2 < 10 - y + 10 * (0 : ℤ) ∧
        10 - y + 10 * (0 : ℤ) < (6 - a 0) + 4
      constructor <;> norm_num <;> linarith [h.1, h.2]
    · refine ⟨0, Or.inr (Or.inl ?_)⟩
      change 6 - a 0 < 10 - y + 10 * (0 : ℤ) ∧
        10 - y + 10 * (0 : ℤ) < (6 - a 1) + 4
      constructor <;> norm_num <;> linarith [h.1, h.2]
    · refine ⟨0, Or.inl ?_⟩
      change 6 - a 1 < 10 - y + 10 * (0 : ℤ) ∧
        10 - y + 10 * (0 : ℤ) < (16 - a 2) + 4 - 10
      constructor <;> norm_num <;> linarith [h.1, h.2]
  · simp only [reflectStart, if_neg ht]
    rcases h with h | h | h
    · refine ⟨0, Or.inr (Or.inl ?_)⟩
      change 16 - a 2 < 10 - y + 10 * (0 : ℤ) ∧
        10 - y + 10 * (0 : ℤ) < (6 - a 0) + 4
      constructor <;> norm_num <;> linarith [h.1, h.2]
    · refine ⟨0, Or.inl ?_⟩
      change 6 - a 0 < 10 - y + 10 * (0 : ℤ) ∧
        10 - y + 10 * (0 : ℤ) < (16 - a 1) + 4 - 10
      constructor <;> norm_num <;> linarith [h.1, h.2]
    · refine ⟨1, Or.inr (Or.inr ?_)⟩
      change 16 - a 1 < 10 - y + 10 * (1 : ℤ) ∧
        10 - y + 10 * (1 : ℤ) < (16 - a 2) + 4
      constructor <;> norm_num <;> linarith [h.1, h.2]

theorem strictMember_reflect_periodic (t : Label) (a : Fin 3 → ℝ) {x : ℝ}
    (h : StrictMember10 a x) :
    ∃ z : ℤ, StrictRowMem10 (reflectStart t a) (10 - x + 10 * z) := by
  rcases h with h | h | h
  · obtain ⟨z, hz⟩ := strictRow_reflect t a h
    refine ⟨z + 1, ?_⟩
    have he : 10 - (x - 10) + 10 * (z : ℝ) =
        10 - x + 10 * ((z + 1 : ℤ) : ℝ) := by push_cast; ring
    rwa [he] at hz
  · exact strictRow_reflect t a h
  · obtain ⟨z, hz⟩ := strictRow_reflect t a h
    refine ⟨z - 1, ?_⟩
    have he : 10 - (x + 10) + 10 * (z : ℝ) =
        10 - x + 10 * ((z - 1 : ℤ) : ℝ) := by push_cast; ring
    rwa [he] at hz

theorem strictMember_of_periodic {a : Fin 3 → ℝ}
    (ha : 0 ≤ a 0) (hab : a 0 < a 1) (hbc : a 1 < a 2) (hc : a 2 < 10)
    {x : ℝ} (hx : 0 ≤ x ∧ x < 15)
    (hm : ∃ z : ℤ, StrictRowMem10 a (x + 10 * z)) : StrictMember10 a x := by
  obtain ⟨z, hz⟩ := hm
  obtain ⟨hl, hh⟩ := sharedRowMem10_bounds ha hab hbc hc (strictRowMem_implies_mem hz)
  have hzlo : (-1 : ℤ) ≤ z := by
    by_contra hn
    have he : z ≤ -2 := by omega
    have he' : (z : ℝ) ≤ -2 := by exact_mod_cast he
    linarith [hx.2]
  have hzhi : z ≤ (1 : ℤ) := by
    by_contra hn
    have he : 2 ≤ z := by omega
    have he' : (2 : ℝ) ≤ z := by exact_mod_cast he
    linarith [hx.1]
  have hcases : z = -1 ∨ z = 0 ∨ z = 1 := by omega
  rcases hcases with rfl | rfl | rfl
  · left; simpa [sub_eq_add_neg] using hz
  · right; left; simpa using hz
  · right; right; simpa using hz

def reflectDirection (q : ℝ) : ℝ := 10 - q

theorem reflectDirection_bounds {q : ℝ} (hq : 0 < q ∧ q < 10) :
    0 < reflectDirection q ∧ reflectDirection q < 10 := by
  unfold reflectDirection
  constructor <;> linarith [hq.1, hq.2]

theorem turn_reflect {x y : ℝ} (h : SharedTurn10 x y) :
    SharedTurn10 (reflectDirection y) (reflectDirection x) := by
  rcases h with h | h
  · left; unfold reflectDirection; constructor <;> linarith [h.1, h.2]
  · right; unfold reflectDirection; constructor <;> linarith [h.1, h.2]

theorem triangle_reflect {u v w : ℝ} (h : SharedTriangle10 u v w) :
    SharedTriangle10 (reflectDirection u) (reflectDirection v) (reflectDirection w) := by
  rcases h with h | h
  · exact Or.inr ⟨turn_reflect h.1, turn_reflect h.2.1, turn_reflect h.2.2⟩
  · exact Or.inl ⟨turn_reflect h.1, turn_reflect h.2.1, turn_reflect h.2.2⟩

noncomputable def reflectInterior {V : Type*} (I : InteriorModel V) : InteriorModel V := by
  have hcell (i : V) (k : Fin 3) :
      (ThreeArcCanonical.starts (I.type i) k : ℝ) < I.start i k ∧
        I.start i k < (ThreeArcCanonical.starts (I.type i) k : ℝ) + 1 :=
    ⟨I.cell_lower i k, (I.cell i k).2⟩
  have hp (i : V) := reflectStart_properties (I.type i) (I.start i) (hcell i)
    (I.order01 i) (I.order12 i) (I.period i) (I.width0 i) (I.width1 i) (I.width2 i)
  let a (i : V) := reflectStart (I.type i) (I.start i)
  let q (i j : V) := reflectDirection (I.direction i j)
  have hnewcell (i : V) := reflectStart_cell (I.type i) (I.start i) (hcell i)
  have hq (i j : V) (hij : i ≠ j) : 0 < q i j ∧ q i j < 10 :=
    reflectDirection_bounds ⟨I.direction_pos i j hij, (I.direction_bounds i j hij).2⟩
  have hleft (i j : V) (hij : i ≠ j) : StrictMember10 (a i) (q i j) := by
    apply strictMember_of_periodic (hp i).1.1 (hp i).2.1 (hp i).2.2.1 (hp i).1.2
      ⟨(hq i j hij).1.le, by linarith [(hq i j hij).2]⟩
    exact strictMember_reflect_periodic (I.type i) (I.start i) (I.covered_left_strict i j hij)
  have hright (i j : V) (hij : i ≠ j) : StrictMember10 (a j) (q i j + 5) := by
    apply strictMember_of_periodic (hp j).1.1 (hp j).2.1 (hp j).2.2.1 (hp j).1.2
      ⟨by linarith [(hq i j hij).1], by linarith [(hq i j hij).2]⟩
    obtain ⟨z, hz⟩ := strictMember_reflect_periodic (I.type j) (I.start j)
      (I.covered_right_strict i j hij)
    refine ⟨z - 1, ?_⟩
    have he : 10 - (I.direction i j + 5) + 10 * (z : ℝ) =
        (q i j + 5) + 10 * ((z - 1 : ℤ) : ℝ) := by dsimp [q, reflectDirection]; push_cast; ring
    rwa [he] at hz
  let D : ThreeArcSharedCanonicalModel V := {
    type := fun i => reflectType (I.type i),
    injective := reflectType_injective.comp I.injective,
    start := a, direction := q,
    cell := fun i k => ⟨(hnewcell i k).1.le, (hnewcell i k).2⟩,
    normalized := fun i => (hp i).1,
    order01 := fun i => (hp i).2.1,
    order12 := fun i => (hp i).2.2.1,
    period := fun i => (hp i).2.2.2.1,
    width0 := fun i => (hp i).2.2.2.2.1,
    width1 := fun i => (hp i).2.2.2.2.2.1,
    width2 := fun i => (hp i).2.2.2.2.2.2,
    direction_bounds := fun i j hij => ⟨(hq i j hij).1.le, (hq i j hij).2⟩,
    covered_left := fun i j hij => strictMember_implies_mem (hleft i j hij),
    covered_right := fun i j hij => strictMember_implies_mem (hright i j hij),
    triangle := fun i j k hij hik hjk => triangle_reflect (I.triangle i j k hij hik hjk) }
  exact {
    toThreeArcSharedCanonicalModel := D,
    cell_lower := fun i k => (hnewcell i k).1,
    direction_pos := fun i j hij => (hq i j hij).1,
    covered_left_strict := hleft, covered_right_strict := hright }

theorem reflectInterior_type {V : Type*} (I : InteriorModel V) (i : V) :
    (reflectInterior I).type i = reflectType (I.type i) := rfl

theorem exists_reflected {V : Type*} [Fintype V] (C : ThreeArcSharedCanonicalModel V) :
    ∃ D : ThreeArcSharedCanonicalModel V, ∀ i, D.type i = reflectType (C.type i) := by
  obtain ⟨eta, heta, I, htype, _, _⟩ := exists_interior C
  refine ⟨(reflectInterior I).toThreeArcSharedCanonicalModel, ?_⟩
  intro i
  change reflectType (I.type i) = reflectType (C.type i)
  rw [htype]

noncomputable def reflect {V : Type*} [Fintype V] (C : ThreeArcSharedCanonicalModel V) :
    ThreeArcSharedCanonicalModel V := Classical.choose (exists_reflected C)

theorem reflect_type {V : Type*} [Fintype V] (C : ThreeArcSharedCanonicalModel V) (i : V) :
    (reflect C).type i = reflectType (C.type i) := Classical.choose_spec (exists_reflected C) i

end Prize.JSP404.ContinuousDirection.ThreeArcSharedReflection
