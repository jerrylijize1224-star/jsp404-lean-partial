import Prize.JSP404.ThreeArcSharedSymmetry
import Prize.JSP404.SharedCoreExclusions
import Mathlib.Tactic.FinCases

/-! A finite pool of proved exclusions. Literal lists make the coverage checks
cheap; cached_match identifies every list with an actual dihedral preimage.
The descriptor table and all finite equalities are kernel checked. -/
namespace Prize.JSP404.ThreeArcShared14Pool
open ContinuousDirection
open ThreeArcOrderCertificate
open ContinuousDirection.ThreeArcSharedSymmetry (Hits)

set_option maxRecDepth 8192
set_option maxHeartbeats 5000000

inductive Origin where
  | old (index : ThreeArcOrder15Data.Index)
  | shared (index : SharedCoreExclusions.Index)

structure Descriptor where
  origin : Origin
  flip : Bool
  rotation : Fin 10

abbrev Index := Fin 251

def descriptorRows (chunk : ℕ) : Array Descriptor :=
  match chunk with
  | 0 => #[⟨.old 0, false, 0⟩, ⟨.old 0, true, 0⟩, ⟨.shared 14, false, 0⟩, ⟨.old 0, false, 1⟩, ⟨.shared 14, false, 2⟩, ⟨.old 0, false, 2⟩, ⟨.shared 14, false, 3⟩, ⟨.shared 14, true, 0⟩, ⟨.shared 14, true, 2⟩, ⟨.old 0, true, 1⟩, ⟨.shared 0, false, 5⟩, ⟨.shared 7, false, 6⟩, ⟨.shared 7, false, 0⟩, ⟨.shared 7, true, 1⟩, ⟨.shared 7, false, 4⟩, ⟨.shared 7, true, 5⟩]
  | 1 => #[⟨.shared 0, false, 3⟩, ⟨.shared 0, true, 0⟩, ⟨.shared 0, false, 4⟩, ⟨.shared 7, true, 4⟩, ⟨.shared 0, false, 2⟩, ⟨.shared 7, false, 5⟩, ⟨.shared 7, false, 1⟩, ⟨.shared 0, true, 4⟩, ⟨.shared 0, true, 5⟩, ⟨.shared 7, true, 0⟩, ⟨.shared 7, true, 6⟩, ⟨.shared 0, true, 2⟩, ⟨.shared 0, true, 3⟩, ⟨.shared 0, false, 0⟩, ⟨.shared 2, false, 5⟩, ⟨.shared 2, false, 8⟩]
  | 2 => #[⟨.shared 2, true, 2⟩, ⟨.shared 2, true, 5⟩, ⟨.shared 2, true, 8⟩, ⟨.shared 2, false, 1⟩, ⟨.shared 2, false, 4⟩, ⟨.shared 4, true, 1⟩, ⟨.shared 4, false, 8⟩, ⟨.shared 4, false, 2⟩, ⟨.shared 4, true, 0⟩, ⟨.shared 4, false, 0⟩, ⟨.shared 4, false, 3⟩, ⟨.shared 4, false, 1⟩, ⟨.shared 4, true, 8⟩, ⟨.shared 4, true, 3⟩, ⟨.shared 4, true, 2⟩, ⟨.shared 6, true, 9⟩]
  | 3 => #[⟨.shared 6, false, 2⟩, ⟨.shared 6, false, 7⟩, ⟨.shared 6, true, 1⟩, ⟨.shared 6, false, 1⟩, ⟨.shared 6, true, 5⟩, ⟨.shared 6, false, 0⟩, ⟨.shared 6, false, 6⟩, ⟨.shared 6, true, 4⟩, ⟨.shared 6, true, 3⟩, ⟨.old 17, false, 0⟩, ⟨.shared 2, true, 6⟩, ⟨.old 17, true, 2⟩, ⟨.shared 1, false, 5⟩, ⟨.shared 1, false, 4⟩, ⟨.shared 1, true, 2⟩, ⟨.shared 1, false, 0⟩]
  | 4 => #[⟨.shared 2, true, 7⟩, ⟨.shared 2, true, 1⟩, ⟨.shared 1, true, 0⟩, ⟨.shared 1, false, 3⟩, ⟨.shared 1, true, 3⟩, ⟨.shared 1, true, 5⟩, ⟨.shared 1, true, 4⟩, ⟨.shared 1, false, 2⟩, ⟨.shared 6, true, 0⟩, ⟨.shared 6, false, 8⟩, ⟨.old 17, true, 3⟩, ⟨.shared 11, false, 8⟩, ⟨.shared 2, false, 9⟩, ⟨.old 17, true, 1⟩, ⟨.shared 11, true, 2⟩, ⟨.shared 13, false, 1⟩]
  | 5 => #[⟨.shared 13, false, 2⟩, ⟨.shared 13, true, 9⟩, ⟨.old 17, false, 8⟩, ⟨.shared 13, true, 5⟩, ⟨.old 17, false, 1⟩, ⟨.shared 2, true, 9⟩, ⟨.shared 11, false, 4⟩, ⟨.old 17, true, 8⟩, ⟨.old 17, false, 3⟩, ⟨.shared 10, true, 9⟩, ⟨.shared 13, false, 6⟩, ⟨.shared 10, false, 5⟩, ⟨.old 17, true, 0⟩, ⟨.shared 13, true, 4⟩, ⟨.shared 10, false, 3⟩, ⟨.shared 10, true, 7⟩]
  | 6 => #[⟨.shared 10, false, 4⟩, ⟨.shared 10, true, 3⟩, ⟨.shared 13, false, 0⟩, ⟨.shared 11, false, 5⟩, ⟨.shared 10, true, 8⟩, ⟨.shared 11, true, 1⟩, ⟨.shared 13, true, 1⟩, ⟨.old 17, false, 2⟩, ⟨.shared 10, false, 9⟩, ⟨.shared 10, false, 7⟩, ⟨.shared 13, false, 8⟩, ⟨.shared 11, false, 0⟩, ⟨.shared 10, true, 5⟩, ⟨.shared 13, true, 3⟩, ⟨.shared 10, true, 4⟩, ⟨.shared 10, false, 8⟩]
  | 7 => #[⟨.shared 12, false, 0⟩, ⟨.shared 10, true, 6⟩, ⟨.shared 10, true, 0⟩, ⟨.old 53, true, 7⟩, ⟨.old 53, false, 4⟩, ⟨.old 53, false, 9⟩, ⟨.shared 11, false, 7⟩, ⟨.shared 10, false, 1⟩, ⟨.shared 10, true, 1⟩, ⟨.old 53, true, 2⟩, ⟨.shared 10, false, 2⟩, ⟨.shared 10, false, 6⟩, ⟨.old 53, false, 2⟩, ⟨.shared 11, true, 0⟩, ⟨.old 53, true, 0⟩, ⟨.shared 10, true, 2⟩]
  | 8 => #[⟨.shared 13, true, 8⟩, ⟨.shared 10, false, 0⟩, ⟨.shared 13, true, 7⟩, ⟨.shared 12, true, 8⟩, ⟨.old 53, false, 1⟩, ⟨.old 53, true, 4⟩, ⟨.shared 11, true, 7⟩, ⟨.shared 13, true, 0⟩, ⟨.shared 13, false, 7⟩, ⟨.shared 11, false, 9⟩, ⟨.shared 5, true, 2⟩, ⟨.shared 5, false, 9⟩, ⟨.shared 2, false, 7⟩, ⟨.shared 11, false, 6⟩, ⟨.shared 5, true, 0⟩, ⟨.shared 5, true, 6⟩]
  | 9 => #[⟨.shared 5, true, 1⟩, ⟨.shared 12, true, 3⟩, ⟨.shared 5, true, 3⟩, ⟨.shared 5, false, 0⟩, ⟨.shared 2, false, 2⟩, ⟨.shared 6, true, 8⟩, ⟨.shared 5, true, 7⟩, ⟨.shared 12, false, 2⟩, ⟨.shared 11, true, 8⟩, ⟨.old 53, true, 5⟩, ⟨.shared 11, false, 1⟩, ⟨.shared 5, false, 5⟩, ⟨.shared 5, true, 8⟩, ⟨.shared 11, true, 3⟩, ⟨.shared 8, false, 0⟩, ⟨.shared 8, false, 1⟩]
  | 10 => #[⟨.shared 6, false, 4⟩, ⟨.shared 6, true, 2⟩, ⟨.shared 6, false, 9⟩, ⟨.shared 12, false, 5⟩, ⟨.shared 12, true, 6⟩, ⟨.shared 12, false, 8⟩, ⟨.shared 13, false, 3⟩, ⟨.shared 8, false, 9⟩, ⟨.shared 8, false, 4⟩, ⟨.shared 8, true, 8⟩, ⟨.shared 8, true, 2⟩, ⟨.shared 8, false, 6⟩, ⟨.shared 2, false, 0⟩, ⟨.shared 8, true, 3⟩, ⟨.shared 6, false, 5⟩, ⟨.shared 6, true, 6⟩]
  | 11 => #[⟨.shared 6, true, 7⟩, ⟨.shared 6, false, 3⟩, ⟨.shared 12, true, 7⟩, ⟨.shared 12, false, 4⟩, ⟨.shared 12, true, 0⟩, ⟨.shared 12, false, 3⟩, ⟨.shared 12, false, 7⟩, ⟨.old 53, false, 7⟩, ⟨.shared 13, true, 6⟩, ⟨.shared 12, true, 1⟩, ⟨.shared 12, true, 4⟩, ⟨.shared 12, false, 1⟩, ⟨.shared 9, true, 8⟩, ⟨.shared 8, false, 5⟩, ⟨.shared 8, true, 7⟩, ⟨.shared 3, true, 6⟩]
  | 12 => #[⟨.shared 3, false, 4⟩, ⟨.shared 3, false, 5⟩, ⟨.shared 3, false, 1⟩, ⟨.shared 3, false, 3⟩, ⟨.shared 3, true, 0⟩, ⟨.shared 3, true, 8⟩, ⟨.shared 3, true, 7⟩, ⟨.shared 3, true, 2⟩, ⟨.shared 3, false, 7⟩, ⟨.shared 3, true, 4⟩, ⟨.shared 3, false, 9⟩, ⟨.shared 3, true, 5⟩, ⟨.shared 3, false, 8⟩, ⟨.shared 3, true, 3⟩, ⟨.shared 3, true, 9⟩, ⟨.shared 3, false, 0⟩]
  | 13 => #[⟨.shared 3, false, 6⟩, ⟨.shared 3, false, 2⟩, ⟨.shared 3, true, 1⟩, ⟨.shared 11, true, 9⟩, ⟨.shared 11, true, 6⟩, ⟨.shared 12, true, 5⟩, ⟨.shared 11, false, 3⟩, ⟨.shared 12, false, 9⟩, ⟨.shared 12, true, 2⟩, ⟨.shared 12, true, 9⟩, ⟨.shared 12, false, 6⟩, ⟨.shared 11, true, 5⟩, ⟨.shared 11, false, 2⟩, ⟨.shared 11, true, 4⟩, ⟨.shared 9, false, 5⟩, ⟨.shared 9, true, 7⟩]
  | 14 => #[⟨.shared 9, false, 4⟩, ⟨.old 66, true, 3⟩, ⟨.old 66, false, 8⟩, ⟨.old 66, true, 8⟩, ⟨.shared 9, true, 6⟩, ⟨.old 66, true, 7⟩, ⟨.old 66, false, 5⟩, ⟨.old 66, false, 0⟩, ⟨.old 66, true, 5⟩, ⟨.old 66, false, 2⟩, ⟨.old 66, true, 1⟩, ⟨.shared 9, false, 3⟩, ⟨.old 66, false, 4⟩, ⟨.old 66, false, 3⟩, ⟨.old 66, false, 9⟩, ⟨.old 66, true, 2⟩]
  | 15 => #[⟨.old 66, true, 4⟩, ⟨.shared 9, true, 0⟩, ⟨.shared 9, true, 9⟩, ⟨.old 66, false, 7⟩, ⟨.old 66, false, 6⟩, ⟨.old 66, true, 0⟩, ⟨.old 66, false, 1⟩, ⟨.shared 9, false, 6⟩, ⟨.old 66, true, 6⟩, ⟨.old 66, true, 9⟩, ⟨.shared 9, false, 7⟩]
  | _ => #[]

def descriptor (i : Index) : Descriptor :=
  (descriptorRows (i.val / 16))[i.val % 16]?.getD ⟨.old 0, false, 0⟩

def baseCore (d : Descriptor) : List Label :=
  match d.origin with
  | .old index => ThreeArcOrder15Data.coreList index
  | .shared index => SharedCoreExclusions.active index

def mappedCore (d : Descriptor) : List Label :=
  ThreeArcSharedSymmetry.preimageCore (baseCore d) d.flip d.rotation

def coreRows (chunk : ℕ) : Array (List Label) :=
  match chunk with
  | 0 => #[[6, 7, 8, 11, 12, 13], [2, 16, 5, 14, 3, 17], [4, 7, 9, 10, 12, 15], [15, 16, 18, 1, 3, 4], [0, 11, 17, 2, 8, 19], [9, 11, 14, 5, 8, 10], [2, 1, 13, 6, 18, 17], [19, 16, 10, 9, 3, 0], [15, 14, 13, 6, 5, 4], [0, 7, 1, 18, 12, 19], [9, 7, 6, 5, 4, 3, 0], [3, 1, 15, 12, 10, 8, 5], [7, 8, 13, 14, 15, 16, 18], [7, 1, 19, 16, 10, 14, 11], [5, 16, 2, 1, 13, 12, 11], [3, 14, 2, 8, 19, 12, 18]]
  | 1 => #[[6, 18, 0, 11, 17, 5, 4], [9, 3, 17, 11, 0, 7, 4], [15, 14, 2, 1, 13, 12, 10], [8, 7, 6, 18, 17, 3, 14], [2, 8, 10, 16, 19, 1, 13], [12, 11, 6, 5, 4, 3, 1], [16, 18, 4, 7, 9, 11, 14], [0, 11, 6, 18, 17, 3, 9], [10, 16, 2, 8, 19, 12, 15], [16, 5, 17, 11, 0, 7, 1], [12, 18, 0, 3, 9, 5, 8], [6, 5, 9, 7, 4, 18, 17], [2, 1, 15, 14, 13, 8, 19], [10, 12, 13, 14, 15, 16, 19], [11, 10, 8, 7, 5, 1, 0], [12, 6, 7, 1, 8, 3, 15]]
  | 2 => #[[11, 13, 8, 5, 7, 16, 17], [14, 9, 5, 16, 8, 18, 15], [3, 2, 16, 18, 5, 12, 0], [18, 19, 1, 3, 7, 14, 17], [16, 4, 3, 14, 1, 11, 10], [9, 1, 15, 12, 19, 16, 10], [17, 12, 13, 1, 19, 8, 2], [0, 14, 2, 8, 10, 16, 19], [19, 5, 9, 3, 17, 11, 0], [4, 8, 10, 12, 13, 14, 15], [2, 7, 6, 18, 0, 11, 17], [10, 18, 0, 3, 4, 7, 9], [13, 3, 17, 18, 4, 5, 6], [6, 16, 2, 1, 15, 14, 13], [15, 11, 6, 5, 9, 7, 4], [0, 7, 8, 13, 1, 2, 16, 5]]
  | 3 => #[[17, 5, 8, 10, 16, 19, 1, 7], [2, 14, 11, 9, 3, 0, 18, 12], [4, 18, 12, 19, 16, 10, 14, 11], [19, 1, 3, 4, 7, 9, 11, 14], [9, 5, 16, 2, 8, 19, 12, 18], [9, 11, 12, 13, 14, 15, 16, 18], [0, 18, 16, 15, 12, 10, 8, 5], [19, 12, 11, 6, 18, 17, 3, 14], [17, 3, 1, 15, 14, 13, 8, 7], [4, 5, 6, 7, 9, 10, 12, 13, 14], [18, 15, 1, 7, 3, 8, 6], [15, 12, 10, 14, 13, 6, 5, 9, 7], [9, 8, 6, 5, 4, 3, 1, 0], [15, 3, 2, 1, 13, 12, 11, 10], [6, 8, 9, 7, 4, 18, 16, 17], [10, 11, 13, 14, 15, 16, 18, 19]]
  | 4 => #[[8, 6, 11, 14, 12, 3, 2], [1, 4, 18, 12, 16, 11, 13], [9, 14, 17, 11, 0, 7, 1, 4], [6, 12, 0, 11, 17, 5, 16, 4], [2, 3, 15, 14, 13, 8, 7, 19], [10, 5, 2, 8, 19, 12, 18, 15], [0, 12, 6, 18, 17, 3, 14, 9], [2, 5, 10, 16, 19, 1, 7, 13], [10, 14, 3, 17, 11, 0, 7, 1], [6, 7, 1, 19, 8, 2, 14, 3], [6, 5, 4, 18, 17, 2, 1, 15, 14], [11, 12, 6, 1, 19, 2, 14, 9, 15], [3, 15, 16, 5, 18, 8, 9], [9, 3, 0, 7, 4, 15, 12, 19, 16], [12, 11, 13, 5, 9, 4, 18, 19, 17], [15, 0, 1, 3, 4, 11, 13, 14, 17]]
  | 5 => #[[9, 2, 5, 8, 10, 1, 4, 7, 13], [6, 19, 7, 8, 13, 16, 4, 5, 10], [17, 11, 0, 18, 6, 13, 1, 19, 8], [17, 10, 5, 16, 2, 12, 6, 18, 15], [10, 12, 15, 16, 19, 0, 3, 4, 7], [12, 0, 7, 8, 1, 5, 10], [18, 16, 4, 14, 2, 13, 12, 0, 10], [13, 14, 15, 1, 2, 17, 18, 4, 5], [2, 8, 19, 1, 13, 6, 18, 0, 11], [11, 0, 19, 7, 13, 2, 16, 5, 10], [4, 19, 18, 16, 15, 8, 6, 5, 2], [12, 10, 9, 8, 6, 4, 3, 1, 0], [19, 8, 2, 16, 10, 9, 3, 17, 11], [13, 0, 12, 11, 6, 3, 15, 14, 9], [1, 13, 6, 12, 0, 17, 5, 16, 4], [5, 6, 13, 11, 10, 15, 1, 3, 2]]
  | 6 => #[[5, 4, 15, 3, 2, 13, 12, 11, 10], [18, 17, 2, 3, 15, 13, 8, 7, 19], [6, 10, 11, 12, 13, 16, 17, 18, 19], [14, 11, 10, 7, 6, 4, 3, 2, 0], [1, 2, 17, 16, 4, 6, 11, 12, 0], [3, 1, 4, 12, 19, 10, 14, 17, 13], [0, 15, 18, 12, 19, 14, 17, 11, 13], [0, 3, 9, 11, 17, 2, 8, 10, 16], [14, 15, 4, 16, 17, 6, 7, 8, 9], [8, 2, 17, 14, 9, 0, 18, 12, 6], [0, 13, 7, 1, 19, 14, 9, 3, 15], [5, 8, 9, 12, 13, 15, 16, 17, 19], [3, 9, 10, 5, 2, 19, 12, 18, 15], [4, 2, 3, 1, 15, 8, 9, 7, 19], [8, 19, 0, 12, 6, 17, 3, 14, 9], [18, 6, 13, 7, 19, 2, 14, 3, 15]]
  | 7 => #[[8, 9, 10, 12, 13, 14, 16, 18, 19], [12, 15, 4, 1, 0, 9, 5, 8, 6], [16, 10, 9, 14, 17, 0, 7, 1, 4], [17, 16, 18, 5, 6, 13, 15, 1, 3], [9, 8, 7, 5, 4, 15, 13, 12, 11], [10, 11, 12, 14, 15, 4, 6, 7, 8], [16, 5, 2, 11, 9, 0, 18, 15, 6], [16, 19, 0, 1, 4, 9, 11, 14, 17], [7, 4, 15, 18, 19, 10, 14, 11, 13], [2, 3, 1, 14, 13, 6, 4, 18, 16], [11, 17, 2, 5, 10, 19, 1, 7, 13], [3, 0, 19, 18, 15, 10, 8, 5, 2], [6, 12, 18, 11, 17, 2, 19, 1, 7], [8, 5, 10, 3, 17, 0, 7, 13, 4], [15, 18, 12, 16, 10, 9, 0, 7, 1], [14, 13, 6, 8, 9, 4, 18, 16, 17]]
  | 8 => #[[15, 17, 16, 18, 4, 11, 10, 12, 0], [7, 9, 10, 11, 13, 15, 16, 18, 19], [9, 13, 11, 14, 10, 1, 0, 3, 2], [3, 2, 17, 18, 4, 5, 11, 12, 0], [2, 5, 8, 16, 19, 0, 9, 11, 14], [10, 5, 16, 8, 19, 0, 17, 3, 14], [7, 8, 6, 14, 10, 15, 1, 0, 2], [2, 9, 14, 3, 17, 7, 13, 1, 4], [10, 17, 14, 11, 9, 18, 15, 12, 6], [1, 3, 15, 5, 17, 6, 7, 19, 9], [14, 11, 6, 9, 7, 4, 19, 16, 17], [14, 3, 4, 17, 18, 6, 19, 8, 9], [5, 2, 14, 11, 3, 12, 6], [7, 1, 0, 16, 15, 10, 8, 6, 2], [16, 5, 9, 17, 11, 0, 13, 1, 4], [12, 18, 4, 0, 3, 9, 2, 8, 6]]
  | 9 => #[[7, 1, 15, 19, 16, 10, 17, 11, 13], [16, 17, 2, 1, 15, 14, 8, 7, 19], [18, 16, 2, 15, 14, 13, 9, 7, 19], [7, 8, 10, 13, 14, 15, 17, 18, 19], [14, 17, 5, 8, 16, 7, 13], [2, 16, 18, 4, 5, 6, 11, 12], [5, 8, 13, 10, 12, 15, 0, 3, 2], [14, 17, 2, 8, 10, 16, 1, 7, 13], [14, 3, 2, 18, 4, 6, 11, 10, 0], [4, 1, 7, 3, 9, 10, 19, 12, 18], [12, 18, 19, 3, 4, 9, 11, 13, 17], [12, 11, 9, 6, 5, 4, 2, 1, 0], [1, 3, 17, 4, 5, 6, 10, 12, 0], [5, 16, 17, 1, 15, 13, 8, 9, 19], [7, 9, 10, 12, 15, 16, 19], [16, 19, 0, 3, 9, 11, 17]]
  | 10 => #[[4, 3, 14, 2, 1, 13, 12, 11], [13, 8, 5, 9, 7, 4, 18, 16], [15, 16, 5, 17, 18, 6, 7, 8], [11, 10, 9, 7, 6, 5, 3, 1, 0], [18, 15, 4, 7, 0, 3, 5, 8, 6], [12, 6, 13, 1, 19, 8, 14, 3, 15], [19, 6, 12, 18, 0, 5, 10, 16, 4], [14, 15, 4, 5, 6, 7, 9], [5, 4, 15, 14, 13, 12, 10], [1, 2, 17, 18, 6, 11, 0], [14, 13, 6, 5, 4, 18, 17], [3, 0, 19, 16, 10, 8, 2], [8, 9, 11, 12, 14, 18, 19], [18, 17, 2, 1, 13, 8, 19], [10, 8, 7, 6, 5, 4, 3, 1], [15, 1, 7, 0, 3, 9, 5, 8]]
  | 11 => #[[6, 11, 14, 10, 12, 15, 1, 3], [13, 12, 18, 0, 11, 17, 5, 16], [8, 6, 13, 14, 10, 12, 1, 3, 2], [16, 4, 15, 14, 2, 1, 12, 11, 10], [5, 10, 9, 3, 17, 11, 7, 1, 4], [7, 13, 6, 18, 0, 11, 5, 16, 4], [5, 2, 17, 11, 9, 3, 18, 12, 6], [13, 7, 1, 8, 2, 17, 0, 18, 12], [19, 4, 1, 7, 0, 5, 2, 8, 6], [1, 4, 15, 12, 19, 16, 14, 11, 13], [7, 19, 0, 11, 6, 18, 3, 14, 9], [18, 19, 0, 3, 4, 7, 11, 14, 17], [13, 3, 2, 17, 16, 18, 4, 6, 11, 10, 12], [12, 10, 9, 7, 4, 3, 0], [5, 6, 13, 14, 15, 1, 2], [14, 4, 1, 0, 3, 9, 5, 6]]
  | 12 => #[[7, 15, 3, 2, 1, 13, 12, 10], [16, 9, 8, 6, 5, 4, 3, 0], [8, 0, 1, 4, 7, 9, 11, 17], [14, 6, 12, 0, 11, 17, 5, 4], [12, 9, 14, 17, 11, 0, 7, 4], [8, 17, 16, 4, 5, 6, 11, 0], [18, 13, 11, 10, 12, 15, 1, 2], [1, 6, 8, 9, 7, 4, 18, 17], [1, 17, 14, 9, 3, 0, 18, 6], [16, 0, 12, 6, 18, 17, 3, 9], [12, 4, 16, 17, 18, 6, 7, 9], [7, 10, 5, 2, 8, 19, 12, 15], [5, 13, 7, 19, 8, 2, 14, 15], [11, 2, 3, 15, 14, 13, 8, 19], [3, 19, 7, 13, 1, 2, 16, 10], [3, 10, 11, 13, 14, 15, 16, 19]]
  | 13 => #[[11, 19, 18, 15, 12, 10, 8, 2], [18, 2, 5, 10, 16, 19, 1, 13], [5, 15, 18, 19, 16, 10, 14, 13], [18, 12, 0, 8, 13, 2, 16, 4, 10], [16, 18, 15, 7, 0, 9, 5, 2, 6], [14, 9, 10, 16, 2, 8, 12, 18, 15], [8, 7, 13, 18, 0, 17, 5, 10, 4], [3, 15, 4, 5, 17, 18, 7, 8, 9], [11, 13, 6, 5, 9, 7, 18, 16, 17], [12, 0, 19, 8, 13, 1, 16, 5, 10], [1, 0, 19, 16, 15, 12, 8, 5, 2], [11, 14, 9, 16, 2, 19, 12, 6, 15], [3, 14, 17, 8, 10, 19, 1, 4, 13], [1, 7, 19, 11, 6, 17, 3, 15, 9], [15, 11, 10, 9, 8, 7, 6, 4, 3, 2, 1], [4, 8, 6, 13, 11, 14, 10, 15, 1, 0, 3]]
  | 14 => #[[6, 16, 4, 15, 3, 14, 2, 13, 12, 0, 11], [12, 11, 6, 5, 4, 16, 17, 2, 3, 9, 7], [16, 5, 17, 11, 0, 12, 6, 13, 7, 9, 3], [7, 8, 13, 14, 15, 3, 2, 17, 16, 10, 12], [10, 18, 15, 4, 1, 7, 0, 9, 5, 2, 8], [16, 18, 4, 7, 9, 8, 6, 13, 11, 0, 3], [18, 16, 15, 14, 13, 11, 10, 9, 8, 2, 1], [1, 3, 4, 5, 6, 8, 9, 10, 11, 17, 18], [1, 7, 0, 11, 17, 14, 9, 10, 5, 6, 18], [12, 18, 0, 3, 9, 14, 17, 2, 5, 4, 7], [8, 5, 9, 3, 0, 1, 4, 15, 18, 17, 11], [2, 7, 13, 6, 12, 18, 0, 17, 5, 10, 16], [8, 7, 6, 18, 17, 16, 4, 15, 3, 0, 11], [3, 14, 2, 8, 19, 7, 13, 6, 12, 10, 16], [11, 12, 13, 1, 2, 3, 15, 4, 16, 19, 8], [3, 1, 15, 12, 10, 11, 13, 6, 8, 19, 16]]
  | 15 => #[[5, 16, 2, 1, 13, 7, 19, 0, 12, 15, 14], [19, 5, 10, 9, 14, 3, 17, 0, 7, 13, 1], [17, 12, 0, 19, 7, 8, 13, 2, 16, 4, 5], [7, 1, 19, 16, 10, 5, 2, 17, 14, 15, 12], [14, 11, 9, 7, 4, 1, 0, 19, 18, 6, 5], [18, 12, 19, 8, 2, 5, 10, 9, 14, 13, 1], [5, 8, 10, 12, 15, 18, 19, 0, 1, 13, 14], [9, 1, 0, 19, 18, 16, 15, 10, 8, 6, 5], [11, 14, 10, 16, 19, 18, 15, 4, 1, 2, 8], [14, 3, 17, 18, 6, 12, 0, 19, 7, 4, 5], [19, 5, 2, 17, 14, 11, 9, 0, 18, 15, 12]]
  | _ => #[]

def coreList (i : Index) : List Label :=
  (coreRows (i.val / 16))[i.val % 16]?.getD []

theorem cached000 : coreList 0 = mappedCore (descriptor 0) := by
  decide +kernel

theorem cached001 : coreList 1 = mappedCore (descriptor 1) := by
  decide +kernel

theorem cached002 : coreList 2 = mappedCore (descriptor 2) := by
  decide +kernel

theorem cached003 : coreList 3 = mappedCore (descriptor 3) := by
  decide +kernel

theorem cached004 : coreList 4 = mappedCore (descriptor 4) := by
  decide +kernel

theorem cached005 : coreList 5 = mappedCore (descriptor 5) := by
  decide +kernel

theorem cached006 : coreList 6 = mappedCore (descriptor 6) := by
  decide +kernel

theorem cached007 : coreList 7 = mappedCore (descriptor 7) := by
  decide +kernel

theorem cached008 : coreList 8 = mappedCore (descriptor 8) := by
  decide +kernel

theorem cached009 : coreList 9 = mappedCore (descriptor 9) := by
  decide +kernel

theorem cached010 : coreList 10 = mappedCore (descriptor 10) := by
  decide +kernel

theorem cached011 : coreList 11 = mappedCore (descriptor 11) := by
  decide +kernel

theorem cached012 : coreList 12 = mappedCore (descriptor 12) := by
  decide +kernel

theorem cached013 : coreList 13 = mappedCore (descriptor 13) := by
  decide +kernel

theorem cached014 : coreList 14 = mappedCore (descriptor 14) := by
  decide +kernel

theorem cached015 : coreList 15 = mappedCore (descriptor 15) := by
  decide +kernel

theorem cached016 : coreList 16 = mappedCore (descriptor 16) := by
  decide +kernel

theorem cached017 : coreList 17 = mappedCore (descriptor 17) := by
  decide +kernel

theorem cached018 : coreList 18 = mappedCore (descriptor 18) := by
  decide +kernel

theorem cached019 : coreList 19 = mappedCore (descriptor 19) := by
  decide +kernel

theorem cached020 : coreList 20 = mappedCore (descriptor 20) := by
  decide +kernel

theorem cached021 : coreList 21 = mappedCore (descriptor 21) := by
  decide +kernel

theorem cached022 : coreList 22 = mappedCore (descriptor 22) := by
  decide +kernel

theorem cached023 : coreList 23 = mappedCore (descriptor 23) := by
  decide +kernel

theorem cached024 : coreList 24 = mappedCore (descriptor 24) := by
  decide +kernel

theorem cached025 : coreList 25 = mappedCore (descriptor 25) := by
  decide +kernel

theorem cached026 : coreList 26 = mappedCore (descriptor 26) := by
  decide +kernel

theorem cached027 : coreList 27 = mappedCore (descriptor 27) := by
  decide +kernel

theorem cached028 : coreList 28 = mappedCore (descriptor 28) := by
  decide +kernel

theorem cached029 : coreList 29 = mappedCore (descriptor 29) := by
  decide +kernel

theorem cached030 : coreList 30 = mappedCore (descriptor 30) := by
  decide +kernel

theorem cached031 : coreList 31 = mappedCore (descriptor 31) := by
  decide +kernel

theorem cached032 : coreList 32 = mappedCore (descriptor 32) := by
  decide +kernel

theorem cached033 : coreList 33 = mappedCore (descriptor 33) := by
  decide +kernel

theorem cached034 : coreList 34 = mappedCore (descriptor 34) := by
  decide +kernel

theorem cached035 : coreList 35 = mappedCore (descriptor 35) := by
  decide +kernel

theorem cached036 : coreList 36 = mappedCore (descriptor 36) := by
  decide +kernel

theorem cached037 : coreList 37 = mappedCore (descriptor 37) := by
  decide +kernel

theorem cached038 : coreList 38 = mappedCore (descriptor 38) := by
  decide +kernel

theorem cached039 : coreList 39 = mappedCore (descriptor 39) := by
  decide +kernel

theorem cached040 : coreList 40 = mappedCore (descriptor 40) := by
  decide +kernel

theorem cached041 : coreList 41 = mappedCore (descriptor 41) := by
  decide +kernel

theorem cached042 : coreList 42 = mappedCore (descriptor 42) := by
  decide +kernel

theorem cached043 : coreList 43 = mappedCore (descriptor 43) := by
  decide +kernel

theorem cached044 : coreList 44 = mappedCore (descriptor 44) := by
  decide +kernel

theorem cached045 : coreList 45 = mappedCore (descriptor 45) := by
  decide +kernel

theorem cached046 : coreList 46 = mappedCore (descriptor 46) := by
  decide +kernel

theorem cached047 : coreList 47 = mappedCore (descriptor 47) := by
  decide +kernel

theorem cached048 : coreList 48 = mappedCore (descriptor 48) := by
  decide +kernel

theorem cached049 : coreList 49 = mappedCore (descriptor 49) := by
  decide +kernel

theorem cached050 : coreList 50 = mappedCore (descriptor 50) := by
  decide +kernel

theorem cached051 : coreList 51 = mappedCore (descriptor 51) := by
  decide +kernel

theorem cached052 : coreList 52 = mappedCore (descriptor 52) := by
  decide +kernel

theorem cached053 : coreList 53 = mappedCore (descriptor 53) := by
  decide +kernel

theorem cached054 : coreList 54 = mappedCore (descriptor 54) := by
  decide +kernel

theorem cached055 : coreList 55 = mappedCore (descriptor 55) := by
  decide +kernel

theorem cached056 : coreList 56 = mappedCore (descriptor 56) := by
  decide +kernel

theorem cached057 : coreList 57 = mappedCore (descriptor 57) := by
  decide +kernel

theorem cached058 : coreList 58 = mappedCore (descriptor 58) := by
  decide +kernel

theorem cached059 : coreList 59 = mappedCore (descriptor 59) := by
  decide +kernel

theorem cached060 : coreList 60 = mappedCore (descriptor 60) := by
  decide +kernel

theorem cached061 : coreList 61 = mappedCore (descriptor 61) := by
  decide +kernel

theorem cached062 : coreList 62 = mappedCore (descriptor 62) := by
  decide +kernel

theorem cached063 : coreList 63 = mappedCore (descriptor 63) := by
  decide +kernel

theorem cached064 : coreList 64 = mappedCore (descriptor 64) := by
  decide +kernel

theorem cached065 : coreList 65 = mappedCore (descriptor 65) := by
  decide +kernel

theorem cached066 : coreList 66 = mappedCore (descriptor 66) := by
  decide +kernel

theorem cached067 : coreList 67 = mappedCore (descriptor 67) := by
  decide +kernel

theorem cached068 : coreList 68 = mappedCore (descriptor 68) := by
  decide +kernel

theorem cached069 : coreList 69 = mappedCore (descriptor 69) := by
  decide +kernel

theorem cached070 : coreList 70 = mappedCore (descriptor 70) := by
  decide +kernel

theorem cached071 : coreList 71 = mappedCore (descriptor 71) := by
  decide +kernel

theorem cached072 : coreList 72 = mappedCore (descriptor 72) := by
  decide +kernel

theorem cached073 : coreList 73 = mappedCore (descriptor 73) := by
  decide +kernel

theorem cached074 : coreList 74 = mappedCore (descriptor 74) := by
  decide +kernel

theorem cached075 : coreList 75 = mappedCore (descriptor 75) := by
  decide +kernel

theorem cached076 : coreList 76 = mappedCore (descriptor 76) := by
  decide +kernel

theorem cached077 : coreList 77 = mappedCore (descriptor 77) := by
  decide +kernel

theorem cached078 : coreList 78 = mappedCore (descriptor 78) := by
  decide +kernel

theorem cached079 : coreList 79 = mappedCore (descriptor 79) := by
  decide +kernel

theorem cached080 : coreList 80 = mappedCore (descriptor 80) := by
  decide +kernel

theorem cached081 : coreList 81 = mappedCore (descriptor 81) := by
  decide +kernel

theorem cached082 : coreList 82 = mappedCore (descriptor 82) := by
  decide +kernel

theorem cached083 : coreList 83 = mappedCore (descriptor 83) := by
  decide +kernel

theorem cached084 : coreList 84 = mappedCore (descriptor 84) := by
  decide +kernel

theorem cached085 : coreList 85 = mappedCore (descriptor 85) := by
  decide +kernel

theorem cached086 : coreList 86 = mappedCore (descriptor 86) := by
  decide +kernel

theorem cached087 : coreList 87 = mappedCore (descriptor 87) := by
  decide +kernel

theorem cached088 : coreList 88 = mappedCore (descriptor 88) := by
  decide +kernel

theorem cached089 : coreList 89 = mappedCore (descriptor 89) := by
  decide +kernel

theorem cached090 : coreList 90 = mappedCore (descriptor 90) := by
  decide +kernel

theorem cached091 : coreList 91 = mappedCore (descriptor 91) := by
  decide +kernel

theorem cached092 : coreList 92 = mappedCore (descriptor 92) := by
  decide +kernel

theorem cached093 : coreList 93 = mappedCore (descriptor 93) := by
  decide +kernel

theorem cached094 : coreList 94 = mappedCore (descriptor 94) := by
  decide +kernel

theorem cached095 : coreList 95 = mappedCore (descriptor 95) := by
  decide +kernel

theorem cached096 : coreList 96 = mappedCore (descriptor 96) := by
  decide +kernel

theorem cached097 : coreList 97 = mappedCore (descriptor 97) := by
  decide +kernel

theorem cached098 : coreList 98 = mappedCore (descriptor 98) := by
  decide +kernel

theorem cached099 : coreList 99 = mappedCore (descriptor 99) := by
  decide +kernel

theorem cached100 : coreList 100 = mappedCore (descriptor 100) := by
  decide +kernel

theorem cached101 : coreList 101 = mappedCore (descriptor 101) := by
  decide +kernel

theorem cached102 : coreList 102 = mappedCore (descriptor 102) := by
  decide +kernel

theorem cached103 : coreList 103 = mappedCore (descriptor 103) := by
  decide +kernel

theorem cached104 : coreList 104 = mappedCore (descriptor 104) := by
  decide +kernel

theorem cached105 : coreList 105 = mappedCore (descriptor 105) := by
  decide +kernel

theorem cached106 : coreList 106 = mappedCore (descriptor 106) := by
  decide +kernel

theorem cached107 : coreList 107 = mappedCore (descriptor 107) := by
  decide +kernel

theorem cached108 : coreList 108 = mappedCore (descriptor 108) := by
  decide +kernel

theorem cached109 : coreList 109 = mappedCore (descriptor 109) := by
  decide +kernel

theorem cached110 : coreList 110 = mappedCore (descriptor 110) := by
  decide +kernel

theorem cached111 : coreList 111 = mappedCore (descriptor 111) := by
  decide +kernel

theorem cached112 : coreList 112 = mappedCore (descriptor 112) := by
  decide +kernel

theorem cached113 : coreList 113 = mappedCore (descriptor 113) := by
  decide +kernel

theorem cached114 : coreList 114 = mappedCore (descriptor 114) := by
  decide +kernel

theorem cached115 : coreList 115 = mappedCore (descriptor 115) := by
  decide +kernel

theorem cached116 : coreList 116 = mappedCore (descriptor 116) := by
  decide +kernel

theorem cached117 : coreList 117 = mappedCore (descriptor 117) := by
  decide +kernel

theorem cached118 : coreList 118 = mappedCore (descriptor 118) := by
  decide +kernel

theorem cached119 : coreList 119 = mappedCore (descriptor 119) := by
  decide +kernel

theorem cached120 : coreList 120 = mappedCore (descriptor 120) := by
  decide +kernel

theorem cached121 : coreList 121 = mappedCore (descriptor 121) := by
  decide +kernel

theorem cached122 : coreList 122 = mappedCore (descriptor 122) := by
  decide +kernel

theorem cached123 : coreList 123 = mappedCore (descriptor 123) := by
  decide +kernel

theorem cached124 : coreList 124 = mappedCore (descriptor 124) := by
  decide +kernel

theorem cached125 : coreList 125 = mappedCore (descriptor 125) := by
  decide +kernel

theorem cached126 : coreList 126 = mappedCore (descriptor 126) := by
  decide +kernel

theorem cached127 : coreList 127 = mappedCore (descriptor 127) := by
  decide +kernel

theorem cached128 : coreList 128 = mappedCore (descriptor 128) := by
  decide +kernel

theorem cached129 : coreList 129 = mappedCore (descriptor 129) := by
  decide +kernel

theorem cached130 : coreList 130 = mappedCore (descriptor 130) := by
  decide +kernel

theorem cached131 : coreList 131 = mappedCore (descriptor 131) := by
  decide +kernel

theorem cached132 : coreList 132 = mappedCore (descriptor 132) := by
  decide +kernel

theorem cached133 : coreList 133 = mappedCore (descriptor 133) := by
  decide +kernel

theorem cached134 : coreList 134 = mappedCore (descriptor 134) := by
  decide +kernel

theorem cached135 : coreList 135 = mappedCore (descriptor 135) := by
  decide +kernel

theorem cached136 : coreList 136 = mappedCore (descriptor 136) := by
  decide +kernel

theorem cached137 : coreList 137 = mappedCore (descriptor 137) := by
  decide +kernel

theorem cached138 : coreList 138 = mappedCore (descriptor 138) := by
  decide +kernel

theorem cached139 : coreList 139 = mappedCore (descriptor 139) := by
  decide +kernel

theorem cached140 : coreList 140 = mappedCore (descriptor 140) := by
  decide +kernel

theorem cached141 : coreList 141 = mappedCore (descriptor 141) := by
  decide +kernel

theorem cached142 : coreList 142 = mappedCore (descriptor 142) := by
  decide +kernel

theorem cached143 : coreList 143 = mappedCore (descriptor 143) := by
  decide +kernel

theorem cached144 : coreList 144 = mappedCore (descriptor 144) := by
  decide +kernel

theorem cached145 : coreList 145 = mappedCore (descriptor 145) := by
  decide +kernel

theorem cached146 : coreList 146 = mappedCore (descriptor 146) := by
  decide +kernel

theorem cached147 : coreList 147 = mappedCore (descriptor 147) := by
  decide +kernel

theorem cached148 : coreList 148 = mappedCore (descriptor 148) := by
  decide +kernel

theorem cached149 : coreList 149 = mappedCore (descriptor 149) := by
  decide +kernel

theorem cached150 : coreList 150 = mappedCore (descriptor 150) := by
  decide +kernel

theorem cached151 : coreList 151 = mappedCore (descriptor 151) := by
  decide +kernel

theorem cached152 : coreList 152 = mappedCore (descriptor 152) := by
  decide +kernel

theorem cached153 : coreList 153 = mappedCore (descriptor 153) := by
  decide +kernel

theorem cached154 : coreList 154 = mappedCore (descriptor 154) := by
  decide +kernel

theorem cached155 : coreList 155 = mappedCore (descriptor 155) := by
  decide +kernel

theorem cached156 : coreList 156 = mappedCore (descriptor 156) := by
  decide +kernel

theorem cached157 : coreList 157 = mappedCore (descriptor 157) := by
  decide +kernel

theorem cached158 : coreList 158 = mappedCore (descriptor 158) := by
  decide +kernel

theorem cached159 : coreList 159 = mappedCore (descriptor 159) := by
  decide +kernel

theorem cached160 : coreList 160 = mappedCore (descriptor 160) := by
  decide +kernel

theorem cached161 : coreList 161 = mappedCore (descriptor 161) := by
  decide +kernel

theorem cached162 : coreList 162 = mappedCore (descriptor 162) := by
  decide +kernel

theorem cached163 : coreList 163 = mappedCore (descriptor 163) := by
  decide +kernel

theorem cached164 : coreList 164 = mappedCore (descriptor 164) := by
  decide +kernel

theorem cached165 : coreList 165 = mappedCore (descriptor 165) := by
  decide +kernel

theorem cached166 : coreList 166 = mappedCore (descriptor 166) := by
  decide +kernel

theorem cached167 : coreList 167 = mappedCore (descriptor 167) := by
  decide +kernel

theorem cached168 : coreList 168 = mappedCore (descriptor 168) := by
  decide +kernel

theorem cached169 : coreList 169 = mappedCore (descriptor 169) := by
  decide +kernel

theorem cached170 : coreList 170 = mappedCore (descriptor 170) := by
  decide +kernel

theorem cached171 : coreList 171 = mappedCore (descriptor 171) := by
  decide +kernel

theorem cached172 : coreList 172 = mappedCore (descriptor 172) := by
  decide +kernel

theorem cached173 : coreList 173 = mappedCore (descriptor 173) := by
  decide +kernel

theorem cached174 : coreList 174 = mappedCore (descriptor 174) := by
  decide +kernel

theorem cached175 : coreList 175 = mappedCore (descriptor 175) := by
  decide +kernel

theorem cached176 : coreList 176 = mappedCore (descriptor 176) := by
  decide +kernel

theorem cached177 : coreList 177 = mappedCore (descriptor 177) := by
  decide +kernel

theorem cached178 : coreList 178 = mappedCore (descriptor 178) := by
  decide +kernel

theorem cached179 : coreList 179 = mappedCore (descriptor 179) := by
  decide +kernel

theorem cached180 : coreList 180 = mappedCore (descriptor 180) := by
  decide +kernel

theorem cached181 : coreList 181 = mappedCore (descriptor 181) := by
  decide +kernel

theorem cached182 : coreList 182 = mappedCore (descriptor 182) := by
  decide +kernel

theorem cached183 : coreList 183 = mappedCore (descriptor 183) := by
  decide +kernel

theorem cached184 : coreList 184 = mappedCore (descriptor 184) := by
  decide +kernel

theorem cached185 : coreList 185 = mappedCore (descriptor 185) := by
  decide +kernel

theorem cached186 : coreList 186 = mappedCore (descriptor 186) := by
  decide +kernel

theorem cached187 : coreList 187 = mappedCore (descriptor 187) := by
  decide +kernel

theorem cached188 : coreList 188 = mappedCore (descriptor 188) := by
  decide +kernel

theorem cached189 : coreList 189 = mappedCore (descriptor 189) := by
  decide +kernel

theorem cached190 : coreList 190 = mappedCore (descriptor 190) := by
  decide +kernel

theorem cached191 : coreList 191 = mappedCore (descriptor 191) := by
  decide +kernel

theorem cached192 : coreList 192 = mappedCore (descriptor 192) := by
  decide +kernel

theorem cached193 : coreList 193 = mappedCore (descriptor 193) := by
  decide +kernel

theorem cached194 : coreList 194 = mappedCore (descriptor 194) := by
  decide +kernel

theorem cached195 : coreList 195 = mappedCore (descriptor 195) := by
  decide +kernel

theorem cached196 : coreList 196 = mappedCore (descriptor 196) := by
  decide +kernel

theorem cached197 : coreList 197 = mappedCore (descriptor 197) := by
  decide +kernel

theorem cached198 : coreList 198 = mappedCore (descriptor 198) := by
  decide +kernel

theorem cached199 : coreList 199 = mappedCore (descriptor 199) := by
  decide +kernel

theorem cached200 : coreList 200 = mappedCore (descriptor 200) := by
  decide +kernel

theorem cached201 : coreList 201 = mappedCore (descriptor 201) := by
  decide +kernel

theorem cached202 : coreList 202 = mappedCore (descriptor 202) := by
  decide +kernel

theorem cached203 : coreList 203 = mappedCore (descriptor 203) := by
  decide +kernel

theorem cached204 : coreList 204 = mappedCore (descriptor 204) := by
  decide +kernel

theorem cached205 : coreList 205 = mappedCore (descriptor 205) := by
  decide +kernel

theorem cached206 : coreList 206 = mappedCore (descriptor 206) := by
  decide +kernel

theorem cached207 : coreList 207 = mappedCore (descriptor 207) := by
  decide +kernel

theorem cached208 : coreList 208 = mappedCore (descriptor 208) := by
  decide +kernel

theorem cached209 : coreList 209 = mappedCore (descriptor 209) := by
  decide +kernel

theorem cached210 : coreList 210 = mappedCore (descriptor 210) := by
  decide +kernel

theorem cached211 : coreList 211 = mappedCore (descriptor 211) := by
  decide +kernel

theorem cached212 : coreList 212 = mappedCore (descriptor 212) := by
  decide +kernel

theorem cached213 : coreList 213 = mappedCore (descriptor 213) := by
  decide +kernel

theorem cached214 : coreList 214 = mappedCore (descriptor 214) := by
  decide +kernel

theorem cached215 : coreList 215 = mappedCore (descriptor 215) := by
  decide +kernel

theorem cached216 : coreList 216 = mappedCore (descriptor 216) := by
  decide +kernel

theorem cached217 : coreList 217 = mappedCore (descriptor 217) := by
  decide +kernel

theorem cached218 : coreList 218 = mappedCore (descriptor 218) := by
  decide +kernel

theorem cached219 : coreList 219 = mappedCore (descriptor 219) := by
  decide +kernel

theorem cached220 : coreList 220 = mappedCore (descriptor 220) := by
  decide +kernel

theorem cached221 : coreList 221 = mappedCore (descriptor 221) := by
  decide +kernel

theorem cached222 : coreList 222 = mappedCore (descriptor 222) := by
  decide +kernel

theorem cached223 : coreList 223 = mappedCore (descriptor 223) := by
  decide +kernel

theorem cached224 : coreList 224 = mappedCore (descriptor 224) := by
  decide +kernel

theorem cached225 : coreList 225 = mappedCore (descriptor 225) := by
  decide +kernel

theorem cached226 : coreList 226 = mappedCore (descriptor 226) := by
  decide +kernel

theorem cached227 : coreList 227 = mappedCore (descriptor 227) := by
  decide +kernel

theorem cached228 : coreList 228 = mappedCore (descriptor 228) := by
  decide +kernel

theorem cached229 : coreList 229 = mappedCore (descriptor 229) := by
  decide +kernel

theorem cached230 : coreList 230 = mappedCore (descriptor 230) := by
  decide +kernel

theorem cached231 : coreList 231 = mappedCore (descriptor 231) := by
  decide +kernel

theorem cached232 : coreList 232 = mappedCore (descriptor 232) := by
  decide +kernel

theorem cached233 : coreList 233 = mappedCore (descriptor 233) := by
  decide +kernel

theorem cached234 : coreList 234 = mappedCore (descriptor 234) := by
  decide +kernel

theorem cached235 : coreList 235 = mappedCore (descriptor 235) := by
  decide +kernel

theorem cached236 : coreList 236 = mappedCore (descriptor 236) := by
  decide +kernel

theorem cached237 : coreList 237 = mappedCore (descriptor 237) := by
  decide +kernel

theorem cached238 : coreList 238 = mappedCore (descriptor 238) := by
  decide +kernel

theorem cached239 : coreList 239 = mappedCore (descriptor 239) := by
  decide +kernel

theorem cached240 : coreList 240 = mappedCore (descriptor 240) := by
  decide +kernel

theorem cached241 : coreList 241 = mappedCore (descriptor 241) := by
  decide +kernel

theorem cached242 : coreList 242 = mappedCore (descriptor 242) := by
  decide +kernel

theorem cached243 : coreList 243 = mappedCore (descriptor 243) := by
  decide +kernel

theorem cached244 : coreList 244 = mappedCore (descriptor 244) := by
  decide +kernel

theorem cached245 : coreList 245 = mappedCore (descriptor 245) := by
  decide +kernel

theorem cached246 : coreList 246 = mappedCore (descriptor 246) := by
  decide +kernel

theorem cached247 : coreList 247 = mappedCore (descriptor 247) := by
  decide +kernel

theorem cached248 : coreList 248 = mappedCore (descriptor 248) := by
  decide +kernel

theorem cached249 : coreList 249 = mappedCore (descriptor 249) := by
  decide +kernel

theorem cached250 : coreList 250 = mappedCore (descriptor 250) := by
  decide +kernel

theorem cached_match (i : Index) : coreList i = mappedCore (descriptor i) := by
  fin_cases i
  · exact cached000
  · exact cached001
  · exact cached002
  · exact cached003
  · exact cached004
  · exact cached005
  · exact cached006
  · exact cached007
  · exact cached008
  · exact cached009
  · exact cached010
  · exact cached011
  · exact cached012
  · exact cached013
  · exact cached014
  · exact cached015
  · exact cached016
  · exact cached017
  · exact cached018
  · exact cached019
  · exact cached020
  · exact cached021
  · exact cached022
  · exact cached023
  · exact cached024
  · exact cached025
  · exact cached026
  · exact cached027
  · exact cached028
  · exact cached029
  · exact cached030
  · exact cached031
  · exact cached032
  · exact cached033
  · exact cached034
  · exact cached035
  · exact cached036
  · exact cached037
  · exact cached038
  · exact cached039
  · exact cached040
  · exact cached041
  · exact cached042
  · exact cached043
  · exact cached044
  · exact cached045
  · exact cached046
  · exact cached047
  · exact cached048
  · exact cached049
  · exact cached050
  · exact cached051
  · exact cached052
  · exact cached053
  · exact cached054
  · exact cached055
  · exact cached056
  · exact cached057
  · exact cached058
  · exact cached059
  · exact cached060
  · exact cached061
  · exact cached062
  · exact cached063
  · exact cached064
  · exact cached065
  · exact cached066
  · exact cached067
  · exact cached068
  · exact cached069
  · exact cached070
  · exact cached071
  · exact cached072
  · exact cached073
  · exact cached074
  · exact cached075
  · exact cached076
  · exact cached077
  · exact cached078
  · exact cached079
  · exact cached080
  · exact cached081
  · exact cached082
  · exact cached083
  · exact cached084
  · exact cached085
  · exact cached086
  · exact cached087
  · exact cached088
  · exact cached089
  · exact cached090
  · exact cached091
  · exact cached092
  · exact cached093
  · exact cached094
  · exact cached095
  · exact cached096
  · exact cached097
  · exact cached098
  · exact cached099
  · exact cached100
  · exact cached101
  · exact cached102
  · exact cached103
  · exact cached104
  · exact cached105
  · exact cached106
  · exact cached107
  · exact cached108
  · exact cached109
  · exact cached110
  · exact cached111
  · exact cached112
  · exact cached113
  · exact cached114
  · exact cached115
  · exact cached116
  · exact cached117
  · exact cached118
  · exact cached119
  · exact cached120
  · exact cached121
  · exact cached122
  · exact cached123
  · exact cached124
  · exact cached125
  · exact cached126
  · exact cached127
  · exact cached128
  · exact cached129
  · exact cached130
  · exact cached131
  · exact cached132
  · exact cached133
  · exact cached134
  · exact cached135
  · exact cached136
  · exact cached137
  · exact cached138
  · exact cached139
  · exact cached140
  · exact cached141
  · exact cached142
  · exact cached143
  · exact cached144
  · exact cached145
  · exact cached146
  · exact cached147
  · exact cached148
  · exact cached149
  · exact cached150
  · exact cached151
  · exact cached152
  · exact cached153
  · exact cached154
  · exact cached155
  · exact cached156
  · exact cached157
  · exact cached158
  · exact cached159
  · exact cached160
  · exact cached161
  · exact cached162
  · exact cached163
  · exact cached164
  · exact cached165
  · exact cached166
  · exact cached167
  · exact cached168
  · exact cached169
  · exact cached170
  · exact cached171
  · exact cached172
  · exact cached173
  · exact cached174
  · exact cached175
  · exact cached176
  · exact cached177
  · exact cached178
  · exact cached179
  · exact cached180
  · exact cached181
  · exact cached182
  · exact cached183
  · exact cached184
  · exact cached185
  · exact cached186
  · exact cached187
  · exact cached188
  · exact cached189
  · exact cached190
  · exact cached191
  · exact cached192
  · exact cached193
  · exact cached194
  · exact cached195
  · exact cached196
  · exact cached197
  · exact cached198
  · exact cached199
  · exact cached200
  · exact cached201
  · exact cached202
  · exact cached203
  · exact cached204
  · exact cached205
  · exact cached206
  · exact cached207
  · exact cached208
  · exact cached209
  · exact cached210
  · exact cached211
  · exact cached212
  · exact cached213
  · exact cached214
  · exact cached215
  · exact cached216
  · exact cached217
  · exact cached218
  · exact cached219
  · exact cached220
  · exact cached221
  · exact cached222
  · exact cached223
  · exact cached224
  · exact cached225
  · exact cached226
  · exact cached227
  · exact cached228
  · exact cached229
  · exact cached230
  · exact cached231
  · exact cached232
  · exact cached233
  · exact cached234
  · exact cached235
  · exact cached236
  · exact cached237
  · exact cached238
  · exact cached239
  · exact cached240
  · exact cached241
  · exact cached242
  · exact cached243
  · exact cached244
  · exact cached245
  · exact cached246
  · exact cached247
  · exact cached248
  · exact cached249
  · exact cached250


theorem descriptor_forbidden {n : ℕ} [NeZero n]
    (C : ThreeArcSharedCanonicalModel (Fin n)) (d : Descriptor)
    (h : Hits C (mappedCore d)) : False := by
  rcases d with ⟨origin, flip, rotation⟩
  cases origin with
  | old index =>
      exact ThreeArcSharedSymmetry.old_core_transformed C index flip rotation h
  | shared index =>
      exact ThreeArcSharedSymmetry.forbidden_preimage (SharedCoreExclusions.active index)
        (fun D hD => SharedCoreExclusions.no_family D index hD) C flip rotation h

theorem no_family {n : ℕ} [NeZero n]
    (C : ThreeArcSharedCanonicalModel (Fin n)) (i : Index)
    (h : Hits C (coreList i)) : False := by
  apply descriptor_forbidden C (descriptor i)
  rwa [← cached_match i]

end Prize.JSP404.ThreeArcShared14Pool
