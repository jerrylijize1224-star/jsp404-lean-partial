import Prize.JSP404.ThreeArcSharedFourteen
import Prize.JSP404.EquallySpacedBinaryAxes

/-! The ordinary twenty-three-point value is 144 degrees. The checked
shared-direction exclusions give three-arc capacity thirteen; the one-arc
capacity is nine. The upper bound is the existing binary planar construction. -/
namespace Prize.JSP404
open ContinuousDirection

theorem card_le_twenty_two_of_plane_angles_four_pi_fifths
    {V : Type*} [Fintype V] (p : V → Plane) (hp : Function.Injective p)
    (hangle : ∀ u v w, u ≠ v → u ≠ w → v ≠ w →
      EuclideanGeometry.angle (p u) (p v) (p w) < 4 * Real.pi / 5) :
    Fintype.card V ≤ 22 := by
  obtain ⟨d, hd0, hd, ⟨M⟩⟩ :=
    exists_triangleCoverModel_of_plane_angles_lt_four_pi_fifths p hp hangle
  exact M.card_le_twenty_two (by linarith) hd

theorem guaranteedAngle_four_pi_fifths_of_twenty_three {N : ℕ} (hN : 23 ≤ N) :
    GuaranteedAngle N (4 * Real.pi / 5) := by
  intro s hs
  classical
  by_contra hn
  have hb : ∀ u v w : s, u ≠ v → u ≠ w → v ≠ w →
      EuclideanGeometry.angle (u : Plane) (v : Plane) (w : Plane) < 4 * Real.pi / 5 := by
    intro u v w huv huw hvw
    apply lt_of_not_ge
    intro ha
    apply hn
    exact ⟨u, u.property, v, v.property, w, w.property,
      (fun h => huv (Subtype.ext h)), (fun h => huw (Subtype.ext h)),
      (fun h => hvw (Subtype.ext h)), ha⟩
  have hc := card_le_twenty_two_of_plane_angles_four_pi_fifths
    (fun u : s => (u : Plane)) Subtype.val_injective hb
  simp only [Fintype.card_coe] at hc
  omega

theorem twentythree_thirtytwo_isSharpBound {N : ℕ} (hlo : 23 ≤ N) (hhi : N ≤ 32) :
    IsSharpBound N (4 * Real.pi / 5) := by
  refine ⟨by positivity, by linarith [Real.pi_pos],
    guaranteedAngle_four_pi_fifths_of_twenty_three hlo, ?_⟩
  intro b hb
  apply dyadic_not_guaranteed (n := 5) (by decide) (by norm_num; omega)
  norm_num
  linarith

theorem alpha_twenty_three : alpha 23 = 4 * Real.pi / 5 :=
  (twentythree_thirtytwo_isSharpBound (by decide) (by decide)).alpha_eq

end Prize.JSP404
