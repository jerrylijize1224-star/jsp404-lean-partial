import Prize.JSP404.ThreeArcSharedRotationPowers
import Prize.JSP404.ThreeArcSharedReflection

/-! Dihedral transports of canonical shared-direction exclusions. The model
transformations are already proved; all inverse type lookups are checked on
the twenty concrete labels. Preimages permit reuse of the original cores. -/
namespace Prize.JSP404.ContinuousDirection.ThreeArcSharedSymmetry

abbrev Label := Fin 20
abbrev Action := Bool × Fin 10

def typeMap (flip : Bool) (r : Fin 10) (t : Label) : Label :=
  ThreeArcSharedRotation.typePower r.val
    (if flip then ThreeArcSharedReflection.reflectType t else t)

def inverseMap (flip : Bool) (r : Fin 10) (t : Label) : Label :=
  if flip then
    ThreeArcSharedReflection.reflectType (ThreeArcSharedRotation.typePower (10 - r.val) t)
  else ThreeArcSharedRotation.typePower (10 - r.val) t

theorem typeMap_inverse : ∀ (flip : Bool) (r : Fin 10) (t : Label),
    typeMap flip r (inverseMap flip r t) = t := by
  decide +kernel

theorem inverse_typeMap : ∀ (flip : Bool) (r : Fin 10) (t : Label),
    inverseMap flip r (typeMap flip r t) = t := by
  decide +kernel

theorem typeMap_injective (flip : Bool) (r : Fin 10) :
    Function.Injective (typeMap flip r) := by
  intro a b hab
  have h := congrArg (inverseMap flip r) hab
  simpa only [inverse_typeMap] using h

theorem inverseMap_injective (flip : Bool) (r : Fin 10) :
    Function.Injective (inverseMap flip r) := by
  intro a b hab
  have h := congrArg (typeMap flip r) hab
  simpa only [typeMap_inverse] using h

noncomputable def transform {V : Type*} [Fintype V]
    (flip : Bool) (r : Fin 10) (C : ThreeArcSharedCanonicalModel V) :
    ThreeArcSharedCanonicalModel V :=
  ThreeArcSharedRotation.power r.val
    (if flip then ThreeArcSharedReflection.reflect C else C)

theorem transform_type {V : Type*} [Fintype V]
    (flip : Bool) (r : Fin 10) (C : ThreeArcSharedCanonicalModel V) (i : V) :
    (transform flip r C).type i = typeMap flip r (C.type i) := by
  unfold transform
  rw [ThreeArcSharedRotation.power_type]
  cases flip <;> simp [typeMap, ThreeArcSharedReflection.reflect_type]

theorem inverse_transform_type {V : Type*} [Fintype V]
    (flip : Bool) (r : Fin 10) (C : ThreeArcSharedCanonicalModel V) (i : V) :
    inverseMap flip r ((transform flip r C).type i) = C.type i := by
  rw [transform_type, inverse_typeMap]

abbrev Hits {V : Type*} (C : ThreeArcSharedCanonicalModel V) (core : List Label) : Prop :=
  ThreeArcSharedRotation.Hits C core

def preimageCore (core : List Label) (flip : Bool) (r : Fin 10) : List Label :=
  core.map (inverseMap flip r)

theorem hits_transform {V : Type*} [Fintype V] (C : ThreeArcSharedCanonicalModel V)
    (core : List Label) (flip : Bool) (r : Fin 10)
    (h : Hits C (preimageCore core flip r)) : Hits (transform flip r C) core := by
  intro t ht
  obtain ⟨v, hv⟩ := h (inverseMap flip r t) (List.mem_map.mpr ⟨t, ht, rfl⟩)
  refine ⟨v, ?_⟩
  rw [transform_type, hv, typeMap_inverse]

theorem hits_preimage {V : Type*} [Fintype V] (C : ThreeArcSharedCanonicalModel V)
    (core : List Label) (flip : Bool) (r : Fin 10)
    (h : Hits (transform flip r C) core) : Hits C (preimageCore core flip r) := by
  intro s hs
  obtain ⟨t, ht, rfl⟩ := List.mem_map.mp hs
  obtain ⟨v, hv⟩ := h t ht
  refine ⟨v, ?_⟩
  have he := congrArg (inverseMap flip r) hv
  simpa only [inverse_transform_type] using he

theorem hits_preimage_iff {V : Type*} [Fintype V] (C : ThreeArcSharedCanonicalModel V)
    (core : List Label) (flip : Bool) (r : Fin 10) :
    Hits C (preimageCore core flip r) ↔ Hits (transform flip r C) core :=
  ⟨hits_transform C core flip r, hits_preimage C core flip r⟩

theorem hits_image {V : Type*} [Fintype V] (C : ThreeArcSharedCanonicalModel V)
    (core : List Label) (flip : Bool) (r : Fin 10) (h : Hits C core) :
    Hits (transform flip r C) (core.map (typeMap flip r)) := by
  intro s hs
  obtain ⟨t, ht, rfl⟩ := List.mem_map.mp hs
  obtain ⟨v, hv⟩ := h t ht
  refine ⟨v, ?_⟩
  rw [transform_type, hv]

theorem forbidden_preimage {V : Type*} [Fintype V] (core : List Label)
    (hbad : ∀ C : ThreeArcSharedCanonicalModel V, Hits C core → False)
    (C : ThreeArcSharedCanonicalModel V) (flip : Bool) (r : Fin 10)
    (h : Hits C (preimageCore core flip r)) : False :=
  hbad (transform flip r C) (hits_transform C core flip r h)

theorem old_core_forbidden {n : ℕ} [NeZero n]
    (C : ThreeArcSharedCanonicalModel (Fin n)) (index : ThreeArcOrder15Data.Index)
    (h : Hits C (ThreeArcOrder15Data.coreList index)) : False :=
  ThreeArcSharedRotation.old_core_forbidden C index h

theorem old_core_transformed {n : ℕ} [NeZero n]
    (C : ThreeArcSharedCanonicalModel (Fin n)) (index : ThreeArcOrder15Data.Index)
    (flip : Bool) (r : Fin 10)
    (h : Hits C (preimageCore (ThreeArcOrder15Data.coreList index) flip r)) : False :=
  forbidden_preimage (ThreeArcOrder15Data.coreList index)
    (fun D hD => old_core_forbidden D index hD) C flip r h

theorem seven_core_transformed {V : Type*} [Fintype V]
    (C : ThreeArcSharedCanonicalModel V) (flip : Bool) (r : Fin 10)
    (h : Hits C (preimageCore SharedSevenExclusion.active flip r)) : False :=
  forbidden_preimage SharedSevenExclusion.active
    (fun D hD => SharedSevenExclusion.no_family D hD) C flip r h

noncomputable def applyAction {V : Type*} [Fintype V]
    (action : Action) (C : ThreeArcSharedCanonicalModel V) : ThreeArcSharedCanonicalModel V :=
  transform action.1 action.2 C

theorem applyAction_type {V : Type*} [Fintype V]
    (action : Action) (C : ThreeArcSharedCanonicalModel V) (i : V) :
    (applyAction action C).type i = typeMap action.1 action.2 (C.type i) :=
  transform_type action.1 action.2 C i

end Prize.JSP404.ContinuousDirection.ThreeArcSharedSymmetry
