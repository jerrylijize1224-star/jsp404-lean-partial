import Prize.JSP404.ThreeArcSharedRotation
import Prize.JSP404.ThreeArcSharedOrder
import Prize.JSP404.SharedSevenExclusion

/-! Finite cyclic transports of checked canonical exclusions. The inverse
lookup table is itself checked in the kernel on the twenty concrete labels. -/
namespace Prize.JSP404.ContinuousDirection.ThreeArcSharedRotation

open ThreeArcOrderCertificate

def typePower : ℕ → Label → Label
  | 0, t => t
  | r + 1, t => rotateType (typePower r t)

noncomputable def power {V : Type*} : ℕ → ThreeArcSharedCanonicalModel V →
    ThreeArcSharedCanonicalModel V
  | 0, C => C
  | r + 1, C => rotate (power r C)

theorem power_type {V : Type*} (r : ℕ) (C : ThreeArcSharedCanonicalModel V) (i : V) :
    (power r C).type i = typePower r (C.type i) := by
  induction r with
  | zero => rfl
  | succ r ih =>
    change rotateType ((power r C).type i) = rotateType (typePower r (C.type i))
    rw [ih]

theorem inverse_typePower : ∀ (r : Fin 10) (t : Label),
    typePower r.val (typePower (10 - r.val) t) = t := by
  decide +kernel

def Hits {V : Type*} (C : ThreeArcSharedCanonicalModel V) (core : List Label) : Prop :=
  ∀ t ∈ core, ∃ v, C.type v = t

def preimageCore (core : List Label) (r : Fin 10) : List Label :=
  core.map (typePower (10 - r.val))

theorem hits_power {V : Type*} (C : ThreeArcSharedCanonicalModel V)
    (core : List Label) (r : Fin 10) (h : Hits C (preimageCore core r)) :
    Hits (power r.val C) core := by
  intro t ht
  obtain ⟨v, hv⟩ := h (typePower (10 - r.val) t) (List.mem_map.mpr ⟨t, ht, rfl⟩)
  refine ⟨v, ?_⟩
  rw [power_type, hv, inverse_typePower r t]

theorem forbidden_preimage {V : Type*} (core : List Label)
    (hbad : ∀ C : ThreeArcSharedCanonicalModel V, Hits C core → False)
    (C : ThreeArcSharedCanonicalModel V) (r : Fin 10)
    (h : Hits C (preimageCore core r)) : False :=
  hbad (power r.val C) (hits_power C core r h)

theorem old_core_forbidden {n : ℕ} [NeZero n]
    (C : ThreeArcSharedCanonicalModel (Fin n)) (index : ThreeArcOrder15Data.Index)
    (h : Hits C (ThreeArcOrder15Data.coreList index)) : False := by
  apply ThreeArcSharedOrder.no_old_core C index
  intro t ht
  have ht' : t ∈ ThreeArcOrder15Data.coreList index := by
    simpa only [ThreeArcOrder15Data.core, List.mem_toFinset] using ht
  obtain ⟨v, hv⟩ := h t ht'
  exact Finset.mem_image.mpr ⟨v, Finset.mem_univ _, hv⟩

theorem seven_core_rotated {V : Type*} (C : ThreeArcSharedCanonicalModel V) (r : Fin 10)
    (h : Hits C (preimageCore SharedSevenExclusion.active r)) : False :=
  forbidden_preimage SharedSevenExclusion.active
    (fun D hD => SharedSevenExclusion.no_family D hD) C r h

theorem old_core_rotated {n : ℕ} [NeZero n]
    (C : ThreeArcSharedCanonicalModel (Fin n)) (index : ThreeArcOrder15Data.Index)
    (r : Fin 10) (h : Hits C (preimageCore (ThreeArcOrder15Data.coreList index) r)) : False :=
  forbidden_preimage (ThreeArcOrder15Data.coreList index)
    (fun D hD => old_core_forbidden D index hD) C r h

end Prize.JSP404.ContinuousDirection.ThreeArcSharedRotation
