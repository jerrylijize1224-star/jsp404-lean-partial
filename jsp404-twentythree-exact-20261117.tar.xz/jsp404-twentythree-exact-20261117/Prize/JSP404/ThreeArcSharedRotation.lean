import Prize.JSP404.ThreeArcSharedDirections
import Mathlib.Data.Fintype.Fin
import Mathlib.Tactic.FinCases

/-! Rotation by one unit of the period-ten shared direction model. The row
slot change is determined by its canonical integer type. No row is perturbed
independently, and all shared edge directions receive the same circle rotation. -/
namespace Prize.JSP404.ContinuousDirection.ThreeArcSharedRotation

abbrev Label := Fin 20

/-- The explicitly computable action of one sector rotation on canonical types. -/
def rotateType : Label → Label := ![
  10, 11, 0, 12, 13, 1, 2, 14, 3, 15, 4, 16, 5, 17, 18, 6, 7, 19, 8, 9]

def wraps (t : Label) : Prop := ThreeArcCanonical.starts t 2 = 9

instance (t : Label) : Decidable (wraps t) :=
  inferInstanceAs (Decidable (ThreeArcCanonical.starts t 2 = 9))

theorem rotateType_injective : Function.Injective rotateType := by decide +kernel

theorem starts_bounds : ∀ t : Label,
    ThreeArcCanonical.starts t 1 < 9 ∧ ThreeArcCanonical.starts t 2 ≤ 9 := by
  decide +kernel

theorem rotateType_starts_wrapped : ∀ t : Label, wraps t →
    ThreeArcCanonical.starts (rotateType t) 0 = ThreeArcCanonical.starts t 2 - 9 ∧
    ThreeArcCanonical.starts (rotateType t) 1 = ThreeArcCanonical.starts t 0 + 1 ∧
    ThreeArcCanonical.starts (rotateType t) 2 = ThreeArcCanonical.starts t 1 + 1 := by
  decide +kernel

theorem rotateType_starts_unwrapped : ∀ t : Label, ¬ wraps t → ∀ k : Fin 3,
    ThreeArcCanonical.starts (rotateType t) k = ThreeArcCanonical.starts t k + 1 := by
  decide +kernel

def rotateStart (t : Label) (a : Fin 3 → ℝ) : Fin 3 → ℝ :=
  if wraps t then ![a 2 - 9, a 0 + 1, a 1 + 1] else fun k => a k + 1

theorem rotateStart_cell (t : Label) (a : Fin 3 → ℝ)
    (hcell : ∀ k, (ThreeArcCanonical.starts t k : ℝ) ≤ a k ∧
      a k < (ThreeArcCanonical.starts t k : ℝ) + 1) :
    ∀ k, (ThreeArcCanonical.starts (rotateType t) k : ℝ) ≤ rotateStart t a k ∧
      rotateStart t a k < (ThreeArcCanonical.starts (rotateType t) k : ℝ) + 1 := by
  by_cases ht : wraps t
  · obtain ⟨h0, h1, h2⟩ := rotateType_starts_wrapped t ht
    intro k
    fin_cases k
    · simp only [rotateStart, if_pos ht]
      change (ThreeArcCanonical.starts (rotateType t) 0 : ℝ) ≤ a 2 - 9 ∧
        a 2 - 9 < (ThreeArcCanonical.starts (rotateType t) 0 : ℝ) + 1
      rw [h0]
      push_cast
      constructor <;> linarith [(hcell 2).1, (hcell 2).2]
    · simp only [rotateStart, if_pos ht]
      change (ThreeArcCanonical.starts (rotateType t) 1 : ℝ) ≤ a 0 + 1 ∧
        a 0 + 1 < (ThreeArcCanonical.starts (rotateType t) 1 : ℝ) + 1
      rw [h1]
      push_cast
      constructor <;> linarith [(hcell 0).1, (hcell 0).2]
    · simp only [rotateStart, if_pos ht]
      change (ThreeArcCanonical.starts (rotateType t) 2 : ℝ) ≤ a 1 + 1 ∧
        a 1 + 1 < (ThreeArcCanonical.starts (rotateType t) 2 : ℝ) + 1
      rw [h2]
      push_cast
      constructor <;> linarith [(hcell 1).1, (hcell 1).2]
  · intro k
    simp only [rotateStart, if_neg ht, rotateType_starts_unwrapped t ht k]
    push_cast
    constructor <;> linarith [(hcell k).1, (hcell k).2]

theorem rotateStart_properties (t : Label) (a : Fin 3 → ℝ)
    (hcell : ∀ k, (ThreeArcCanonical.starts t k : ℝ) ≤ a k ∧
      a k < (ThreeArcCanonical.starts t k : ℝ) + 1)
    (hnorm : 0 ≤ a 0 ∧ a 2 < 10)
    (h01 : a 0 < a 1) (h12 : a 1 < a 2) (hperiod : a 2 < a 0 + 10)
    (hw0 : a 0 < a 2 - 6) (hw1 : a 1 < a 0 + 4) (hw2 : a 2 < a 1 + 4) :
    (0 ≤ rotateStart t a 0 ∧ rotateStart t a 2 < 10) ∧
    rotateStart t a 0 < rotateStart t a 1 ∧
    rotateStart t a 1 < rotateStart t a 2 ∧
    rotateStart t a 2 < rotateStart t a 0 + 10 ∧
    rotateStart t a 0 < rotateStart t a 2 - 6 ∧
    rotateStart t a 1 < rotateStart t a 0 + 4 ∧
    rotateStart t a 2 < rotateStart t a 1 + 4 := by
  by_cases ht : wraps t
  · have hc : 9 ≤ a 2 := by
      have h := (hcell 2).1
      change ThreeArcCanonical.starts t 2 = 9 at ht
      rw [ht] at h
      norm_num at h
      exact h
    have hb : a 1 < 9 := by
      have hbI : ThreeArcCanonical.starts t 1 + 1 ≤ 9 := by
        have h := (starts_bounds t).1
        omega
      have hbR : (ThreeArcCanonical.starts t 1 : ℝ) + 1 ≤ 9 := by exact_mod_cast hbI
      linarith [(hcell 1).2]
    simp only [rotateStart, if_pos ht]
    change (0 ≤ a 2 - 9 ∧ a 1 + 1 < 10) ∧
      a 2 - 9 < a 0 + 1 ∧ a 0 + 1 < a 1 + 1 ∧
      a 1 + 1 < (a 2 - 9) + 10 ∧
      a 2 - 9 < (a 1 + 1) - 6 ∧
      a 0 + 1 < (a 2 - 9) + 4 ∧ a 1 + 1 < (a 0 + 1) + 4
    refine ⟨⟨?_, ?_⟩, ?_, ?_, ?_, ?_, ?_, ?_⟩ <;> linarith
  · have hcI : ThreeArcCanonical.starts t 2 + 1 ≤ 9 := by
      have h := (starts_bounds t).2
      change ¬ ThreeArcCanonical.starts t 2 = 9 at ht
      omega
    have hcR : (ThreeArcCanonical.starts t 2 : ℝ) + 1 ≤ 9 := by exact_mod_cast hcI
    have hc : a 2 < 9 := by linarith [(hcell 2).2]
    simp only [rotateStart, if_neg ht]
    change (0 ≤ a 0 + 1 ∧ a 2 + 1 < 10) ∧
      a 0 + 1 < a 1 + 1 ∧ a 1 + 1 < a 2 + 1 ∧
      a 2 + 1 < (a 0 + 1) + 10 ∧ a 0 + 1 < (a 2 + 1) - 6 ∧
      a 1 + 1 < (a 0 + 1) + 4 ∧ a 2 + 1 < (a 1 + 1) + 4
    refine ⟨⟨?_, ?_⟩, ?_, ?_, ?_, ?_, ?_, ?_⟩ <;> linarith [hnorm.1]

/-- Rotating a row cover only changes the integer lift of an old member. -/
theorem rowMem_rotateStart (t : Label) (a : Fin 3 → ℝ) {y : ℝ}
    (h : SharedRowMem10 a y) :
    ∃ z : ℤ, SharedRowMem10 (rotateStart t a) (y + 1 + 10 * z) := by
  by_cases ht : wraps t
  · simp only [rotateStart, if_pos ht]
    rcases h with h | h | h
    · refine ⟨0, Or.inr (Or.inl ?_)⟩
      change a 0 + 1 ≤ y + 1 + 10 * (0 : ℤ) ∧
        y + 1 + 10 * (0 : ℤ) < (a 2 - 9) + 4
      constructor <;> norm_num <;> linarith [h.1, h.2]
    · refine ⟨0, Or.inr (Or.inr ?_)⟩
      change a 1 + 1 ≤ y + 1 + 10 * (0 : ℤ) ∧
        y + 1 + 10 * (0 : ℤ) < (a 0 + 1) + 4
      constructor <;> norm_num <;> linarith [h.1, h.2]
    · refine ⟨-1, Or.inl ?_⟩
      change a 2 - 9 ≤ y + 1 + 10 * (-1 : ℤ) ∧
        y + 1 + 10 * (-1 : ℤ) < (a 1 + 1) + 4 - 10
      constructor <;> norm_num <;> linarith [h.1, h.2]
  · simp only [rotateStart, if_neg ht]
    refine ⟨0, ?_⟩
    rcases h with h | h | h
    · left
      change a 0 + 1 ≤ y + 1 + 10 * (0 : ℤ) ∧
        y + 1 + 10 * (0 : ℤ) < (a 2 + 1) + 4 - 10
      constructor <;> norm_num <;> linarith [h.1, h.2]
    · right; left
      change a 1 + 1 ≤ y + 1 + 10 * (0 : ℤ) ∧
        y + 1 + 10 * (0 : ℤ) < (a 0 + 1) + 4
      constructor <;> norm_num <;> linarith [h.1, h.2]
    · right; right
      change a 2 + 1 ≤ y + 1 + 10 * (0 : ℤ) ∧
        y + 1 + 10 * (0 : ℤ) < (a 1 + 1) + 4
      constructor <;> norm_num <;> linarith [h.1, h.2]

theorem member_rotateStart_periodic (t : Label) (a : Fin 3 → ℝ) {x : ℝ}
    (h : SharedMember10 a x) :
    ∃ z : ℤ, SharedRowMem10 (rotateStart t a) (x + 1 + 10 * z) := by
  rcases h with h | h | h
  · obtain ⟨z, hz⟩ := rowMem_rotateStart t a h
    refine ⟨z - 1, ?_⟩
    have he : (x - 10) + 1 + 10 * (z : ℝ) =
        x + 1 + 10 * ((z - 1 : ℤ) : ℝ) := by push_cast; ring
    rwa [he] at hz
  · exact rowMem_rotateStart t a h
  · obtain ⟨z, hz⟩ := rowMem_rotateStart t a h
    refine ⟨z + 1, ?_⟩
    have he : (x + 10) + 1 + 10 * (z : ℝ) =
        x + 1 + 10 * ((z + 1 : ℤ) : ℝ) := by push_cast; ring
    rwa [he] at hz

noncomputable def rotationPeriod (q : ℝ) : ℤ := if q < 9 then 0 else -1
noncomputable def rotateDirection (q : ℝ) : ℝ := q + 1 + 10 * rotationPeriod q

theorem rotateDirection_bounds {q : ℝ} (hq : 0 ≤ q ∧ q < 10) :
    0 ≤ rotateDirection q ∧ rotateDirection q < 10 := by
  unfold rotateDirection rotationPeriod
  split_ifs with h <;> norm_num <;> constructor <;> linarith [hq.1, hq.2]

theorem turn_rotateDirection {x y : ℝ}
    (hx : 0 ≤ x ∧ x < 10) (hy : 0 ≤ y ∧ y < 10) (h : SharedTurn10 x y) :
    SharedTurn10 (rotateDirection x) (rotateDirection y) := by
  unfold rotateDirection rotationPeriod
  split_ifs with hx9 hy9 <;> norm_num
  all_goals
    rcases h with h | h
    all_goals
      first
      | left; constructor <;> linarith [h.1, h.2]
      | right; constructor <;> linarith [h.1, h.2]

theorem triangle_rotateDirection {u v w : ℝ}
    (hu : 0 ≤ u ∧ u < 10) (hv : 0 ≤ v ∧ v < 10) (hw : 0 ≤ w ∧ w < 10)
    (h : SharedTriangle10 u v w) :
    SharedTriangle10 (rotateDirection u) (rotateDirection v) (rotateDirection w) := by
  rcases h with h | h
  · exact Or.inl ⟨turn_rotateDirection hu hv h.1,
      turn_rotateDirection hu hw h.2.1, turn_rotateDirection hv hw h.2.2⟩
  · exact Or.inr ⟨turn_rotateDirection hv hu h.1,
      turn_rotateDirection hw hu h.2.1, turn_rotateDirection hw hv h.2.2⟩

theorem member_rotateDirection (t : Label) (a : Fin 3 → ℝ) {q delta : ℝ}
    (hnorm : 0 ≤ rotateStart t a 0 ∧ rotateStart t a 2 < 10)
    (h01 : rotateStart t a 0 < rotateStart t a 1)
    (h12 : rotateStart t a 1 < rotateStart t a 2)
    (hq : 0 ≤ q ∧ q < 10) (hdelta : 0 ≤ delta ∧ delta ≤ 5)
    (hmem : SharedMember10 a (q + delta)) :
    SharedMember10 (rotateStart t a) (rotateDirection q + delta) := by
  have hq' := rotateDirection_bounds hq
  apply sharedMember10_of_periodic hnorm.1 h01 h12 hnorm.2
    ⟨by linarith [hq'.1, hdelta.1], by linarith [hq'.2, hdelta.2]⟩
  obtain ⟨z, hz⟩ := member_rotateStart_periodic t a hmem
  refine ⟨z - rotationPeriod q, ?_⟩
  have he : (rotateDirection q + delta) + 10 * ((z - rotationPeriod q : ℤ) : ℝ) =
      (q + delta) + 1 + 10 * (z : ℝ) := by
    unfold rotateDirection
    push_cast
    ring
  rw [he]
  exact hz

noncomputable def rotate {V : Type*} (C : ThreeArcSharedCanonicalModel V) :
    ThreeArcSharedCanonicalModel V := by
  have hp (i : V) := rotateStart_properties (C.type i) (C.start i) (C.cell i)
    (C.normalized i) (C.order01 i) (C.order12 i) (C.period i)
    (C.width0 i) (C.width1 i) (C.width2 i)
  refine {
    type := fun i => rotateType (C.type i)
    injective := rotateType_injective.comp C.injective
    start := fun i => rotateStart (C.type i) (C.start i)
    direction := fun i j => rotateDirection (C.direction i j)
    cell := fun i => rotateStart_cell (C.type i) (C.start i) (C.cell i)
    normalized := fun i => (hp i).1
    order01 := fun i => (hp i).2.1
    order12 := fun i => (hp i).2.2.1
    period := fun i => (hp i).2.2.2.1
    width0 := fun i => (hp i).2.2.2.2.1
    width1 := fun i => (hp i).2.2.2.2.2.1
    width2 := fun i => (hp i).2.2.2.2.2.2
    direction_bounds := ?_, covered_left := ?_, covered_right := ?_, triangle := ?_ }
  · intro i j hij
    exact rotateDirection_bounds (C.direction_bounds i j hij)
  · intro i j hij
    simpa using member_rotateDirection (C.type i) (C.start i)
      (q := C.direction i j) (delta := 0) (hp i).1 (hp i).2.1
      (hp i).2.2.1 (C.direction_bounds i j hij) ⟨le_rfl, by norm_num⟩
      (by simpa using C.covered_left i j hij)
  · intro i j hij
    exact member_rotateDirection (C.type j) (C.start j)
      (q := C.direction i j) (delta := 5) (hp j).1 (hp j).2.1
      (hp j).2.2.1 (C.direction_bounds i j hij) ⟨by norm_num, le_rfl⟩
      (C.covered_right i j hij)
  · intro i j k hij hik hjk
    exact triangle_rotateDirection (C.direction_bounds i j hij) (C.direction_bounds i k hik)
      (C.direction_bounds j k hjk) (C.triangle i j k hij hik hjk)

theorem rotate_type {V : Type*} (C : ThreeArcSharedCanonicalModel V) (i : V) :
    (rotate C).type i = rotateType (C.type i) := rfl

end Prize.JSP404.ContinuousDirection.ThreeArcSharedRotation
