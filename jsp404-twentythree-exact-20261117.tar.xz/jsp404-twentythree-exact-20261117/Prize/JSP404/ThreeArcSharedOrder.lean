import Prize.JSP404.ThreeArcSharedDifference
import Prize.JSP404.ThreeArcOrderModelGeneral
import Prize.JSP404.ThreeArcFourteen

/-! The relaxed shared-direction model also satisfies the already checked
pairwise strict-order specification. This reuses the old cores without choosing
an unrelated canonicalization or strengthening any membership lower bound. -/
namespace Prize.JSP404.ThreeArcSharedOrder
open ContinuousDirection ThreeArcOrderCertificate ThreeArcFractionOrder

variable {n : ℕ}

def frac (C : ThreeArcSharedCanonicalModel (Fin n)) (i : Fin n) (k : Fin 3) : ℝ :=
  C.start i k - (ThreeArcCanonical.starts (C.type i) k : ℝ)

theorem frac_bounds (C : ThreeArcSharedCanonicalModel (Fin n)) (i : Fin n) (k : Fin 3) :
    0 ≤ frac C i k ∧ frac C i k < 1 := by
  dsimp [frac]
  constructor <;> linarith [(C.cell i k).1, (C.cell i k).2]

theorem decompose (C : ThreeArcSharedCanonicalModel (Fin n)) (i : Fin n) (k : Fin 3) :
    C.start i k = (ThreeArcCanonical.starts (C.type i) k : ℝ) + frac C i k := by
  dsimp [frac]
  ring

theorem row_order (C : ThreeArcSharedCanonicalModel (Fin n)) (i : Fin n) :
    RowOrder (ThreeArcCanonical.starts (C.type i)) (frac C i) := by
  intro k
  have hw : C.start i k < C.start i (ContinuousThreeArc.previous k) + 4 - (offset k : ℝ) := by
    fin_cases k <;> simp only [ContinuousThreeArc.previous, offset] <;>
      norm_num <;> linarith [C.width0 i, C.width1 i, C.width2 i]
  have hg : C.start i k - C.start i (ContinuousThreeArc.previous k) <
      ((4 - offset k : ℤ) : ℝ) := by push_cast; linarith
  rw [decompose C i k, decompose C i (ContinuousThreeArc.previous k)] at hg
  exact (strict_gap_iff _ _ _ _ _ (frac_bounds C i k).1 (frac_bounds C i k).2
    (frac_bounds C i (ContinuousThreeArc.previous k)).1
    (frac_bounds C i (ContinuousThreeArc.previous k)).2).mp hg

theorem member_arc {a : Fin 3 → ℝ} {x : ℝ} (h : SharedMember10 a x) :
    ∃ z : ℤ, ∃ k : Fin 3, a k ≤ x + 10 * z ∧
      x + 10 * z < a (ContinuousThreeArc.previous k) + 4 - (offset k : ℝ) := by
  rcases h with h | h | h
  · obtain ⟨k, hk⟩ := ThreeArcSharedDifference.rowMem_choice h
    refine ⟨-1, k, ?_⟩
    simpa [ThreeArcSharedDifference.offset, offset, sub_eq_add_neg] using hk
  · obtain ⟨k, hk⟩ := ThreeArcSharedDifference.rowMem_choice h
    refine ⟨0, k, ?_⟩
    simpa [ThreeArcSharedDifference.offset, offset] using hk
  · obtain ⟨k, hk⟩ := ThreeArcSharedDifference.rowMem_choice h
    refine ⟨1, k, ?_⟩
    simpa [ThreeArcSharedDifference.offset, offset] using hk

theorem pair_order (C : ThreeArcSharedCanonicalModel (Fin n)) (i j : Fin n) (hij : i ≠ j) :
    PairOrder (ThreeArcCanonical.starts (C.type i)) (ThreeArcCanonical.starts (C.type j))
      (frac C i) (frac C j) := by
  obtain ⟨s, k, hk0, hk1⟩ := member_arc (C.covered_left i j hij)
  obtain ⟨t, l, hl0, hl1⟩ := member_arc (C.covered_right i j hij)
  refine ⟨k, l, s - t - 1, ?_, ?_⟩
  · have hg : C.start i k - C.start j (ContinuousThreeArc.previous l) <
        ((9 - offset l + 10 * (s - t - 1) : ℤ) : ℝ) := by
      push_cast
      linarith
    rw [decompose C i k, decompose C j (ContinuousThreeArc.previous l)] at hg
    exact (strict_gap_iff _ _ _ _ _ (frac_bounds C i k).1 (frac_bounds C i k).2
      (frac_bounds C j (ContinuousThreeArc.previous l)).1
      (frac_bounds C j (ContinuousThreeArc.previous l)).2).mp hg
  · have hg : C.start j l - C.start i (ContinuousThreeArc.previous k) <
        ((-1 - offset k - 10 * (s - t - 1) : ℤ) : ℝ) := by
      push_cast
      linarith
    rw [decompose C j l, decompose C i (ContinuousThreeArc.previous k)] at hg
    exact (strict_gap_iff _ _ _ _ _ (frac_bounds C j l).1 (frac_bounds C j l).2
      (frac_bounds C i (ContinuousThreeArc.previous k)).1
      (frac_bounds C i (ContinuousThreeArc.previous k)).2).mp hg

variable [NeZero n]

noncomputable def values (C : ThreeArcSharedCanonicalModel (Fin n)) (v : Var) : ℝ :=
  let p := (finProdFinEquiv : Label × Fin 3 ≃ Var).symm v
  frac C (Function.invFun C.type p.1) p.2

theorem values_var (C : ThreeArcSharedCanonicalModel (Fin n)) (i : Fin n) (k : Fin 3) :
    values C (ThreeArcOrderData.var (C.type i) k) = frac C i k := by
  unfold values
  rw [ThreeArcOrderData.var_decode]
  change frac C (Function.invFun C.type (C.type i)) k = frac C i k
  rw [Function.leftInverse_invFun C.injective i]

theorem model (C : ThreeArcSharedCanonicalModel (Fin n)) :
    Model ThreeArcOrderData.spec (ThreeArcOrderModelGeneral.active C.type) (values C) := by
  classical
  constructor
  · intro i hi edge he
    obtain ⟨u, _, rfl⟩ := Finset.mem_image.mp hi
    obtain ⟨k, hk, rfl⟩ := ThreeArcOrderData.width_cover (C.type u) edge he
    change values C (ThreeArcOrderData.var (C.type u) k) <
      values C (ThreeArcOrderData.var (C.type u) (ContinuousThreeArc.previous k))
    rw [values_var, values_var]
    exact gap_boundary (row_order C u k) hk
  · intro i hi j hj hij
    obtain ⟨u, _, rfl⟩ := Finset.mem_image.mp hi
    obtain ⟨v, _, rfl⟩ := Finset.mem_image.mp hj
    have huv : u ≠ v := by
      intro h
      subst v
      exact (lt_irrefl (C.type u)) hij
    obtain ⟨k, l, z, hz, hk, hl⟩ := ThreeArcFractionOrder.pair_order_bounded
      (ThreeArcOrderData.starts_bounds (C.type u))
      (ThreeArcOrderData.starts_bounds (C.type v)) (pair_order C u v huv)
    obtain ⟨q, hq⟩ : ∃ q : Fin 2, ThreeArcOrderData.shift q = z := by
      rcases hz with rfl | rfl
      · exact ⟨0, by decide⟩
      · exact ⟨1, by decide⟩
    rw [← hq] at hk hl
    obtain ⟨alt, halt, hcover⟩ := ThreeArcOrderData.options_cover
      (C.type u) (C.type v) hij k l q (gap_le hk) (gap_le hl)
    refine ⟨alt, halt, ?_⟩
    intro edge he
    rcases hcover edge he with ⟨hb, rfl⟩ | ⟨hb, rfl⟩
    · change values C (ThreeArcOrderData.var (C.type u) k) <
        values C (ThreeArcOrderData.var (C.type v) (ContinuousThreeArc.previous l))
      rw [values_var, values_var]
      exact gap_boundary hk hb
    · change values C (ThreeArcOrderData.var (C.type v) l) <
        values C (ThreeArcOrderData.var (C.type u) (ContinuousThreeArc.previous k))
      rw [values_var, values_var]
      exact gap_boundary hl hb

theorem no_old_core (C : ThreeArcSharedCanonicalModel (Fin n)) (index : ThreeArcOrder15Data.Index)
    (hcore : ThreeArcOrder15Data.core index ⊆ ThreeArcOrderModelGeneral.active C.type) : False := by
  have hx := (model C).mono hcore
  have hx' : Model ThreeArcOrder15Data.spec (ThreeArcOrder15Data.core index) (values C) := by
    change Model ThreeArcOrderFiniteSpec.spec _ _
    rw [ThreeArcOrderFiniteSpec.spec_eq_original]
    exact hx
  exact ThreeArcOrderDagCertificate.accepted_false _ _ _
    (ThreeArcOrder15Data.all_accepted index) ⟨values C, hx'⟩

end Prize.JSP404.ThreeArcSharedOrder
