import Lean.Elab.Command
import Lean.Elab.InfoTree.Main

/-! Batch generated commands without retaining editor information for each
declaration. Every enclosed command still goes through the ordinary command
elaborator and its usual kernel checks. This changes neither proof terms nor
the mathematical acceptance condition. -/
namespace Prize.JSP404
open Lean Elab Command

syntax (name := certificateBatch)
  "certificate_batch" ppLine command* "end_certificate_batch" : command

@[command_elab certificateBatch]
def elabCertificateBatch : CommandElab := fun stx =>
  withEnableInfoTree false do
    for cmd in stx[1].getArgs do
      elabCommand cmd

end Prize.JSP404
