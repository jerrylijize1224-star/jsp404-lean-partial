"""Untrusted extraction of mixed-difference theory lemmas and a SAT certificate."""
from pathlib import Path
from itertools import combinations,product
from fractions import Fraction
from collections import Counter
import argparse,json,time,sys,runpy,subprocess
import z3
z3.set_param(proof=True)
parser=argparse.ArgumentParser()
parser.add_argument('--active',default='10,12,13,14,15,16,19')
parser.add_argument('--out',type=Path,required=True)
parser.add_argument('--cadical',type=Path,default=Path('.tools/elan/toolchains/leanprover--lean4---v4.34.0/bin/cadical'))
parser.add_argument('--timeout-ms',type=int,default=30000)
parser.add_argument('--sat-timeout-seconds',type=int,default=30)
args=parser.parse_args();args.out.mkdir(parents=True,exist_ok=True)
active=list(map(int,args.active.split(',')))
if active!=sorted(set(active)) or not set(active)<=set(range(20)):
 parser.error('active labels must be distinct, sorted, and within 0..19')
base=runpy.run_path('scripts/export_three_arc_order_certificate.py')
starts=base['STARTS'];pairs=list(combinations(range(20),2));pair_id={(i,j):61+20*i+j for i,j in pairs}
def av(i,k):return 1+3*i+k
def edge(u,v,k=0,strict=True):return (u,v,k,bool(strict))
def comp(e):return (e[1],e[0],-e[2],not e[3])
initial=[];source=[]
for i in active:
 a=[av(i,k) for k in range(3)]
 for k,u in enumerate(a):initial.extend([edge(0,u,-starts[i][k],False),edge(u,0,starts[i][k]+1)])
 initial.extend([edge(a[0],a[1]),edge(a[1],a[2]),edge(a[2],a[0],10),edge(a[0],a[2],-6),edge(a[1],a[0],4),edge(a[2],a[1],4)])
for i,j in combinations(active,2):
 q=pair_id[i,j];initial.extend([edge(0,q,0,False),edge(q,0,10)])
 for label,offset in [(i,0),(j,5)]:
  source.append([[edge(av(label,k),q,offset+shift,False),edge(q,av(label,(k-1)%3),4-(10 if k==0 else 0)-offset-shift)] for shift in (-10,0,10) for k in range(3)])
def turn(u,v):return [[edge(u,v),edge(v,u,5)],[edge(u,v,10),edge(v,u,-5)]]
for i,j,k in combinations(active,3):
 u,v,w=pair_id[i,j],pair_id[i,k],pair_id[j,k]
 options=[]
 for orientation in [[(u,v),(u,w),(v,w)],[(v,u),(w,u),(w,v)]]:
  for choices in product(*(turn(*p) for p in orientation)):options.append(sum(choices,[]))
 source.append(options)
forms=[];form_ids={};supports=[];cnf=[]
def form(key):
 if key in form_ids:return form_ids[key]
 index=len(forms);forms.append(key);form_ids[key]=index
 kind=key[0]
 if kind=='top':supports.append(['truth',index]);cnf.append([index+1])
 elif kind=='bot':supports.append(['falsity',index]);cnf.append([-index-1])
 elif kind=='neg':
  a=key[1];supports.extend([['negForward',index,a],['negBack',index,a]])
  cnf.extend([[-index-1,-a-1],[index+1,a+1]])
 elif kind=='conj':
  a,b=key[1:];supports.extend([['andLeft',index,a,b],['andRight',index,a,b],['andBack',index,a,b]])
  cnf.extend([[-index-1,a+1],[-index-1,b+1],[index+1,-a-1,-b-1]])
 elif kind=='disj':
  a,b=key[1:];supports.extend([['orLeft',index,a,b],['orRight',index,a,b],['orBack',index,a,b]])
  cnf.extend([[index+1,-a-1],[index+1,-b-1],[-index-1,a+1,b+1]])
 return index
def ef(e):return form(('neg',form(('atom',comp(e))))) if e[3] else form(('atom',e))
def choice_formula(c):
 p=form(('top',))
 for e in reversed(c):p=form(('conj',ef(e),p))
 return p
def clause_formula(c):
 p=form(('bot',))
 for choice in reversed(c):p=form(('disj',choice_formula(choice),p))
 return p
for n,e in enumerate(initial):
 p=ef(e);supports.append(['initial',n,p]);cnf.append([p+1])
for n,c in enumerate(source):
 p=clause_formula(c);supports.append(['source',n,p]);cnf.append([p+1])
# Solve the exact same difference specification, rather than trusting an SMT rewrite.
used={0}
for e in initial+[e for clause in source for choice in clause for e in choice]:used.update(e[:2])
x={n:z3.Real(f'v{n}') for n in used}
def ez(e):
 u,v,k,strict=e
 return x[u]<x[v]+k if strict else x[u]<=x[v]+k
solver=z3.SolverFor('QF_RDL');solver.set(timeout=args.timeout_ms,random_seed=0)
solver.add(*[ez(e) for e in initial])
for c in source:solver.add(z3.Or([z3.And([ez(e) for e in choice]) for choice in c]))
t=time.monotonic();answer=solver.check();print('SMT',answer,time.monotonic()-t,flush=True)
if answer!=z3.unsat:raise SystemExit(1)
proof=solver.proof()
# Canonicalize arithmetic atoms to weak difference edges. No solver rewriting is trusted.
def linear(ex):
 if z3.is_rational_value(ex):return {},Fraction(ex.numerator_as_long(),ex.denominator_as_long())
 if z3.is_const(ex) and ex.sort().kind()==z3.Z3_REAL_SORT:
  return {int(str(ex)[1:]):Fraction(1)},Fraction(0)
 name=str(ex.decl().name());cs=ex.children()
 if name in ('+','-'):
  out={};constant=Fraction(0)
  for i,c in enumerate(cs):
   coefficients,k=linear(c);sgn=-1 if name=='-' and (len(cs)==1 or i>0) else 1
   constant+=sgn*k
   for v,n in coefficients.items():out[v]=out.get(v,0)+sgn*n
  return {v:n for v,n in out.items() if n},constant
 if name=='*':
  a,ak=linear(cs[0]);b,bk=linear(cs[1]);assert not a or not b
  if a:return {v:n*bk for v,n in a.items()},ak*bk
  return {v:n*ak for v,n in b.items()},ak*bk
 raise ValueError(('nonlinear',str(ex)))
def arithmetic_literal(ex):
 name=str(ex.decl().name());a,b=ex.children();aa,ak=linear(a);bb,bk=linear(b)
 coefficients=dict(aa)
 for v,n in bb.items():coefficients[v]=coefficients.get(v,0)-n
 coefficients={v:n for v,n in coefficients.items() if n};constant=ak-bk
 # Convert to not(weak reverse) for every strict relation.
 reverse=name in ('>=','<');negative=name in ('<','>')
 if reverse:coefficients={v:-n for v,n in coefficients.items()};constant=-constant
 if not coefficients:
  truth=constant<=0
  return truth != negative
 positives=[(v,n) for v,n in coefficients.items() if n>0];negatives=[(v,n) for v,n in coefficients.items() if n<0]
 assert len(positives)<=1 and len(negatives)<=1,(name,coefficients)
 u,scale=positives[0] if positives else (0,-negatives[0][1]);v,scale2=negatives[0] if negatives else (0,-scale)
 assert scale==-scale2
 offset=-constant/scale;assert offset.denominator==1
 key=edge(u,v,int(offset),False);number=form(('atom',key))+1
 return -number if negative else number

def literal(ex,negated=False):
 if z3.is_not(ex):return literal(ex.arg(0),not negated)
 if z3.is_true(ex):return not negated
 if z3.is_false(ex):return negated
 if str(ex.decl().name()) not in ('<=','<','>=','>'):raise ValueError('non-arithmetic literal')
 l=arithmetic_literal(ex)
 if type(l) is bool:return l != negated
 return -l if negated else l

def flatten_clause(ex,negated=False):
 if z3.is_or(ex) and not negated:return sum((flatten_clause(c) for c in ex.children()),[])
 return [literal(ex,negated)]

def negative_cycle(lits):
 data=[]
 for l in lits:
  f=forms[abs(l)-1];assert f[0]=='atom';e=f[1];data.append(comp(e) if l>0 else e)
 nodes=sorted({v for e in data for v in e[:2]});dist={v:0 for v in nodes};pred={}
 factor=len(nodes)+1;updated=None
 for _ in nodes:
  updated=None
  for n,(u,v,k,strict) in enumerate(data):
   value=dist[v]+factor*k-int(strict)
   if dist[u]>value:dist[u]=value;pred[u]=n;updated=u
  if updated is None:return None
 current=updated
 for _ in nodes:current=data[pred[current]][1]
 first=current;indices=[]
 while True:
  n=pred[current];indices.append(n);current=data[n][1]
  if current==first:break
  assert len(indices)<=len(nodes)
 cycle=[data[n] for n in indices];s=sum(e[2] for e in cycle)
 assert s<0 or s==0 and any(e[3] for e in cycle)
 return sorted(set(lits[n] for n in indices)),cycle
seen=set();todo=[proof];lemmas={};ignored=Counter();theory_count=0
while todo:
 n=todo.pop()
 if n.get_id() in seen:continue
 seen.add(n.get_id());todo.extend(n.children())
 if str(n.decl().name())!='th-lemma':continue
 theory_count+=1
 try:
  children=n.children();last=children[-1];assert last.sort().kind()==z3.Z3_BOOL_SORT
  ls=flatten_clause(last)
  for premise in children[:-1]:ls+=flatten_clause(premise.children()[-1],True)
  if any(type(l) is bool and l for l in ls):ignored['constant true']+=1;continue
  ls=sorted(set(l for l in ls if type(l) is not bool))
  found=negative_cycle(ls)
  if found is None:ignored['not a difference cycle']+=1;continue
  subset,cycle=found;lemmas.setdefault(tuple(subset),cycle)
 except (ValueError,AssertionError,IndexError,KeyError) as e:ignored[type(e).__name__+':'+str(e)[:70]]+=1
for lits,cycle in lemmas.items():supports.append(['theory',list(lits),cycle]);cnf.append(list(lits))
packet={'scope':'Untrusted extraction; no Lean proof claimed until checked','active':active,'initial':initial,'clauses':source,'forms':forms,'supports':supports,'theory_count':theory_count,'ignored':dict(ignored),'theory_lemmas':len(lemmas),'proof_nodes':len(seen),'solver_version':z3.get_version_string(),'variable_encoding':'anchor=0; start=1+3*label+k; direction=61+20*i+j','lean_verified':False}
(args.out/'packet.json').write_text(json.dumps(packet,separators=(',',':'))+'\n')
cnf_text=f'p cnf {len(forms)} {len(cnf)}\n'+''.join(' '.join(map(str,c))+' 0\n' for c in cnf)
(args.out/'case.cnf').write_text(cnf_text)
print({k:packet[k] for k in ['active','theory_count','theory_lemmas','ignored','proof_nodes']},'forms',len(forms),'cnf',len(cnf),flush=True)
cadical=args.cadical.resolve()
r=subprocess.run([str(cadical),'--lrat','--no-binary','--plain','-q','-t',str(args.sat_timeout_seconds),str(args.out/'case.cnf'),str(args.out/'case.lrat')],capture_output=True,text=True)
(args.out/'cadical.log').write_text(r.stdout+r.stderr)
print('CADICAL',r.returncode,r.stdout[:300],flush=True)
if r.returncode!=20:raise SystemExit(2)
for line in (args.out/'case.lrat').read_text().splitlines():
 tokens=line.split()
 if len(tokens)>1 and tokens[1]=='d':continue
 split=tokens.index('0');assert all(int(v)>=0 for v in tokens[split+1:]),'RAT step unsupported'
print('RUP-only LRAT', (args.out/'case.lrat').stat().st_size,flush=True)
