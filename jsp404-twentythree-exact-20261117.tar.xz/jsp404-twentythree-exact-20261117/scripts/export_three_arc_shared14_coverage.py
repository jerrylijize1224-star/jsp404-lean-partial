#!/usr/bin/env python3
"""Export checked dihedral-core witnesses for all 38,760 fourteen-label sets.

Python performs only untrusted finite selection.  The generated Lean modules
check every cached transformed core against the actual symmetry definitions,
transport the corresponding proved exclusion, and check every omission sextuple.
"""

import argparse
import hashlib
from itertools import combinations
import json
from pathlib import Path


# These lookup tables guide the untrusted exporter.  cached_match in the output
# checks each used image against ThreeArcSharedSymmetry.preimageCore itself.
ROTATE = [10, 11, 0, 12, 13, 1, 2, 14, 3, 15, 4, 16, 5, 17, 18, 6, 7, 19, 8, 9]
REFLECT = [15, 18, 6, 12, 19, 8, 2, 16, 5, 10, 9, 14, 3, 17, 11, 0, 7, 13, 1, 4]
CHUNK = 16
LABELS = 20
FULL = (1 << LABELS) - 1


def popcount(value):
    # Compatible with the system Python 3.9 as well as later Python versions.
    return bin(value).count('1')


def mask(core):
    return sum(1 << x for x in core)


def validate_library(cores, size, name):
    if len(cores) != size:
        raise ValueError(f'{name}: expected {size} cores, found {len(cores)}')
    for core in cores:
        if (not core or len(set(core)) != len(core)
                or any(type(x) is not int or not 0 <= x < LABELS for x in core)):
            raise ValueError(f'{name}: invalid core {core!r}')


def preimage(core, flip, rotation):
    result = list(core)
    for _ in range(10 - rotation):
        result = [ROTATE[x] for x in result]
    if flip:
        result = [REFLECT[x] for x in result]
    return result


def select_pool(old, shared):
    """Deduplicate supports, remove inclusion redundancy, then greedy cover."""
    images = {}
    for origin, library in [('old', old), ('shared', shared)]:
        for index, core in enumerate(library):
            for rotation in range(10):
                for flip in (False, True):
                    transformed = preimage(core, flip, rotation)
                    support = mask(transformed)
                    images.setdefault(support, {
                        'origin': origin, 'index': index, 'flip': flip,
                        'rotation': rotation, 'core': transformed,
                        'mask': support,
                    })
    minimal = []
    for support, record in sorted(images.items(), key=lambda p: (popcount(p[0]), p[0])):
        if not any(other['mask'] & support == other['mask'] for other in minimal):
            minimal.append(record)

    # The active-set order is documented in the manifest and deterministic.
    active_masks = [mask(core) for core in combinations(range(LABELS), 14)]
    coverage = []
    for record in minimal:
        covered = 0
        for index, active in enumerate(active_masks):
            if record['mask'] & active == record['mask']:
                covered |= 1 << index
        coverage.append(covered)
    remaining = (1 << len(active_masks)) - 1
    selected = []
    gains = []
    while remaining:
        best = max(range(len(minimal)),
                   key=lambda i: (popcount(coverage[i] & remaining), -i))
        gain = popcount(coverage[best] & remaining)
        if not gain:
            raise ValueError(f'core images miss {popcount(remaining)} active sets')
        selected.append(minimal[best])
        gains.append(gain)
        remaining &= ~coverage[best]
    stats = {
        'distinct_images': len(images),
        'inclusion_minimal_images': len(minimal),
        'pool_size': len(selected),
        'pool_old': sum(r['origin'] == 'old' for r in selected),
        'pool_shared': sum(r['origin'] == 'shared' for r in selected),
        'active_sets': len(active_masks),
        'greedy_newly_covered': gains,
    }
    return selected, stats


def lean_list(core):
    return '[' + ', '.join(str(x) for x in core) + ']'


def export_pool(pool):
    lines = '''import Prize.JSP404.ThreeArcSharedSymmetry
import Prize.JSP404.SharedCoreExclusions
import Mathlib.Tactic.FinCases

/-! A finite pool of proved exclusions. Literal lists make the coverage checks
cheap; cached_match identifies every list with an actual dihedral preimage.
The descriptor table and all finite equalities are kernel checked. -/
namespace Prize.JSP404.ThreeArcShared14Pool
open ContinuousDirection
open ThreeArcOrderCertificate
open ContinuousDirection.ThreeArcSharedSymmetry (Hits)

set_option maxRecDepth 8192
set_option maxHeartbeats 5000000

inductive Origin where
  | old (index : ThreeArcOrder15Data.Index)
  | shared (index : SharedCoreExclusions.Index)

structure Descriptor where
  origin : Origin
  flip : Bool
  rotation : Fin 10
'''.splitlines()
    lines.extend(['', f'abbrev Index := Fin {len(pool)}', '',
                  'def descriptorRows (chunk : ℕ) : Array Descriptor :=',
                  '  match chunk with'])
    for start in range(0, len(pool), CHUNK):
        descriptors = []
        for record in pool[start:start + CHUNK]:
            flip = str(record['flip']).lower()
            descriptors.append(
                f'⟨.{record["origin"]} {record["index"]}, {flip}, {record["rotation"]}⟩')
        lines.append(f'  | {start // CHUNK} => #[{", ".join(descriptors)}]')
    lines.extend('''  | _ => #[]

def descriptor (i : Index) : Descriptor :=
  (descriptorRows (i.val / 16))[i.val % 16]?.getD ⟨.old 0, false, 0⟩

def baseCore (d : Descriptor) : List Label :=
  match d.origin with
  | .old index => ThreeArcOrder15Data.coreList index
  | .shared index => SharedCoreExclusions.active index

def mappedCore (d : Descriptor) : List Label :=
  ThreeArcSharedSymmetry.preimageCore (baseCore d) d.flip d.rotation

def coreRows (chunk : ℕ) : Array (List Label) :=
  match chunk with'''.splitlines())
    for start in range(0, len(pool), CHUNK):
        lists = ', '.join(lean_list(record['core']) for record in pool[start:start + CHUNK])
        lines.append(f'  | {start // CHUNK} => #[{lists}]')
    lines.extend('''  | _ => #[]

def coreList (i : Index) : List Label :=
  (coreRows (i.val / 16))[i.val % 16]?.getD []
'''.splitlines())
    for index in range(len(pool)):
        lines.extend([
            '',
            f'theorem cached{index:03d} : coreList {index} = mappedCore (descriptor {index}) := by',
            '  decide +kernel',
        ])
    lines.extend([
        '',
        'theorem cached_match (i : Index) : coreList i = mappedCore (descriptor i) := by',
        '  fin_cases i',
    ])
    lines.extend(f'  · exact cached{index:03d}' for index in range(len(pool)))
    lines.extend('''

theorem descriptor_forbidden {n : ℕ} [NeZero n]
    (C : ThreeArcSharedCanonicalModel (Fin n)) (d : Descriptor)
    (h : Hits C (mappedCore d)) : False := by
  rcases d with ⟨origin, flip, rotation⟩
  cases origin with
  | old index =>
      exact ThreeArcSharedSymmetry.old_core_transformed C index flip rotation h
  | shared index =>
      exact ThreeArcSharedSymmetry.forbidden_preimage (SharedCoreExclusions.active index)
        (fun D hD => SharedCoreExclusions.no_family D index hD) C flip rotation h

theorem no_family {n : ℕ} [NeZero n]
    (C : ThreeArcSharedCanonicalModel (Fin n)) (i : Index)
    (h : Hits C (coreList i)) : False := by
  apply descriptor_forbidden C (descriptor i)
  rwa [← cached_match i]

end Prize.JSP404.ThreeArcShared14Pool
'''.splitlines())
    return '\n'.join(lines) + '\n'


def make_witnesses(pool):
    """Independent sextuple traversal, also used to validate emitted addresses."""
    witnesses = {}
    supports = [record['mask'] for record in pool]
    for omitted in combinations(range(LABELS), 6):
        active = FULL ^ mask(omitted)
        index = next((i for i, support in enumerate(supports)
                      if support & active == support), None)
        if index is None:
            raise ValueError(f'no pool witness for omitted labels {omitted}')
        witnesses[omitted] = index
    if len(witnesses) != 38760:
        raise ValueError('wrong number of omission sextuples')
    return witnesses


def export_coverage(pool, witnesses):
    lines = '''import Prize.JSP404.ThreeArcShared14Pool
import Mathlib.Tactic.FinCases
import Mathlib.Data.Fintype.Fin
import Lean.Elab.Tactic.Omega

/-! Explicit core witnesses for all 38760 increasing omission sextuples.
The 120 first-pair checks enumerate only valid increasing suffixes.
The nested arrays have at most 120 entries in any leaf. -/
namespace Prize.JSP404.ThreeArcShared14Coverage
open ThreeArcOrderCertificate ThreeArcShared14Pool

set_option maxRecDepth 8192
set_option maxHeartbeats 5000000

def witnessRows (a b : Label) : Array (Array (Array Index)) :=
  match a.val, b.val with'''.splitlines()
    addressed = {}
    leaf_max = 0
    for a, b in combinations(range(16), 2):
        lines.append(f'  | {a}, {b} => #[')
        for c in range(b + 1, 17):
            lines.append('      #[')
            for d in range(c + 1, 18):
                row = []
                for f in range(d + 2, 20):
                    for e in range(d + 1, f):
                        omitted = (a, b, c, d, e, f)
                        index = witnesses[omitted]
                        e1, f1 = e - (d + 1), f - (d + 1)
                        if f1 * (f1 - 1) // 2 + e1 != len(row):
                            raise ValueError('incorrect triangular witness address')
                        row.append(index)
                        addressed[omitted] = index
                comma = ',' if d < 17 else ''
                lines.append(f'        #[{", ".join(map(str, row))}]{comma}')
                leaf_max = max(leaf_max, len(row))
            comma = ',' if c < 16 else ''
            lines.append(f'      ]{comma}')
        lines.append('    ]')
    if addressed != witnesses or leaf_max > 120:
        raise ValueError('nested array export did not reproduce the sextuple map')
    lines.extend('''  | _, _ => #[]

def witness (a b c d e f : Label) : Index :=
  let cRows := (witnessRows a b)[c.val - (b.val + 1)]?.getD #[]
  let row := cRows[d.val - (c.val + 1)]?.getD #[]
  let e' := e.val - (d.val + 1)
  let f' := f.val - (d.val + 1)
  row[f' * (f' - 1) / 2 + e']?.getD 0

def avoids (i : Index) (a b c d e f : Label) : Bool :=
  (coreList i).all (fun x => decide (x ≠ a ∧ x ≠ b ∧ x ≠ c ∧ x ≠ d ∧ x ≠ e ∧ x ≠ f))

/-- Labels above `x` with room for `room` further labels. -/
def later (x : Label) (room : ℕ) : List Label :=
  (List.range' (x.val + 1) (20 - room - (x.val + 1))).map
    (fun k => ⟨k % 20, Nat.mod_lt _ (by decide)⟩)

theorem mem_later {x y : Label} {room : ℕ}
    (hxy : x < y) (hy : y.val + room < 20) : y ∈ later x room := by
  have hxy' : x.val < y.val := hxy
  unfold later
  refine List.mem_map.mpr ⟨y.val, List.mem_range'_1.mpr ?_, ?_⟩
  · constructor <;> omega
  · exact Fin.ext (Nat.mod_eq_of_lt y.isLt)

def pairChecked (a b : Label) : Bool :=
  (later b 3).all (fun c =>
    (later c 2).all (fun d =>
      (later d 1).all (fun e =>
        (later e 0).all (fun f => avoids (witness a b c d e f) a b c d e f))))

theorem pairChecked_of_late (a b : Label) (hb : 16 ≤ b.val) :
    pairChecked a b = true := by
  have hn : 20 - 3 - (b.val + 1) = 0 := by omega
  simp [pairChecked, later, hn]
'''.splitlines())
    for a, b in combinations(range(16), 2):
        lines.extend([
            '',
            f'theorem checked{a:02d}_{b:02d} : pairChecked {a} {b} = true := by',
            '  decide +kernel',
        ])
    for a in range(20):
        lines.extend([
            '',
            f'theorem row{a:02d}_checked (b : Label) (hab : {a} < b) :',
            f'    pairChecked {a} b = true := by',
            '  fin_cases b',
        ])
        for b in range(20):
            if b <= a:
                tactic = 'norm_num at hab'
            elif b >= 16:
                tactic = f'exact pairChecked_of_late {a} {b} (by decide)'
            else:
                tactic = f'exact checked{a:02d}_{b:02d}'
            lines.append(f'  · {tactic}')
    lines.extend([
        '',
        'theorem all_pairs_checked (a b : Label) (hab : a < b) :',
        '    pairChecked a b = true := by',
        '  fin_cases a',
    ])
    lines.extend(f'  · exact row{a:02d}_checked b hab' for a in range(20))
    lines.extend('''

theorem all_covered (a b c d e f : Label) (hab : a < b) (hbc : b < c)
    (hcd : c < d) (hde : d < e) (hef : e < f) :
    ∃ i : Index, (coreList i).toFinset ⊆
      (((((Finset.univ.erase a).erase b).erase c).erase d).erase e).erase f := by
  have hcd' : c.val < d.val := hcd
  have hde' : d.val < e.val := hde
  have hef' : e.val < f.val := hef
  have hf_lt : f.val < 20 := f.isLt
  have hcmem : c ∈ later b 3 := mem_later hbc (by omega)
  have hdmem : d ∈ later c 2 := mem_later hcd (by omega)
  have hemem : e ∈ later d 1 := mem_later hde (by omega)
  have hfmem : f ∈ later e 0 := mem_later hef (by omega)
  have h := all_pairs_checked a b hab
  unfold pairChecked at h
  have hc := List.all_eq_true.mp h c hcmem
  have hd := List.all_eq_true.mp hc d hdmem
  have he := List.all_eq_true.mp hd e hemem
  have hf := List.all_eq_true.mp he f hfmem
  refine ⟨witness a b c d e f, ?_⟩
  intro x hx
  have hx' : x ∈ coreList (witness a b c d e f) := List.mem_toFinset.mp hx
  unfold avoids at hf
  have hne : x ≠ a ∧ x ≠ b ∧ x ≠ c ∧ x ≠ d ∧ x ≠ e ∧ x ≠ f :=
    of_decide_eq_true (List.all_eq_true.mp hf x hx')
  obtain ⟨ha, hb, hc', hd', he', hf'⟩ := hne
  exact Finset.mem_erase.mpr ⟨hf', Finset.mem_erase.mpr ⟨he',
    Finset.mem_erase.mpr ⟨hd', Finset.mem_erase.mpr ⟨hc',
      Finset.mem_erase.mpr ⟨hb, Finset.mem_erase.mpr ⟨ha, Finset.mem_univ x⟩⟩⟩⟩⟩⟩

end Prize.JSP404.ThreeArcShared14Coverage
'''.splitlines())
    return '\n'.join(lines) + '\n'


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--old-library', required=True, type=Path)
    parser.add_argument('--selected', required=True, type=Path)
    parser.add_argument('--pool-output', required=True, type=Path)
    parser.add_argument('--coverage-output', required=True, type=Path)
    parser.add_argument('--manifest-output', type=Path)
    args = parser.parse_args()
    old = [r['core'] for r in json.loads(args.old_library.read_text())['greedy']]
    shared = json.loads(args.selected.read_text())['selected_cores']
    validate_library(old, 387, 'old')
    validate_library(shared, 15, 'shared')
    pool, stats = select_pool(old, shared)
    witnesses = make_witnesses(pool)
    args.pool_output.write_text(export_pool(pool))
    args.coverage_output.write_text(export_coverage(pool, witnesses))
    manifest = {
        'scope': 'Untrusted finite exporter data; generated Lean checks all used maps and coverage.',
        'old_library_sha256': sha256(args.old_library),
        'selected_sha256': sha256(args.selected),
        'pool_lean_sha256': sha256(args.pool_output),
        'coverage_lean_sha256': sha256(args.coverage_output),
        'active_set_order': 'itertools.combinations(range(20), 14)',
        'selection': 'inclusion-minimal images, greedy maximum uncovered gain; deterministic ties',
        'statistics': stats,
        'pool': pool,
    }
    if args.manifest_output:
        args.manifest_output.write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps(stats, sort_keys=True))


if __name__ == '__main__':
    main()
