#!/usr/bin/env python3
"""Render a kernel-only check proof against the sealed seven-row data.

Default: the first 512 non-theory supports, in four 128-entry chunks.
No Lean process is started. --full renders the same proof strategy for the
complete original support table and projects back to the old accepted API.
"""
from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--packet", type=Path, default=Path(
        "research/jsp404-shared-seven-sat/packet.json"))
    parser.add_argument("--output", type=Path, default=Path(
        "/tmp/jsp404-fast-support-smoke.lean"))
    parser.add_argument("--count", type=int, default=512)
    parser.add_argument("--offset", type=int, default=0)
    parser.add_argument("--chunk-size", type=int, default=128)
    parser.add_argument("--full", action="store_true")
    parser.add_argument("--inline-leaves", action="store_true",
                        help="inline support values/leaf proofs in chunks; fewer declarations")
    parser.add_argument("--data-namespace", default="SharedSevenCertificate")
    parser.add_argument("--lean-namespace", default="Prize.JSP404.FastSupportSmoke")
    parser.add_argument("--no-import", action="store_true")
    parser.add_argument("--no-markers", action="store_true")
    parser.add_argument("--private-results", action="store_true")
    args = parser.parse_args()
    assert 0 < args.chunk_size <= 128
    packet = json.loads(args.packet.read_text())
    selected = list(enumerate(packet["supports"]))
    if not args.full:
        selected = [(i, support) for i, support in selected if support[0] != "theory"]
        selected = selected[args.offset:args.offset + args.count]
    assert selected
    out: list[str] = [
        "import Prize.JSP404.SharedSevenCertificate",
        "",
        "/-! Uncompiled performance experiment. No existing proof is changed.",
        "Shape equalities use kernel definitional equality, then decide_eq_true;",
        "theory-cycle leaves continue to use decide +kernel. -/",
        f"namespace {args.lean_namespace}",
        "open DifferenceCertificate DifferenceSat",
        "set_option maxRecDepth 262144",
        "set_option maxHeartbeats 50000000",
        "set_option Elab.async false",
        "",
        "private theorem checked_cons {S : Spec} {fs : ℕ → Formula}",
        "    {head : Support} {tail : List Support}",
        "    (hh : Support.check S fs head = true)",
        "    (ht : tail.all (Support.check S fs) = true) :",
        "    (head :: tail).all (Support.check S fs) = true :=",
        "  Bool.and_eq_true_iff.mpr ⟨hh, ht⟩",
        "",
        "private theorem checked_append {S : Spec} {fs : ℕ → Formula}",
        "    {left right : List Support}",
        "    (hl : left.all (Support.check S fs) = true)",
        "    (hr : right.all (Support.check S fs) = true) :",
        "    (left ++ right).all (Support.check S fs) = true := by",
        "  simpa only [List.all_append] using Bool.and_eq_true_iff.mpr ⟨hl, hr⟩",
        "",
    ]
    spec = f"{args.data_namespace}.spec"
    forms = f"{args.data_namespace}.forms"

    # Keep each closed generated leaf behind an opaque theorem. The generic
    # theorem bodies reduce Support.check with symbolic arguments, so neither
    # elaboration nor kernel conversion needs to evaluate a closed Formula Eq.
    out.extend([
        "private theorem check_initial {S : Spec} {fs : ℕ → Formula}",
        "    {index p : ℕ} {edge : Edge}",
        "    (hi : S.initial[index]? = some edge)",
        "    (hs : form fs p = edgeFormula edge) :",
        "    Support.check S fs (.initial index p) = true := by",
        "  simpa only [Support.check, hi] using decide_eq_true hs",
        "",
        "private theorem check_source {S : Spec} {fs : ℕ → Formula}",
        "    {index p : ℕ} {clause : DifferenceCertificate.Clause}",
        "    (hi : S.clauses[index]? = some clause)",
        "    (hs : form fs p = clauseFormula clause) :",
        "    Support.check S fs (.source index p) = true := by",
        "  simpa only [Support.check, hi] using decide_eq_true hs",
        "",
    ])
    for kind in ("andLeft", "andRight", "andBack", "orLeft", "orRight", "orBack"):
        constructor = "conj" if kind.startswith("and") else "disj"
        out.extend([
            f"private theorem check_{kind} {{S : Spec}} {{fs : ℕ → Formula}} {{p a b : ℕ}}",
            f"    (hs : form fs p = .{constructor} (form fs a) (form fs b)) :",
            f"    Support.check S fs (.{kind} p a b) = true :=",
            "  decide_eq_true hs", "",
        ])
    for kind in ("negForward", "negBack"):
        out.extend([
            f"private theorem check_{kind} {{S : Spec}} {{fs : ℕ → Formula}} {{p a : ℕ}}",
            "    (hs : form fs p = .neg (form fs a)) :",
            f"    Support.check S fs (.{kind} p a) = true :=",
            "  decide_eq_true hs", "",
        ])
    for kind, constructor in (("truth", "top"), ("falsity", "bot")):
        out.extend([
            f"private theorem check_{kind} {{S : Spec}} {{fs : ℕ → Formula}} {{p : ℕ}}",
            f"    (hs : form fs p = .{constructor}) :",
            f"    Support.check S fs (.{kind} p) = true :=",
            "  decide_eq_true hs", "",
        ])

    def mark(phase: str) -> None:
        if args.no_markers:
            return
        prefix = args.output.with_suffix("")
        out.extend([
            "#eval (do",
            "  let stamp ← IO.monoMsNow",
            f"  IO.FS.writeFile {json.dumps(str(prefix) + '-' + phase + '.marker')} (toString stamp)",
            "  : IO Unit)", "",
        ])

    def edge(value: list) -> str:
        return f"⟨{value[0]}, {value[1]}, {value[2]}, {str(value[3]).lower()}⟩"

    def edges(values: list) -> str:
        return "[" + ", ".join(map(edge, values)) + "]"

    def support(value: list) -> str:
        if value[0] != "theory":
            return "." + value[0] + " " + " ".join(map(str, value[1:]))
        lits = ", ".join(f"⟨{abs(lit) - 1}, {str(lit > 0).lower()}⟩" for lit in value[1])
        return ".theory [" + lits + "] " + edges(value[2])

    def form(index: int) -> str:
        return f"form {forms} {index}"

    def shape(value: list) -> tuple[tuple, str]:
        kind = value[0]
        if kind == "initial":
            index, parent = value[1:]
            return (kind, index, parent), f"{form(parent)} = edgeFormula {edge(packet['initial'][index])}"
        if kind == "source":
            index, parent = value[1:]
            clause = "[" + ", ".join(map(edges, packet["clauses"][index])) + "]"
            return (kind, index, parent), f"{form(parent)} = clauseFormula {clause}"
        if kind.startswith("and") or kind.startswith("or"):
            head = "conj" if kind.startswith("and") else "disj"
            parent, a, b = value[1:]
            return (head, parent, a, b), f"{form(parent)} = .{head} ({form(a)}) ({form(b)})"
        if kind.startswith("neg"):
            parent, a = value[1:]
            return ("neg", parent, a), f"{form(parent)} = .neg ({form(a)})"
        if kind in ("truth", "falsity"):
            head = "top" if kind == "truth" else "bot"
            return (head, value[1]), f"{form(value[1])} = .{head}"
        raise ValueError(kind)

    mark("imports")
    if not args.inline_leaves:
        for original_index, value in selected:
            out.append(f"private noncomputable def support_{original_index:05d} : Support := {support(value)}")
    out.append("")

    chunks: list[tuple[str, list[tuple[int, list]]]] = []
    for chunk_index, low in enumerate(range(0, len(selected), args.chunk_size)):
        entries = selected[low:low + args.chunk_size]
        name = f"chunk_{chunk_index:04d}"
        contents = ", ".join(
            support(value) if args.inline_leaves else f"support_{index:05d}"
            for index, value in entries)
        out.append(f"private noncomputable def {name} : List Support := [{contents}]")
        chunks.append((name, entries))
    out.append("")
    mark("data")

    shared_shapes: dict[tuple, str] = {}
    for _, value in selected:
        if value[0] == "theory":
            continue
        key, statement = shape(value)
        if key not in shared_shapes:
            name = f"shape_{len(shared_shapes):05d}"
            shared_shapes[key] = name
            out.extend([f"private theorem {name} : {statement} := by", "  rfl", ""])
    mark("shapes")

    def check_proof(value: list) -> str:
        if value[0] == "theory":
            return "by decide +kernel"
        key, _ = shape(value)
        lookup = " (by rfl)" if value[0] in ("initial", "source") else ""
        return f"check_{value[0]}{lookup} {shared_shapes[key]}"

    if not args.inline_leaves:
        for original_index, value in selected:
            out.extend([
                f"private theorem check_{original_index:05d} :",
                f"    Support.check {spec} {forms} support_{original_index:05d} = true := by",
            ])
            if value[0] == "theory":
                out.append("  decide +kernel")
            else:
                out.append(f"  exact {check_proof(value)}")
            out.append("")
    mark("checks")

    for name, entries in chunks:
        out.extend([
            f"private theorem {name}_checked :",
            f"    {name}.all (Support.check {spec} {forms}) = true := by",
            f"  unfold {name}",
        ])
        for original_index, value in entries:
            proof = f"({check_proof(value)})" if args.inline_leaves else f"check_{original_index:05d}"
            out.append(f"  refine checked_cons {proof} ?_")
        out.extend(["  rfl", ""])

    merges = 0

    def merge(names: list[str]) -> str:
        nonlocal merges
        if len(names) == 1:
            return names[0]
        mid = len(names) // 2
        left, right = merge(names[:mid]), merge(names[mid:])
        name = f"join_{merges:04d}"
        merges += 1
        out.extend([
            f"private noncomputable def {name} : List Support := {left} ++ {right}",
            f"private theorem {name}_checked :",
            f"    {name}.all (Support.check {spec} {forms}) = true :=",
            f"  checked_append {left}_checked {right}_checked",
            "",
        ])
        return name

    table = merge([name for name, _ in chunks])
    out.extend([
        f"noncomputable def sample : Array Support := {table}.toArray",
        f"theorem sample_checked : accepted {spec} {forms} sample = true := by",
        f"  exact {table}_checked",
        "",
    ])
    if args.full:
        out.extend([
            f"theorem support_table_eq : sample = {args.data_namespace}.supports := by",
            "  rfl",
            "",
            "theorem full_checked :",
            f"    accepted {spec} {forms} {args.data_namespace}.supports = true := by",
            f"  exact (congrArg (fun table => accepted {spec} {forms} table = true)",
            "    support_table_eq).mp sample_checked",
            "",
        ])
    mark("aggregated")
    out.extend((["#print axioms sample_checked"] if not args.no_markers else []) + [f"end {args.lean_namespace}", ""])
    if args.no_import:
        out = [line for line in out if not line.startswith("import ")]
    if args.private_results:
        out = [line.replace("theorem sample_checked", "private theorem sample_checked").replace("theorem support_table_eq", "private theorem support_table_eq").replace("theorem full_checked", "private theorem full_checked") for line in out]
    args.output.write_text("\n".join(out))
    print(json.dumps({
        "output": str(args.output), "supports": len(selected),
        "shared_shapes": len(shared_shapes), "chunks": len(chunks),
        "inline_leaves": args.inline_leaves,
        "support_kinds": dict(Counter(value[0] for _, value in selected)),
        "bytes": args.output.stat().st_size,
        "lean_executed": False,
    }, indent=2))


if __name__ == "__main__":
    main()
