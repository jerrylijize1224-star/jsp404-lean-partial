"""Discover smaller shared-direction contradiction cores.

Every newly registered core has an actual QF_RDL UNSAT result. Dihedral images
are used only for exploratory combinatorial coverage. This script exports no
Lean proof and does not change the existing batch results.
"""

import argparse
import hashlib
from itertools import combinations
import json
from pathlib import Path
import runpy
import time

import z3


ALL_LABELS = frozenset(range(20))
INITIAL_SHARED_CORE = (10, 12, 13, 14, 15, 16, 19)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def mask(labels):
    return sum(1 << label for label in labels)


def dihedral_maps(types):
    lookup = {frozenset(row): index for index, row in enumerate(types)}
    maps = [
        tuple(lookup[frozenset((rotation + sign * cell) % 10 for cell in row)]
              for row in types)
        for sign in (1, -1)
        for rotation in range(10)
    ]
    assert len(lookup) == 20 and len(set(maps)) == 20
    return maps


def core_images(core, maps):
    return sorted({tuple(sorted(mapping[label] for label in core)) for mapping in maps})


def remove_covered(uncovered, image_masks):
    remaining = [row for row in uncovered
                 if not any(row[1] & core == core for core in image_masks)]
    return remaining, len(uncovered) - len(remaining)


def save(path, output, started):
    output["wall_seconds"] = time.monotonic() - started
    output["check_counts"] = {
        status: sum(row["status"] == status for row in output["checks"])
        for status in ("unsat", "sat", "unknown", "error")
    }
    temporary = path.with_name(path.name + ".partial")
    temporary.write_text(json.dumps(output, indent=2) + "\n")
    temporary.replace(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--timeout-ms", type=int, default=4000)
    parser.add_argument("--seed-library", type=Path)
    parser.add_argument("--budget-seconds", type=float, default=355)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output already exists; choose a new path")
    if args.timeout_ms <= 0 or args.budget_seconds <= 0:
        parser.error("timeout and budget must be positive")

    started = time.monotonic()
    deadline = started + args.budget_seconds
    canonical_path = args.root / "scripts/export_three_arc_order_certificate.py"
    batch_path = args.root / "scripts/explore_shared_triangle_fourteen_batch.py"
    library_path = args.root / "research/jsp404-order15-certificate-input.json"
    initial_proof_path = args.root / "Prize/JSP404/SharedSevenExclusion.lean"
    canonical = runpy.run_path(str(canonical_path))
    batch = runpy.run_path(str(batch_path))
    payload = json.loads(library_path.read_text())
    pairwise_records = payload["greedy"] if isinstance(payload, dict) else payload
    pairwise_masks = []
    for row in pairwise_records:
        assert row["core"] == sorted(set(row["core"]))
        assert set(row["core"]) <= ALL_LABELS
        assert row["core_mask"] == mask(row["core"])
        pairwise_masks.append(row["core_mask"])
    maps = dihedral_maps(canonical["TYPES"])
    images = core_images(INITIAL_SHARED_CORE, maps)
    initial_image_masks = [mask(row) for row in images]

    total = 0
    uncovered = []
    for missing in combinations(range(20), 6):
        total += 1
        active_mask = (1 << 20) - 1 - mask(missing)
        if not any(active_mask & core == core for core in pairwise_masks):
            uncovered.append((missing, active_mask))
    pairwise_covered = total - len(uncovered)
    uncovered, initially_added = remove_covered(uncovered, initial_image_masks)
    assert total == 38760 and len(pairwise_records) == 387
    assert pairwise_covered == 31699
    assert len(images) == 10 and initially_added == 2822 and len(uncovered) == 4239

    source_hashes = {
        "canonical": digest(canonical_path),
        "batch_model": digest(batch_path),
        "pairwise_library": digest(library_path),
        "provided_core_theorem": digest(initial_proof_path),
    }
    output = {
        "scope": "Untrusted shared-direction core discovery with exploratory image coverage",
        "proof_certificate_exported": False,
        "symmetry_transport_lean_proved": False,
        "model_revision": batch["MODEL_REVISION"],
        "solver_version": z3.get_version_string(),
        "script_sha256": digest(Path(__file__)),
        "source_hashes": source_hashes,
        "timeout_ms": args.timeout_ms,
        "budget_seconds": args.budget_seconds,
        "active14_total": total,
        "baseline_pairwise_core_count": len(pairwise_records),
        "baseline_pairwise_direct_coverage": pairwise_covered,
        "provided_shared_core": {
            "active": list(INITIAL_SHARED_CORE),
            "source_theorem": "Prize.JSP404.SharedSevenExclusion.no_family",
            "images": [list(row) for row in images],
            "additional_exploratory_coverage": initially_added,
        },
        "new_cores": [],
        "checks": [],
        "seed_attempts": [],
        "coverage_history": [{"new_core_count": 0, "uncovered_active14": len(uncovered)}],
        "exploratory_uncovered_active14": len(uncovered),
        "complete": False,
    }
    if args.seed_library:
        prior = json.loads(args.seed_library.read_text())
        assert prior["source_hashes"] == source_hashes
        assert prior["model_revision"] == output["model_revision"]
        for record in prior["new_cores"]:
            check = prior["checks"][record["actual_unsat_check_index"]]
            assert check["status"] == "unsat" and check["active"] == record["active"]
            uncovered, _ = remove_covered(uncovered,
                [mask(row) for row in core_images(record["active"], maps)])
        output["new_cores"] = prior["new_cores"]
        output["checks"] = prior["checks"]
        output["seed_attempts"] = prior["seed_attempts"]
        output["coverage_history"] = prior["coverage_history"]
        output["exploratory_uncovered_active14"] = len(uncovered)
        output["seed_library_sha256"] = digest(args.seed_library)
        output["seed_library_wall_seconds"] = prior["wall_seconds"]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    cache = {mask(record["active"]): record for record in output["checks"]
             if record["status"] in ("unsat", "sat")}

    def query(active, purpose, **details):
        active = tuple(sorted(active))
        key = mask(active)
        if key in cache:
            return cache[key]
        if time.monotonic() >= deadline:
            return None
        candidate = {
            "index": len(output["checks"]),
            "active": list(active),
            "missing": sorted(ALL_LABELS - set(active)),
        }
        try:
            result = batch["solve_candidate"](
                candidate, canonical["STARTS"], args.timeout_ms, deadline)
        except Exception as error:
            result = dict(candidate, status="error", reason=repr(error))
        result.update(purpose=purpose, **details)
        output["checks"].append(result)
        cache[key] = result
        save(args.output, output, started)
        print(json.dumps({field: result[field] for field in
                          ("index", "active", "purpose", "status", "solve_seconds")
                          if field in result}), flush=True)
        return result

    def minimize(seed, seed_result):
        current = tuple(seed)
        current_result = seed_result
        trace = []
        final_deletions = []
        while True:
            changed = False
            final_deletions = []
            for label in tuple(current):
                smaller = tuple(item for item in current if item != label)
                result = query(smaller, "deletion", parent_active=list(current),
                               removed_label=label)
                if result is None:
                    return current, current_result, trace, final_deletions, False
                trace.append({"from": list(current), "removed_label": label,
                              "check_index": result["index"], "status": result["status"]})
                if result["status"] == "unsat":
                    current = smaller
                    current_result = result
                    changed = True
                else:
                    final_deletions.append({"removed_label": label,
                                            "check_index": result["index"],
                                            "status": result["status"]})
            if not changed:
                return current, current_result, trace, final_deletions, True

    save(args.output, output, started)
    print(json.dumps({"initial_pairwise_coverage": pairwise_covered,
                      "provided_core_images": len(images),
                      "provided_core_added_coverage": initially_added,
                      "remaining_active14": len(uncovered)}), flush=True)
    attempted_seeds = set()
    stop_reason = "wall_budget"
    while uncovered and time.monotonic() < deadline:
        seed_entry = next((row for row in uncovered if row[1] not in attempted_seeds), None)
        if seed_entry is None:
            stop_reason = "all_remaining_seeds_attempted"
            break
        missing, seed_mask = seed_entry
        seed = tuple(sorted(ALL_LABELS - set(missing)))
        attempted_seeds.add(seed_mask)
        result = query(seed, "seed")
        if result is None:
            break
        output["seed_attempts"].append({"active": list(seed),
                                        "check_index": result["index"],
                                        "status": result["status"]})
        if result["status"] == "sat":
            stop_reason = "independently_checked_sat_seed"
            break
        if result["status"] != "unsat":
            continue

        core, core_result, trace, last_pass, minimization_complete = minimize(seed, result)
        assert core_result["status"] == "unsat"
        images = core_images(core, maps)
        uncovered, newly_covered = remove_covered(uncovered, [mask(row) for row in images])
        assert newly_covered > 0
        core_record = {
            "active": list(core),
            "actual_unsat_check_index": core_result["index"],
            "seed_active": list(seed),
            "deletion_trace": trace,
            "final_single_deletions": last_pass,
            "greedy_pass_complete": minimization_complete,
            "single_deletion_sat_models_checked": minimization_complete and all(
                row["status"] == "sat" for row in last_pass),
            "images": [list(row) for row in images],
            "images_individually_solved": False,
            "new_exploratory_coverage": newly_covered,
            "remaining_active14": len(uncovered),
        }
        output["new_cores"].append(core_record)
        output["exploratory_uncovered_active14"] = len(uncovered)
        output["coverage_history"].append({
            "new_core_count": len(output["new_cores"]),
            "uncovered_active14": len(uncovered),
            "actual_unsat_core": list(core),
        })
        save(args.output, output, started)
        print(json.dumps({"new_core": list(core), "images": len(images),
                          "newly_covered": newly_covered,
                          "remaining_active14": len(uncovered)}), flush=True)
        if not minimization_complete:
            break
    if not uncovered:
        stop_reason = "all_active14_exploratorily_covered"
    output["stop_reason"] = stop_reason
    output["exploratory_uncovered_active14"] = len(uncovered)
    output["remaining_missing_sixes"] = [list(row[0]) for row in uncovered]
    output["all_active14_exploratorily_covered"] = not uncovered
    output["complete"] = True
    output["source_hashes_preserved"] = source_hashes == {
        "canonical": digest(canonical_path),
        "batch_model": digest(batch_path),
        "pairwise_library": digest(library_path),
        "provided_core_theorem": digest(initial_proof_path),
    }
    save(args.output, output, started)
    print(json.dumps({"new_cores": len(output["new_cores"]),
                      "remaining_active14": len(uncovered),
                      "check_counts": output["check_counts"],
                      "stop_reason": stop_reason,
                      "wall_seconds": output["wall_seconds"]}), flush=True)


if __name__ == "__main__":
    main()
