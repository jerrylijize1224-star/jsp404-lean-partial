#!/usr/bin/env python3
"""Update the twenty-three-point release notes only from complete verified logs.

This script does not run Lean or create a release archive. By default it checks
the evidence and reports the measured counts. Pass --apply to update the notes
after the normal project build and axiom audit have both finished successfully.
"""

from pathlib import Path
import argparse
import hashlib
import json
import re


ROOT = Path(__file__).resolve().parents[1]
DATE = "2026-11-17"
EXPECTED_TOTAL = 5425
EXPECTED_NEW = 532
BASE_NEW_MODULES = 25
SPLIT_CORE_INDICES = {9, 10, 11, 12, 13}
FORM_BLOCK_CORE_INDICES = {10, 11, 12, 13}
FORM_BLOCK_SIZE = 1024
BATCH_COMMAND_CORE_INDICES = {11, 12, 13}
BATCH_HELPER_PATH = "Prize/JSP404/CertificateBatch.lean"
ALLOWED_AXIOMS = {"propext", "Classical.choice", "Quot.sound"}
# These bytes match the sealed seven-core snapshot published before this step.
TARGET_HASHES = {
    "Prize/JSP404/Basic.lean": "3c7d576279ed91121740df659fcb0026e35d49b6691c23242de1ca45a6af0bce",
    "Prize/JSP404/Target.lean": "fe517395815f45e102699d8fbce73ba937460a62f723e970d4689fbeee329fca",
}
AUDIT_MARKER = "-- Shared-direction fourteen-row cover and the twenty-three-point value."
CHINESE_HEADING = "## 2026-11-17　23 点精确值为 144°"


def require(condition, message):
    if not condition:
        raise SystemExit(message)


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def proof_code(text):
    """Remove nested comments and strings before looking for proof commands."""
    result = []
    index = depth = 0
    string = False
    while index < len(text):
        if depth:
            if text.startswith("/-", index):
                depth += 1
                index += 2
            elif text.startswith("-/", index):
                depth -= 1
                index += 2
            else:
                index += 1
        elif string:
            if text[index] == "\\":
                index += 2
            elif text[index] == '"':
                string = False
                index += 1
            else:
                index += 1
        elif text.startswith("/-", index):
            result.append(" ")
            depth = 1
            index += 2
        elif text.startswith("--", index):
            result.append(" ")
            end = text.find("\n", index)
            index = len(text) if end < 0 else end
        elif text[index] == '"':
            result.append(" ")
            string = True
            index += 1
        else:
            result.append(text[index])
            index += 1
    require(not depth and not string, "Unterminated Lean comment or string requires review")
    return "".join(result)


def verify():
    build_path = ROOT / "research/logs/jsp404-build.log"
    audit_path = ROOT / "research/logs/jsp404-audit.log"
    audit_source = ROOT / "Prize/Audit.lean"
    build = build_path.read_text()
    audit = audit_path.read_text()
    source = audit_source.read_text()
    require("error:" not in build.lower() and "sorryAx" not in build,
            "The full build log contains an error or sorryAx")
    final_build_line = build.strip().splitlines()[-1] if build.strip() else ""
    completion = re.fullmatch(r"Build completed successfully \((\d+) jobs\)\.", final_build_line)
    require(completion is not None, "The final full-build line must record successful completion")
    require("error:" not in audit.lower() and "sorryAx" not in audit,
            "The axiom log contains an error or sorryAx")
    expected = re.findall(r"^#print axioms (\S+)\s*$", source, re.M)
    require(len(expected) == len(set(expected)) == EXPECTED_TOTAL,
            "Unexpected audit scope: review the 5425 declaration list before finalizing")
    require(source.count(AUDIT_MARKER) == 1, "The new audit section marker is missing or duplicated")
    new_expected = re.findall(r"^#print axioms (\S+)\s*$", source.split(AUDIT_MARKER)[1], re.M)
    require(len(new_expected) == EXPECTED_NEW, "Unexpected scope of the 532 new audited declarations")

    entries = re.findall(r"'([^']+)' depends on axioms:\s*\[([^\]]*)\]", audit, re.S)
    free = re.findall(r"'([^']+)' does not depend on any axioms", audit)
    require(len(entries) == audit.count("depends on axioms:"), "An axiom entry was not parsed")
    actual = [name for name, _ in entries] + free
    require(len(actual) == len(set(actual)) == len(expected) and set(actual) == set(expected),
            "The axiom log is stale, duplicated or does not exactly match Prize/Audit.lean")
    dependencies = {}
    for name, names in entries:
        values = set(re.split(r",\s*", names.strip())) if names.strip() else set()
        require(values <= ALLOWED_AXIOMS, f"Disallowed axiom dependencies: {name}: {sorted(values)}")
        dependencies[name] = sorted(values)
    dependencies.update({name: [] for name in free})
    final_names = [
        "Prize.JSP404.ContinuousDirection.no_fourteen_shared_family",
        "Prize.JSP404.ContinuousDirection.TriangleCoverModel.three_card_le_thirteen",
        "Prize.JSP404.guaranteedAngle_four_pi_fifths_of_twenty_three",
        "Prize.JSP404.twentythree_thirtytwo_isSharpBound",
        "Prize.JSP404.alpha_twenty_three",
    ]
    require(set(final_names) <= set(dependencies), "A final twenty-three-point theorem is not audited")
    for index in range(1, 15):
        for suffix in ("checked", "context_eq", "no_model", "cnfRefutation.unsat"):
            name = f"Prize.JSP404.SharedCores.Core{index:02d}.{suffix}"
            require(name in dependencies, f"Missing concrete core audit: {name}")
    require("import Prize.JSP404.TwentythreeExact" in (ROOT / "Prize.lean").read_text(),
            "The final result is not included in the project build")
    for relative, digest in TARGET_HASHES.items():
        require(sha256(ROOT / relative) == digest, f"An original target definition changed: {relative}")

    lean_sources = [ROOT / "Prize.lean"] + sorted((ROOT / "Prize").rglob("*.lean"))
    latest_source = max(path.stat().st_mtime for path in lean_sources)
    require(build_path.stat().st_mtime >= latest_source, "A Lean source changed after the full build")
    require(audit_path.stat().st_mtime >= build_path.stat().st_mtime,
            "The axiom audit must run after the completed full build")
    forbidden = re.compile(r"\b(?:sorry|admit|native_decide|axiom)\b")
    for path in lean_sources:
        text = path.read_text()
        if forbidden.search(text):
            require(not forbidden.search(proof_code(text)),
                    f"Forbidden proof command in {path.relative_to(ROOT).as_posix()}")
    lean_pin = (ROOT / "lean-toolchain").read_text().strip()
    require(lean_pin == "leanprover/lean4:v4.34.0", "The Lean pin changed")
    mathlib_pin = "5ed2965256430c3649e86755f9576b54eca72435"
    require(f'rev = "{mathlib_pin}"' in (ROOT / "lakefile.toml").read_text(), "The mathlib pin changed")
    reproduction_path = ROOT / "research/logs/jsp404-shared-core-library-reproduction-20261115.json"
    reproduction = json.loads(reproduction_path.read_text())
    batch_source = reproduction.get("command_batch_source")
    require(isinstance(batch_source, dict) and batch_source.get("path") == BATCH_HELPER_PATH,
            "The command batch helper reproduction evidence is missing or unexpected")
    batch_helper = ROOT / BATCH_HELPER_PATH
    require(sha256(batch_helper) == batch_source["sha256"]
            and batch_helper.stat().st_size == batch_source["bytes"],
            "Stale byte-reproduction evidence for the command batch helper")
    batch_source_record = {key: batch_source[key] for key in ("path", "bytes", "sha256")}
    rows = reproduction["rows"]
    require(sorted(row["index"] for row in rows) == list(range(1, 15)),
            "The core reproduction record does not cover all fourteen sources")
    extra_sources = set()
    form_sources = set()
    form_block_counts = {}
    for row in rows:
        index = row["index"]
        if index in BATCH_COMMAND_CORE_INDICES:
            require(row.get("batch_commands") is True,
                    f"Expected command batching for Core{index:02d}")
        else:
            require(row.get("batch_commands", False) is False,
                    f"Unexpected command batching for Core{index:02d}")
        main_relative = f"Prize/JSP404/SharedCores/Core{index:02d}.lean"
        path = ROOT / main_relative
        require(row["reproduced_byte_identically"]
                and sha256(path) == row["lean_source_sha256"]
                and path.stat().st_size == row["lean_source_bytes"],
                f"Stale byte-reproduction evidence for Core{index:02d}")
        expected_sources = {main_relative}
        if index in SPLIT_CORE_INDICES:
            expected_sources.update(
                f"Prize/JSP404/SharedCores/Core{index:02d}{part}.lean"
                for part in ("Data", "Checks", "Lrat"))
            require(row.get("proof_layout") in (None, "split_modules"),
                    f"Unexpected proof layout for Core{index:02d}")
        if index in FORM_BLOCK_CORE_INDICES:
            require(row.get("form_block_size") == FORM_BLOCK_SIZE,
                    f"Expected 1024-definition form blocks for Core{index:02d}")
            packet_path = ROOT / f"research/jsp404-shared-core-library/{index:02d}/packet.json"
            packet = json.loads(packet_path.read_text())
            form_count = len(packet["forms"])
            require(form_count > 0 and row["forms"] == form_count,
                    f"The formula count for Core{index:02d} does not match its packet")
            block_count = (form_count + FORM_BLOCK_SIZE - 1) // FORM_BLOCK_SIZE
            form_block_counts[index] = block_count
            core_form_sources = {
                f"Prize/JSP404/SharedCores/Core{index:02d}Forms{block:02d}.lean"
                for block in range(block_count)
            }
            expected_sources.update(core_form_sources)
            form_sources.update(core_form_sources)
        elif index in SPLIT_CORE_INDICES:
            require(row.get("form_block_size", 0) == 0,
                    f"Core{index:02d} should retain its formula definitions in Data")
            form_block_counts[index] = 0
        source_map = row.get("lean_sources")
        if source_map is None:
            require(index not in SPLIT_CORE_INDICES,
                    f"Missing split-source reproduction evidence for Core{index:02d}")
        else:
            require(isinstance(source_map, dict) and set(source_map) == expected_sources,
                    f"The reproduction source set for Core{index:02d} is incomplete or unexpected")
            for relative, evidence in source_map.items():
                path = ROOT / relative
                require(sha256(path) == evidence["sha256"] and path.stat().st_size == evidence["bytes"],
                        f"Stale byte-reproduction evidence: {relative}")
            extra_sources.update(set(source_map) - {main_relative})
        for name, evidence in row["files"].items():
            path = ROOT / f"research/jsp404-shared-core-library/{index:02d}" / name
            require(sha256(path) == evidence["sha256"], f"Changed core input: {index:02d}/{name}")
    expected_extra_count = 3 * len(SPLIT_CORE_INDICES) + sum(form_block_counts.values())
    require(len(extra_sources) == expected_extra_count,
            "The split certificate or formula-block module count is inconsistent")
    actual_form_sources = {
        path.relative_to(ROOT).as_posix()
        for index in SPLIT_CORE_INDICES
        for path in (ROOT / "Prize/JSP404/SharedCores").glob(f"Core{index:02d}Forms*.lean")
    }
    require(actual_form_sources == form_sources,
            "Formula block files are missing or include stale extra modules")
    new_lean_module_count = BASE_NEW_MODULES + len(extra_sources) + 1
    coverage_path = ROOT / "research/logs/jsp404-shared14-coverage-20261115.json"
    coverage = json.loads(coverage_path.read_text())
    for key, relative in [
        ("old_library_sha256", "research/jsp404-order15-certificate-input.json"),
        ("selected_sha256", "research/jsp404-shared-core-selection.json"),
        ("pool_lean_sha256", "Prize/JSP404/ThreeArcShared14Pool.lean"),
        ("coverage_lean_sha256", "Prize/JSP404/ThreeArcShared14Coverage.lean"),
    ]:
        require(sha256(ROOT / relative) == coverage[key], f"Stale coverage record: {relative}")
    axiom_union = sorted({axiom for values in dependencies.values() for axiom in values})
    return {
        "scope": "Complete project build and exact axiom audit for the twenty-three-point result",
        "date": DATE,
        "build_jobs": int(completion.group(1)),
        "audited_declarations": len(actual),
        "new_audited_declarations": len(new_expected),
        "new_lean_modules": new_lean_module_count,
        "batch_command_core_indices": sorted(BATCH_COMMAND_CORE_INDICES),
        "command_batch_source": batch_source_record,
        "split_core_indices": sorted(SPLIT_CORE_INDICES),
        "form_block_core_indices": sorted(FORM_BLOCK_CORE_INDICES),
        "form_block_size": FORM_BLOCK_SIZE,
        "form_blocks_per_core": {f"{index:02d}": count for index, count in sorted(form_block_counts.items())},
        "form_definition_modules": sorted(form_sources),
        "additional_certificate_modules": sorted(extra_sources),
        "axiom_free_declarations": len(free),
        "actual_axioms": axiom_union,
        "final_theorem_dependencies": {name: dependencies[name] for name in final_names},
        "original_target_sha256": TARGET_HASHES,
        "lean_pin": lean_pin,
        "mathlib_pin": mathlib_pin,
        "transitive_manifest_sha256": sha256(ROOT / "lake-manifest.json"),
        "build_log_sha256": sha256(build_path),
        "audit_log_sha256": sha256(audit_path),
        "audit_source_sha256": sha256(audit_source),
        "core_reproduction_record_sha256": sha256(reproduction_path),
        "coverage_record_sha256": sha256(coverage_path),
        "lean_source_sha256": {
            path.relative_to(ROOT).as_posix(): sha256(path) for path in lean_sources
        },
        "verified_result": "alpha 23 = 4 * Real.pi / 5; IsSharpBound N (4 * Real.pi / 5) for 23 <= N <= 32",
        "remaining_scope": "Values for 21 and 22 points remain in [140,144] degrees; SendovClaim is unproved",
        "novelty_or_priority_claim": False,
        "fresh_external_search": False,
    }


def replace_section(text, heading, content, before=None):
    block = heading + "\n\n" + content.strip() + "\n\n"
    if heading in text:
        start = text.index(heading)
        end = text.find("\n## ", start + len(heading))
        return text[:start] + block + (text[end + 1:] if end >= 0 else "")
    require(before is not None and before in text, f"Cannot locate insertion point for {heading}")
    return text.replace(before, block + before, 1)


def chinese_summary(record, note_link):
    return f"""Lean 已核验 14 份新增共享方向核心证书，并把原七类型核心及已有的两两约束核心
通过类型上的旋转、反射传输，组成 251 项排除池。120 组有限检查覆盖了全部
38,760 种十四类型集合，因此三弧容量至多 13。结合单弧容量 9，所有角小于 144°
的平面配置至多有 22 点；已有构造给出匹配上界。

得到 **alpha(23)=4π/5=144°**，以及 **23～32 点完整 `IsSharpBound`**。
结论适用于原题的任意有限平面点集，没有增加一般位置、凸性或模型可实现性假设。
完整构建 **{record['build_jobs']} 项**、公理审计 **{record['audited_declarations']} 项**通过，
其中 **{record['axiom_free_declarations']} 项不依赖公理**；其余仅使用实际审计中允许的标准基础公理。
本轮 {record['new_lean_modules']} 个新模块有 532 个公开审计声明，多数用于同一有限证书与覆盖的核验。

**21～22 点仍在 [140°,144°]，任意点数的完整 `SendovClaim` 尚未证明。**
数值目标来自 Sendov 的已知分类，本轮不作数学新发现、首次形式化或优先权声明，
也未做新的外部优先权检索。详见 [23 点证明与核验记录]({note_link})。
下方旧日期段落是历史记录，其中的点数范围以本节为准。"""


def proof_note(record):
    return f"""# 23 点精确值 144° 的形式化证明

{DATE}。完整构建和公理审计通过，得到原题定义下的
`alpha 23 = 4*Real.pi/5`，以及 23～32 点完整 `IsSharpBound`。
21～22 点仍在 [140°,144°]；任意点数的完整 `SendovClaim` 尚未证明。

## 从原题到 9+13=22

假设一个有限平面点集的所有三点角都严格小于 144°。已有几何桥梁给出
`TriangleCoverModel`，参数满足 `0 ≤ d < 36/5`，且总数至多
`9 + threeVertices.card`。若有至少 14 个三弧顶点，
`exists_fourteen_sharedCanonical` 抽取十四行规范共享方向模型，保留覆盖映射、
共享边方向和全部三角形方向必要条件。其类型是固定二十类型中的十四个互异标签。

十四个互异标签恰好缺失六个递增标签。`ThreeArcOrderModelGeneralSix` 列出六个遗漏；
`ThreeArcShared14Coverage.all_covered` 找到被排除的核心；
`ThreeArcShared14Pool.no_family` 给出矛盾。因此三弧容量至多 13，总容量至多
`9+13=22`，任意 23 点必有一个至少 144° 的角。
已有五层二进制平面构造在至多 32 点时反驳每个严格更大的角界，给出匹配上界。
最终定理在 `TwentythreeExact.lean`，仍使用 `Basic.lean` 中原始的 `Plane`、
`GuaranteedAngle`、`IsSharpBound` 和 `alpha`；没有新增一般位置、凸性、有理坐标、
模型可实现性或极值达到假设。

## 共享核心、类型前像与覆盖

基础库复用已有 387 个两两约束矛盾核心，并使用 15 个共享方向核心：原七类型核心
加 14 个新核心。`SharedCoreExclusions.rawSpec_eq` 逐项证明字面规格正是原有
共享方向必要条件的计算结果。每份新证书由差分坏循环与纯命题 LRAT 反驳组成。

对一个核心，类型映射是 `R^r ∘ F^flip`，前像逐项使用 `R^(10-r)` 后按 `flip`
选择是否施加 `F`。反射前先作统一的充分小内部扰动：所有起点加 `η`，所有共享方向
加 `2η`；类型、严格上界和三角形方向差保持，并把成员下界移到内部。这处理了半开
单元的边界，不是对原题新增扰动假设。经过扰动的整模型变换不被声称构成严格群作用；
证明只使用类型上的二面对称及对应的排除传输。

二十种前像去重后有 662 个掩码；删去含有较小核心的冗余项后为 330 个。
确定性选取得到 251 项排除池，其中 45 项来自旧核心索引 0、17、53、66，
206 项来自全部 15 个共享方向核心。缓存列表保留实际 `preimageCore` 的顺序，
`cached_match` 在内核中核对其逐项相等，而非只比较掩码。
覆盖表按前两个遗漏标签分成 120 个非空组，只枚举合法递增四元后缀，覆盖全部
`C(20,14)=C(20,6)=38,760` 个组合。有限检查与一般子集定理均由 Lean 核验。

## 核验与复现

完整构建 **{record['build_jobs']} 项**成功；全部 **{record['audited_declarations']} 项**
`#print axioms` 与当前审计源码精确匹配，其中 **{record['axiom_free_declarations']} 项无公理**。
实际基础公理并集为 `{', '.join(record['actual_axioms'])}`。
最终精确值、尖锐性、三弧容量与十四行排除的实际依赖记录在
`logs/jsp404-shared23-verification-20261117.json`。
相对七类型快照新增 {record['new_lean_modules']} 个 Lean 模块、532 个公开审计声明；多数是核验同一有限任务的
分段检查和汇总，不代表 532 个独立数学结果。

Z3 4.15.4 只用于发现理论子句，CaDiCaL 2.1.2 只用于生成 RUP-only LRAT。
求解器 UNSAT 状态和 Python 统计均不是公理。理论子句必须附有内核检查的混合
严格／非严格差分坏循环，命题反驳使用固定 mathlib 的 `FromLRAT` 既有证明项构造器。
支持项的语义核验组合了定义相等、普通定理及 `decide +kernel`，没有使用
`native_decide`、`sorry`、`admit` 或新增公理。

核心输入在 `research/jsp404-shared-core-library/01` 至 `14`。
标准库渲染器逐字节复现十四组证书源码的记录见
`logs/jsp404-shared-core-library-reproduction-20261115.json`；
其中 09～13 号证书按数据、支持项核验、LRAT 和最终排除分段；09 号公式定义在数据模块
内，10～13 号另把公式定义按每块 1024 项顺序拆成独立模块，以降低单次编译的内存需求。
该布局只改变模块单元与公式定义的跨模块可见性，保留同一规格、核验规则和最终定理，
不改变数学条件；复现记录逐个列出全部模块的大小和哈希。
11～13 号另通过 `CertificateBatch.lean` 包装生成命令，省略逐声明保留的编辑器信息。
包装中的每条命令仍调用普通 Lean 命令展开器并接受通常的内核检查；这不改变数学条件、
证明义务或核验规则。辅助模块的大小和哈希也在同一复现记录中核对。
覆盖的输入哈希、选择与输出哈希见 `logs/jsp404-shared14-coverage-20261115.json`。
以下命令重建核心与覆盖源码，不必重新运行求解器：

```sh
python3 scripts/render_shared_difference_sat.py --packet-directory research/jsp404-shared-core-library/01 --output /tmp/Core01.lean --namespace Prize.JSP404.SharedCores.Core01 --proof-style shapes
python3 scripts/render_shared_difference_sat.py --packet-directory research/jsp404-shared-core-library/09 --output /tmp/Core09.lean --namespace Prize.JSP404.SharedCores.Core09 --proof-style shapes --split-modules
python3 scripts/render_shared_difference_sat.py --packet-directory research/jsp404-shared-core-library/10 --output /tmp/Core10.lean --namespace Prize.JSP404.SharedCores.Core10 --proof-style shapes --split-modules --form-block-size 1024
python3 scripts/render_shared_difference_sat.py --packet-directory research/jsp404-shared-core-library/11 --output /tmp/Core11.lean --namespace Prize.JSP404.SharedCores.Core11 --proof-style shapes --split-modules --form-block-size 1024 --batch-commands
python3 scripts/export_three_arc_shared14_coverage.py --old-library research/jsp404-order15-certificate-input.json --selected research/jsp404-shared-core-selection.json --pool-output /tmp/ThreeArcShared14Pool.lean --coverage-output /tmp/ThreeArcShared14Coverage.lean --manifest-output /tmp/shared14-manifest.json
./scripts/lake.sh build
./scripts/lake.sh env lean Prize/Audit.lean
```

Lean 固定为 `{record['lean_pin']}`，mathlib 固定为
`{record['mathlib_pin']}`，传递依赖固定在 `lake-manifest.json`。
这是本地完整核验，不声称独立外部复审或全新机器重建。

## 文献、贡献与搜索范围

数值目标属于 Sendov 的已知分类：Bl. Sendov,
*Minimax of the angles in a plane configuration of points*, Acta Mathematica Hungarica
69 (1995), 27–46（[DOI](https://doi.org/10.1007/BF01874605)，
[公开馆藏](https://real-j.mtak.hu/7467/)）；另见
*Compulsory configurations of points in the plane*, Theorem 4.4，
[Math-Net 官方入口](https://www.mathnet.ru/eng/fpm81)。
本轮贡献是项目中的几何连接、共享方向核心证书、类型前像传输与有限覆盖的形式化，
不声称数学新发现、首次形式化或奖金优先权。本轮没有新的文献、题库状态或全网
优先权检索；既有来源访问与检索覆盖见 `jsp404-english-source.md`、`jsp404-proof-map.md`。
没有向官方题库提交整题完成或奖金申请。
"""


def update_docs(record):
    readme_path = ROOT / "README.md"
    status_path = ROOT / "research/jsp404-status.md"
    release_path = ROOT / "research/jsp404-release-20260918.md"
    readme = readme_path.read_text()
    readme = readme.replace("已验证 n=3 到 n=20、n=24～32、", "已验证 n=3 到 n=20、n=23～32、", 1)
    readme = replace_section(readme, CHINESE_HEADING,
                             chinese_summary(record, "research/jsp404-twentythree-exact.md"),
                             "## 2026-11-13　23 点路线：一组七类型参数族已排除")
    status = replace_section(status_path.read_text(), CHINESE_HEADING,
                             chinese_summary(record, "jsp404-twentythree-exact.md"),
                             "## 2026-11-13　23 点路线：一组七类型参数族已排除")
    release = release_path.read_text()
    release = re.sub(r"Snapshot date: \d{4}-\d{2}-\d{2}\.", f"Snapshot date: {DATE}.", release, count=1)
    start = release.find("## Checked shared-direction exclusion on seven canonical types")
    if start < 0:
        start = release.find("## Exact ordinary value for twenty-three points")
    end = release.find("## Retained exact value for twenty-four points")
    require(0 <= start < end, "Cannot locate the English release's current-result section")
    english = f"""## Exact ordinary value for twenty-three points

This snapshot proves **alpha(23)=4*pi/5=144 degrees**, with full `IsSharpBound`
for **23<=N<=32**, on the original arbitrary finite planar configurations.
No general-position, convexity, rational-coordinate or realizability hypothesis
has been added. Values for **21 and 22** remain in **[140,144] degrees**;
the arbitrary-cardinality `SendovClaim` remains unproved.

Fourteen new shared-direction core certificates supplement the previously
checked seven-type core and the existing pairwise cores. Proved type preimage
transports assemble a pool of 251 exclusions. The kernel checks 120 groups of
witnesses covering all 38,760 omission sextuples. Hence fourteen shared
three-arc rows are impossible, giving capacity thirteen. The single-arc
capacity nine gives a total of at most 22 below 144 degrees. The existing
five-level binary planar construction supplies the matching sharp upper bound.

Reflection first uses one common interior perturbation, preserving types and
all necessary conditions. Only the finite type maps and exclusion transport
are used; the perturbed model transformations are not claimed to form a strict
group action. Source constraints, non-strict membership lower bounds, semantic
CNF support checks, mixed difference cycles and RUP-only LRAT refutations are
checked by Lean. Z3 4.15.4 and CaDiCaL 2.1.2 are discovery tools, not premises.

The {record['new_lean_modules']} new modules contain 532 audited declarations, predominantly checks and
assembly of one finite proof task. These are not 532 independent mathematical
results. The known numerical target is part of Sendov's classification; no
mathematical novelty, first formalization or priority claim is made.
The five larger certificates are split into Data, Checks, Lrat and final
exclusion stages. Core09 stores its formula definitions in Data; Core10 through
Core13 use sequential modules containing up to 1024 formula definitions apiece.
This bounds memory use by changing module units and making formula constants
visible across their modules. The specification, checker rules, final theorems
and mathematical conditions are unchanged. Core11 through Core13 additionally
batch generated commands through `CertificateBatch.lean`, omitting per-declaration
editor information. Every enclosed command still uses Lean's ordinary command
elaborator and usual kernel checks. Reproduction records cover every certificate
source module and the helper's bytes and hash.
See `research/jsp404-twentythree-exact.md` and the saved reproduction records.

The retained checkpoint descriptions below are historical. Their then-current
unresolved ranges are superseded by this section and the current summary near
the end of this document.

"""
    release = release[:start] + english + release[end:]
    remaining = """Earlier results cover exact ordinary values for 3 through 20, all powers of
two with exponent at least two, and every one below a power of two with
exponent at least three. This snapshot also gives exact values throughout
23 through 32. Both bands' general upper bounds and weaker general lower
bounds remain included.

The next incomplete ordinary cardinalities are 21 and 22; their classical
target is 144 degrees and their proved range remains [140,144] degrees.
The arbitrary-cardinality sharp lower bounds and full `SendovClaim` remain
unproved. A successful build of this snapshot is not a solution of all JSP-000404."""
    release = replace_section(release, "## Retained results and remaining work", remaining)
    old_verification = re.search(r"(## Verification and reproduction\n\n).*?(\nPinned Lean:)", release, re.S)
    require(old_verification is not None, "Cannot locate the English verification paragraph")
    verification = f"""The full project build passed ({record['build_jobs']} jobs), and the axiom audit
passed all {record['audited_declarations']} declarations, including 532 new audited
declarations. {record['axiom_free_declarations']} declarations are axiom-free; the actual
axiom union is `{', '.join(record['actual_axioms'])}`. Every audit entry matches
the current `Prize/Audit.lean`; final theorem dependencies and source/log hashes
are recorded in `research/logs/jsp404-shared23-verification-20261117.json`.
Original target definitions and all dependency pins are unchanged.
"""
    release = release[:old_verification.start()] + old_verification.group(1) + verification + old_verification.group(2) + release[old_verification.end():]
    outputs = {
        readme_path: readme,
        status_path: status,
        release_path: release,
        ROOT / "research/jsp404-twentythree-exact.md": proof_note(record),
        ROOT / "research/logs/jsp404-shared23-verification-20261117.json": json.dumps(record, indent=2) + "\n",
    }
    for path, text in outputs.items():
        require(("/" + "Users" + "/") not in text and ("BEGIN" + " PRIVATE KEY") not in text,
                f"Private marker in {path.relative_to(ROOT).as_posix()}")
    for path, text in outputs.items():
        temp = path.with_name(path.name + ".tmp")
        temp.write_text(text)
        temp.replace(path)
    return [path.relative_to(ROOT).as_posix() for path in outputs]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--apply", action="store_true", help="write the notes after all evidence checks pass")
    args = parser.parse_args()
    record = verify()
    written = update_docs(record) if args.apply else []
    print(json.dumps({key: record[key] for key in (
        "build_jobs", "audited_declarations", "new_audited_declarations",
        "new_lean_modules", "split_core_indices", "axiom_free_declarations", "actual_axioms")}, indent=2))
    print(json.dumps({"applied": args.apply, "written": written}))


if __name__ == "__main__":
    main()
