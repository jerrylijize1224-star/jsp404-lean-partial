"""Render an untrusted concrete SAT packet into fully checked Lean declarations.
No solver result is assumed. The generated acceptance theorem reduces in the
kernel and the LRAT command produces ordinary proof terms through mathlib.
"""
from pathlib import Path
import argparse,json,re,subprocess,sys,tempfile
parser=argparse.ArgumentParser(description='Render transparent data, checked theory clauses and a kernel LRAT refutation.')
parser.add_argument('--packet-directory',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True)
parser.add_argument('--namespace',default='Prize.JSP404.SharedSevenCertificate')
parser.add_argument('--proof-style',choices=('kernel','shapes'),default='kernel')
parser.add_argument('--split-modules',action='store_true',
 help='write Data/Checks/Lrat siblings; requires shapes and an output basename matching the namespace')
parser.add_argument('--batch-commands',action='store_true',
 help='elaborate generated commands without retaining per-declaration editor information')
parser.add_argument('--form-block-size',type=int,default=0,
 help='move formula definitions to sequential Forms modules of this size; requires --split-modules')
args=parser.parse_args()
if args.batch_commands and not args.split_modules:parser.error('--batch-commands requires --split-modules')
if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_.]*',args.namespace):parser.error('invalid Lean namespace')
if args.form_block_size<0:parser.error('--form-block-size must be nonnegative')
if args.form_block_size and not args.split_modules:parser.error('--form-block-size requires --split-modules')
if args.split_modules and args.proof_style!='shapes':parser.error('--split-modules requires --proof-style shapes')
if args.split_modules and args.output.stem!=args.namespace.rsplit('.',1)[-1]:
 parser.error('split module output basename must match the last namespace component')
folder=args.packet_directory
p=json.loads((folder/'packet.json').read_text())
def edge(e):return f'⟨{e[0]}, {e[1]}, {e[2]}, {str(e[3]).lower()}⟩'
def elist(es):return '['+', '.join(edge(e) for e in es)+']'
lines=['import Prize.JSP404.DifferenceSat','', 'namespace '+args.namespace,'open DifferenceCertificate DifferenceSat','set_option maxRecDepth '+('262144' if args.proof_style=='shapes' else '65536'),'set_option maxHeartbeats 20000000','','noncomputable def spec : DifferenceCertificate.Spec := {', '  initial := '+elist(p['initial']), '  clauses := #[']
for c in p['clauses']:lines.append('    ['+', '.join(elist(choice) for choice in c)+'],')
lines+=['  ]','}']
for n,f in enumerate(p['forms']):
 kind=f[0]
 if kind=='atom':value='.atom '+edge(f[1])
 elif kind in ('top','bot'):value='.'+kind
 elif kind=='neg':value=f'.neg f{f[1]}'
 else:value=f'.{kind} f{f[1]} f{f[2]}'
 lines.append(f'private noncomputable def f{n} : Formula := {value}')
def tree(lo,hi):
 if lo>=hi:return '.empty'
 mid=(lo+hi)//2
 return f'(.node {mid} f{mid} {tree(lo,mid)} {tree(mid+1,hi)})'
lines.append('private noncomputable def formTree : FormTree := '+tree(0,len(p['forms'])))
lines.append('noncomputable def forms : ℕ → Formula := formTree.get')
lines.append('noncomputable def supports : Array Support := #[')
for s in p['supports']:
 if s[0]=='theory':
  lits='['+', '.join(f'⟨{abs(l)-1}, {str(l>0).lower()}⟩' for l in s[1])+']'
  value='.theory '+lits+' '+elist(s[2])
 else:value='.'+s[0]+' '+' '.join(map(str,s[1:]))
 lines.append('  '+value+',')
lines+= [']','']
if args.proof_style=='kernel':
 lines+= ['theorem checked : DifferenceSat.accepted spec forms supports = true := by','  decide +kernel','']
else:
 lines+= ['end '+args.namespace,'']
 with tempfile.TemporaryDirectory(prefix='jsp404-support-render-') as task_temp:
  generated=Path(task_temp)/'Checks.lean'
  subprocess.run([sys.executable,str(Path(__file__).with_name('render_difference_support_checks.py')),
   '--packet',str(folder/'packet.json'),'--output',str(generated),'--full','--inline-leaves',
   '--data-namespace',args.namespace,'--lean-namespace',args.namespace+'.FastChecks',
   '--no-import','--no-markers','--private-results'],check=True,capture_output=True)
  lines.append(generated.read_text().replace('Uncompiled performance experiment. No existing proof is changed.', 'Acceptance checks assembled from kernel-checked shape and cycle proofs.'))
 lines+= ['namespace '+args.namespace,'open DifferenceCertificate DifferenceSat',
  'set_option maxRecDepth 262144','set_option maxHeartbeats 50000000',
  'theorem checked : DifferenceSat.accepted spec forms supports = true := FastChecks.full_checked','']
lines+= ['difference_lrat cnfRefutation '+json.dumps((folder/'case.cnf').read_text())+' '+json.dumps((folder/'case.lrat').read_text()),'',
 'theorem context_eq : cnfRefutation.ctx = DifferenceSat.formula supports := by','  rfl','',
 'theorem no_model : ¬ ∃ x, DifferenceCertificate.Model spec x := by',
 '  apply DifferenceSat.accepted_false spec forms supports checked',
 '  exact (congrArg (fun f : Sat.Fmla => f.proof []) context_eq).mp cnfRefutation.unsat','',
 'end '+args.namespace]
out=args.output;out.parent.mkdir(parents=True,exist_ok=True)
rendered='\n'.join(lines)+'\n'
if not args.split_modules:
 out.write_text(rendered);print(out.stat().st_size)
else:
 # Partition the existing rendering, retaining its definitions and proof terms.
 # The dependency chain also prevents a build from retaining every frontend
 # snapshot in one Lean process. No checker or mathematical target changes.
 data_end_marker='\nend '+args.namespace+'\n'
 data_end=rendered.index(data_end_marker)+len(data_end_marker)
 data=rendered[:data_end]
 remaining=rendered[data_end:]
 lrat_start=remaining.index('\ndifference_lrat cnfRefutation ')
 no_model_start=remaining.index('\ntheorem no_model : ')
 checks=remaining[:lrat_start]
 lrat=remaining[lrat_start+1:no_model_start]
 main=remaining[no_model_start+1:]
 header_start=checks.rindex('\nnamespace '+args.namespace+'\n')+1
 checked_start=checks.index('theorem checked : DifferenceSat.accepted')
 header=checks[header_start:checked_start]
 assert header.startswith('namespace '+args.namespace+'\n')
 assert 'set_option maxRecDepth 262144\n' in header
 assert 'set_option maxHeartbeats 50000000\n' in header
 ending='end '+args.namespace+'\n'
 paths={suffix:out.with_name(out.stem+suffix+'.lean') for suffix in ('Data','Checks','Lrat')}
 outputs={
  paths['Data']:data,
  paths['Checks']:'import '+args.namespace+'Data\n\n'+checks.lstrip('\n')+ending,
  paths['Lrat']:'import '+args.namespace+'Checks\n\n'+header+lrat+ending,
  out:'import '+args.namespace+'Lrat\n\n'+header+main,
 }
 if args.form_block_size:
  # Formula bodies refer only to earlier formula IDs. Make those declarations
  # visible across small sequential modules, without changing any formula body.
  formula_start=data.index('private noncomputable def f0 : Formula := ')
  tree_start=data.index('private noncomputable def formTree : FormTree := ')
  form_lines=data[formula_start:tree_start].splitlines(keepends=True)
  assert len(form_lines)==len(p['forms'])
  for index,line in enumerate(form_lines):
   assert line.startswith(f'private noncomputable def f{index} : Formula := ')
   assert line.endswith('\n')
  spec_start=data.index('noncomputable def spec : DifferenceCertificate.Spec := ')
  data_header_start=data.index('namespace '+args.namespace+'\n')
  form_header=data[data_header_start:spec_start].rstrip('\n')+'\nset_option Elab.async false\n\n'
  form_outputs={}
  previous_module='Prize.JSP404.DifferenceSat'
  for block,start in enumerate(range(0,len(form_lines),args.form_block_size)):
   suffix=f'Forms{block:02d}'
   body=''.join(line[len('private '):] for line in form_lines[start:start+args.form_block_size])
   path=out.with_name(out.stem+suffix+'.lean')
   form_outputs[path]='import '+previous_module+'\n\n'+form_header+body+'\n'+ending
   previous_module=args.namespace+suffix
  original_import='import Prize.JSP404.DifferenceSat\n'
  assert data.startswith(original_import)
  data_without_forms=data[:formula_start]+data[tree_start:]
  outputs[paths['Data']]='import '+previous_module+'\n'+data_without_forms[len(original_import):]
  outputs={**form_outputs,**outputs}
 if args.batch_commands:
  for path,text in outputs.items():
   import_line,body=text.split('\n',1)
   assert import_line.startswith('import ')
   outputs[path]=(import_line+'\nimport Prize.JSP404.CertificateBatch\n\n'
    +'certificate_batch\nset_option Elab.async false\n'+body.lstrip('\n')
    +'\nend_certificate_batch\n')
 for path,text in outputs.items():path.write_text(text)
 summary={'split_modules':True,'files':[
  {'name':path.name,'bytes':path.stat().st_size} for path in outputs]}
 if args.form_block_size:summary['form_block_size']=args.form_block_size
 if args.batch_commands:summary['batch_commands']=True
 print(json.dumps(summary))
