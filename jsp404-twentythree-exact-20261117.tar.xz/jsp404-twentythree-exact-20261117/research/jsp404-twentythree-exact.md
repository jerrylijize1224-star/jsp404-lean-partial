# 23 点精确值 144° 的形式化证明

2026-11-17。完整构建和公理审计通过，得到原题定义下的
`alpha 23 = 4*Real.pi/5`，以及 23～32 点完整 `IsSharpBound`。
21～22 点仍在 [140°,144°]；任意点数的完整 `SendovClaim` 尚未证明。

## 从原题到 9+13=22

假设一个有限平面点集的所有三点角都严格小于 144°。已有几何桥梁给出
`TriangleCoverModel`，参数满足 `0 ≤ d < 36/5`，且总数至多
`9 + threeVertices.card`。若有至少 14 个三弧顶点，
`exists_fourteen_sharedCanonical` 抽取十四行规范共享方向模型，保留覆盖映射、
共享边方向和全部三角形方向必要条件。其类型是固定二十类型中的十四个互异标签。

十四个互异标签恰好缺失六个递增标签。`ThreeArcOrderModelGeneralSix` 列出六个遗漏；
`ThreeArcShared14Coverage.all_covered` 找到被排除的核心；
`ThreeArcShared14Pool.no_family` 给出矛盾。因此三弧容量至多 13，总容量至多
`9+13=22`，任意 23 点必有一个至少 144° 的角。
已有五层二进制平面构造在至多 32 点时反驳每个严格更大的角界，给出匹配上界。
最终定理在 `TwentythreeExact.lean`，仍使用 `Basic.lean` 中原始的 `Plane`、
`GuaranteedAngle`、`IsSharpBound` 和 `alpha`；没有新增一般位置、凸性、有理坐标、
模型可实现性或极值达到假设。

## 共享核心、类型前像与覆盖

基础库复用已有 387 个两两约束矛盾核心，并使用 15 个共享方向核心：原七类型核心
加 14 个新核心。`SharedCoreExclusions.rawSpec_eq` 逐项证明字面规格正是原有
共享方向必要条件的计算结果。每份新证书由差分坏循环与纯命题 LRAT 反驳组成。

对一个核心，类型映射是 `R^r ∘ F^flip`，前像逐项使用 `R^(10-r)` 后按 `flip`
选择是否施加 `F`。反射前先作统一的充分小内部扰动：所有起点加 `η`，所有共享方向
加 `2η`；类型、严格上界和三角形方向差保持，并把成员下界移到内部。这处理了半开
单元的边界，不是对原题新增扰动假设。经过扰动的整模型变换不被声称构成严格群作用；
证明只使用类型上的二面对称及对应的排除传输。

二十种前像去重后有 662 个掩码；删去含有较小核心的冗余项后为 330 个。
确定性选取得到 251 项排除池，其中 45 项来自旧核心索引 0、17、53、66，
206 项来自全部 15 个共享方向核心。缓存列表保留实际 `preimageCore` 的顺序，
`cached_match` 在内核中核对其逐项相等，而非只比较掩码。
覆盖表按前两个遗漏标签分成 120 个非空组，只枚举合法递增四元后缀，覆盖全部
`C(20,14)=C(20,6)=38,760` 个组合。有限检查与一般子集定理均由 Lean 核验。

## 核验与复现

完整构建 **3405 项**成功；全部 **5425 项**
`#print axioms` 与当前审计源码精确匹配，其中 **19 项无公理**。
实际基础公理并集为 `Classical.choice, Quot.sound, propext`。
最终精确值、尖锐性、三弧容量与十四行排除的实际依赖记录在
`logs/jsp404-shared23-verification-20261117.json`。
相对七类型快照新增 97 个 Lean 模块、532 个公开审计声明；多数是核验同一有限任务的
分段检查和汇总，不代表 532 个独立数学结果。

Z3 4.15.4 只用于发现理论子句，CaDiCaL 2.1.2 只用于生成 RUP-only LRAT。
求解器 UNSAT 状态和 Python 统计均不是公理。理论子句必须附有内核检查的混合
严格／非严格差分坏循环，命题反驳使用固定 mathlib 的 `FromLRAT` 既有证明项构造器。
支持项的语义核验组合了定义相等、普通定理及 `decide +kernel`，没有使用
`native_decide`、`sorry`、`admit` 或新增公理。

核心输入在 `research/jsp404-shared-core-library/01` 至 `14`。
标准库渲染器逐字节复现十四组证书源码的记录见
`logs/jsp404-shared-core-library-reproduction-20261115.json`；
其中 09～13 号证书按数据、支持项核验、LRAT 和最终排除分段；09 号公式定义在数据模块
内，10～13 号另把公式定义按每块 1024 项顺序拆成独立模块，以降低单次编译的内存需求。
该布局只改变模块单元与公式定义的跨模块可见性，保留同一规格、核验规则和最终定理，
不改变数学条件；复现记录逐个列出全部模块的大小和哈希。
11～13 号另通过 `CertificateBatch.lean` 包装生成命令，省略逐声明保留的编辑器信息。
包装中的每条命令仍调用普通 Lean 命令展开器并接受通常的内核检查；这不改变数学条件、
证明义务或核验规则。辅助模块的大小和哈希也在同一复现记录中核对。
覆盖的输入哈希、选择与输出哈希见 `logs/jsp404-shared14-coverage-20261115.json`。
以下命令重建核心与覆盖源码，不必重新运行求解器：

```sh
python3 scripts/render_shared_difference_sat.py --packet-directory research/jsp404-shared-core-library/01 --output /tmp/Core01.lean --namespace Prize.JSP404.SharedCores.Core01 --proof-style shapes
python3 scripts/render_shared_difference_sat.py --packet-directory research/jsp404-shared-core-library/09 --output /tmp/Core09.lean --namespace Prize.JSP404.SharedCores.Core09 --proof-style shapes --split-modules
python3 scripts/render_shared_difference_sat.py --packet-directory research/jsp404-shared-core-library/10 --output /tmp/Core10.lean --namespace Prize.JSP404.SharedCores.Core10 --proof-style shapes --split-modules --form-block-size 1024
python3 scripts/render_shared_difference_sat.py --packet-directory research/jsp404-shared-core-library/11 --output /tmp/Core11.lean --namespace Prize.JSP404.SharedCores.Core11 --proof-style shapes --split-modules --form-block-size 1024 --batch-commands
python3 scripts/export_three_arc_shared14_coverage.py --old-library research/jsp404-order15-certificate-input.json --selected research/jsp404-shared-core-selection.json --pool-output /tmp/ThreeArcShared14Pool.lean --coverage-output /tmp/ThreeArcShared14Coverage.lean --manifest-output /tmp/shared14-manifest.json
./scripts/lake.sh build
./scripts/lake.sh env lean Prize/Audit.lean
```

Lean 固定为 `leanprover/lean4:v4.34.0`，mathlib 固定为
`5ed2965256430c3649e86755f9576b54eca72435`，传递依赖固定在 `lake-manifest.json`。
这是本地完整核验，不声称独立外部复审或全新机器重建。

## 文献、贡献与搜索范围

数值目标属于 Sendov 的已知分类：Bl. Sendov,
*Minimax of the angles in a plane configuration of points*, Acta Mathematica Hungarica
69 (1995), 27–46（[DOI](https://doi.org/10.1007/BF01874605)，
[公开馆藏](https://real-j.mtak.hu/7467/)）；另见
*Compulsory configurations of points in the plane*, Theorem 4.4，
[Math-Net 官方入口](https://www.mathnet.ru/eng/fpm81)。
本轮贡献是项目中的几何连接、共享方向核心证书、类型前像传输与有限覆盖的形式化，
不声称数学新发现、首次形式化或奖金优先权。本轮没有新的文献、题库状态或全网
优先权检索；既有来源访问与检索覆盖见 `jsp404-english-source.md`、`jsp404-proof-map.md`。
没有向官方题库提交整题完成或奖金申请。
