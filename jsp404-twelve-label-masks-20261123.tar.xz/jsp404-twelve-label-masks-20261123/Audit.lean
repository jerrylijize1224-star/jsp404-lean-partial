import Finite21.Checked
#print axioms Prize.JSP404.TwelveLabelMasks.covered_of_walk
#print axioms Prize.JSP404.TwelveLabelMasks.all_rows
#print axioms Prize.JSP404.TwelveLabelMasks.walk_checked
#print axioms Prize.JSP404.TwelveLabelMasks.all_covered
