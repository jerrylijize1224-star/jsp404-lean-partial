# A bit-mask proof of the twelve-label covering theorem

For any subset of at least 12 of the 20 direction labels, one of the 2,214 listed cores lies entirely in the subset. This Lean project proves the same finite statement as the companion LRAT archive using a different calculation. Both take the same ordered list of cores as input.

For exactly 12 chosen labels, eight labels are absent. A bit in the row for an absent label records that the corresponding core omits that label. Lean checks the 20 rows against the lists and verifies that each of the 125,970 intersections for eight absent labels has a set bit. That bit identifies a core. A larger subset contains a twelve-element subset. The argument and all finite computations are checked by the Lean kernel.

With elan installed, unpack the archive, enter its directory, and run these commands.

```sh
lake exe cache get Mathlib.Data.Finset.Sort Mathlib.Data.Finset.Card Mathlib.Tactic.FinCases Mathlib.Data.Fintype.Fin
lake build
lake env lean Audit.lean
```

The exported theorem is `Prize.JSP404.TwelveLabelMasks.all_covered`. The observed dependencies appear in `verification/axioms.log`. The separate step that excludes those cores in the actual plane configuration is part of the 21-point proof. This archive establishes only the finite covering statement.
