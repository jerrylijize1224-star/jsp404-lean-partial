import Finite21.Bits

namespace Prize.JSP404.TwelveLabelMasks
open ThreeArcShared12Lists
set_option maxRecDepth 65536
set_option maxHeartbeats 18000000

theorem p00_01 : pair 0 1 = true := by decide +kernel
theorem p00_02 : pair 0 2 = true := by decide +kernel
theorem p00_03 : pair 0 3 = true := by decide +kernel
theorem p00_04 : pair 0 4 = true := by decide +kernel
theorem p00_05 : pair 0 5 = true := by decide +kernel
theorem p00_06 : pair 0 6 = true := by decide +kernel
theorem p00_07 : pair 0 7 = true := by decide +kernel
theorem p00_08 : pair 0 8 = true := by decide +kernel
theorem p00_09 : pair 0 9 = true := by decide +kernel
theorem p00_10 : pair 0 10 = true := by decide +kernel
theorem p00_11 : pair 0 11 = true := by decide +kernel
theorem p00_12 : pair 0 12 = true := by decide +kernel
theorem p00_13 : pair 0 13 = true := by decide +kernel
theorem p00_14 : pair 0 14 = true := by decide +kernel
theorem p00_15 : pair 0 15 = true := by decide +kernel
theorem p00_16 : pair 0 16 = true := by decide +kernel
theorem p00_17 : pair 0 17 = true := by decide +kernel
theorem p00_18 : pair 0 18 = true := by decide +kernel
theorem p00_19 : pair 0 19 = true := by decide +kernel

theorem from_00 (b : Nat) (hlo : 0 < b) (hhi : b < 20) : pair 0 b = true := by
  have hh : b = 1 ∨ b = 2 ∨ b = 3 ∨ b = 4 ∨ b = 5 ∨ b = 6 ∨ b = 7 ∨ b = 8 ∨ b = 9 ∨ b = 10 ∨ b = 11 ∨ b = 12 ∨ b = 13 ∨ b = 14 ∨ b = 15 ∨ b = 16 ∨ b = 17 ∨ b = 18 ∨ b = 19 := by omega
  rcases hh with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact p00_01
  · exact p00_02
  · exact p00_03
  · exact p00_04
  · exact p00_05
  · exact p00_06
  · exact p00_07
  · exact p00_08
  · exact p00_09
  · exact p00_10
  · exact p00_11
  · exact p00_12
  · exact p00_13
  · exact p00_14
  · exact p00_15
  · exact p00_16
  · exact p00_17
  · exact p00_18
  · exact p00_19

end Prize.JSP404.TwelveLabelMasks
