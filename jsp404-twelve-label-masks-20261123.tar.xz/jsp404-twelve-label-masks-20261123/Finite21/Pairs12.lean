import Finite21.Bits

namespace Prize.JSP404.TwelveLabelMasks
open ThreeArcShared12Lists
set_option maxRecDepth 65536
set_option maxHeartbeats 18000000

theorem p12_13 : pair 12 13 = true := by decide +kernel
theorem p12_14 : pair 12 14 = true := by decide +kernel
theorem p12_15 : pair 12 15 = true := by decide +kernel
theorem p12_16 : pair 12 16 = true := by decide +kernel
theorem p12_17 : pair 12 17 = true := by decide +kernel
theorem p12_18 : pair 12 18 = true := by decide +kernel
theorem p12_19 : pair 12 19 = true := by decide +kernel

theorem from_12 (b : Nat) (hlo : 12 < b) (hhi : b < 20) : pair 12 b = true := by
  have hh : b = 13 ∨ b = 14 ∨ b = 15 ∨ b = 16 ∨ b = 17 ∨ b = 18 ∨ b = 19 := by omega
  rcases hh with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact p12_13
  · exact p12_14
  · exact p12_15
  · exact p12_16
  · exact p12_17
  · exact p12_18
  · exact p12_19

end Prize.JSP404.TwelveLabelMasks
