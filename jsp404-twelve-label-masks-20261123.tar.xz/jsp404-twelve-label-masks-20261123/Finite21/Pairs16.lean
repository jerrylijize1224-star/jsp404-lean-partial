import Finite21.Bits

namespace Prize.JSP404.TwelveLabelMasks
open ThreeArcShared12Lists
set_option maxRecDepth 65536
set_option maxHeartbeats 18000000

theorem p16_17 : pair 16 17 = true := by decide +kernel
theorem p16_18 : pair 16 18 = true := by decide +kernel
theorem p16_19 : pair 16 19 = true := by decide +kernel

theorem from_16 (b : Nat) (hlo : 16 < b) (hhi : b < 20) : pair 16 b = true := by
  have hh : b = 17 ∨ b = 18 ∨ b = 19 := by omega
  rcases hh with rfl | rfl | rfl
  · exact p16_17
  · exact p16_18
  · exact p16_19

end Prize.JSP404.TwelveLabelMasks
