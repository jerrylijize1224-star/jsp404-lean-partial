import Finite21.Bits

namespace Prize.JSP404.TwelveLabelMasks
open ThreeArcShared12Lists
set_option maxRecDepth 65536
set_option maxHeartbeats 18000000

theorem mask_ok_12 : rowOK 12 = true := by decide +kernel
theorem mask_ok_13 : rowOK 13 = true := by decide +kernel
theorem mask_ok_14 : rowOK 14 = true := by decide +kernel
theorem mask_ok_15 : rowOK 15 = true := by decide +kernel

end Prize.JSP404.TwelveLabelMasks
