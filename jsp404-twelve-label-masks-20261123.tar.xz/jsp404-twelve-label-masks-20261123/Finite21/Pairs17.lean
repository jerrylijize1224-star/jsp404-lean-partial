import Finite21.Bits

namespace Prize.JSP404.TwelveLabelMasks
open ThreeArcShared12Lists
set_option maxRecDepth 65536
set_option maxHeartbeats 18000000

theorem p17_18 : pair 17 18 = true := by decide +kernel
theorem p17_19 : pair 17 19 = true := by decide +kernel

theorem from_17 (b : Nat) (hlo : 17 < b) (hhi : b < 20) : pair 17 b = true := by
  have hh : b = 18 ∨ b = 19 := by omega
  rcases hh with rfl | rfl
  · exact p17_18
  · exact p17_19

end Prize.JSP404.TwelveLabelMasks
