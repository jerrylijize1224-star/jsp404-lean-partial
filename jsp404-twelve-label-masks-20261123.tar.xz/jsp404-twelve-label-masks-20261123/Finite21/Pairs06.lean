import Finite21.Bits

namespace Prize.JSP404.TwelveLabelMasks
open ThreeArcShared12Lists
set_option maxRecDepth 65536
set_option maxHeartbeats 18000000

theorem p06_07 : pair 6 7 = true := by decide +kernel
theorem p06_08 : pair 6 8 = true := by decide +kernel
theorem p06_09 : pair 6 9 = true := by decide +kernel
theorem p06_10 : pair 6 10 = true := by decide +kernel
theorem p06_11 : pair 6 11 = true := by decide +kernel
theorem p06_12 : pair 6 12 = true := by decide +kernel
theorem p06_13 : pair 6 13 = true := by decide +kernel
theorem p06_14 : pair 6 14 = true := by decide +kernel
theorem p06_15 : pair 6 15 = true := by decide +kernel
theorem p06_16 : pair 6 16 = true := by decide +kernel
theorem p06_17 : pair 6 17 = true := by decide +kernel
theorem p06_18 : pair 6 18 = true := by decide +kernel
theorem p06_19 : pair 6 19 = true := by decide +kernel

theorem from_06 (b : Nat) (hlo : 6 < b) (hhi : b < 20) : pair 6 b = true := by
  have hh : b = 7 ∨ b = 8 ∨ b = 9 ∨ b = 10 ∨ b = 11 ∨ b = 12 ∨ b = 13 ∨ b = 14 ∨ b = 15 ∨ b = 16 ∨ b = 17 ∨ b = 18 ∨ b = 19 := by omega
  rcases hh with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact p06_07
  · exact p06_08
  · exact p06_09
  · exact p06_10
  · exact p06_11
  · exact p06_12
  · exact p06_13
  · exact p06_14
  · exact p06_15
  · exact p06_16
  · exact p06_17
  · exact p06_18
  · exact p06_19

end Prize.JSP404.TwelveLabelMasks
