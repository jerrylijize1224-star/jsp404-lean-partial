import Finite21.Bits

namespace Prize.JSP404.TwelveLabelMasks
open ThreeArcShared12Lists
set_option maxRecDepth 65536
set_option maxHeartbeats 18000000

theorem p01_02 : pair 1 2 = true := by decide +kernel
theorem p01_03 : pair 1 3 = true := by decide +kernel
theorem p01_04 : pair 1 4 = true := by decide +kernel
theorem p01_05 : pair 1 5 = true := by decide +kernel
theorem p01_06 : pair 1 6 = true := by decide +kernel
theorem p01_07 : pair 1 7 = true := by decide +kernel
theorem p01_08 : pair 1 8 = true := by decide +kernel
theorem p01_09 : pair 1 9 = true := by decide +kernel
theorem p01_10 : pair 1 10 = true := by decide +kernel
theorem p01_11 : pair 1 11 = true := by decide +kernel
theorem p01_12 : pair 1 12 = true := by decide +kernel
theorem p01_13 : pair 1 13 = true := by decide +kernel
theorem p01_14 : pair 1 14 = true := by decide +kernel
theorem p01_15 : pair 1 15 = true := by decide +kernel
theorem p01_16 : pair 1 16 = true := by decide +kernel
theorem p01_17 : pair 1 17 = true := by decide +kernel
theorem p01_18 : pair 1 18 = true := by decide +kernel
theorem p01_19 : pair 1 19 = true := by decide +kernel

theorem from_01 (b : Nat) (hlo : 1 < b) (hhi : b < 20) : pair 1 b = true := by
  have hh : b = 2 ∨ b = 3 ∨ b = 4 ∨ b = 5 ∨ b = 6 ∨ b = 7 ∨ b = 8 ∨ b = 9 ∨ b = 10 ∨ b = 11 ∨ b = 12 ∨ b = 13 ∨ b = 14 ∨ b = 15 ∨ b = 16 ∨ b = 17 ∨ b = 18 ∨ b = 19 := by omega
  rcases hh with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact p01_02
  · exact p01_03
  · exact p01_04
  · exact p01_05
  · exact p01_06
  · exact p01_07
  · exact p01_08
  · exact p01_09
  · exact p01_10
  · exact p01_11
  · exact p01_12
  · exact p01_13
  · exact p01_14
  · exact p01_15
  · exact p01_16
  · exact p01_17
  · exact p01_18
  · exact p01_19

end Prize.JSP404.TwelveLabelMasks
