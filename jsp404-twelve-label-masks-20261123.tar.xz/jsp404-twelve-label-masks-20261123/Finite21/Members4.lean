import Finite21.Bits

namespace Prize.JSP404.TwelveLabelMasks
open ThreeArcShared12Lists
set_option maxRecDepth 65536
set_option maxHeartbeats 18000000

theorem mask_ok_16 : rowOK 16 = true := by decide +kernel
theorem mask_ok_17 : rowOK 17 = true := by decide +kernel
theorem mask_ok_18 : rowOK 18 = true := by decide +kernel
theorem mask_ok_19 : rowOK 19 = true := by decide +kernel

end Prize.JSP404.TwelveLabelMasks
