import Finite21.Bits

namespace Prize.JSP404.TwelveLabelMasks
open ThreeArcShared12Lists
set_option maxRecDepth 65536
set_option maxHeartbeats 18000000

theorem mask_ok_04 : rowOK 4 = true := by decide +kernel
theorem mask_ok_05 : rowOK 5 = true := by decide +kernel
theorem mask_ok_06 : rowOK 6 = true := by decide +kernel
theorem mask_ok_07 : rowOK 7 = true := by decide +kernel

end Prize.JSP404.TwelveLabelMasks
