import Finite21.Bits

namespace Prize.JSP404.TwelveLabelMasks
open ThreeArcShared12Lists
set_option maxRecDepth 65536
set_option maxHeartbeats 18000000

theorem p08_09 : pair 8 9 = true := by decide +kernel
theorem p08_10 : pair 8 10 = true := by decide +kernel
theorem p08_11 : pair 8 11 = true := by decide +kernel
theorem p08_12 : pair 8 12 = true := by decide +kernel
theorem p08_13 : pair 8 13 = true := by decide +kernel
theorem p08_14 : pair 8 14 = true := by decide +kernel
theorem p08_15 : pair 8 15 = true := by decide +kernel
theorem p08_16 : pair 8 16 = true := by decide +kernel
theorem p08_17 : pair 8 17 = true := by decide +kernel
theorem p08_18 : pair 8 18 = true := by decide +kernel
theorem p08_19 : pair 8 19 = true := by decide +kernel

theorem from_08 (b : Nat) (hlo : 8 < b) (hhi : b < 20) : pair 8 b = true := by
  have hh : b = 9 ∨ b = 10 ∨ b = 11 ∨ b = 12 ∨ b = 13 ∨ b = 14 ∨ b = 15 ∨ b = 16 ∨ b = 17 ∨ b = 18 ∨ b = 19 := by omega
  rcases hh with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact p08_09
  · exact p08_10
  · exact p08_11
  · exact p08_12
  · exact p08_13
  · exact p08_14
  · exact p08_15
  · exact p08_16
  · exact p08_17
  · exact p08_18
  · exact p08_19

end Prize.JSP404.TwelveLabelMasks
