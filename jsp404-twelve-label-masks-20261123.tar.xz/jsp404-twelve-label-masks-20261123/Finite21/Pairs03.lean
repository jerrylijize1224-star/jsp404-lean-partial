import Finite21.Bits

namespace Prize.JSP404.TwelveLabelMasks
open ThreeArcShared12Lists
set_option maxRecDepth 65536
set_option maxHeartbeats 18000000

theorem p03_04 : pair 3 4 = true := by decide +kernel
theorem p03_05 : pair 3 5 = true := by decide +kernel
theorem p03_06 : pair 3 6 = true := by decide +kernel
theorem p03_07 : pair 3 7 = true := by decide +kernel
theorem p03_08 : pair 3 8 = true := by decide +kernel
theorem p03_09 : pair 3 9 = true := by decide +kernel
theorem p03_10 : pair 3 10 = true := by decide +kernel
theorem p03_11 : pair 3 11 = true := by decide +kernel
theorem p03_12 : pair 3 12 = true := by decide +kernel
theorem p03_13 : pair 3 13 = true := by decide +kernel
theorem p03_14 : pair 3 14 = true := by decide +kernel
theorem p03_15 : pair 3 15 = true := by decide +kernel
theorem p03_16 : pair 3 16 = true := by decide +kernel
theorem p03_17 : pair 3 17 = true := by decide +kernel
theorem p03_18 : pair 3 18 = true := by decide +kernel
theorem p03_19 : pair 3 19 = true := by decide +kernel

theorem from_03 (b : Nat) (hlo : 3 < b) (hhi : b < 20) : pair 3 b = true := by
  have hh : b = 4 ∨ b = 5 ∨ b = 6 ∨ b = 7 ∨ b = 8 ∨ b = 9 ∨ b = 10 ∨ b = 11 ∨ b = 12 ∨ b = 13 ∨ b = 14 ∨ b = 15 ∨ b = 16 ∨ b = 17 ∨ b = 18 ∨ b = 19 := by omega
  rcases hh with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact p03_04
  · exact p03_05
  · exact p03_06
  · exact p03_07
  · exact p03_08
  · exact p03_09
  · exact p03_10
  · exact p03_11
  · exact p03_12
  · exact p03_13
  · exact p03_14
  · exact p03_15
  · exact p03_16
  · exact p03_17
  · exact p03_18
  · exact p03_19

end Prize.JSP404.TwelveLabelMasks
