import Finite21.Bits

namespace Prize.JSP404.TwelveLabelMasks
open ThreeArcShared12Lists
set_option maxRecDepth 65536
set_option maxHeartbeats 18000000

theorem p09_10 : pair 9 10 = true := by decide +kernel
theorem p09_11 : pair 9 11 = true := by decide +kernel
theorem p09_12 : pair 9 12 = true := by decide +kernel
theorem p09_13 : pair 9 13 = true := by decide +kernel
theorem p09_14 : pair 9 14 = true := by decide +kernel
theorem p09_15 : pair 9 15 = true := by decide +kernel
theorem p09_16 : pair 9 16 = true := by decide +kernel
theorem p09_17 : pair 9 17 = true := by decide +kernel
theorem p09_18 : pair 9 18 = true := by decide +kernel
theorem p09_19 : pair 9 19 = true := by decide +kernel

theorem from_09 (b : Nat) (hlo : 9 < b) (hhi : b < 20) : pair 9 b = true := by
  have hh : b = 10 ∨ b = 11 ∨ b = 12 ∨ b = 13 ∨ b = 14 ∨ b = 15 ∨ b = 16 ∨ b = 17 ∨ b = 18 ∨ b = 19 := by omega
  rcases hh with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact p09_10
  · exact p09_11
  · exact p09_12
  · exact p09_13
  · exact p09_14
  · exact p09_15
  · exact p09_16
  · exact p09_17
  · exact p09_18
  · exact p09_19

end Prize.JSP404.TwelveLabelMasks
