import Finite21.Bits

namespace Prize.JSP404.TwelveLabelMasks
open ThreeArcShared12Lists
set_option maxRecDepth 65536
set_option maxHeartbeats 18000000

theorem mask_ok_00 : rowOK 0 = true := by decide +kernel
theorem mask_ok_01 : rowOK 1 = true := by decide +kernel
theorem mask_ok_02 : rowOK 2 = true := by decide +kernel
theorem mask_ok_03 : rowOK 3 = true := by decide +kernel

end Prize.JSP404.TwelveLabelMasks
