import Finite21.Bits

namespace Prize.JSP404.TwelveLabelMasks
open ThreeArcShared12Lists
set_option maxRecDepth 65536
set_option maxHeartbeats 18000000

theorem p05_06 : pair 5 6 = true := by decide +kernel
theorem p05_07 : pair 5 7 = true := by decide +kernel
theorem p05_08 : pair 5 8 = true := by decide +kernel
theorem p05_09 : pair 5 9 = true := by decide +kernel
theorem p05_10 : pair 5 10 = true := by decide +kernel
theorem p05_11 : pair 5 11 = true := by decide +kernel
theorem p05_12 : pair 5 12 = true := by decide +kernel
theorem p05_13 : pair 5 13 = true := by decide +kernel
theorem p05_14 : pair 5 14 = true := by decide +kernel
theorem p05_15 : pair 5 15 = true := by decide +kernel
theorem p05_16 : pair 5 16 = true := by decide +kernel
theorem p05_17 : pair 5 17 = true := by decide +kernel
theorem p05_18 : pair 5 18 = true := by decide +kernel
theorem p05_19 : pair 5 19 = true := by decide +kernel

theorem from_05 (b : Nat) (hlo : 5 < b) (hhi : b < 20) : pair 5 b = true := by
  have hh : b = 6 ∨ b = 7 ∨ b = 8 ∨ b = 9 ∨ b = 10 ∨ b = 11 ∨ b = 12 ∨ b = 13 ∨ b = 14 ∨ b = 15 ∨ b = 16 ∨ b = 17 ∨ b = 18 ∨ b = 19 := by omega
  rcases hh with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact p05_06
  · exact p05_07
  · exact p05_08
  · exact p05_09
  · exact p05_10
  · exact p05_11
  · exact p05_12
  · exact p05_13
  · exact p05_14
  · exact p05_15
  · exact p05_16
  · exact p05_17
  · exact p05_18
  · exact p05_19

end Prize.JSP404.TwelveLabelMasks
