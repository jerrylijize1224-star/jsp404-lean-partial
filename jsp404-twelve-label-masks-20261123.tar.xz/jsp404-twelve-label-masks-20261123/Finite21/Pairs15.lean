import Finite21.Bits

namespace Prize.JSP404.TwelveLabelMasks
open ThreeArcShared12Lists
set_option maxRecDepth 65536
set_option maxHeartbeats 18000000

theorem p15_16 : pair 15 16 = true := by decide +kernel
theorem p15_17 : pair 15 17 = true := by decide +kernel
theorem p15_18 : pair 15 18 = true := by decide +kernel
theorem p15_19 : pair 15 19 = true := by decide +kernel

theorem from_15 (b : Nat) (hlo : 15 < b) (hhi : b < 20) : pair 15 b = true := by
  have hh : b = 16 ∨ b = 17 ∨ b = 18 ∨ b = 19 := by omega
  rcases hh with rfl | rfl | rfl | rfl
  · exact p15_16
  · exact p15_17
  · exact p15_18
  · exact p15_19

end Prize.JSP404.TwelveLabelMasks
