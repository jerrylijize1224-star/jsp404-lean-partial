import Finite21.Bits

namespace Prize.JSP404.TwelveLabelMasks
open ThreeArcShared12Lists
set_option maxRecDepth 65536
set_option maxHeartbeats 18000000

theorem p10_11 : pair 10 11 = true := by decide +kernel
theorem p10_12 : pair 10 12 = true := by decide +kernel
theorem p10_13 : pair 10 13 = true := by decide +kernel
theorem p10_14 : pair 10 14 = true := by decide +kernel
theorem p10_15 : pair 10 15 = true := by decide +kernel
theorem p10_16 : pair 10 16 = true := by decide +kernel
theorem p10_17 : pair 10 17 = true := by decide +kernel
theorem p10_18 : pair 10 18 = true := by decide +kernel
theorem p10_19 : pair 10 19 = true := by decide +kernel

theorem from_10 (b : Nat) (hlo : 10 < b) (hhi : b < 20) : pair 10 b = true := by
  have hh : b = 11 ∨ b = 12 ∨ b = 13 ∨ b = 14 ∨ b = 15 ∨ b = 16 ∨ b = 17 ∨ b = 18 ∨ b = 19 := by omega
  rcases hh with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact p10_11
  · exact p10_12
  · exact p10_13
  · exact p10_14
  · exact p10_15
  · exact p10_16
  · exact p10_17
  · exact p10_18
  · exact p10_19

end Prize.JSP404.TwelveLabelMasks
