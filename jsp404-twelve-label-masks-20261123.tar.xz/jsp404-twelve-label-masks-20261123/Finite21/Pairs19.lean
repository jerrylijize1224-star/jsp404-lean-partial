import Finite21.Bits

namespace Prize.JSP404.TwelveLabelMasks
open ThreeArcShared12Lists
set_option maxRecDepth 65536
set_option maxHeartbeats 18000000


theorem from_19 (b : Nat) (hlo : 19 < b) (hhi : b < 20) : pair 19 b = true := by
  exfalso; omega

end Prize.JSP404.TwelveLabelMasks
