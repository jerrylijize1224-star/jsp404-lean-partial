import Finite21.Bits

namespace Prize.JSP404.TwelveLabelMasks
open ThreeArcShared12Lists
set_option maxRecDepth 65536
set_option maxHeartbeats 18000000

theorem mask_ok_08 : rowOK 8 = true := by decide +kernel
theorem mask_ok_09 : rowOK 9 = true := by decide +kernel
theorem mask_ok_10 : rowOK 10 = true := by decide +kernel
theorem mask_ok_11 : rowOK 11 = true := by decide +kernel

end Prize.JSP404.TwelveLabelMasks
