import Finite21.Bits

namespace Prize.JSP404.TwelveLabelMasks
open ThreeArcShared12Lists
set_option maxRecDepth 65536
set_option maxHeartbeats 18000000

theorem p13_14 : pair 13 14 = true := by decide +kernel
theorem p13_15 : pair 13 15 = true := by decide +kernel
theorem p13_16 : pair 13 16 = true := by decide +kernel
theorem p13_17 : pair 13 17 = true := by decide +kernel
theorem p13_18 : pair 13 18 = true := by decide +kernel
theorem p13_19 : pair 13 19 = true := by decide +kernel

theorem from_13 (b : Nat) (hlo : 13 < b) (hhi : b < 20) : pair 13 b = true := by
  have hh : b = 14 ∨ b = 15 ∨ b = 16 ∨ b = 17 ∨ b = 18 ∨ b = 19 := by omega
  rcases hh with rfl | rfl | rfl | rfl | rfl | rfl
  · exact p13_14
  · exact p13_15
  · exact p13_16
  · exact p13_17
  · exact p13_18
  · exact p13_19

end Prize.JSP404.TwelveLabelMasks
