import Finite21.Bits

namespace Prize.JSP404.TwelveLabelMasks
open ThreeArcShared12Lists
set_option maxRecDepth 65536
set_option maxHeartbeats 18000000

theorem p02_03 : pair 2 3 = true := by decide +kernel
theorem p02_04 : pair 2 4 = true := by decide +kernel
theorem p02_05 : pair 2 5 = true := by decide +kernel
theorem p02_06 : pair 2 6 = true := by decide +kernel
theorem p02_07 : pair 2 7 = true := by decide +kernel
theorem p02_08 : pair 2 8 = true := by decide +kernel
theorem p02_09 : pair 2 9 = true := by decide +kernel
theorem p02_10 : pair 2 10 = true := by decide +kernel
theorem p02_11 : pair 2 11 = true := by decide +kernel
theorem p02_12 : pair 2 12 = true := by decide +kernel
theorem p02_13 : pair 2 13 = true := by decide +kernel
theorem p02_14 : pair 2 14 = true := by decide +kernel
theorem p02_15 : pair 2 15 = true := by decide +kernel
theorem p02_16 : pair 2 16 = true := by decide +kernel
theorem p02_17 : pair 2 17 = true := by decide +kernel
theorem p02_18 : pair 2 18 = true := by decide +kernel
theorem p02_19 : pair 2 19 = true := by decide +kernel

theorem from_02 (b : Nat) (hlo : 2 < b) (hhi : b < 20) : pair 2 b = true := by
  have hh : b = 3 ∨ b = 4 ∨ b = 5 ∨ b = 6 ∨ b = 7 ∨ b = 8 ∨ b = 9 ∨ b = 10 ∨ b = 11 ∨ b = 12 ∨ b = 13 ∨ b = 14 ∨ b = 15 ∨ b = 16 ∨ b = 17 ∨ b = 18 ∨ b = 19 := by omega
  rcases hh with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact p02_03
  · exact p02_04
  · exact p02_05
  · exact p02_06
  · exact p02_07
  · exact p02_08
  · exact p02_09
  · exact p02_10
  · exact p02_11
  · exact p02_12
  · exact p02_13
  · exact p02_14
  · exact p02_15
  · exact p02_16
  · exact p02_17
  · exact p02_18
  · exact p02_19

end Prize.JSP404.TwelveLabelMasks
