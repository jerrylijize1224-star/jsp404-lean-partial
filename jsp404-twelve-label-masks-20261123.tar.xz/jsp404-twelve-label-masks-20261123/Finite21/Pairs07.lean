import Finite21.Bits

namespace Prize.JSP404.TwelveLabelMasks
open ThreeArcShared12Lists
set_option maxRecDepth 65536
set_option maxHeartbeats 18000000

theorem p07_08 : pair 7 8 = true := by decide +kernel
theorem p07_09 : pair 7 9 = true := by decide +kernel
theorem p07_10 : pair 7 10 = true := by decide +kernel
theorem p07_11 : pair 7 11 = true := by decide +kernel
theorem p07_12 : pair 7 12 = true := by decide +kernel
theorem p07_13 : pair 7 13 = true := by decide +kernel
theorem p07_14 : pair 7 14 = true := by decide +kernel
theorem p07_15 : pair 7 15 = true := by decide +kernel
theorem p07_16 : pair 7 16 = true := by decide +kernel
theorem p07_17 : pair 7 17 = true := by decide +kernel
theorem p07_18 : pair 7 18 = true := by decide +kernel
theorem p07_19 : pair 7 19 = true := by decide +kernel

theorem from_07 (b : Nat) (hlo : 7 < b) (hhi : b < 20) : pair 7 b = true := by
  have hh : b = 8 ∨ b = 9 ∨ b = 10 ∨ b = 11 ∨ b = 12 ∨ b = 13 ∨ b = 14 ∨ b = 15 ∨ b = 16 ∨ b = 17 ∨ b = 18 ∨ b = 19 := by omega
  rcases hh with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact p07_08
  · exact p07_09
  · exact p07_10
  · exact p07_11
  · exact p07_12
  · exact p07_13
  · exact p07_14
  · exact p07_15
  · exact p07_16
  · exact p07_17
  · exact p07_18
  · exact p07_19

end Prize.JSP404.TwelveLabelMasks
