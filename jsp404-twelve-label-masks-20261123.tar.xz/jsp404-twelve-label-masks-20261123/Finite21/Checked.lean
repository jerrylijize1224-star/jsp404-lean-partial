import Finite21.Members0
import Finite21.Members1
import Finite21.Members2
import Finite21.Members3
import Finite21.Members4
import Finite21.Pairs00
import Finite21.Pairs01
import Finite21.Pairs02
import Finite21.Pairs03
import Finite21.Pairs04
import Finite21.Pairs05
import Finite21.Pairs06
import Finite21.Pairs07
import Finite21.Pairs08
import Finite21.Pairs09
import Finite21.Pairs10
import Finite21.Pairs11
import Finite21.Pairs12
import Finite21.Pairs13
import Finite21.Pairs14
import Finite21.Pairs15
import Finite21.Pairs16
import Finite21.Pairs17
import Finite21.Pairs18
import Finite21.Pairs19

namespace Prize.JSP404.TwelveLabelMasks
open ThreeArcShared12Lists
set_option maxRecDepth 65536
set_option maxHeartbeats 18000000

theorem all_rows (x : Label) : rowOK x = true := by
  fin_cases x
  · exact mask_ok_00
  · exact mask_ok_01
  · exact mask_ok_02
  · exact mask_ok_03
  · exact mask_ok_04
  · exact mask_ok_05
  · exact mask_ok_06
  · exact mask_ok_07
  · exact mask_ok_08
  · exact mask_ok_09
  · exact mask_ok_10
  · exact mask_ok_11
  · exact mask_ok_12
  · exact mask_ok_13
  · exact mask_ok_14
  · exact mask_ok_15
  · exact mask_ok_16
  · exact mask_ok_17
  · exact mask_ok_18
  · exact mask_ok_19

theorem all_pairs (a b : Nat) (ha : a < 20) (hb : b < 20) (hab : a < b) : pair a b = true := by
  have hh : a = 0 ∨ a = 1 ∨ a = 2 ∨ a = 3 ∨ a = 4 ∨ a = 5 ∨ a = 6 ∨ a = 7 ∨ a = 8 ∨ a = 9 ∨ a = 10 ∨ a = 11 ∨ a = 12 ∨ a = 13 ∨ a = 14 ∨ a = 15 ∨ a = 16 ∨ a = 17 ∨ a = 18 ∨ a = 19 := by omega
  rcases hh with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact from_00 b hab hb
  · exact from_01 b hab hb
  · exact from_02 b hab hb
  · exact from_03 b hab hb
  · exact from_04 b hab hb
  · exact from_05 b hab hb
  · exact from_06 b hab hb
  · exact from_07 b hab hb
  · exact from_08 b hab hb
  · exact from_09 b hab hb
  · exact from_10 b hab hb
  · exact from_11 b hab hb
  · exact from_12 b hab hb
  · exact from_13 b hab hb
  · exact from_14 b hab hb
  · exact from_15 b hab hb
  · exact from_16 b hab hb
  · exact from_17 b hab hb
  · exact from_18 b hab hb
  · exact from_19 b hab hb

theorem walk_checked : walk mask 8 0 (2^2214-1) = true := by
  apply List.all_eq_true.mpr
  intro a ha
  apply List.all_eq_true.mpr
  intro b hb
  have h₁ := List.mem_range'_1.mp ha
  have h₂ := List.mem_range'_1.mp hb
  exact all_pairs a b (by omega) (by omega) (by omega)

theorem all_covered (s : Finset Label) (hs : 12 ≤ s.card) :
    ∃ i : Index, (coreList i).toFinset ⊆ s :=
  covered_of_walk mask (fun x i => row_entry_sound x (all_rows x) i) walk_checked s hs

end Prize.JSP404.TwelveLabelMasks
