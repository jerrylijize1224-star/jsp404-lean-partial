import Finite21.Bits

namespace Prize.JSP404.TwelveLabelMasks
open ThreeArcShared12Lists
set_option maxRecDepth 65536
set_option maxHeartbeats 18000000

theorem p18_19 : pair 18 19 = true := by decide +kernel

theorem from_18 (b : Nat) (hlo : 18 < b) (hhi : b < 20) : pair 18 b = true := by
  have hh : b = 19 := by omega
  rcases hh with rfl
  · exact p18_19

end Prize.JSP404.TwelveLabelMasks
