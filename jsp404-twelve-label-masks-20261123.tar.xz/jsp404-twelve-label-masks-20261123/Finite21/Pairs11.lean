import Finite21.Bits

namespace Prize.JSP404.TwelveLabelMasks
open ThreeArcShared12Lists
set_option maxRecDepth 65536
set_option maxHeartbeats 18000000

theorem p11_12 : pair 11 12 = true := by decide +kernel
theorem p11_13 : pair 11 13 = true := by decide +kernel
theorem p11_14 : pair 11 14 = true := by decide +kernel
theorem p11_15 : pair 11 15 = true := by decide +kernel
theorem p11_16 : pair 11 16 = true := by decide +kernel
theorem p11_17 : pair 11 17 = true := by decide +kernel
theorem p11_18 : pair 11 18 = true := by decide +kernel
theorem p11_19 : pair 11 19 = true := by decide +kernel

theorem from_11 (b : Nat) (hlo : 11 < b) (hhi : b < 20) : pair 11 b = true := by
  have hh : b = 12 ∨ b = 13 ∨ b = 14 ∨ b = 15 ∨ b = 16 ∨ b = 17 ∨ b = 18 ∨ b = 19 := by omega
  rcases hh with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact p11_12
  · exact p11_13
  · exact p11_14
  · exact p11_15
  · exact p11_16
  · exact p11_17
  · exact p11_18
  · exact p11_19

end Prize.JSP404.TwelveLabelMasks
