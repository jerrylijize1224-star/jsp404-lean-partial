import Finite21.Bits

namespace Prize.JSP404.TwelveLabelMasks
open ThreeArcShared12Lists
set_option maxRecDepth 65536
set_option maxHeartbeats 18000000

theorem p04_05 : pair 4 5 = true := by decide +kernel
theorem p04_06 : pair 4 6 = true := by decide +kernel
theorem p04_07 : pair 4 7 = true := by decide +kernel
theorem p04_08 : pair 4 8 = true := by decide +kernel
theorem p04_09 : pair 4 9 = true := by decide +kernel
theorem p04_10 : pair 4 10 = true := by decide +kernel
theorem p04_11 : pair 4 11 = true := by decide +kernel
theorem p04_12 : pair 4 12 = true := by decide +kernel
theorem p04_13 : pair 4 13 = true := by decide +kernel
theorem p04_14 : pair 4 14 = true := by decide +kernel
theorem p04_15 : pair 4 15 = true := by decide +kernel
theorem p04_16 : pair 4 16 = true := by decide +kernel
theorem p04_17 : pair 4 17 = true := by decide +kernel
theorem p04_18 : pair 4 18 = true := by decide +kernel
theorem p04_19 : pair 4 19 = true := by decide +kernel

theorem from_04 (b : Nat) (hlo : 4 < b) (hhi : b < 20) : pair 4 b = true := by
  have hh : b = 5 ∨ b = 6 ∨ b = 7 ∨ b = 8 ∨ b = 9 ∨ b = 10 ∨ b = 11 ∨ b = 12 ∨ b = 13 ∨ b = 14 ∨ b = 15 ∨ b = 16 ∨ b = 17 ∨ b = 18 ∨ b = 19 := by omega
  rcases hh with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact p04_05
  · exact p04_06
  · exact p04_07
  · exact p04_08
  · exact p04_09
  · exact p04_10
  · exact p04_11
  · exact p04_12
  · exact p04_13
  · exact p04_14
  · exact p04_15
  · exact p04_16
  · exact p04_17
  · exact p04_18
  · exact p04_19

end Prize.JSP404.TwelveLabelMasks
