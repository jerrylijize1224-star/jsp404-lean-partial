import Finite21.Bits

namespace Prize.JSP404.TwelveLabelMasks
open ThreeArcShared12Lists
set_option maxRecDepth 65536
set_option maxHeartbeats 18000000

theorem p14_15 : pair 14 15 = true := by decide +kernel
theorem p14_16 : pair 14 16 = true := by decide +kernel
theorem p14_17 : pair 14 17 = true := by decide +kernel
theorem p14_18 : pair 14 18 = true := by decide +kernel
theorem p14_19 : pair 14 19 = true := by decide +kernel

theorem from_14 (b : Nat) (hlo : 14 < b) (hhi : b < 20) : pair 14 b = true := by
  have hh : b = 15 ∨ b = 16 ∨ b = 17 ∨ b = 18 ∨ b = 19 := by omega
  rcases hh with rfl | rfl | rfl | rfl | rfl
  · exact p14_15
  · exact p14_16
  · exact p14_17
  · exact p14_18
  · exact p14_19

end Prize.JSP404.TwelveLabelMasks
