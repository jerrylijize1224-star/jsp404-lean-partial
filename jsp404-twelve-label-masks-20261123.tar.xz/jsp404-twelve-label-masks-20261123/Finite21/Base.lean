import Prize.JSP404.ThreeArcShared12Lists
import Mathlib.Data.Finset.Sort
import Mathlib.Data.Finset.Card
import Mathlib.Tactic.FinCases
import Lean.Elab.Tactic.Omega

namespace Prize.JSP404.TwelveLabelMasks
open ThreeArcShared12Lists

def walk (masks : Nat → Nat) : Nat → Nat → Nat → Bool
  | 0, _, live => decide (live ≠ 0)
  | k+1, start, live => (List.range' start (20-start)).all fun j =>
        walk masks k (j+1) (live &&& masks j)

def liveAfter (masks : Nat → Nat) : List Label → Nat → Nat
  | [], bits => bits
  | x::xs, bits => liveAfter masks xs (bits &&& masks x.val)

theorem walk_sound (masks : Nat → Nat) (xs : List Label) (hxs : xs.Pairwise (· < ·))
    (start bits : Nat) (hstart : ∀ x ∈ xs, start ≤ x.val)
    (h : walk masks xs.length start bits = true) : liveAfter masks xs bits ≠ 0 := by
  induction xs generalizing start bits with
  | nil => exact of_decide_eq_true h
  | cons x xs ih =>
    have hp := List.pairwise_cons.mp hxs
    have hx := hstart x (by simp)
    have hm : x.val ∈ List.range' start (20-start) := by
      apply List.mem_range'_1.mpr
      have hlt := x.isLt
      constructor <;> omega
    apply ih hp.2 (x.val+1) (bits &&& masks x.val)
    · intro y hy
      exact hp.1 y hy
    · exact List.all_eq_true.mp h x.val hm

theorem liveAfter_le (masks : Nat → Nat) (xs : List Label) (bits : Nat) :
    liveAfter masks xs bits ≤ bits := by
  induction xs generalizing bits with
  | nil => exact le_rfl
  | cons x xs ih => exact (ih _).trans Nat.and_le_left

theorem live_bit (masks : Nat → Nat) (xs : List Label) (bits i : Nat)
    (hi : (liveAfter masks xs bits).testBit i = true) :
    bits.testBit i = true ∧ ∀ x ∈ xs, (masks x.val).testBit i = true := by
  induction xs generalizing bits with
  | nil => exact ⟨hi, by simp⟩
  | cons x xs ih =>
    obtain ⟨h, ht⟩ := ih (bits &&& masks x.val) hi
    rw [Nat.testBit_and, Bool.and_eq_true_iff] at h
    exact ⟨h.1, fun y hy => (List.mem_cons.mp hy).elim (fun e => e ▸ h.2) (ht y)⟩

theorem covered_of_walk (masks : Nat → Nat)
    (sound : ∀ (x : Label) (i : Index), (masks x.val).testBit i.val = true → x ∉ coreList i)
    (checked : walk masks 8 0 (2^2214-1) = true)
    (s : Finset Label) (hs : 12 ≤ s.card) : ∃ i : Index, (coreList i).toFinset ⊆ s := by
  classical
  obtain ⟨q, hqs, hq⟩ := Finset.exists_subset_card_eq hs
  let missing : Finset Label := Finset.univ \ q
  let xs := missing.sort
  have hl : xs.length = 8 := by
    dsimp [xs, missing]
    rw [Finset.length_sort, Finset.card_sdiff_of_subset (Finset.subset_univ _), hq]
    decide
  have hp : xs.Pairwise (· < ·) := missing.sortedLT_sort.pairwise
  let bits := 2^2214-1
  let final := liveAfter masks xs bits
  have hn : final ≠ 0 :=
    walk_sound masks xs hp 0 bits (by intros; omega) (by simpa only [hl] using checked)
  have hb : final < 2^2214 := lt_of_le_of_lt (liveAfter_le masks xs bits) (by dsimp [bits]; omega)
  let i : Index := ⟨final.log2, (Nat.log2_lt hn).mpr hb⟩
  have hi : final.testBit i.val = true := Nat.testBit_log2 hn
  have hh := (live_bit masks xs bits i.val hi).2
  refine ⟨i, fun x hx => hqs ?_⟩
  by_contra hnot
  have hx' : x ∈ xs := (Finset.mem_sort (· ≤ ·)).mpr (Finset.mem_sdiff.mpr ⟨Finset.mem_univ _, hnot⟩)
  exact sound x i (hh x hx') (List.mem_toFinset.mp hx)

end Prize.JSP404.TwelveLabelMasks
