import Prize.JSP404.FirstBandLowerBounds

/-! The exact six-point case via an explicit regular hexagon. This supplies
the sharpness direction for six points only, not seven or eight points. -/

namespace Prize.JSP404

open EuclideanGeometry
open scoped RealInnerProductSpace

/-- A polynomial inner-product certificate for an angle at most 120 degrees.
It also handles zero vectors, whose angle in mathlib is pi/2. -/
theorem angle_le_two_pi_div_three_of_inner {u v : Plane}
    (h : 0 ≤ ⟪u, v⟫ ∨ 4 * ⟪u, v⟫ ^ 2 ≤ ⟪u, u⟫ * ⟪v, v⟫) :
    InnerProductGeometry.angle u v ≤ (2 / 3 : ℝ) * Real.pi := by
  have hcos : -(1 / 2 : ℝ) ≤ Real.cos (InnerProductGeometry.angle u v) := by
    rw [InnerProductGeometry.cos_angle]
    rcases h with h | h
    · exact (by norm_num : -(1 / 2 : ℝ) ≤ 0).trans
        (div_nonneg h (mul_nonneg (norm_nonneg u) (norm_nonneg v)))
    · rw [real_inner_self_eq_norm_sq, real_inner_self_eq_norm_sq, ← mul_pow] at h
      have hn : 0 ≤ ‖u‖ * ‖v‖ := mul_nonneg (norm_nonneg u) (norm_nonneg v)
      by_cases hz : ‖u‖ * ‖v‖ = 0
      · simp [hz]
      · apply (le_div_iff₀ (lt_of_le_of_ne hn (Ne.symm hz))).mpr
        nlinarith
  have hvalue : Real.cos ((2 / 3 : ℝ) * Real.pi) = -(1 / 2 : ℝ) := by
    rw [show (2 / 3 : ℝ) * Real.pi = Real.pi - Real.pi / 3 by ring,
      Real.cos_pi_sub, Real.cos_pi_div_three]
  by_contra hn
  have hh := Real.strictAntiOn_cos
    (show (2 / 3 : ℝ) * Real.pi ∈ Set.Icc 0 Real.pi by
      constructor <;> nlinarith [Real.pi_pos])
    ⟨InnerProductGeometry.angle_nonneg u v, InnerProductGeometry.angle_le_pi u v⟩
    (lt_of_not_ge hn)
  rw [hvalue] at hh
  linarith

noncomputable def hexagonVertex : Fin 6 → Plane :=
  ![!₂[2, 0], !₂[1, Real.sqrt 3], !₂[-1, Real.sqrt 3],
    !₂[-2, 0], !₂[-1, -Real.sqrt 3], !₂[1, -Real.sqrt 3]]

theorem hexagonVertex_injective : Function.Injective hexagonVertex := by
  intro i j h
  have h0 := congrArg (fun v : Plane => v 0) h
  have h1 := congrArg (fun v : Plane => v 1) h
  have hs : 0 < Real.sqrt 3 := Real.sqrt_pos.mpr (by norm_num)
  fin_cases i <;> fin_cases j <;> norm_num [hexagonVertex] at h0 <;>
    norm_num [hexagonVertex] at h1
  all_goals first | rfl | linarith

set_option maxHeartbeats 2000000 in
theorem hexagonVertex_angle (i j k : Fin 6) :
    angle (hexagonVertex i) (hexagonVertex j) (hexagonVertex k) ≤
      (2 / 3 : ℝ) * Real.pi := by
  apply angle_le_two_pi_div_three_of_inner
  simp only [PiLp.inner_apply, Fin.sum_univ_two]
  fin_cases i <;> fin_cases j <;> fin_cases k <;>
    norm_num [hexagonVertex, PiLp.inner_apply, Fin.sum_univ_two] <;>
    ring_nf <;> norm_num [Real.sq_sqrt]

noncomputable def hexagonSet : Finset Plane := Finset.univ.image hexagonVertex

theorem hexagonSet_card : hexagonSet.card = 6 := by
  rw [hexagonSet, Finset.card_image_of_injective _ hexagonVertex_injective]
  simp

theorem hexagonSet_angle {x y z : Plane}
    (hx : x ∈ hexagonSet) (hy : y ∈ hexagonSet) (hz : z ∈ hexagonSet) :
    angle x y z ≤ (2 / 3 : ℝ) * Real.pi := by
  obtain ⟨i, _, rfl⟩ := Finset.mem_image.mp hx
  obtain ⟨j, _, rfl⟩ := Finset.mem_image.mp hy
  obtain ⟨k, _, rfl⟩ := Finset.mem_image.mp hz
  exact hexagonVertex_angle i j k

theorem sixPoints_sharp : IsSharpBound 6 ((2 / 3 : ℝ) * Real.pi) := by
  refine ⟨by positivity, by linarith [Real.pi_pos],
    guaranteedAngle_two_pi_div_three (by decide), ?_⟩
  intro b hb h
  obtain ⟨x, hx, y, hy, z, hz, _, _, _, hangle⟩ := h hexagonSet hexagonSet_card
  have := hexagonSet_angle hx hy hz
  linarith

theorem alpha_six : alpha 6 = (2 / 3 : ℝ) * Real.pi := sixPoints_sharp.alpha_eq

end Prize.JSP404
