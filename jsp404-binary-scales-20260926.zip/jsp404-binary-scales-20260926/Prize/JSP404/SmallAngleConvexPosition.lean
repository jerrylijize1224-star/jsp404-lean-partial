import Prize.JSP404.FiniteClusterCounting
import Prize.JSP404.FourCentreClassification
import Mathlib.Analysis.Convex.Caratheodory
import Mathlib.Analysis.Convex.Independent

/-!
# Convex position in the first parameter band

An actual plane configuration with angle cap (1 - 1/t) pi and 0 < t < 3
is convex independent. This supplies a geometric restriction on the number
of small local weights; no polygon cardinality or sharp capacity bound is
claimed here.
-/

namespace Prize.JSP404

open EuclideanGeometry

theorem notMem_triangle_of_angle_bound {s : Finset Plane} {t : ℝ}
    (ht : 0 < t) (ht3 : t < 3)
    (ha : ∀ A ∈ s, ∀ B ∈ s, ∀ C ∈ s, A ≠ B → A ≠ C → B ≠ C →
      angle A B C ≤ (1 - 1 / t) * Real.pi)
    {A B C D : Plane} (hA : A ∈ s) (hB : B ∈ s) (hC : C ∈ s) (hD : D ∈ s)
    (hAB : A ≠ B) (hAC : A ≠ C) (hBC : B ≠ C)
    (hDA : D ≠ A) (hDB : D ≠ B) (hDC : D ≠ C) :
    D ∉ convexHull ℝ ({A, B, C} : Set Plane) := by
  intro hmem
  obtain ⟨a, b, c, ha0, hb0, hc0, hw, hv⟩ :=
    barycentric_of_mem_triangle hAB hAC hBC hmem
  let v : InteriorFourGeometry t := {
    A := A, B := B, C := C, D := D, a := a, b := b, c := c
    a_nonneg := ha0, b_nonneg := hb0, c_nonneg := hc0
    weights_sum := hw, barycentric := hv
    ab_ne := hAB, ac_ne := hAC, bc_ne := hBC
    da_ne := hDA, db_ne := hDB, dc_ne := hDC
    angle_a := ha B hB A hA C hC hAB.symm hBC hAC
    angle_b := ha A hA B hB C hC hAB hAC hBC
    angle_c := ha A hA C hC B hB hAC hAB hBC.symm
    angle_dab := ha A hA D hD B hB hDA.symm hAB hDB
    angle_dac := ha A hA D hD C hC hDA.symm hAC hDC
    angle_dbc := ha B hB D hD C hC hDB.symm hBC hDC }
  exact (not_le_of_gt ht3) (v.angleData ht).three_le_parameter

/-- No point lies in the convex hull of all the other points. The convex-hull
support is reduced to at most three points by mathlib's Caratheodory theorem. -/
theorem notMem_convexHull_erase_of_angle_bound {s : Finset Plane} {t : ℝ}
    (ht : 0 < t) (ht3 : t < 3)
    (ha : ∀ A ∈ s, ∀ B ∈ s, ∀ C ∈ s, A ≠ B → A ≠ C → B ≠ C →
      angle A B C ≤ (1 - 1 / t) * Real.pi)
    {D : Plane} (hD : D ∈ s) : D ∉ convexHull ℝ (↑(s.erase D) : Set Plane) := by
  classical
  intro hmem
  let q := Caratheodory.minCardFinsetOfMemConvexHull hmem
  have hqsub : q ⊆ s.erase D := Caratheodory.minCardFinsetOfMemConvexHull_subseteq hmem
  have hqmem : D ∈ convexHull ℝ (↑q : Set Plane) :=
    Caratheodory.mem_minCardFinsetOfMemConvexHull hmem
  have hqi := Caratheodory.affineIndependent_minCardFinsetOfMemConvexHull hmem
  have hcard : q.card ≤ 3 := by
    have hc := hqi.card_le_finrank_succ
    have hd := Submodule.finrank_le (vectorSpan ℝ (Set.range ((↑) : q → Plane)))
    have hp : Module.finrank ℝ Plane = 2 := by simp [Plane]
    rw [hp] at hd
    simp only [Fintype.card_coe] at hc
    change q.card ≤ Module.finrank ℝ (vectorSpan ℝ (Set.range ((↑) : q → Plane))) + 1 at hc
    omega
  have hqpos : 0 < q.card := Finset.card_pos.mpr
    (Caratheodory.minCardFinsetOfMemConvexHull_nonempty hmem)
  have hpoint {A : Plane} (h : A ∈ q) : A ∈ s ∧ D ≠ A := by
    have hh := Finset.mem_erase.mp (hqsub h)
    exact ⟨hh.2, hh.1.symm⟩
  have hcap : (1 - 1 / t) * Real.pi < Real.pi := by
    have he : (1 - 1 / t) * Real.pi = Real.pi - Real.pi / t := by ring
    rw [he]
    linarith [div_pos Real.pi_pos ht]
  have hgp : GeneralPosition s := generalPosition_of_angle_bound hcap ha
  have hcases : q.card = 1 ∨ q.card = 2 ∨ q.card = 3 := by omega
  rcases hcases with h1 | h2 | h3
  · obtain ⟨A, hA⟩ := Finset.card_eq_one.mp h1
    have hp := hpoint (A := A) (by simp [hA])
    have he : D = A := by simpa [hA] using hqmem
    exact hp.2 he
  · obtain ⟨A, B, hAB, hq⟩ := Finset.card_eq_two.mp h2
    have hpA := hpoint (A := A) (by simp [hq])
    have hpB := hpoint (A := B) (by simp [hq])
    have hseg : D ∈ segment ℝ A B := by simpa [hq, convexHull_pair] using hqmem
    exact hgp A hpA.1 D hD B hpB.1 hpA.2.symm hAB hpB.2
      (mem_segment_iff_wbtw.mp hseg).collinear
  · obtain ⟨A, B, C, hAB, hAC, hBC, hq⟩ := Finset.card_eq_three.mp h3
    have hpA := hpoint (A := A) (by simp [hq])
    have hpB := hpoint (A := B) (by simp [hq])
    have hpC := hpoint (A := C) (by simp [hq])
    apply notMem_triangle_of_angle_bound ht ht3 ha hpA.1 hpB.1 hpC.1 hD
      hAB hAC hBC hpA.2 hpB.2 hpC.2
    simpa [hq] using hqmem

theorem convexIndependent_of_angle_bound {s : Finset Plane} {t : ℝ}
    (ht : 0 < t) (ht3 : t < 3)
    (ha : ∀ A ∈ s, ∀ B ∈ s, ∀ C ∈ s, A ≠ B → A ≠ C → B ≠ C →
      angle A B C ≤ (1 - 1 / t) * Real.pi) :
    ConvexIndependent ℝ ((↑) : s → Plane) := by
  classical
  apply convexIndependent_set_iff_notMem_convexHull_sdiff.mpr
  intro D hD
  simpa only [Finset.coe_erase] using notMem_convexHull_erase_of_angle_bound ht ht3 ha hD

namespace FiniteClusterModel

theorem centres_convexIndependent {V : Type*} {m : ℕ} (M : FiniteClusterModel V m)
    {t : ℝ} (ht : 0 < t) (ht3 : t < 3)
    (hbound : M.directions.AngleBound ((1 - 1 / t) * Real.pi)) :
    ConvexIndependent ℝ M.centre := by
  have h := convexIndependent_of_angle_bound ht ht3 (M.centres_angle_bound hbound)
  let e : Fin (m + 2) ↪ M.centres :=
    ⟨fun i => ⟨M.centre i, M.centre_mem i⟩, fun _ _ he => M.distinct (congrArg Subtype.val he)⟩
  exact h.comp_embedding e

end FiniteClusterModel
end Prize.JSP404
