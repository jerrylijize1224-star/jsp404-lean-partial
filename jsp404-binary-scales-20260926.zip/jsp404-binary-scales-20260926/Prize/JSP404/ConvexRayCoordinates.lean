import Prize.JSP404.SmallAngleConvexPosition
import Mathlib.Analysis.LocallyConvex.Separation
import Mathlib.Analysis.Convex.Topology

/-! Supporting functionals and ordered affine ray coordinates. These are
constructed from convex independence, rather than assumed direction charts. -/

namespace Prize.JSP404

theorem exists_positive_support {ι : Type*} [Finite ι] (p : ι → Plane)
    (hp : ConvexIndependent ℝ p) (a : ι) :
    ∃ f : Plane →ₗ[ℝ] ℝ, ∀ i, i ≠ a → 0 < f (p i - p a) := by
  classical
  let S : Set Plane := p '' (Set.univ \ {a})
  have hnot : p a ∉ convexHull ℝ S :=
    (convexIndependent_iff_notMem_convexHull_sdiff.mp hp) a Set.univ
  have hS : S.Finite := (Set.toFinite (Set.univ \ {a})).image p
  have hclosed : IsClosed (convexHull ℝ S) := hS.isClosed_convexHull ℝ
  obtain ⟨f, r, ha, hs⟩ := geometric_hahn_banach_point_closed (convex_convexHull ℝ S) hclosed hnot
  refine ⟨f.toLinearMap, ?_⟩
  intro i hi
  have hm : p i ∈ convexHull ℝ S := subset_convexHull ℝ S
    (Set.mem_image_of_mem p (by simp [hi]))
  have hb := hs _ hm
  change 0 < f (p i - p a)
  rw [map_sub]
  linarith

def planeCoordinate (i : Fin 2) : Plane →ₗ[ℝ] ℝ where
  toFun u := u i
  map_add' _ _ := rfl
  map_smul' _ _ := rfl

theorem linearMap_plane_formula (f : Plane →ₗ[ℝ] ℝ) (u : Plane) :
    f u = u 0 * f !₂[1, 0] + u 1 * f !₂[0, 1] := by
  have he : u = u 0 • !₂[1, 0] + u 1 • !₂[0, 1] := by
    ext i
    fin_cases i <;> simp
  conv_lhs => rw [he]
  simp only [map_add, map_smul, smul_eq_mul]

theorem exists_complementary_coordinate (f : Plane →ₗ[ℝ] ℝ) (hf : f ≠ 0) :
    ∃ g : Plane →ₗ[ℝ] ℝ, ∀ u v, f u = f v → g u = g v → u = v := by
  by_cases hc1 : f !₂[0, 1] = 0
  · have hc0 : f !₂[1, 0] ≠ 0 := by
      intro h
      apply hf
      ext u
      simp [linearMap_plane_formula, h, hc1]
    refine ⟨planeCoordinate 1, ?_⟩
    intro u v huv hg
    change u 1 = v 1 at hg
    have h0 : u 0 = v 0 := by
      rw [linearMap_plane_formula f u, linearMap_plane_formula f v, hc1] at huv
      simpa using (mul_right_cancel₀ hc0 (by simpa using huv))
    ext i
    fin_cases i
    · exact h0
    · exact hg
  · refine ⟨planeCoordinate 0, ?_⟩
    intro u v huv hg
    change u 0 = v 0 at hg
    have h1 : u 1 = v 1 := by
      rw [linearMap_plane_formula f u, linearMap_plane_formula f v, hg] at huv
      exact mul_right_cancel₀ hc1 (by linarith)
    ext i
    fin_cases i
    · exact hg
    · exact h1

theorem slope_injective_of_positive_support {ι : Type*} (p : ι → Plane)
    (f g : Plane →ₗ[ℝ] ℝ)
    (hfg : ∀ u v, f u = f v → g u = g v → u = v)
    (hpos : ∀ i, 0 < f (p i))
    (hangle : ∀ i j, i ≠ j → InnerProductGeometry.angle (p i) (p j) ≠ 0) :
    Function.Injective (fun i => g (p i) / f (p i)) := by
  intro i j hij
  by_contra hne
  have he : (1 / f (p i)) • p i = (1 / f (p j)) • p j := by
    apply hfg
    · simp [map_smul, smul_eq_mul, ne_of_gt (hpos i), ne_of_gt (hpos j)]
    · simpa [map_smul, smul_eq_mul, div_eq_mul_inv, mul_comm] using hij
  have hpi : p i ≠ 0 := by
    intro h
    have hh := hpos i
    simpa [h] using hh
  have hnorm : (1 / f (p i)) • p i ≠ 0 :=
    smul_ne_zero (ne_of_gt (one_div_pos.mpr (hpos i))) hpi
  have hang := InnerProductGeometry.angle_self hnorm
  nth_rw 2 [he] at hang
  rw [InnerProductGeometry.angle_smul_left_of_pos _ _ (one_div_pos.mpr (hpos i)),
    InnerProductGeometry.angle_smul_right_of_pos _ _ (one_div_pos.mpr (hpos j))] at hang
  exact hangle i j hne hang

end Prize.JSP404
