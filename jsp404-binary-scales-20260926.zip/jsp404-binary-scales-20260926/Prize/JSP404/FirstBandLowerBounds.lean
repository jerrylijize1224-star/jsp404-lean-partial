import Prize.JSP404.SixPointObstruction
import Prize.JSP404.Sharpness

/-! Universal bounds for the original ordinary finite configurations.
These are lower bounds, not sharpness constructions or the full target. -/

namespace Prize.JSP404

open EuclideanGeometry

theorem exists_parameter_of_angle_lt_two_pi_div_three {a : ℝ}
    (ha : a < (2 / 3 : ℝ) * Real.pi) :
    ∃ t : ℝ, 0 < t ∧ t < 3 ∧ a = (1 - 1 / t) * Real.pi := by
  have hd : 0 < Real.pi - a := by linarith [Real.pi_pos]
  refine ⟨Real.pi / (Real.pi - a), div_pos Real.pi_pos hd, ?_, ?_⟩
  · apply (div_lt_iff₀ hd).mpr
    linarith
  · field_simp
    <;> ring

theorem hasLargeAngle_two_pi_div_three {s : Finset Plane} (hs : 6 ≤ s.card) :
    HasLargeAngle s ((2 / 3 : ℝ) * Real.pi) := by
  obtain ⟨x, hx, y, hy, z, hz, hxy, hxz, hyz, hm⟩ := exists_largest_angle (by omega : 3 ≤ s.card)
  refine ⟨x, hx, y, hy, z, hz, hxy, hxz, hyz, ?_⟩
  by_contra h
  obtain ⟨t, ht, ht3, he⟩ := exists_parameter_of_angle_lt_two_pi_div_three (lt_of_not_ge h)
  have hc := card_le_five_of_angle_bound ht ht3 (by simpa only [← he] using hm)
  omega

theorem hasLargeAngle_three_pi_div_five {s : Finset Plane} (hs : 5 ≤ s.card) :
    HasLargeAngle s ((3 / 5 : ℝ) * Real.pi) := by
  classical
  obtain ⟨x, hx, y, hy, z, hz, hxy, hxz, hyz, hm⟩ := exists_largest_angle (by omega : 3 ≤ s.card)
  refine ⟨x, hx, y, hy, z, hz, hxy, hxz, hyz, ?_⟩
  by_contra h
  have ha : angle x y z < (2 / 3 : ℝ) * Real.pi := by linarith [Real.pi_pos]
  obtain ⟨t, ht, ht3, he⟩ := exists_parameter_of_angle_lt_two_pi_div_three ha
  have hc := convexIndependent_of_angle_bound ht ht3 (by simpa only [← he] using hm)
  obtain ⟨e⟩ := Function.Embedding.nonempty_of_card_le
    (show Fintype.card (Fin 5) ≤ Fintype.card s by simpa using hs)
  obtain ⟨r, ⟨hfan⟩⟩ := exists_pentagonFan_reindex _ (hc.comp_embedding e)
  let p : Fin 5 → Plane := fun i => (e (r i)).val
  have hp : Function.Injective p := Subtype.val_injective.comp (e.injective.comp r.injective)
  have hsum := hfan.angle_sum hp
  have hb (i j k : Fin 5) (hij : i ≠ j) (hik : i ≠ k) (hjk : j ≠ k) :
      angle (p i) (p j) (p k) ≤ angle x y z :=
    hm _ (e (r i)).property _ (e (r j)).property _ (e (r k)).property
      (hp.ne hij) (hp.ne hik) (hp.ne hjk)
  have h0 := hb 4 0 1 (by decide) (by decide) (by decide)
  have h1 := hb 0 1 2 (by decide) (by decide) (by decide)
  have h2 := hb 1 2 3 (by decide) (by decide) (by decide)
  have h3 := hb 2 3 4 (by decide) (by decide) (by decide)
  have h4 := hb 3 4 0 (by decide) (by decide) (by decide)
  change angle (p 4) (p 0) (p 1) + angle (p 0) (p 1) (p 2) +
    angle (p 1) (p 2) (p 3) + angle (p 2) (p 3) (p 4) +
    angle (p 3) (p 4) (p 0) = 3 * Real.pi at hsum
  linarith

theorem guaranteedAngle_two_pi_div_three {n : ℕ} (hn : 6 ≤ n) :
    GuaranteedAngle n ((2 / 3 : ℝ) * Real.pi) := by
  intro s hs
  exact hasLargeAngle_two_pi_div_three (hs ▸ hn)

theorem guaranteedAngle_three_pi_div_five {n : ℕ} (hn : 5 ≤ n) :
    GuaranteedAngle n ((3 / 5 : ℝ) * Real.pi) := by
  intro s hs
  exact hasLargeAngle_three_pi_div_five (hs ▸ hn)

theorem two_pi_div_three_le_alpha {n : ℕ} (hn : 6 ≤ n) :
    (2 / 3 : ℝ) * Real.pi ≤ alpha n :=
  le_csSup (admissibleAngles_bddAbove n)
    ⟨by positivity, by linarith [Real.pi_pos], guaranteedAngle_two_pi_div_three hn⟩

theorem three_pi_div_five_le_alpha {n : ℕ} (hn : 5 ≤ n) :
    (3 / 5 : ℝ) * Real.pi ≤ alpha n :=
  le_csSup (admissibleAngles_bddAbove n)
    ⟨by positivity, by linarith [Real.pi_pos], guaranteedAngle_three_pi_div_five hn⟩

end Prize.JSP404
