import Prize.JSP404.ConvexRayCoordinates
import Prize.JSP404.ConvexFourCrossings

/-! Ordered rays force the middle diagonal pairing in a convex quadruple. -/

namespace Prize.JSP404

open EuclideanGeometry

theorem not_crossing_of_linear_side (L : Plane →ₗ[ℝ] ℝ) {A B C D O : Plane}
    (hAB : L A = L B) (hC : L A < L C) (hD : L A < L D)
    (h1 : Wbtw ℝ A O B) (h2 : Wbtw ℝ C O D) : False := by
  have hm1 := h1.map L.toAffineMap
  have hm2 := h2.map L.toAffineMap
  change Wbtw ℝ (L A) (L O) (L B) at hm1
  change Wbtw ℝ (L C) (L O) (L D) at hm2
  rw [← hAB, wbtw_self_iff] at hm1
  rcases le_total (L C) (L D) with hcd | hdc
  · have hh := (wbtw_iff_of_le hcd).mp hm2
    linarith
  · have hh := (wbtw_iff_of_le hdc).mp hm2.symm
    linarith

theorem not_crossing_of_slope_lt (f g : Plane →ₗ[ℝ] ℝ) {A B C D O : Plane}
    (hB : 0 < f (B - A)) (hC : 0 < f (C - A)) (hD : 0 < f (D - A))
    (hBC : g (B - A) / f (B - A) < g (C - A) / f (C - A))
    (hBD : g (B - A) / f (B - A) < g (D - A) / f (D - A))
    (h1 : Wbtw ℝ A O B) (h2 : Wbtw ℝ C O D) : False := by
  let s := g (B - A) / f (B - A)
  let L : Plane →ₗ[ℝ] ℝ := g - s • f
  have he : s * f (B - A) = g (B - A) := div_mul_cancel₀ _ (ne_of_gt hB)
  have hc := (lt_div_iff₀ hC).mp hBC
  have hd := (lt_div_iff₀ hD).mp hBD
  change s * f (C - A) < g (C - A) at hc
  change s * f (D - A) < g (D - A) at hd
  apply not_crossing_of_linear_side L ?_ ?_ ?_ h1 h2
  all_goals
    dsimp [L]
    simp only [map_sub] at he hc hd
    nlinarith

theorem not_crossing_of_slope_gt (f g : Plane →ₗ[ℝ] ℝ) {A B C D O : Plane}
    (hB : 0 < f (B - A)) (hC : 0 < f (C - A)) (hD : 0 < f (D - A))
    (hCB : g (C - A) / f (C - A) < g (B - A) / f (B - A))
    (hDB : g (D - A) / f (D - A) < g (B - A) / f (B - A))
    (h1 : Wbtw ℝ A O B) (h2 : Wbtw ℝ C O D) : False := by
  apply not_crossing_of_slope_lt f (-g) hB hC hD ?_ ?_ h1 h2
  · simpa only [LinearMap.neg_apply, neg_div] using neg_lt_neg hCB
  · simpa only [LinearMap.neg_apply, neg_div] using neg_lt_neg hDB

theorem ordered_rays_crossing (p : Fin 4 → Plane) (hp : ConvexIndependent ℝ p)
    (f g : Plane →ₗ[ℝ] ℝ)
    (h1 : 0 < f (p 1 - p 0)) (h2 : 0 < f (p 2 - p 0)) (h3 : 0 < f (p 3 - p 0))
    (h12 : g (p 1 - p 0) / f (p 1 - p 0) < g (p 2 - p 0) / f (p 2 - p 0))
    (h23 : g (p 2 - p 0) / f (p 2 - p 0) < g (p 3 - p 0) / f (p 3 - p 0)) :
    ∃ O, Sbtw ℝ (p 0) O (p 2) ∧ Sbtw ℝ (p 1) O (p 3) := by
  rcases convex_four_weak_crossing_cases p hp with ⟨O, hA, hB⟩ | ⟨O, hA, hB⟩ | ⟨O, hA, hB⟩
  · exact (not_crossing_of_slope_lt f g h1 h2 h3 h12 (h12.trans h23) hA hB).elim
  · refine ⟨O, strict_crossing_of_convexIndependent hp ?_ hA hB⟩
    rw [Set.disjoint_left]
    intro i hi hj
    simp only [Set.mem_insert_iff, Set.mem_singleton_iff] at hi hj
    rcases hi with rfl | rfl <;> norm_num at hj
  · exact (not_crossing_of_slope_gt f g h3 h1 h2 (h12.trans h23) h23 hA hB).elim

end Prize.JSP404
