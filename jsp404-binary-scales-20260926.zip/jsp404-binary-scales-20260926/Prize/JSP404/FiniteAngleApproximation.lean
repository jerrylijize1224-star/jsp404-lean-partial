import Prize.JSP404.Sharpness
import Mathlib.Topology.Order.Basic

/-! A finite simultaneous approximation interface for scaled point differences.
The nonzero limiting directions and the positive scaling laws are explicit
premises, to be discharged by a concrete construction. -/

namespace Prize.JSP404

open EuclideanGeometry Filter
open scoped Topology

set_option maxHeartbeats 1000000 in
theorem exists_finite_angle_approximation {ι : Type*} [Fintype ι]
    (p : ℝ → ι → Plane) (q : ℝ → ι → ι → Plane) (c : ℝ → ι → ι → ℝ)
    (hcont : ∀ i j, ContinuousAt (fun t => q t i j) 0)
    (hne : ∀ i j, i ≠ j → q 0 i j ≠ 0)
    (hc : ∀ t, 0 < t → ∀ i j, 0 < c t i j)
    (hrep : ∀ t, 0 < t → ∀ i j, p t j - p t i = c t i j • q t i j)
    {A ε : ℝ}
    (hangle : ∀ i j k, i ≠ j → i ≠ k → j ≠ k →
      InnerProductGeometry.angle (q 0 j i) (q 0 j k) ≤ A)
    (hε : 0 < ε) :
    ∃ t : ℝ, 0 < t ∧ Function.Injective (p t) ∧
      ∀ i j k, i ≠ j → i ≠ k → j ≠ k → angle (p t i) (p t j) (p t k) < A + ε := by
  have hnonzero : ∀ᶠ t in 𝓝 (0 : ℝ), ∀ i j, i ≠ j → q t i j ≠ 0 := by
    apply eventually_all.mpr
    intro i
    apply eventually_all.mpr
    intro j
    by_cases hij : i = j
    · exact Eventually.of_forall (fun _ h => False.elim (h hij))
    · filter_upwards [(hcont i j).eventually_ne (hne i j hij)] with t ht _
      exact ht
  have hangles : ∀ᶠ t in 𝓝 (0 : ℝ), ∀ i j k, i ≠ j → i ≠ k → j ≠ k →
      InnerProductGeometry.angle (q t j i) (q t j k) < A + ε := by
    apply eventually_all.mpr
    intro i
    apply eventually_all.mpr
    intro j
    apply eventually_all.mpr
    intro k
    by_cases hij : i = j
    · exact Eventually.of_forall (fun _ h => False.elim (h hij))
    by_cases hik : i = k
    · exact Eventually.of_forall (fun _ _ h => False.elim (h hik))
    by_cases hjk : j = k
    · exact Eventually.of_forall (fun _ _ _ h => False.elim (h hjk))
    have hpair : ContinuousAt (fun t : ℝ => (q t j i, q t j k)) 0 :=
      (hcont j i).prodMk (hcont j k)
    have hfun : ContinuousAt
        (fun v : Plane × Plane => InnerProductGeometry.angle v.1 v.2)
        (q 0 j i, q 0 j k) :=
      InnerProductGeometry.continuousAt_angle (x := (q 0 j i, q 0 j k))
        (hne j i (fun h => hij h.symm)) (hne j k hjk)
    have hlimit : ContinuousAt
        (fun t : ℝ => InnerProductGeometry.angle (q t j i) (q t j k)) 0 :=
      ContinuousAt.comp (f := fun t : ℝ => (q t j i, q t j k)) hfun hpair
    have hlt : InnerProductGeometry.angle (q 0 j i) (q 0 j k) < A + ε := by
      linarith [hangle i j k hij hik hjk]
    filter_upwards [hlimit.tendsto.eventually_lt_const hlt] with t ht _ _ _
    exact ht
  have hboth : ∀ᶠ t in 𝓝[>] (0 : ℝ),
      (∀ i j, i ≠ j → q t i j ≠ 0) ∧
      (∀ i j k, i ≠ j → i ≠ k → j ≠ k →
        InnerProductGeometry.angle (q t j i) (q t j k) < A + ε) :=
    (hnonzero.and hangles).filter_mono nhdsWithin_le_nhds
  have hpos : ∀ᶠ t : ℝ in 𝓝[>] (0 : ℝ), 0 < t := self_mem_nhdsWithin
  obtain ⟨t, ht, hq, ha⟩ := (hpos.and hboth).exists
  refine ⟨t, ht, ?_, ?_⟩
  · intro i j he
    by_contra hij
    have hz : c t i j • q t i j = 0 := by rw [← hrep t ht i j, he, sub_self]
    exact (smul_ne_zero (ne_of_gt (hc t ht i j)) (hq i j hij)) hz
  · intro i j k hij hik hjk
    change InnerProductGeometry.angle (p t i - p t j) (p t k - p t j) < A + ε
    rw [hrep t ht j i, hrep t ht j k,
      InnerProductGeometry.angle_smul_left_of_pos _ _ (hc t ht j i),
      InnerProductGeometry.angle_smul_right_of_pos _ _ (hc t ht j k)]
    exact ha i j k hij hik hjk

end Prize.JSP404
