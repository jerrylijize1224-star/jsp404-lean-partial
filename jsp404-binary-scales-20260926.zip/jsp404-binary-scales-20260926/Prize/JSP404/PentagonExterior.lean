import Prize.JSP404.FiniteExteriorBound
import Prize.JSP404.FourCentreConvexGeometry

/-!
# An exterior budget from three actual pentagon diagonal crossings

The incidence hypotheses certify the needed fan angle decompositions. Their
existence for an arbitrary convex-independent five-point set is not proved here.
-/

namespace Prize.JSP404

open EuclideanGeometry

structure PentagonFan (p : Fin 5 → Plane) where
  O₁ : Plane
  O₂ : Plane
  O₃ : Plane
  ac_bd_left : Sbtw ℝ (p 0) O₁ (p 2)
  ac_bd_right : Sbtw ℝ (p 1) O₁ (p 3)
  ad_ce_left : Sbtw ℝ (p 0) O₂ (p 3)
  ad_ce_right : Sbtw ℝ (p 2) O₂ (p 4)
  ac_be_left : Sbtw ℝ (p 0) O₃ (p 2)
  ac_be_right : Sbtw ℝ (p 1) O₃ (p 4)

def pentagonPrev : Fin 5 → Fin 5 := ![4, 0, 1, 2, 3]
def pentagonNext : Fin 5 → Fin 5 := ![1, 2, 3, 4, 0]

namespace PentagonFan

variable {p : Fin 5 → Plane} (f : PentagonFan p)

include f

theorem angle_sum (hp : Function.Injective p) :
    angle (p 4) (p 0) (p 1) + angle (p 0) (p 1) (p 2) +
      angle (p 1) (p 2) (p 3) + angle (p 2) (p 3) (p 4) +
      angle (p 3) (p 4) (p 0) = 3 * Real.pi := by
  have hA₁ := angle_add_angle_eq_of_sbtw (p := p 0) f.ac_be_right
  rw [f.ac_be_left.angle_eq_right (p 1), f.ac_be_left.angle_eq_left (p 4)] at hA₁
  have hA₂ := angle_add_angle_eq_of_sbtw (p := p 0) f.ad_ce_right
  rw [f.ad_ce_left.angle_eq_right (p 2), f.ad_ce_left.angle_eq_left (p 4)] at hA₂
  have hC := angle_add_angle_eq_of_sbtw (p := p 2) f.ac_bd_right
  rw [f.ac_bd_left.symm.angle_eq_right (p 1), f.ac_bd_left.symm.angle_eq_left (p 3)] at hC
  have hD := angle_add_angle_eq_of_sbtw (p := p 3) f.ad_ce_right
  rw [f.ad_ce_left.symm.angle_eq_right (p 2), f.ad_ce_left.symm.angle_eq_left (p 4)] at hD
  have hABC := angle_add_angle_add_angle_eq_pi (p 2) (hp.ne (by decide : (1 : Fin 5) ≠ 0))
  have hACD := angle_add_angle_add_angle_eq_pi (p 3) (hp.ne (by decide : (2 : Fin 5) ≠ 0))
  have hADE := angle_add_angle_add_angle_eq_pi (p 4) (hp.ne (by decide : (3 : Fin 5) ≠ 0))
  rw [angle_comm (p 2) (p 0) (p 1)] at hABC
  rw [angle_comm (p 3) (p 0) (p 2)] at hACD
  rw [angle_comm (p 4) (p 0) (p 3)] at hADE
  rw [angle_comm (p 4) (p 0) (p 1)]
  linarith

theorem exterior_sum (hp : Function.Injective p) :
    (∑ i, (1 - angle (p (pentagonPrev i)) (p i) (p (pentagonNext i)) / Real.pi)) = 2 := by
  have h := f.angle_sum hp
  simp [pentagonPrev, pentagonNext, Fin.sum_univ_succ]
  field_simp
  linarith

end PentagonFan

namespace FiniteClusterModel

theorem card_le_five_of_pentagon_fan {V : Type*} [Fintype V] (M : FiniteClusterModel V 3)
    {t : ℝ} (ht : 1 ≤ t) (ht3 : t < 3)
    (hbound : M.directions.AngleBound ((1 - 1 / t) * Real.pi))
    (hfan : PentagonFan M.centre) : Fintype.card V ≤ 5 := by
  apply M.card_le_five_of_exterior_budget ht ht3 hbound pentagonPrev pentagonNext
  · intro i; fin_cases i <;> decide
  · intro i; fin_cases i <;> decide
  · intro i; fin_cases i <;> decide
  · exact (hfan.exterior_sum M.distinct).le

theorem card_eq_five_of_pentagon_fan {V : Type*} [Fintype V] (M : FiniteClusterModel V 3)
    {t : ℝ} (ht : 1 ≤ t) (ht3 : t < 3)
    (hbound : M.directions.AngleBound ((1 - 1 / t) * Real.pi))
    (hfan : PentagonFan M.centre) : Fintype.card V = 5 := by
  have hupper := M.card_le_five_of_pentagon_fan ht ht3 hbound hfan
  have hlower := Fintype.card_le_of_surjective M.cluster M.occupied
  simp only [Fintype.card_fin] at hlower
  omega

theorem not_angleBound_of_pentagon_fan_low {V : Type*} [Fintype V] (M : FiniteClusterModel V 3)
    {t : ℝ} (ht : 1 ≤ t) (ht' : t < 5 / 2) (hfan : PentagonFan M.centre) :
    ¬ M.directions.AngleBound ((1 - 1 / t) * Real.pi) := by
  intro hbound
  have hupper := M.card_le_four_of_exterior_budget ht ht' hbound pentagonPrev pentagonNext
    (by intro i; fin_cases i <;> decide) (by intro i; fin_cases i <;> decide)
    (by intro i; fin_cases i <;> decide) (hfan.exterior_sum M.distinct).le
  have hlower := Fintype.card_le_of_surjective M.cluster M.occupied
  simp only [Fintype.card_fin] at hlower
  omega

end FiniteClusterModel
end Prize.JSP404
