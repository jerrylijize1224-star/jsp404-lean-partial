import Prize.JSP404.FourCentreInterior

/-!
# Arithmetic for a prospective exterior-angle budget

The arguments x below are proposed scaled exterior angles. Their relation to
actual local indices is NOT proved here. The lower and upper band conclusions
are conditional arithmetic lemmas, not finite-cluster capacity theorems.
-/

namespace Prize.JSP404

theorem gapBits_weight_le_of_one_le_lt_three {x : ℝ} (h1 : 1 ≤ x) (h3 : x < 3) :
    (2 ^ gapBits x : ℕ) ≤ x := by
  have hf1 : (1 : ℤ) ≤ ⌊x⌋ := Int.le_floor.mpr (by simpa using h1)
  have hf2 : ⌊x⌋ ≤ (2 : ℤ) := Int.floor_le_iff.mpr (by norm_num; exact h3)
  have hcases : ⌊x⌋ = 1 ∨ ⌊x⌋ = 2 := by omega
  rcases hcases with h | h
  · simpa [gapBits, sectorCapacity, h] using h1
  · have hx : (2 : ℝ) ≤ x := by simpa [h] using Int.floor_le x
    simpa [gapBits, sectorCapacity, h] using hx

theorem exterior_budget_weight_sum {ι : Type*} (s : Finset ι) (x : ι → ℝ)
    {t : ℝ} (h1 : ∀ i ∈ s, 1 ≤ x i) (h3 : ∀ i ∈ s, x i < 3)
    (hsum : ∑ i ∈ s, x i = 2 * t) :
    (∑ i ∈ s, 2 ^ gapBits (x i) : ℕ) ≤ 2 * t := by
  rw [Nat.cast_sum]
  exact (Finset.sum_le_sum (fun i hi =>
    gapBits_weight_le_of_one_le_lt_three (h1 i hi) (h3 i hi))).trans_eq hsum

theorem exterior_budget_low {ι : Type*} (s : Finset ι) (x : ι → ℝ)
    {t : ℝ} (ht : t < 5 / 2) (h1 : ∀ i ∈ s, 1 ≤ x i)
    (h3 : ∀ i ∈ s, x i < 3) (hsum : ∑ i ∈ s, x i = 2 * t) :
    ∑ i ∈ s, 2 ^ gapBits (x i) ≤ 4 := by
  have h := exterior_budget_weight_sum s x h1 h3 hsum
  have hh : ((∑ i ∈ s, 2 ^ gapBits (x i) : ℕ) : ℝ) < 5 := by linarith
  have hn : (∑ i ∈ s, 2 ^ gapBits (x i) : ℕ) < 5 := by exact_mod_cast hh
  omega

theorem exterior_budget_high {ι : Type*} (s : Finset ι) (x : ι → ℝ)
    {t : ℝ} (ht : t < 3) (h1 : ∀ i ∈ s, 1 ≤ x i)
    (h3 : ∀ i ∈ s, x i < 3) (hsum : ∑ i ∈ s, x i = 2 * t) :
    ∑ i ∈ s, 2 ^ gapBits (x i) ≤ 5 := by
  have h := exterior_budget_weight_sum s x h1 h3 hsum
  have hh : ((∑ i ∈ s, 2 ^ gapBits (x i) : ℕ) : ℝ) < 6 := by linarith
  have hn : (∑ i ∈ s, 2 ^ gapBits (x i) : ℕ) < 6 := by exact_mod_cast hh
  omega

end Prize.JSP404
