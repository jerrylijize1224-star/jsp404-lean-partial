import Prize.JSP404.PentagonOrder

/-! A fan crossing order for any finite convex-independent family. -/

namespace Prize.JSP404

open EuclideanGeometry

/-- Every ordered triple of non-base vertices gives a strict diagonal crossing. -/
def ConvexFanCrossings {n : ℕ} (p : Fin (n + 1) → Plane) : Prop :=
  ∀ i j k : Fin n, i < j → j < k →
    ∃ O, Sbtw ℝ (p 0) O (p j.succ) ∧ Sbtw ℝ (p i.succ) O (p k.succ)

theorem exists_convexFanCrossings_reindex {n : ℕ}
    (p : Fin (n + 2) → Plane) (hp : ConvexIndependent ℝ p) :
    ∃ e : Equiv.Perm (Fin (n + 2)), ConvexFanCrossings (p ∘ e) := by
  classical
  obtain ⟨f, hf⟩ := exists_positive_support p hp 0
  have hfne : f ≠ 0 := by
    intro he
    have hh := hf (Fin.succ 0) (Fin.succ_ne_zero _)
    simpa [he] using hh
  obtain ⟨g, hfg⟩ := exists_complementary_coordinate f hfne
  let u : Fin (n + 1) → Plane := fun i => p i.succ - p 0
  have hu (i : Fin (n + 1)) : 0 < f (u i) := hf i.succ (Fin.succ_ne_zero i)
  have hang (i j : Fin (n + 1)) (hij : i ≠ j) : InnerProductGeometry.angle (u i) (u j) ≠ 0 := by
    change angle (p i.succ) (p 0) (p j.succ) ≠ 0
    exact angle_ne_zero_of_not_collinear (convexIndependent_not_collinear hp
      (Fin.succ_ne_zero i) (fun h => hij (Fin.succ_inj.mp h)) (Fin.succ_ne_zero j).symm)
  have hinj := slope_injective_of_positive_support u f g hfg hu hang
  obtain ⟨e, he⟩ := exists_strictMono_reindex (fun i => g (u i) / f (u i)) hinj
  let E : Equiv.Perm (Fin (n + 2)) :=
    (finSuccEquiv (n + 1)).trans ((Equiv.optionCongr e).trans (finSuccEquiv (n + 1)).symm)
  let q : Fin (n + 2) → Plane := p ∘ E
  have hq0 : q 0 = p 0 := by simp [q, E]
  have hqs (i : Fin (n + 1)) : q i.succ = p (e i).succ := by simp [q, E]
  have hq : ConvexIndependent ℝ q := hp.comp_embedding E.toEmbedding
  have hpos (i : Fin (n + 1)) : 0 < f (q i.succ - q 0) := by
    rw [hqs, hq0]
    exact hu (e i)
  have hsort : StrictMono (fun i : Fin (n + 1) => g (q i.succ - q 0) / f (q i.succ - q 0)) := by
    intro i j hij
    change g (q i.succ - q 0) / f (q i.succ - q 0) < g (q j.succ - q 0) / f (q j.succ - q 0)
    rw [hqs, hqs, hq0]
    exact he hij
  have hcross (i j k : Fin (n + 1)) (hij : i < j) (hjk : j < k) :
      ∃ O, Sbtw ℝ (q 0) O (q j.succ) ∧ Sbtw ℝ (q i.succ) O (q k.succ) := by
    let r : Fin 4 → Fin (n + 2) := ![0, i.succ, j.succ, k.succ]
    have hr : Function.Injective r := by
      intro a b hab
      apply Fin.ext
      have hv := congrArg Fin.val hab
      fin_cases a <;> fin_cases b <;> norm_num [r] at hv <;> omega
    have hh := ordered_rays_crossing (q ∘ r) (hq.comp_embedding ⟨r, hr⟩) f g
      (by simpa [r, Function.comp_def] using hpos i)
      (by simpa [r, Function.comp_def] using hpos j)
      (by simpa [r, Function.comp_def] using hpos k)
      (by simpa [r, Function.comp_def] using hsort hij)
      (by simpa [r, Function.comp_def] using hsort hjk)
    simpa [r, Function.comp_def] using hh
  exact ⟨E, hcross⟩

end Prize.JSP404
