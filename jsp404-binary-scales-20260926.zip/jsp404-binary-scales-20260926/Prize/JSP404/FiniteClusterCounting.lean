import Prize.JSP404.FiniteDirectionChart

/-! Arbitrary finite one-level cluster models. Local capacities bound the total
cardinality, but their sharp total upper bound is not proved here. -/

namespace Prize.JSP404

structure FiniteClusterModel (V : Type*) (n : ℕ) where
  directions : GeneralizedDirections V
  cluster : V → Fin (n + 2)
  occupied : Function.Surjective cluster
  centre : Fin (n + 2) → Plane
  distinct : Function.Injective centre
  cross : ∀ u v, cluster u ≠ cluster v →
    directions.direction u v = centre (cluster v) - centre (cluster u)

namespace FiniteClusterModel

variable {V : Type*} {n : ℕ} (M : FiniteClusterModel V n)

noncomputable def centres : Finset Plane := Finset.univ.image M.centre

theorem centre_mem (i : Fin (n + 2)) : M.centre i ∈ M.centres := by
  classical
  exact Finset.mem_image.mpr ⟨i, Finset.mem_univ i, rfl⟩

theorem centres_card : M.centres.card = n + 2 := by
  classical
  simp [centres, Finset.card_image_of_injective _ M.distinct]

theorem centres_angle_bound {a : ℝ} (hbound : M.directions.AngleBound a) :
    ∀ A ∈ M.centres, ∀ B ∈ M.centres, ∀ C ∈ M.centres,
      A ≠ B → A ≠ C → B ≠ C → EuclideanGeometry.angle A B C ≤ a := by
  classical
  intro A hA B hB C hC hAB hAC hBC
  obtain ⟨i, _, rfl⟩ := Finset.mem_image.mp hA
  obtain ⟨j, _, rfl⟩ := Finset.mem_image.mp hB
  obtain ⟨k, _, rfl⟩ := Finset.mem_image.mp hC
  have hij : i ≠ j := fun h => hAB (congrArg M.centre h)
  have hik : i ≠ k := fun h => hAC (congrArg M.centre h)
  have hjk : j ≠ k := fun h => hBC (congrArg M.centre h)
  obtain ⟨u, hu⟩ := M.occupied i
  obtain ⟨v, hv⟩ := M.occupied j
  obtain ⟨w, hw⟩ := M.occupied k
  have huv : M.cluster u ≠ M.cluster v := by rwa [hu, hv]
  have huw : M.cluster u ≠ M.cluster w := by rwa [hu, hw]
  have hvw : M.cluster v ≠ M.cluster w := by rwa [hv, hw]
  have h := hbound u v w (fun h => huv (congrArg M.cluster h))
    (fun h => huw (congrArg M.cluster h)) (fun h => hvw (congrArg M.cluster h))
  change InnerProductGeometry.angle (M.directions.direction v u)
    (M.directions.direction v w) ≤ a at h
  rw [M.cross v u huv.symm, M.cross v w hvw, hu, hv, hw] at h
  exact h

theorem centres_generalPosition {t : ℝ} (ht : 0 < t)
    (hbound : M.directions.AngleBound ((1 - 1 / t) * Real.pi)) :
    GeneralPosition M.centres := by
  apply generalPosition_of_angle_bound ?_ (M.centres_angle_bound hbound)
  have h : 0 < Real.pi / t := div_pos Real.pi_pos ht
  have he : (1 - 1 / t) * Real.pi = Real.pi - Real.pi / t := by ring
  rw [he]
  linarith

def outgoing (i : Fin (n + 2)) : Fin (n + 1) → Plane :=
  fun j => M.centre (i.succAbove j) - M.centre i

theorem exists_direction_chart {t : ℝ} (ht : 0 < t)
    (hbound : M.directions.AngleBound ((1 - 1 / t) * Real.pi)) (i : Fin (n + 2)) :
    Nonempty (SortedDirectionChart (M.outgoing i)) := by
  have hg := M.centres_generalPosition ht hbound
  apply exists_sortedDirectionChart
  · intro j
    exact sub_ne_zero.mpr (M.distinct.ne (Fin.succAbove_ne i j))
  · intro j k hjk
    change EuclideanGeometry.angle (M.centre (i.succAbove j)) (M.centre i)
      (M.centre (i.succAbove k)) ≠ 0 ∧
      EuclideanGeometry.angle (M.centre (i.succAbove j)) (M.centre i)
        (M.centre (i.succAbove k)) ≠ Real.pi
    have hc := hg _ (M.centre_mem _) _ (M.centre_mem _) _ (M.centre_mem _)
      (M.distinct.ne (Fin.succAbove_ne i j))
      (M.distinct.ne (Fin.succAbove_right_injective.ne hjk))
      (M.distinct.ne (Fin.ne_succAbove i k))
    exact ⟨EuclideanGeometry.angle_ne_zero_of_not_collinear hc,
      EuclideanGeometry.angle_ne_pi_of_not_collinear hc⟩

theorem cluster_card_le_gapIndex [Fintype V] {t : ℝ} (ht : 1 ≤ t)
    (hbound : M.directions.AngleBound ((1 - 1 / t) * Real.pi))
    (i : Fin (n + 2)) (v : SortedDirectionChart (M.outgoing i)) :
    Fintype.card {u : V // M.cluster u = i} ≤ 2 ^ v.gapIndex t := by
  classical
  have htpos : 0 < t := by linarith
  have hw : 0 < Real.pi / t := div_pos Real.pi_pos htpos
  have hwπ : Real.pi / t ≤ Real.pi := (div_le_iff₀ htpos).mpr (by nlinarith [Real.pi_pos])
  have he : (1 - 1 / t) * Real.pi = Real.pi - Real.pi / t := by ring
  have hcount := M.directions.cluster_card_le_finite_gap_capacity M.cluster M.centre
    M.occupied M.cross i i.succAbove (Fin.succAbove_ne i) v hw hwπ (he ▸ hbound)
  have hgap (j : Fin (n + 1)) : v.gap j / (Real.pi / t) = t * (v.gap j / Real.pi) := by
    field_simp
  have hexp : (∑ j, sectorCapacity 1 (v.gap j / (Real.pi / t))) = v.gapIndex t := by
    simp only [SortedDirectionChart.gapIndex, sectorCapacity, one_mul, hgap]
  change Fintype.card {u : V // M.cluster u = i} ≤
    2 ^ (∑ j, sectorCapacity 1 (v.gap j / (Real.pi / t))) at hcount
  rwa [hexp] at hcount

/-- This theorem is about actual cardinalities for any occupied-centre count.
The right-hand side is still a sum of local capacities, not a sharp global bound. -/
theorem card_le_sum_gap_capacity [Fintype V] {t : ℝ} (ht : 1 ≤ t)
    (hbound : M.directions.AngleBound ((1 - 1 / t) * Real.pi))
    (v : ∀ i, SortedDirectionChart (M.outgoing i)) :
    Fintype.card V ≤ ∑ i, 2 ^ (v i).gapIndex t := by
  classical
  have hcard : Fintype.card V = ∑ i, Fintype.card {u : V // M.cluster u = i} := by
    have h := Finset.card_eq_sum_card_fiberwise
      (s := (Finset.univ : Finset V)) (t := (Finset.univ : Finset (Fin (n + 2))))
      (f := M.cluster) (by intro u hu; exact Finset.mem_univ _)
    simpa only [Fintype.card_subtype, Finset.card_univ] using h
  rw [hcard]
  exact Finset.sum_le_sum (fun i _ => M.cluster_card_le_gapIndex ht hbound i (v i))

/-- The charts in the capacity bound exist for the actual centres; their
existence is not an additional unproved hypothesis. -/
theorem exists_capacity_bound [Fintype V] {t : ℝ} (ht : 1 ≤ t)
    (hbound : M.directions.AngleBound ((1 - 1 / t) * Real.pi)) :
    ∃ v : ∀ i, SortedDirectionChart (M.outgoing i),
      Fintype.card V ≤ ∑ i, 2 ^ (v i).gapIndex t := by
  classical
  let v := fun i => Classical.choice (M.exists_direction_chart (by linarith) hbound i)
  exact ⟨v, M.card_le_sum_gap_capacity ht hbound v⟩

end FiniteClusterModel
end Prize.JSP404
