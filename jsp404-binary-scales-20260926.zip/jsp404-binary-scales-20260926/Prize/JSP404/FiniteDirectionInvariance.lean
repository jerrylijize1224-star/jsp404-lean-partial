import Prize.JSP404.FiniteDirectionChart
import Mathlib.Order.Preorder.Finite

/-! The finite projective-gap capacity is independent of the chosen chart. -/

namespace Prize.JSP404

open InnerProductGeometry

theorem projective_coordinate_unique {U : Plane} (hU : U ≠ 0)
    {θ φ r s : ℝ} (hθ : 0 ≤ θ) (hθπ : θ < Real.pi)
    (hφ : 0 ≤ φ) (hφπ : φ < Real.pi) (hr : 0 < r) (hs : 0 < s)
    (b c : Bool) (hu : U = r • signedDirection θ b)
    (hv : U = s • signedDirection φ c) : θ = φ := by
  have hd : |θ - φ| < Real.pi := abs_lt.mpr ⟨by linarith, by linarith⟩
  have hangle : angle (r • signedDirection θ b) (s • signedDirection φ c) = 0 := by
    rw [← hu, ← hv]
    exact angle_self hU
  rw [angle_smul_left_of_pos _ _ hr, angle_smul_right_of_pos _ _ hs] at hangle
  cases b <;> cases c <;>
    simp [signedDirection, angle_neg_left, angle_neg_right, unitDirection_angle_abs hd.le] at hangle
  all_goals
    first
    | exact sub_eq_zero.mp hangle
    | exfalso; linarith

namespace SortedDirectionChart

variable {n : ℕ} {p : Fin (n + 1) → Plane}

theorem direction_ne_zero (v : SortedDirectionChart p) (i : Fin (n + 1)) :
    p (v.reindex i) ≠ 0 := by
  rw [v.represents i]
  apply smul_ne_zero (ne_of_gt (v.length_pos i))
  have hunit : unitDirection (v.theta i) ≠ 0 := by
    intro h
    have hn := unitDirection_norm (v.theta i)
    rw [h, norm_zero] at hn
    norm_num at hn
  cases v.ray i <;> simp [signedDirection, hunit]

theorem theta_unique (v w : SortedDirectionChart p) : v.theta = w.theta := by
  let e : Equiv.Perm (Fin (n + 1)) := v.reindex.trans w.reindex.symm
  have he (i : Fin (n + 1)) : v.theta i = w.theta (e i) := by
    have hwrep : p (v.reindex i) =
        w.length (e i) • signedDirection (w.theta (e i)) (w.ray (e i)) := by
      simpa [e] using w.represents (e i)
    exact projective_coordinate_unique (v.direction_ne_zero i)
      (v.nonneg i) (v.lt_pi i) (w.nonneg (e i)) (w.lt_pi (e i))
      (v.length_pos i) (w.length_pos (e i)) (v.ray i) (w.ray (e i))
      (v.represents i) hwrep
  have hmono : StrictMono e := by
    intro i j hij
    apply w.sorted.lt_iff_lt.mp
    rw [← he i, ← he j]
    exact v.sorted hij
  have hid : (e : Fin (n + 1) → Fin (n + 1)) = id := hmono.eq_id
  funext i
  simpa only [hid, id_eq] using he i

theorem gap_unique (v w : SortedDirectionChart p) : v.gap = w.gap := by
  funext i
  simp only [gap, v.theta_unique w]

theorem gapIndex_unique (v w : SortedDirectionChart p) (t : ℝ) :
    v.gapIndex t = w.gapIndex t := by
  simp only [gapIndex, v.gap_unique w]

end SortedDirectionChart
end Prize.JSP404
