import Prize.JSP404.FiniteGapRestriction
import Prize.JSP404.FiniteClusterCounting

/-!
# Maximal local exponents for actual finite centre models

The triangle-restriction inequality is proved from actual gap merging. The
result still does not control the sum of all smaller local weights.
-/

namespace Prize.JSP404
namespace FiniteClusterModel

open EuclideanGeometry

variable {V : Type*} {m : ℕ} (M : FiniteClusterModel V m)

theorem gapIndex_le_triangle {t : ℝ} (ht : 0 ≤ t)
    (v : ∀ i, SortedDirectionChart (M.outgoing i))
    {a b c : Fin (m + 2)} (hab : a ≠ b) (hcb : c ≠ b) :
    (v b).gapIndex t ≤ triangleVertexCapacity t (angle (M.centre a) (M.centre b) (M.centre c) / Real.pi) := by
  obtain ⟨j, hj⟩ := Fin.exists_succAbove_eq hab
  obtain ⟨k, hk⟩ := Fin.exists_succAbove_eq hcb
  have h := (v b).gapIndex_le_anchor_angle ht j k
  change (v b).gapIndex t ≤ triangleVertexCapacity t
    (angle (M.centre (b.succAbove j)) (M.centre b) (M.centre (b.succAbove k)) / Real.pi) at h
  rwa [hj, hk] at h

theorem triple_capacity_le_triangle {t : ℝ} (ht : 0 ≤ t)
    (v : ∀ i, SortedDirectionChart (M.outgoing i))
    {a b c : Fin (m + 2)} (hab : a ≠ b) (hac : a ≠ c) (hbc : b ≠ c) :
    2 ^ (v a).gapIndex t + 2 ^ (v b).gapIndex t + 2 ^ (v c).gapIndex t ≤
      2 ^ triangleVertexCapacity t (angle (M.centre c) (M.centre a) (M.centre b) / Real.pi) +
      2 ^ triangleVertexCapacity t (angle (M.centre a) (M.centre b) (M.centre c) / Real.pi) +
      2 ^ triangleVertexCapacity t (angle (M.centre b) (M.centre c) (M.centre a) / Real.pi) := by
  have hA := M.gapIndex_le_triangle ht v hac.symm hab.symm
  have hB := M.gapIndex_le_triangle ht v hab hbc.symm
  have hC := M.gapIndex_le_triangle ht v hbc hac
  gcongr

/-- For at least three occupied centres, no local exponent exceeds n-1
throughout n <= t < n+1. The centre angle bound supplies the floor premise. -/
theorem gapIndex_le_pred (hm : 1 ≤ m) {n : ℕ} (hn : 2 ≤ n)
    {t : ℝ} (ht : (n : ℝ) ≤ t) (ht' : t < n + 1)
    (hbound : M.directions.AngleBound ((1 - 1 / t) * Real.pi))
    (v : ∀ i, SortedDirectionChart (M.outgoing i)) (b : Fin (m + 2)) :
    (v b).gapIndex t ≤ n - 1 := by
  classical
  have hcard : 1 < (Finset.univ.erase b).card := by simp; omega
  obtain ⟨a, ha, c, hc, hac⟩ := Finset.one_lt_card.mp hcard
  have hab : a ≠ b := (Finset.mem_erase.mp ha).1
  have hcb : c ≠ b := (Finset.mem_erase.mp hc).1
  have htpos : 0 < t := by
    have : (2 : ℝ) ≤ n := by exact_mod_cast hn
    linarith
  have hangle := M.centres_angle_bound hbound _ (M.centre_mem a) _ (M.centre_mem b)
    _ (M.centre_mem c) (M.distinct.ne hab) (M.distinct.ne hac) (M.distinct.ne hcb.symm)
  have hnorm : angle (M.centre a) (M.centre b) (M.centre c) / Real.pi ≤ 1 - 1 / t :=
    (div_le_iff₀ Real.pi_pos).mpr hangle
  have hmul := mul_le_mul_of_nonneg_left hnorm htpos.le
  have hinv : t * (1 / t) = 1 := by field_simp
  have hcomp : 1 ≤ t * (1 - angle (M.centre a) (M.centre b) (M.centre c) / Real.pi) := by
    nlinarith
  have htri := triangleVertexCapacity_control hn ht ht'
    (div_nonneg (angle_nonneg _ _ _) Real.pi_pos.le) hcomp
  exact (M.gapIndex_le_triangle htpos.le v hab hcb).trans htri.1

theorem triple_capacity_low {n : ℕ} (hn : 2 ≤ n) {t : ℝ} (ht : (n : ℝ) ≤ t)
    (ht' : t < n + 1 / 2)
    (hbound : M.directions.AngleBound ((1 - 1 / t) * Real.pi))
    (v : ∀ i, SortedDirectionChart (M.outgoing i))
    {a b c : Fin (m + 2)} (hab : a ≠ b) (hac : a ≠ c) (hbc : b ≠ c) :
    2 ^ (v a).gapIndex t + 2 ^ (v b).gapIndex t + 2 ^ (v c).gapIndex t ≤ 2 ^ n := by
  have ht0 : 0 ≤ t := (Nat.cast_nonneg n).trans ht
  have htri := M.triple_capacity_le_triangle ht0 v hab hac hbc
  have ha := M.centres_angle_bound hbound
  have h := threeCentre_capacity_low_of_angles hn ht ht' (M.distinct.ne hab)
    (ha _ (M.centre_mem a) _ (M.centre_mem b) _ (M.centre_mem c)
      (M.distinct.ne hab) (M.distinct.ne hac) (M.distinct.ne hbc))
    (ha _ (M.centre_mem b) _ (M.centre_mem c) _ (M.centre_mem a)
      (M.distinct.ne hbc) (M.distinct.ne hab.symm) (M.distinct.ne hac.symm))
    (ha _ (M.centre_mem c) _ (M.centre_mem a) _ (M.centre_mem b)
      (M.distinct.ne hac.symm) (M.distinct.ne hbc.symm) (M.distinct.ne hab))
  omega

theorem triple_capacity_high {n : ℕ} (hn : 2 ≤ n) {t : ℝ} (ht : (n : ℝ) ≤ t)
    (ht' : t < n + 1)
    (hbound : M.directions.AngleBound ((1 - 1 / t) * Real.pi))
    (v : ∀ i, SortedDirectionChart (M.outgoing i))
    {a b c : Fin (m + 2)} (hab : a ≠ b) (hac : a ≠ c) (hbc : b ≠ c) :
    2 ^ (v a).gapIndex t + 2 ^ (v b).gapIndex t + 2 ^ (v c).gapIndex t ≤
      2 ^ n + 2 ^ (n - 2) := by
  have ht0 : 0 ≤ t := (Nat.cast_nonneg n).trans ht
  have htri := M.triple_capacity_le_triangle ht0 v hab hac hbc
  have ha := M.centres_angle_bound hbound
  have h := threeCentre_capacity_high_of_angles hn ht ht' (M.distinct.ne hab)
    (ha _ (M.centre_mem a) _ (M.centre_mem b) _ (M.centre_mem c)
      (M.distinct.ne hab) (M.distinct.ne hac) (M.distinct.ne hbc))
    (ha _ (M.centre_mem b) _ (M.centre_mem c) _ (M.centre_mem a)
      (M.distinct.ne hbc) (M.distinct.ne hab.symm) (M.distinct.ne hac.symm))
    (ha _ (M.centre_mem c) _ (M.centre_mem a) _ (M.centre_mem b)
      (M.distinct.ne hac.symm) (M.distinct.ne hbc.symm) (M.distinct.ne hab))
  omega

theorem maximal_exponents_low (hm : 1 ≤ m) {n : ℕ} (hn : 2 ≤ n)
    {t : ℝ} (ht : (n : ℝ) ≤ t) (ht' : t < n + 1 / 2)
    (hbound : M.directions.AngleBound ((1 - 1 / t) * Real.pi))
    (v : ∀ i, SortedDirectionChart (M.outgoing i)) :
    (Finset.univ.filter fun i => n - 1 ≤ (v i).gapIndex t).card ≤ 1 := by
  classical
  apply maximal_exponents_card_low Finset.univ (fun i => (v i).gapIndex t) (by omega)
    (by simp; omega)
  intro a _ b _ c _ hab hac hbc
  exact M.triple_capacity_low hn ht ht' hbound v hab hac hbc

theorem maximal_exponents_high {n : ℕ} (hn : 2 ≤ n)
    {t : ℝ} (ht : (n : ℝ) ≤ t) (ht' : t < n + 1)
    (hbound : M.directions.AngleBound ((1 - 1 / t) * Real.pi))
    (v : ∀ i, SortedDirectionChart (M.outgoing i)) :
    (Finset.univ.filter fun i => n - 1 ≤ (v i).gapIndex t).card ≤ 2 := by
  classical
  apply maximal_exponents_card_high Finset.univ (fun i => (v i).gapIndex t) hn
  intro a _ b _ c _ hab hac hbc
  exact M.triple_capacity_high hn ht ht' hbound v hab hac hbc

end FiniteClusterModel
end Prize.JSP404
