import Prize.JSP404.ThreeGapAllowed
import Mathlib.Logic.Equiv.Fin.Rotate

/-!
# An arbitrary nonempty finite family of projective directions

The sorted coordinates, positive cyclic gaps, and allowed-coordinate theorem
are independent of the number of anchors. No sharp total-capacity inequality
for an arbitrary number of centres is asserted.
-/

namespace Prize.JSP404

open InnerProductGeometry

structure SortedDirectionChart {n : ℕ} (p : Fin (n + 1) → Plane) where
  reindex : Equiv.Perm (Fin (n + 1))
  theta : Fin (n + 1) → ℝ
  length : Fin (n + 1) → ℝ
  ray : Fin (n + 1) → Bool
  sorted : StrictMono theta
  nonneg : ∀ i, 0 ≤ theta i
  lt_pi : ∀ i, theta i < Real.pi
  length_pos : ∀ i, 0 < length i
  represents : ∀ i, p (reindex i) = length i • signedDirection (theta i) (ray i)

theorem exists_sortedDirectionChart {n : ℕ} (p : Fin (n + 1) → Plane)
    (hne : ∀ i, p i ≠ 0)
    (hparallel : ∀ i j, i ≠ j → angle (p i) (p j) ≠ 0 ∧ angle (p i) (p j) ≠ Real.pi) :
    Nonempty (SortedDirectionChart p) := by
  classical
  choose θ r b hθ hπ hr hp using fun i => exists_projective_coordinates (hne i)
  have hθinj : Function.Injective θ := by
    intro i j hij
    by_contra hneij
    obtain ⟨hzero, hpi⟩ := hparallel i j hneij
    have he : angle (p i) (p j) = signedPairAngle Real.pi 0 (b i) (b j) := by
      rw [hp i, hp j, angle_smul_left_of_pos _ _ (hr i),
        angle_smul_right_of_pos _ _ (hr j), hij]
      simpa using signedDirection_angle (θ := θ j) (φ := θ j) le_rfl
        (by simpa using Real.pi_pos.le) (b i) (b j)
    by_cases hb : b i = b j
    · exact hzero (by simpa [signedPairAngle, hb] using he)
    · exact hpi (by simpa [signedPairAngle, hb] using he)
  obtain ⟨e, he⟩ := exists_strictMono_reindex θ hθinj
  exact ⟨{
    reindex := e
    theta := θ ∘ e
    length := r ∘ e
    ray := b ∘ e
    sorted := he
    nonneg := fun i => hθ (e i)
    lt_pi := fun i => hπ (e i)
    length_pos := fun i => hr (e i)
    represents := fun i => hp (e i) }⟩

namespace SortedDirectionChart

variable {n : ℕ} {p : Fin (n + 1) → Plane} (v : SortedDirectionChart p)

noncomputable def gap (i : Fin (n + 1)) : ℝ :=
  v.theta (finRotate (n + 1) i) - v.theta i + if i = Fin.last n then Real.pi else 0

theorem gap_last : v.gap (Fin.last n) = Real.pi - (v.theta (Fin.last n) - v.theta 0) := by
  simp [gap]
  ring

theorem gap_of_ne_last {i : Fin (n + 1)} (hi : i ≠ Fin.last n) :
    v.gap i = v.theta (finRotate (n + 1) i) - v.theta i := by simp [gap, hi]

theorem gap_pos (i : Fin (n + 1)) : 0 < v.gap i := by
  by_cases hi : i = Fin.last n
  · subst i
    rw [v.gap_last]
    linarith [v.nonneg 0, v.lt_pi (Fin.last n)]
  · rw [v.gap_of_ne_last hi]
    exact sub_pos.mpr (v.sorted ((lt_finRotate_iff_ne_last i).mpr hi))

theorem gap_sum : ∑ i, v.gap i = Real.pi := by
  classical
  have he : (∑ i, v.theta (finRotate (n + 1) i)) = ∑ i, v.theta i :=
    Equiv.sum_comp (finRotate (n + 1)) v.theta
  simp only [gap, Finset.sum_add_distrib, Finset.sum_sub_distrib, he, sub_self, zero_add]
  simp

noncomputable def gapIndex (t : ℝ) : ℕ :=
  ∑ i, sectorCapacity t (v.gap i / Real.pi)

/-- Use the last anchor at or before the direction. Its cyclic successor
handles the end of the ordered list without any fixed-size case enumeration. -/
theorem exists_allowed_gap {θ w : ℝ} (hθ : v.theta 0 ≤ θ)
    (hsep : ∀ i, w ≤ |θ - v.theta i| ∧ |θ - v.theta i| ≤ Real.pi - w) :
    ∃ i, v.theta i + w ≤ θ ∧ θ ≤ v.theta i + v.gap i - w := by
  classical
  let s : Finset (Fin (n + 1)) := Finset.univ.filter (fun i => v.theta i ≤ θ)
  have hs : s.Nonempty := ⟨0, Finset.mem_filter.mpr ⟨Finset.mem_univ 0, hθ⟩⟩
  let i := s.max' hs
  have hi : v.theta i ≤ θ := (Finset.mem_filter.mp (s.max'_mem hs)).2
  have hsi := hsep i
  rw [abs_of_nonneg (sub_nonneg.mpr hi)] at hsi
  refine ⟨i, by linarith [hsi.1], ?_⟩
  by_cases hilast : i = Fin.last n
  · have hs0 := hsep 0
    rw [abs_of_nonneg (sub_nonneg.mpr hθ)] at hs0
    rw [hilast, v.gap_last]
    linarith [hs0.2]
  · have hnext : θ < v.theta (finRotate (n + 1) i) := by
      by_contra h
      have hmem : finRotate (n + 1) i ∈ s :=
        Finset.mem_filter.mpr ⟨Finset.mem_univ _, le_of_not_gt h⟩
      have hle : finRotate (n + 1) i ≤ i := s.le_max' _ hmem
      exact (not_lt_of_ge hle) ((lt_finRotate_iff_ne_last i).mpr hilast)
    have hsnext := hsep (finRotate (n + 1) i)
    rw [abs_of_nonpos (sub_nonpos.mpr hnext.le)] at hsnext
    rw [v.gap_of_ne_last hilast]
    linarith [hsnext.1]

theorem exists_allowed_coordinates {U : Plane} (hU : U ≠ 0) {w : ℝ} (hw : 0 < w)
    (hsep : ∀ i, w ≤ angle U (p i) ∧ angle U (p i) ≤ Real.pi - w) :
    ∃ i, ∃ x r : ℝ, ∃ b : Bool, x ∈ Set.Icc 1 (v.gap i / w - 1) ∧ 0 < r ∧
      U = r • signedDirection (v.theta i + w * x) b := by
  obtain ⟨θ, r, b, hθ, hθπ, hr, hrep⟩ :=
    exists_projective_coordinates_from hU (v.nonneg 0) (v.lt_pi 0)
  have hs : ∀ i, w ≤ |θ - v.theta i| ∧ |θ - v.theta i| ≤ Real.pi - w := by
    intro i
    have hi : v.theta 0 ≤ v.theta i := v.sorted.monotone (Fin.zero_le i)
    have hwidth : |θ - v.theta i| ≤ Real.pi := by
      apply abs_le.mpr
      constructor <;> linarith [v.lt_pi i, v.nonneg 0]
    have h := hsep (v.reindex i)
    rw [hrep, v.represents i] at h
    exact abs_separation_of_signed_angle_bounds hwidth hr (v.length_pos i) b (v.ray i) h
  obtain ⟨i, hlo, hhi⟩ := v.exists_allowed_gap hθ hs
  refine ⟨i, (θ - v.theta i) / w, r, b, ⟨?_, ?_⟩, hr, ?_⟩
  · apply (le_div_iff₀ hw).mpr
    linarith
  · have he : v.gap i / w - 1 = (v.gap i - w) / w := by field_simp
    rw [he]
    apply (div_le_div_iff_of_pos_right hw).mpr
    linarith
  · have he : v.theta i + w * ((θ - v.theta i) / w) = θ := by field_simp; ring
    rwa [he]

end SortedDirectionChart
theorem GeneralizedDirections.card_le_of_finite_anchor_separation
    {V : Type*} [Fintype V] {n : ℕ} (D : GeneralizedDirections V)
    {p : Fin (n + 1) → Plane} (v : SortedDirectionChart p)
    {w : ℝ} (hw : 0 < w) (hwπ : w ≤ Real.pi)
    (hbound : D.AngleBound (Real.pi - w))
    (hsep : ∀ u q, u ≠ q → ∀ i,
      w ≤ angle (D.direction u q) (p i) ∧
      angle (D.direction u q) (p i) ≤ Real.pi - w) :
    Fintype.card V ≤ 2 ^ (∑ i, sectorCapacity 1 (v.gap i / w)) := by
  apply D.card_le_of_allowed_gap_coordinates v.theta (fun i => v.gap i / w) hw hwπ hbound
  intro u q huq
  obtain ⟨i, x, r, b, hx, hr, hrep⟩ :=
    v.exists_allowed_coordinates (D.nonzero u q huq) hw (hsep u q huq)
  refine ⟨i, x, hx, r, hr, ?_⟩
  cases b
  · exact Or.inl (by simpa [signedDirection] using hrep)
  · right
    rw [D.reverse u q, hrep]
    simp [signedDirection]

/-- For a cluster with finitely many occupied external centres, the angular exclusion
needed above follows from mixed triples of leaves. -/
theorem GeneralizedDirections.cluster_card_le_finite_gap_capacity
    {V I : Type*} [Fintype V] {n : ℕ} [DecidableEq I] (D : GeneralizedDirections V)
    (cluster : V → I) (centre : I → Plane) (hsurj : Function.Surjective cluster)
    (hcross : ∀ u q, cluster u ≠ cluster q →
      D.direction u q = centre (cluster q) - centre (cluster u))
    (a : I) (j : Fin (n + 1) → I) (hj : ∀ i, j i ≠ a)
    (v : SortedDirectionChart (fun i => centre (j i) - centre a))
    {w : ℝ} (hw : 0 < w) (hwπ : w ≤ Real.pi)
    (hbound : D.AngleBound (Real.pi - w)) :
    Fintype.card {u : V // cluster u = a} ≤
      2 ^ (∑ i, sectorCapacity 1 (v.gap i / w)) := by
  classical
  apply (D.restrict {u | cluster u = a}).card_le_of_finite_anchor_separation
    v hw hwπ (D.angleBound_restrict hbound _) ?_
  intro u q huq i
  obtain ⟨e, he⟩ := hsurj (j i)
  have hout : cluster (u : V) ≠ cluster e := by
    rw [u.property, he]
    exact (hj i).symm
  have h := D.internal_angle_bounds_of_centres cluster centre hcross hbound
    (fun h => huq (Subtype.ext h)) (u.property.trans q.property.symm) hout
  change w ≤ angle (D.direction u q) (centre (j i) - centre a) ∧
    angle (D.direction u q) (centre (j i) - centre a) ≤ Real.pi - w
  have hua : cluster (u : V) = a := u.property
  simpa only [he, hua, sub_sub_cancel] using h


end Prize.JSP404
