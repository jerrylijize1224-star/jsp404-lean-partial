import Prize.JSP404.FiniteAngleApproximation

/-! Finite binary configurations with arbitrarily many separated scales.
The angle bound between distinct signed axes is an explicit hypothesis here;
this module does not assert existence of a sharp axis family for every size. -/

namespace Prize.JSP404

open EuclideanGeometry

abbrev BinaryLabel (n : ℕ) := Fin n → Bool

def binaryDigit (b : Bool) : ℝ := if b then 1 else 0

theorem exists_first_binary_difference {n : ℕ} {b c : BinaryLabel n} (h : b ≠ c) :
    ∃ r : Fin n, b r ≠ c r ∧ ∀ s : Fin n, s < r → b s = c s := by
  classical
  let d := Finset.univ.filter (fun r => b r ≠ c r)
  have hd : d.Nonempty := by
    obtain ⟨r, hr⟩ := Function.ne_iff.mp h
    exact ⟨r, Finset.mem_filter.mpr ⟨Finset.mem_univ _, hr⟩⟩
  refine ⟨d.min' hd, (Finset.mem_filter.mp (d.min'_mem hd)).2, ?_⟩
  intro s hs
  by_contra hne
  have hm := d.min'_le s (Finset.mem_filter.mpr ⟨Finset.mem_univ _, hne⟩)
  exact (not_lt_of_ge hm) hs

noncomputable def binaryScaleRank {n : ℕ} (b c : BinaryLabel n) : ℕ :=
  if h : b ≠ c then (Classical.choose (exists_first_binary_difference h)).val else 0

theorem binaryScaleRank_spec {n : ℕ} {b c : BinaryLabel n} (h : b ≠ c) :
    ∃ r : Fin n, binaryScaleRank b c = r.val ∧ b r ≠ c r ∧
      ∀ s : Fin n, s < r → b s = c s := by
  classical
  exact ⟨_, by simp [binaryScaleRank, h], Classical.choose_spec
    (exists_first_binary_difference h)⟩

theorem binaryScaleRank_before {n : ℕ} (b c : BinaryLabel n) (s : Fin n)
    (hs : s.val < binaryScaleRank b c) : b s = c s := by
  by_cases h : b = c
  · rw [h]
  obtain ⟨r, hr, _, hbefore⟩ := binaryScaleRank_spec h
  exact hbefore s (by simpa [hr] using hs)

noncomputable def binaryScalePoint {n : ℕ} (v : Fin n → Plane)
    (t : ℝ) (b : BinaryLabel n) : Plane :=
  ∑ r : Fin n, (t ^ r.val * binaryDigit (b r)) • v r

noncomputable def binaryScaleNormal {n : ℕ} (v : Fin n → Plane)
    (t : ℝ) (b c : BinaryLabel n) : Plane :=
  ∑ r : Fin n, if binaryScaleRank b c ≤ r.val then
    (t ^ (r.val - binaryScaleRank b c) * (binaryDigit (c r) - binaryDigit (b r))) • v r
    else 0

theorem binaryScaleNormal_continuous {n : ℕ} (v : Fin n → Plane)
    (b c : BinaryLabel n) : ContinuousAt (fun t => binaryScaleNormal v t b c) 0 := by
  unfold binaryScaleNormal
  apply Continuous.continuousAt
  apply continuous_finsetSum
  intro r _
  split_ifs <;> fun_prop

theorem binaryScale_difference {n : ℕ} (v : Fin n → Plane)
    (t : ℝ) (b c : BinaryLabel n) :
    binaryScalePoint v t c - binaryScalePoint v t b =
      t ^ binaryScaleRank b c • binaryScaleNormal v t b c := by
  classical
  unfold binaryScalePoint binaryScaleNormal
  rw [← Finset.sum_sub_distrib, Finset.smul_sum]
  apply Finset.sum_congr rfl
  intro r _
  by_cases h : binaryScaleRank b c ≤ r.val
  · rw [ite_eq_left h, smul_smul, ← sub_smul]
    congr 1
    rw [← mul_assoc, ← pow_add, Nat.add_sub_of_le h]
    ring
  · have he := binaryScaleRank_before b c r (Nat.lt_of_not_ge h)
    simp [he]

theorem binaryScaleNormal_zero {n : ℕ} (v : Fin n → Plane)
    {b c : BinaryLabel n} (h : b ≠ c) :
    ∃ r : Fin n, binaryScaleRank b c = r.val ∧ b r ≠ c r ∧
      binaryScaleNormal v 0 b c = (binaryDigit (c r) - binaryDigit (b r)) • v r := by
  classical
  obtain ⟨r, hr, hdiff, _⟩ := binaryScaleRank_spec h
  refine ⟨r, hr, hdiff, ?_⟩
  unfold binaryScaleNormal
  rw [Finset.sum_eq_single r]
  · simp [hr]
  · intro s _ hsr
    by_cases hs : binaryScaleRank b c ≤ s.val
    · have hexp : s.val - binaryScaleRank b c ≠ 0 := by
        have hval : s.val ≠ r.val := fun he => hsr (Fin.ext he)
        omega
      simp [hs, zero_pow hexp]
    · simp [hs]
  · simp

theorem binaryScaleNormal_nonzero {n : ℕ} {v : Fin n → Plane}
    (hv : ∀ r, v r ≠ 0) (b c : BinaryLabel n) (h : b ≠ c) :
    binaryScaleNormal v 0 b c ≠ 0 := by
  obtain ⟨r, _, hdiff, he⟩ := binaryScaleNormal_zero v h
  rw [he]
  apply smul_ne_zero _ (hv r)
  cases hb : b r <;> cases hc : c r <;> simp_all [binaryDigit]

def signedBinaryAxis (v : Plane) (b : Bool) : Plane := if b then -v else v

theorem signedBinaryAxis_ne_zero {v : Plane} (hv : v ≠ 0) (b : Bool) :
    signedBinaryAxis v b ≠ 0 := by
  cases b <;> simpa [signedBinaryAxis] using hv

theorem binaryScaleNormal_signed {n : ℕ} (v : Fin n → Plane)
    {b c : BinaryLabel n} (h : b ≠ c) :
    ∃ r : Fin n, binaryScaleRank b c = r.val ∧
      binaryScaleNormal v 0 b c = signedBinaryAxis (v r) (b r) := by
  obtain ⟨r, hr, hdiff, he⟩ := binaryScaleNormal_zero v h
  refine ⟨r, hr, ?_⟩
  rw [he]
  cases hb : b r <;> cases hc : c r <;>
    simp_all [binaryDigit, signedBinaryAxis]

/-- Distinct levels must control all sign choices. Equal levels automatically
have the same sign because the two rays share their binary source label. -/
theorem binaryScaleNormal_angle {n : ℕ} {v : Fin n → Plane} {A : ℝ}
    (hv : ∀ r, v r ≠ 0) (hA : 0 ≤ A)
    (haxes : ∀ r s, r ≠ s → ∀ b c : Bool,
      InnerProductGeometry.angle (signedBinaryAxis (v r) b) (signedBinaryAxis (v s) c) ≤ A)
    (i j k : BinaryLabel n) (hij : i ≠ j) (hjk : j ≠ k) :
    InnerProductGeometry.angle (binaryScaleNormal v 0 j i) (binaryScaleNormal v 0 j k) ≤ A := by
  obtain ⟨r, _, hr⟩ := binaryScaleNormal_signed v (fun h => hij h.symm)
  obtain ⟨s, _, hs⟩ := binaryScaleNormal_signed v hjk
  rw [hr, hs]
  by_cases hrs : r = s
  · subst s
    rw [InnerProductGeometry.angle_self (signedBinaryAxis_ne_zero (hv r) (j r))]
    exact hA
  · exact haxes r s hrs _ _

theorem exists_binaryScale_approximation {n : ℕ} {v : Fin n → Plane} {A ε : ℝ}
    (hv : ∀ r, v r ≠ 0) (hA : 0 ≤ A)
    (haxes : ∀ r s, r ≠ s → ∀ b c : Bool,
      InnerProductGeometry.angle (signedBinaryAxis (v r) b) (signedBinaryAxis (v s) c) ≤ A)
    (hε : 0 < ε) :
    ∃ t : ℝ, 0 < t ∧ Function.Injective (binaryScalePoint v t) ∧
      ∀ i j k, i ≠ j → i ≠ k → j ≠ k →
        angle (binaryScalePoint v t i) (binaryScalePoint v t j) (binaryScalePoint v t k) < A + ε := by
  apply exists_finite_angle_approximation (binaryScalePoint v) (binaryScaleNormal v)
    (fun t b c => t ^ binaryScaleRank b c)
    (binaryScaleNormal_continuous v) (binaryScaleNormal_nonzero hv)
    (by intro t ht b c; exact pow_pos ht _)
    (by intro t _ b c; exact binaryScale_difference v t b c)
    (by intro i j k hij _ hjk; exact binaryScaleNormal_angle hv hA haxes i j k hij hjk) hε

/-- An ordinary configuration of exactly 2^n distinct points. The axis
hypotheses remain explicit; no general sharp axis-existence theorem is assumed. -/
theorem exists_binaryScale_counterexample {n : ℕ} {v : Fin n → Plane} {A ε : ℝ}
    (hv : ∀ r, v r ≠ 0) (hA : 0 ≤ A)
    (haxes : ∀ r s, r ≠ s → ∀ b c : Bool,
      InnerProductGeometry.angle (signedBinaryAxis (v r) b) (signedBinaryAxis (v s) c) ≤ A)
    (hε : 0 < ε) :
    ∃ s : Finset Plane, s.card = 2 ^ n ∧ ¬ HasLargeAngle s (A + ε) := by
  classical
  obtain ⟨t, _, hinj, ha⟩ := exists_binaryScale_approximation hv hA haxes hε
  refine ⟨Finset.univ.image (binaryScalePoint v t), ?_, ?_⟩
  · rw [Finset.card_image_of_injective _ hinj]
    simp [BinaryLabel]
  · rintro ⟨x, hx, y, hy, z, hz, hxy, hxz, hyz, hlarge⟩
    obtain ⟨i, _, rfl⟩ := Finset.mem_image.mp hx
    obtain ⟨j, _, rfl⟩ := Finset.mem_image.mp hy
    obtain ⟨k, _, rfl⟩ := Finset.mem_image.mp hz
    exact (not_lt_of_ge hlarge) (ha i j k
      (fun h => hxy (congrArg (binaryScalePoint v t) h))
      (fun h => hxz (congrArg (binaryScalePoint v t) h))
      (fun h => hyz (congrArg (binaryScalePoint v t) h)))


theorem alpha_le_of_large_approximation {m : ℕ} {A : ℝ} (hm : 3 ≤ m)
    (happrox : ∀ ε : ℝ, 0 < ε →
      ∃ s : Finset Plane, m ≤ s.card ∧ ¬ HasLargeAngle s (A + ε)) : alpha m ≤ A := by
  apply csSup_le ⟨_, pi_div_three_mem_admissibleAngles hm⟩
  intro a ha
  by_contra h
  obtain ⟨s, hs, hbad⟩ := happrox (a - A) (sub_pos.mpr (lt_of_not_ge h))
  rw [show A + (a - A) = a by ring] at hbad
  exact (not_guaranteedAngle_of_large_counterexample hs hbad) ha.2.2

theorem binaryScale_alpha_le {n m : ℕ} {v : Fin n → Plane} {A : ℝ}
    (hv : ∀ r, v r ≠ 0) (hA : 0 ≤ A)
    (haxes : ∀ r s, r ≠ s → ∀ b c : Bool,
      InnerProductGeometry.angle (signedBinaryAxis (v r) b) (signedBinaryAxis (v s) c) ≤ A)
    (hm : 3 ≤ m) (hcard : m ≤ 2 ^ n) : alpha m ≤ A := by
  apply alpha_le_of_large_approximation hm
  intro ε hε
  obtain ⟨s, hs, hbad⟩ := exists_binaryScale_counterexample hv hA haxes hε
  exact ⟨s, by omega, hbad⟩

end Prize.JSP404
