import Prize.JSP404.FiniteDirectionInvariance
import Prize.JSP404.MaximalCentres
import Mathlib.Order.Interval.Finset.Fin

/-!
# Restricting actual cyclic gaps to two anchor directions

The complete local exponent is bounded by the exponent obtained by keeping
two of the actual anchor lines. This is the geometric premise formerly left
explicit in the maximal-exponent counting interface. It is not a sharp bound
on the total capacity of all centres.
-/

namespace Prize.JSP404
namespace SortedDirectionChart

variable {n : ℕ} {p : Fin (n + 1) → Plane} (v : SortedDirectionChart p)

theorem gap_sum_Iio (b : Fin (n + 1)) :
    ∑ i ∈ Finset.Iio b, v.gap i = v.theta b - v.theta 0 := by
  classical
  let F : Fin (n + 1) → ℝ := fun i => min (v.theta i) (v.theta b)
  have hstep (i : Fin (n + 1)) :
      (if i < b then v.gap i else 0) =
        F (finRotate (n + 1) i) - F i +
          if i = Fin.last n then v.theta b - v.theta 0 else 0 := by
    by_cases hilast : i = Fin.last n
    · subst i
      have h0 := v.sorted.monotone (Fin.zero_le b)
      have hb := v.sorted.monotone (Fin.le_last b)
      simp [F, min_eq_left h0, min_eq_right hb,
        not_lt.mpr (Fin.le_last b)]
    · have hrot : i < finRotate (n + 1) i := (lt_finRotate_iff_ne_last i).mpr hilast
      by_cases hib : i < b
      · have hnext : finRotate (n + 1) i ≤ b := by
          have hv := coe_finRotate_of_ne_last hilast
          have hi : (i : ℕ) < b := hib
          apply Fin.le_def.mpr
          omega
        simp only [if_pos hib, if_neg hilast, v.gap_of_ne_last hilast, F,
          min_eq_left (v.sorted.monotone hib.le), min_eq_left (v.sorted.monotone hnext), add_zero]
      · have hbi : b ≤ i := le_of_not_gt hib
        simp only [if_neg hib, if_neg hilast, F, min_eq_right (v.sorted.monotone hbi),
          min_eq_right (v.sorted.monotone (hbi.trans hrot.le)), sub_self, add_zero]
  have hfilter : Finset.univ.filter (fun i : Fin (n + 1) => i < b) = Finset.Iio b := by
    ext i
    simp
  have hperm : (∑ i, F (finRotate (n + 1) i)) = ∑ i, F i :=
    Equiv.sum_comp (finRotate (n + 1)) F
  rw [← hfilter, Finset.sum_filter]
  simp_rw [hstep]
  rw [Finset.sum_add_distrib, Finset.sum_sub_distrib, hperm]
  simp

theorem gap_sum_Ico {a b : Fin (n + 1)} (hab : a ≤ b) :
    ∑ i ∈ Finset.Ico a b, v.gap i = v.theta b - v.theta a := by
  classical
  have hsub : Finset.Iio a ⊆ Finset.Iio b := by
    intro i hi
    exact Finset.mem_Iio.mpr ((Finset.mem_Iio.mp hi).trans_le hab)
  have hset : Finset.Iio b \ Finset.Iio a = Finset.Ico a b := by
    ext i
    simp only [Finset.mem_sdiff, Finset.mem_Iio, Finset.mem_Ico]
    omega
  have h := Finset.sum_sdiff_eq_sub (f := v.gap) hsub
  rw [hset, v.gap_sum_Iio b, v.gap_sum_Iio a] at h
  linarith

theorem gap_sum_compl_Ico {a b : Fin (n + 1)} (hab : a ≤ b) :
    ∑ i ∈ Finset.univ \ Finset.Ico a b, v.gap i =
      Real.pi - (v.theta b - v.theta a) := by
  have h := Finset.sum_sdiff_eq_sub (f := v.gap) (Finset.subset_univ (Finset.Ico a b))
  rwa [v.gap_sum, v.gap_sum_Ico hab] at h

/-- Keeping two sorted anchor lines merges the gaps into two blocks. -/
theorem gapIndex_le_two_line_capacity {t : ℝ} (ht : 0 ≤ t)
    {a b : Fin (n + 1)} (hab : a ≤ b) :
    v.gapIndex t ≤ triangleVertexCapacity t ((v.theta b - v.theta a) / Real.pi) := by
  classical
  let S := Finset.Ico a b
  let T := Finset.univ \ S
  have hpos (i : Fin (n + 1)) : 0 ≤ v.gap i / Real.pi :=
    div_nonneg (v.gap_pos i).le Real.pi_pos.le
  have hs : ∑ i ∈ S, v.gap i / Real.pi = (v.theta b - v.theta a) / Real.pi := by
    rw [← Finset.sum_div, v.gap_sum_Ico hab]
  have hr : ∑ i ∈ T, v.gap i / Real.pi = 1 - (v.theta b - v.theta a) / Real.pi := by
    rw [← Finset.sum_div, v.gap_sum_compl_Ico hab]
    field_simp
  have h := capacity_le_triangle_of_gap_blocks S T (fun i => v.gap i / Real.pi)
    (fun i => v.gap i / Real.pi) ht (fun i _ => hpos i) (fun i _ => hpos i) hs hr
  have hsum := Finset.sum_sdiff (f := fun i => sectorCapacity t (v.gap i / Real.pi))
    (Finset.subset_univ S)
  change (∑ i ∈ T, sectorCapacity t (v.gap i / Real.pi)) +
    (∑ i ∈ S, sectorCapacity t (v.gap i / Real.pi)) = v.gapIndex t at hsum
  omega

theorem gapIndex_le_anchor_angle {t : ℝ} (ht : 0 ≤ t) (a b : Fin (n + 1)) :
    v.gapIndex t ≤ triangleVertexCapacity t (InnerProductGeometry.angle (p a) (p b) / Real.pi) := by
  have hcompl (x : ℝ) : triangleVertexCapacity t (1 - x) = triangleVertexCapacity t x := by
    simp [triangleVertexCapacity, add_comm]
  have hpair (x : ℝ) (c d : Bool) :
      triangleVertexCapacity t (signedPairAngle Real.pi x c d / Real.pi) =
        triangleVertexCapacity t (x / Real.pi) := by
    by_cases h : c = d
    · simp [signedPairAngle, h]
    · simp only [signedPairAngle, if_neg h]
      rw [show (Real.pi - x) / Real.pi = 1 - x / Real.pi by field_simp]
      exact hcompl _
  have hsorted (i j : Fin (n + 1)) (hij : i ≤ j) :
      v.gapIndex t ≤ triangleVertexCapacity t
        (InnerProductGeometry.angle (p (v.reindex i)) (p (v.reindex j)) / Real.pi) := by
    rw [v.represents i, v.represents j,
      InnerProductGeometry.angle_smul_left_of_pos _ _ (v.length_pos i),
      InnerProductGeometry.angle_smul_right_of_pos _ _ (v.length_pos j),
      signedDirection_angle (v.sorted.monotone hij)
        (by linarith [v.lt_pi j, v.nonneg i]), hpair]
    exact v.gapIndex_le_two_line_capacity ht hij
  rcases le_total (v.reindex.symm a) (v.reindex.symm b) with hab | hba
  · simpa only [Equiv.apply_symm_apply] using hsorted _ _ hab
  · simpa only [Equiv.apply_symm_apply, InnerProductGeometry.angle_comm (p b) (p a)]
      using hsorted _ _ hba

end SortedDirectionChart
end Prize.JSP404
