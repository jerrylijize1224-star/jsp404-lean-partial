import Prize.JSP404.FiniteMaximalCentres
import Prize.JSP404.ExteriorBudget

/-!
# Exterior upper bounds without rotating direction charts

For t < 3 the interior-angle contribution to a triangle capacity vanishes.
Consequently triangle restriction already bounds the actual local index by
the complementary-angle capacity. Equality and common ray signs are not needed.

The global budget theorems below retain an explicit sum-of-exterior-angles
premise. Constructing the neighbours and proving that premise are not done here.
-/

namespace Prize.JSP404

theorem sectorCapacity_angle_eq_zero {t A : ℝ} (ht : 0 ≤ t) (ht3 : t < 3)
    (hA : A ≤ (1 - 1 / t) * Real.pi) : sectorCapacity t (A / Real.pi) = 0 := by
  have hn := (div_le_iff₀ Real.pi_pos).mpr hA
  have hm := mul_le_mul_of_nonneg_left hn ht
  have hx : t * (A / Real.pi) < 2 := by
    by_cases hz : t = 0
    · simp [hz]
    · have hi : t * (1 / t) = 1 := by field_simp
      nlinarith
  have hf : ⌊t * (A / Real.pi)⌋ ≤ (1 : ℤ) :=
    Int.floor_le_iff.mpr (by norm_num; exact hx)
  unfold sectorCapacity
  omega

namespace SortedDirectionChart

theorem gapIndex_le_exterior {n : ℕ} {p : Fin (n + 1) → Plane}
    (v : SortedDirectionChart p) {t : ℝ} (ht : 0 ≤ t) (ht3 : t < 3)
    (a b : Fin (n + 1))
    (hangle : InnerProductGeometry.angle (p a) (p b) ≤ (1 - 1 / t) * Real.pi) :
    v.gapIndex t ≤ sectorCapacity t (1 - InnerProductGeometry.angle (p a) (p b) / Real.pi) := by
  have h := v.gapIndex_le_anchor_angle ht a b
  simpa only [triangleVertexCapacity, sectorCapacity_angle_eq_zero ht ht3 hangle, zero_add] using h

end SortedDirectionChart

namespace FiniteClusterModel

open EuclideanGeometry

variable {V : Type*} {m : ℕ} (M : FiniteClusterModel V m)

theorem gapIndex_le_exterior {t : ℝ} (ht : 0 ≤ t) (ht3 : t < 3)
    (hbound : M.directions.AngleBound ((1 - 1 / t) * Real.pi))
    (v : ∀ i, SortedDirectionChart (M.outgoing i))
    {a b c : Fin (m + 2)} (hab : a ≠ b) (hac : a ≠ c) (hbc : b ≠ c) :
    (v b).gapIndex t ≤ sectorCapacity t (1 - angle (M.centre a) (M.centre b) (M.centre c) / Real.pi) := by
  have hangle := M.centres_angle_bound hbound _ (M.centre_mem a) _ (M.centre_mem b)
    _ (M.centre_mem c) (M.distinct.ne hab) (M.distinct.ne hac) (M.distinct.ne hbc)
  have h := M.gapIndex_le_triangle ht v hab hbc.symm
  simpa only [triangleVertexCapacity, sectorCapacity_angle_eq_zero ht ht3 hangle, zero_add] using h

/-- The only additional geometric premise is the stated exterior budget.
The two maps a,c are intended as polygon neighbours but are not assumed to
be permutations or claimed to exist with this budget. -/
theorem capacity_le_twice_parameter_of_exterior_budget {t : ℝ} (ht : 0 < t) (ht3 : t < 3)
    (hbound : M.directions.AngleBound ((1 - 1 / t) * Real.pi))
    (v : ∀ i, SortedDirectionChart (M.outgoing i)) (a c : Fin (m + 2) → Fin (m + 2))
    (ha : ∀ i, a i ≠ i) (hc : ∀ i, c i ≠ i) (hac : ∀ i, a i ≠ c i)
    (hbudget : (∑ i, (1 - angle (M.centre (a i)) (M.centre i) (M.centre (c i)) / Real.pi)) ≤ 2) :
    ((∑ i, 2 ^ (v i).gapIndex t : ℕ) : ℝ) ≤ 2 * t := by
  classical
  let x := fun i => t * (1 - angle (M.centre (a i)) (M.centre i) (M.centre (c i)) / Real.pi)
  have hx1 (i) : 1 ≤ x i := by
    have hangle := M.centres_angle_bound hbound _ (M.centre_mem (a i)) _ (M.centre_mem i)
      _ (M.centre_mem (c i)) (M.distinct.ne (ha i)) (M.distinct.ne (hac i)) (M.distinct.ne (hc i).symm)
    have hn := (div_le_iff₀ Real.pi_pos).mpr hangle
    have hm := mul_le_mul_of_nonneg_left hn ht.le
    have hi : t * (1 / t) = 1 := by field_simp
    dsimp [x]
    nlinarith
  have hx3 (i) : x i < 3 := by
    have hn := div_nonneg (angle_nonneg (M.centre (a i)) (M.centre i) (M.centre (c i))) Real.pi_pos.le
    dsimp [x]
    nlinarith
  have hw (i) : ((2 ^ (v i).gapIndex t : ℕ) : ℝ) ≤ x i := by
    have hidx := M.gapIndex_le_exterior ht.le ht3 hbound v (ha i) (hac i) (hc i).symm
    have hid : sectorCapacity t (1 - angle (M.centre (a i)) (M.centre i) (M.centre (c i)) / Real.pi) =
        gapBits (x i) := by simp only [gapBits, sectorCapacity, one_mul, x]
    rw [hid] at hidx
    have hp : (2 ^ (v i).gapIndex t : ℕ) ≤ 2 ^ gapBits (x i) := by gcongr
    have hp' : ((2 ^ (v i).gapIndex t : ℕ) : ℝ) ≤ ((2 ^ gapBits (x i) : ℕ) : ℝ) := by
      exact_mod_cast hp
    exact hp'.trans (gapBits_weight_le_of_one_le_lt_three (hx1 i) (hx3 i))
  rw [Nat.cast_sum]
  calc
    _ ≤ ∑ i, x i := Finset.sum_le_sum (fun i _ => hw i)
    _ = t * ∑ i, (1 - angle (M.centre (a i)) (M.centre i) (M.centre (c i)) / Real.pi) := by
      simp only [x, Finset.mul_sum]
    _ ≤ 2 * t := by nlinarith [mul_le_mul_of_nonneg_left hbudget ht.le]

/-- Actual label count, conditional only on the displayed neighbour and
exterior-budget hypotheses in addition to the model and angle cap. -/
theorem card_le_twice_parameter_of_exterior_budget [Fintype V] {t : ℝ}
    (ht : 1 ≤ t) (ht3 : t < 3)
    (hbound : M.directions.AngleBound ((1 - 1 / t) * Real.pi))
    (a c : Fin (m + 2) → Fin (m + 2))
    (ha : ∀ i, a i ≠ i) (hc : ∀ i, c i ≠ i) (hac : ∀ i, a i ≠ c i)
    (hbudget : (∑ i, (1 - angle (M.centre (a i)) (M.centre i) (M.centre (c i)) / Real.pi)) ≤ 2) :
    (Fintype.card V : ℝ) ≤ 2 * t := by
  classical
  have htpos : 0 < t := by linarith
  let v := fun i => Classical.choice (M.exists_direction_chart htpos hbound i)
  have hcard := M.card_le_sum_gap_capacity ht hbound v
  have hcap := M.capacity_le_twice_parameter_of_exterior_budget htpos ht3 hbound v a c ha hc hac hbudget
  exact le_trans (by exact_mod_cast hcard) hcap

theorem card_le_four_of_exterior_budget [Fintype V] {t : ℝ}
    (ht : 1 ≤ t) (ht' : t < 5 / 2)
    (hbound : M.directions.AngleBound ((1 - 1 / t) * Real.pi))
    (a c : Fin (m + 2) → Fin (m + 2))
    (ha : ∀ i, a i ≠ i) (hc : ∀ i, c i ≠ i) (hac : ∀ i, a i ≠ c i)
    (hbudget : (∑ i, (1 - angle (M.centre (a i)) (M.centre i) (M.centre (c i)) / Real.pi)) ≤ 2) :
    Fintype.card V ≤ 4 := by
  have h := M.card_le_twice_parameter_of_exterior_budget ht (by linarith) hbound a c ha hc hac hbudget
  have hr : (Fintype.card V : ℝ) < 5 := by linarith
  have hn : Fintype.card V < 5 := by exact_mod_cast hr
  omega

theorem card_le_five_of_exterior_budget [Fintype V] {t : ℝ}
    (ht : 1 ≤ t) (ht' : t < 3)
    (hbound : M.directions.AngleBound ((1 - 1 / t) * Real.pi))
    (a c : Fin (m + 2) → Fin (m + 2))
    (ha : ∀ i, a i ≠ i) (hc : ∀ i, c i ≠ i) (hac : ∀ i, a i ≠ c i)
    (hbudget : (∑ i, (1 - angle (M.centre (a i)) (M.centre i) (M.centre (c i)) / Real.pi)) ≤ 2) :
    Fintype.card V ≤ 5 := by
  have h := M.card_le_twice_parameter_of_exterior_budget ht ht' hbound a c ha hc hac hbudget
  have hr : (Fintype.card V : ℝ) < 6 := by linarith
  have hn : Fintype.card V < 6 := by exact_mod_cast hr
  omega

end FiniteClusterModel
end Prize.JSP404
