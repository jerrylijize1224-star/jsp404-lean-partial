import Prize.JSP404.FiniteAngleApproximation
import Prize.JSP404.SixPoints

/-! Eight distinct points at three successively smaller binary scales.
Scaled pair differences have nonzero limiting directions whose triple angles
are bounded by 120 degrees. This gives approximation, not attainment. -/

namespace Prize.JSP404

open EuclideanGeometry
open scoped RealInnerProductSpace

def cubeBit0 : Fin 8 → ℝ := ![0, 0, 0, 0, 1, 1, 1, 1]
def cubeBit1 : Fin 8 → ℝ := ![0, 0, 1, 1, 0, 0, 1, 1]
def cubeBit2 : Fin 8 → ℝ := ![0, 1, 0, 1, 0, 1, 0, 1]

noncomputable def cubeAxis0 : Plane := !₂[2, 0]
noncomputable def cubeAxis1 : Plane := !₂[1, Real.sqrt 3]
noncomputable def cubeAxis2 : Plane := !₂[-1, Real.sqrt 3]

noncomputable def binaryEightPoint (t : ℝ) (i : Fin 8) : Plane :=
  cubeBit0 i • cubeAxis0 + (t * cubeBit1 i) • cubeAxis1 +
    (t ^ 2 * cubeBit2 i) • cubeAxis2

noncomputable def binaryEightRank (i j : Fin 8) : ℕ :=
  if cubeBit0 i = cubeBit0 j then if cubeBit1 i = cubeBit1 j then 2 else 1 else 0

noncomputable def binaryEightNormal (t : ℝ) (i j : Fin 8) : Plane :=
  if cubeBit0 i = cubeBit0 j then
    if cubeBit1 i = cubeBit1 j then (cubeBit2 j - cubeBit2 i) • cubeAxis2
    else (cubeBit1 j - cubeBit1 i) • cubeAxis1 +
      (t * (cubeBit2 j - cubeBit2 i)) • cubeAxis2
  else (cubeBit0 j - cubeBit0 i) • cubeAxis0 +
    (t * (cubeBit1 j - cubeBit1 i)) • cubeAxis1 +
    (t ^ 2 * (cubeBit2 j - cubeBit2 i)) • cubeAxis2

theorem binaryEightNormal_continuous (i j : Fin 8) :
    ContinuousAt (fun t => binaryEightNormal t i j) 0 := by
  unfold binaryEightNormal
  split_ifs <;> fun_prop

theorem binaryEight_difference (t : ℝ) (i j : Fin 8) :
    binaryEightPoint t j - binaryEightPoint t i =
      t ^ binaryEightRank i j • binaryEightNormal t i j := by
  unfold binaryEightRank binaryEightNormal
  split_ifs with h0 h1 <;> ext r <;> fin_cases r <;>
    simp_all [binaryEightPoint, cubeAxis0, cubeAxis1, cubeAxis2] <;> ring

theorem binaryEightNormal_nonzero (i j : Fin 8) (hij : i ≠ j) :
    binaryEightNormal 0 i j ≠ 0 := by
  intro he
  have hx := congrArg (fun v : Plane => v 0) he
  fin_cases i <;> fin_cases j <;> norm_num at hij <;>
    norm_num [binaryEightNormal, cubeBit0, cubeBit1, cubeBit2,
      cubeAxis0, cubeAxis1, cubeAxis2] at hx

set_option maxHeartbeats 8000000 in
theorem binaryEightNormal_angle (i j k : Fin 8) :
    InnerProductGeometry.angle (binaryEightNormal 0 j i) (binaryEightNormal 0 j k) ≤
      (2 / 3 : ℝ) * Real.pi := by
  apply angle_le_two_pi_div_three_of_inner
  simp only [PiLp.inner_apply, Fin.sum_univ_two]
  fin_cases i <;> fin_cases j <;> fin_cases k <;>
    norm_num [binaryEightNormal, cubeBit0, cubeBit1, cubeBit2,
      cubeAxis0, cubeAxis1, cubeAxis2] <;>
    (try ring_nf) <;> norm_num [Real.sq_sqrt]

theorem exists_binaryEight_approximation {ε : ℝ} (hε : 0 < ε) :
    ∃ t : ℝ, 0 < t ∧ Function.Injective (binaryEightPoint t) ∧
      ∀ i j k, i ≠ j → i ≠ k → j ≠ k →
        angle (binaryEightPoint t i) (binaryEightPoint t j) (binaryEightPoint t k) <
          (2 / 3 : ℝ) * Real.pi + ε := by
  apply exists_finite_angle_approximation binaryEightPoint binaryEightNormal
    (fun t i j => t ^ binaryEightRank i j)
    binaryEightNormal_continuous binaryEightNormal_nonzero
    (by intro t ht i j; exact pow_pos ht _)
    (by intro t _ i j; exact binaryEight_difference t i j)
    (by intro i j k _ _ _; exact binaryEightNormal_angle i j k) hε

theorem exists_eightPoint_counterexample {ε : ℝ} (hε : 0 < ε) :
    ∃ s : Finset Plane, s.card = 8 ∧ ¬ HasLargeAngle s ((2 / 3 : ℝ) * Real.pi + ε) := by
  classical
  obtain ⟨t, ht, hinj, ha⟩ := exists_binaryEight_approximation hε
  refine ⟨Finset.univ.image (binaryEightPoint t), ?_, ?_⟩
  · rw [Finset.card_image_of_injective _ hinj]
    simp
  · rintro ⟨x, hx, y, hy, z, hz, hxy, hxz, hyz, hlarge⟩
    obtain ⟨i, _, rfl⟩ := Finset.mem_image.mp hx
    obtain ⟨j, _, rfl⟩ := Finset.mem_image.mp hy
    obtain ⟨k, _, rfl⟩ := Finset.mem_image.mp hz
    have hsmall := ha i j k (fun h => hxy (congrArg (binaryEightPoint t) h))
      (fun h => hxz (congrArg (binaryEightPoint t) h))
      (fun h => hyz (congrArg (binaryEightPoint t) h))
    exact (not_lt_of_ge hlarge) hsmall

theorem first_high_band_sharp {n : ℕ} (hn : 6 ≤ n) (hn8 : n ≤ 8) :
    IsSharpBound n ((2 / 3 : ℝ) * Real.pi) := by
  apply isSharpBound_of_approximation (by positivity) (by linarith [Real.pi_pos])
    (guaranteedAngle_two_pi_div_three hn)
  intro ε hε
  obtain ⟨s, hs, hbad⟩ := exists_eightPoint_counterexample hε
  exact ⟨s, by omega, hbad⟩

theorem sevenPoints_sharp : IsSharpBound 7 ((2 / 3 : ℝ) * Real.pi) :=
  first_high_band_sharp (by decide) (by decide)

theorem eightPoints_sharp : IsSharpBound 8 ((2 / 3 : ℝ) * Real.pi) :=
  first_high_band_sharp (by decide) (by decide)

theorem alpha_seven : alpha 7 = (2 / 3 : ℝ) * Real.pi := sevenPoints_sharp.alpha_eq
theorem alpha_eight : alpha 8 = (2 / 3 : ℝ) * Real.pi := eightPoints_sharp.alpha_eq

end Prize.JSP404
