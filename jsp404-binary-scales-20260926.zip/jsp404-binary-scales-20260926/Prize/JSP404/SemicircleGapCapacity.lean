import Prize.JSP404.FiniteDirectionChart

/-!
# Local exterior capacity for a coherently signed direction chart

The same-ray premise below is explicit. Constructing such charts in rotated
coordinates from convex position is a remaining geometric step.
-/

namespace Prize.JSP404
namespace SortedDirectionChart

theorem gapIndex_eq_exterior_of_same_ray {n : ℕ} {p : Fin (n + 1) → Plane}
    (v : SortedDirectionChart p) {t : ℝ} (ht : 0 ≤ t) (ht3 : t < 3)
    (hray : ∀ i, v.ray i = v.ray 0)
    (hangle : InnerProductGeometry.angle (p (v.reindex 0)) (p (v.reindex (Fin.last n))) ≤
      (1 - 1 / t) * Real.pi) :
    v.gapIndex t = sectorCapacity t
      (1 - InnerProductGeometry.angle (p (v.reindex 0))
        (p (v.reindex (Fin.last n))) / Real.pi) := by
  classical
  have he : InnerProductGeometry.angle (p (v.reindex 0)) (p (v.reindex (Fin.last n))) =
      v.theta (Fin.last n) - v.theta 0 := by
    rw [v.represents 0, v.represents (Fin.last n),
      InnerProductGeometry.angle_smul_left_of_pos _ _ (v.length_pos 0),
      InnerProductGeometry.angle_smul_right_of_pos _ _ (v.length_pos (Fin.last n)),
      signedDirection_angle (v.sorted.monotone (Fin.zero_le _))
        (by linarith [v.lt_pi (Fin.last n), v.nonneg 0])]
    simp [signedPairAngle, hray]
  have hspread : t * ((v.theta (Fin.last n) - v.theta 0) / Real.pi) < 2 := by
    rw [he] at hangle
    have hn := (div_le_iff₀ Real.pi_pos).mpr hangle
    have hm := mul_le_mul_of_nonneg_left hn ht
    by_cases hz : t = 0
    · simp [hz]
    · have hi : t * (1 / t) = 1 := by field_simp
      nlinarith
  unfold gapIndex
  rw [Finset.sum_eq_single (Fin.last n)]
  · rw [v.gap_last, he]
    congr 1
    field_simp
    <;> ring
  · intro i _ hi
    have hgap : v.gap i ≤ v.theta (Fin.last n) - v.theta 0 := by
      rw [v.gap_of_ne_last hi]
      linarith [v.sorted.monotone (Fin.le_last (finRotate (n + 1) i)),
        v.sorted.monotone (Fin.zero_le i)]
    have hmul := mul_le_mul_of_nonneg_left (div_le_div_of_nonneg_right hgap Real.pi_pos.le) ht
    have hf : ⌊t * (v.gap i / Real.pi)⌋ ≤ (1 : ℤ) :=
      Int.floor_le_iff.mpr (by norm_num; linarith)
    unfold sectorCapacity
    omega
  · simp

end SortedDirectionChart
end Prize.JSP404
