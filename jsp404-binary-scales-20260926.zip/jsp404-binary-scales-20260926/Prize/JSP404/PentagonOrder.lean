import Prize.JSP404.OrderedRayCrossing
import Prize.JSP404.PentagonExterior

/-! A crossing fan exists after relabelling any convex-independent five points. -/

namespace Prize.JSP404

open EuclideanGeometry

theorem convexIndependent_not_collinear {ι : Type*} {p : ι → Plane}
    (hp : ConvexIndependent ℝ p) {a b c : ι}
    (hab : a ≠ b) (hac : a ≠ c) (hbc : b ≠ c) :
    ¬ Collinear ℝ ({p a, p b, p c} : Set Plane) := by
  intro hcol
  rcases hcol.wbtw_or_wbtw_or_wbtw with h | h | h
  · have hm := hp ({a, c} : Set ι) b (by
      simpa [Set.image_pair, convexHull_pair] using mem_segment_iff_wbtw.mpr h)
    simpa [hab.symm, hbc] using hm
  · have hm := hp ({b, a} : Set ι) c (by
      simpa [Set.image_pair, convexHull_pair] using mem_segment_iff_wbtw.mpr h)
    simpa [hbc.symm, hac.symm] using hm
  · have hm := hp ({c, b} : Set ι) a (by
      simpa [Set.image_pair, convexHull_pair] using mem_segment_iff_wbtw.mpr h)
    simpa [hac, hab] using hm

theorem exists_pentagonFan_reindex (p : Fin 5 → Plane) (hp : ConvexIndependent ℝ p) :
    ∃ e : Equiv.Perm (Fin 5), Nonempty (PentagonFan (p ∘ e)) := by
  classical
  obtain ⟨f, hf⟩ := exists_positive_support p hp 0
  have hfne : f ≠ 0 := by
    intro he
    have hh := hf 1 (by decide)
    simpa [he] using hh
  obtain ⟨g, hfg⟩ := exists_complementary_coordinate f hfne
  let u : Fin 4 → Plane := fun i => p i.succ - p 0
  have hu (i : Fin 4) : 0 < f (u i) := hf i.succ (Fin.succ_ne_zero i)
  have hang (i j : Fin 4) (hij : i ≠ j) : InnerProductGeometry.angle (u i) (u j) ≠ 0 := by
    change angle (p i.succ) (p 0) (p j.succ) ≠ 0
    exact angle_ne_zero_of_not_collinear (convexIndependent_not_collinear hp
      (Fin.succ_ne_zero i) (fun h => hij (Fin.succ_inj.mp h)) (Fin.succ_ne_zero j).symm)
  have hinj := slope_injective_of_positive_support u f g hfg hu hang
  obtain ⟨e, he⟩ := exists_strictMono_reindex (fun i => g (u i) / f (u i)) hinj
  let E : Equiv.Perm (Fin 5) :=
    (finSuccEquiv 4).trans ((Equiv.optionCongr e).trans (finSuccEquiv 4).symm)
  let q : Fin 5 → Plane := p ∘ E
  have hq0 : q 0 = p 0 := by simp [q, E]
  have hqs (i : Fin 4) : q i.succ = p (e i).succ := by simp [q, E]
  have hq : ConvexIndependent ℝ q := hp.comp_embedding E.toEmbedding
  have hpos (i : Fin 4) : 0 < f (q i.succ - q 0) := by
    rw [hqs, hq0]
    exact hu (e i)
  have hsort : StrictMono (fun i : Fin 4 => g (q i.succ - q 0) / f (q i.succ - q 0)) := by
    intro i j hij
    change g (q i.succ - q 0) / f (q i.succ - q 0) < g (q j.succ - q 0) / f (q j.succ - q 0)
    rw [hqs, hqs, hq0]
    exact he hij
  have hcross (i j k : Fin 4) (hij : i < j) (hjk : j < k) :
      ∃ O, Sbtw ℝ (q 0) O (q j.succ) ∧ Sbtw ℝ (q i.succ) O (q k.succ) := by
    let r : Fin 4 → Fin 5 := ![0, i.succ, j.succ, k.succ]
    have hr : Function.Injective r := by
      intro a b hab
      apply Fin.ext
      have hv := congrArg Fin.val hab
      fin_cases a <;> fin_cases b <;> norm_num [r] at hv <;> omega
    have hh := ordered_rays_crossing (q ∘ r) (hq.comp_embedding ⟨r, hr⟩) f g
      (by simpa [r, Function.comp_def] using hpos i)
      (by simpa [r, Function.comp_def] using hpos j)
      (by simpa [r, Function.comp_def] using hpos k)
      (by simpa [r, Function.comp_def] using hsort hij)
      (by simpa [r, Function.comp_def] using hsort hjk)
    simpa [r, Function.comp_def] using hh
  obtain ⟨O₁, h11, h12⟩ := hcross 0 1 2 (by decide) (by decide)
  obtain ⟨O₂, h21, h22⟩ := hcross 1 2 3 (by decide) (by decide)
  obtain ⟨O₃, h31, h32⟩ := hcross 0 1 3 (by decide) (by decide)
  exact ⟨E, ⟨{
    O₁ := O₁, O₂ := O₂, O₃ := O₃
    ac_bd_left := h11, ac_bd_right := h12
    ad_ce_left := h21, ad_ce_right := h22
    ac_be_left := h31, ac_be_right := h32 }⟩⟩

namespace FiniteClusterModel

/-- Relabel centres and cluster indices by inverse permutations. Directions
and the leaf type are unchanged, and occupation and cross directions are proved. -/
def relabel {V : Type*} {m : ℕ} (M : FiniteClusterModel V m)
    (e : Equiv.Perm (Fin (m + 2))) : FiniteClusterModel V m where
  directions := M.directions
  cluster := e.symm ∘ M.cluster
  occupied := e.symm.surjective.comp M.occupied
  centre := M.centre ∘ e
  distinct := M.distinct.comp e.injective
  cross := by
    intro u v huv
    have hn : M.cluster u ≠ M.cluster v := fun h => huv (congrArg e.symm h)
    simpa only [Function.comp_apply, Equiv.apply_symm_apply] using M.cross u v hn

/-- Every five-centre model in this parameter band has exactly five labels.
No order, diagonal crossing, or exterior-budget hypothesis is imposed. -/
theorem card_eq_five_of_lt_three {V : Type*} [Fintype V] (M : FiniteClusterModel V 3)
    {t : ℝ} (ht : 1 ≤ t) (ht3 : t < 3)
    (hbound : M.directions.AngleBound ((1 - 1 / t) * Real.pi)) : Fintype.card V = 5 := by
  have hc := M.centres_convexIndependent (by linarith) ht3 hbound
  obtain ⟨e, ⟨hfan⟩⟩ := exists_pentagonFan_reindex M.centre hc
  exact (M.relabel e).card_eq_five_of_pentagon_fan ht ht3 hbound hfan

theorem not_angleBound_of_five_centres_low {V : Type*} [Fintype V] (M : FiniteClusterModel V 3)
    {t : ℝ} (ht : 1 ≤ t) (ht' : t < 5 / 2) :
    ¬ M.directions.AngleBound ((1 - 1 / t) * Real.pi) := by
  intro hbound
  have hc := M.centres_convexIndependent (by linarith) (by linarith) hbound
  obtain ⟨e, ⟨hfan⟩⟩ := exists_pentagonFan_reindex M.centre hc
  exact (M.relabel e).not_angleBound_of_pentagon_fan_low ht ht' hfan hbound

end FiniteClusterModel
end Prize.JSP404
