import Prize.JSP404.BinaryScaleConstruction
import Prize.JSP404.FivePoints

/-! A sixteen-point approximation at 135 degrees, obtained from four binary
scales and four explicitly verified axes. This proves an upper bound only;
the matching sixteen-point universal lower bound is not proved here. -/

namespace Prize.JSP404

open scoped RealInnerProductSpace

noncomputable def fourBinaryAxes : Fin 4 → Plane :=
  ![!₂[2, 0], !₂[Real.sqrt 2, Real.sqrt 2], !₂[0, 2], !₂[-Real.sqrt 2, Real.sqrt 2]]

theorem fourBinaryAxes_nonzero (r : Fin 4) : fourBinaryAxes r ≠ 0 := by
  intro h
  have hx := congrArg (fun v : Plane => v 0) h
  have hy := congrArg (fun v : Plane => v 1) h
  fin_cases r <;> norm_num [fourBinaryAxes] at hx <;> norm_num [fourBinaryAxes] at hy

set_option maxHeartbeats 2000000 in
theorem fourBinaryAxes_angle (r s : Fin 4) (hrs : r ≠ s) (b c : Bool) :
    InnerProductGeometry.angle (signedBinaryAxis (fourBinaryAxes r) b)
      (signedBinaryAxis (fourBinaryAxes s) c) ≤ (3 / 4 : ℝ) * Real.pi := by
  apply angle_le_of_inner_certificate (c := Real.sqrt 2 / 2)
    (by positivity) (by linarith [Real.pi_pos]) (by positivity)
  · rw [show (3 / 4 : ℝ) * Real.pi = Real.pi - Real.pi / 4 by ring,
      Real.cos_pi_sub, Real.cos_pi_div_four]
  · simp only [PiLp.inner_apply, Fin.sum_univ_two]
    fin_cases r <;> fin_cases s <;> norm_num at hrs <;> cases b <;> cases c <;>
      norm_num [signedBinaryAxis, fourBinaryAxes] <;>
      (try ring_nf) <;> norm_num [Real.sq_sqrt]

theorem exists_sixteenPoint_counterexample {ε : ℝ} (hε : 0 < ε) :
    ∃ s : Finset Plane, s.card = 16 ∧ ¬ HasLargeAngle s ((3 / 4 : ℝ) * Real.pi + ε) := by
  simpa using exists_binaryScale_counterexample fourBinaryAxes_nonzero
    (by positivity : 0 ≤ (3 / 4 : ℝ) * Real.pi) fourBinaryAxes_angle hε

theorem alpha_le_three_pi_div_four {m : ℕ} (hm : 3 ≤ m) (hm16 : m ≤ 16) :
    alpha m ≤ (3 / 4 : ℝ) * Real.pi := by
  exact binaryScale_alpha_le fourBinaryAxes_nonzero (by positivity)
    fourBinaryAxes_angle hm (by simpa using hm16)

theorem alpha_sixteen_bounds :
    (2 / 3 : ℝ) * Real.pi ≤ alpha 16 ∧ alpha 16 ≤ (3 / 4 : ℝ) * Real.pi :=
  ⟨two_pi_div_three_le_alpha (by decide), alpha_le_three_pi_div_four (by decide) (by decide)⟩

end Prize.JSP404
