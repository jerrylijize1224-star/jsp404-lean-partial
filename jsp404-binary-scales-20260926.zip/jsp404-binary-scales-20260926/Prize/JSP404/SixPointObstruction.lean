import Prize.JSP404.ConvexFanOrder

/-! Six points force an angle at least 120 degrees in the first parameter band.
The finite-set bound follows by selecting six points, without assuming a
polygon ordering or a global exterior-angle budget. -/

namespace Prize.JSP404

open EuclideanGeometry

theorem ConvexFanCrossings.hexagon_angle_sum {p : Fin 6 → Plane}
    (hfan : ConvexFanCrossings p) (hp : Function.Injective p) :
    angle (p 5) (p 0) (p 1) + angle (p 0) (p 1) (p 2) +
      angle (p 1) (p 2) (p 3) + angle (p 2) (p 3) (p 4) +
      angle (p 3) (p 4) (p 5) + angle (p 4) (p 5) (p 0) = 4 * Real.pi := by
  obtain ⟨O₁, h11, h12⟩ := hfan 0 1 2 (by decide) (by decide)
  obtain ⟨O₂, h21, h22⟩ := hfan 1 2 3 (by decide) (by decide)
  obtain ⟨O₃, h31, h32⟩ := hfan 2 3 4 (by decide) (by decide)
  obtain ⟨O₄, h41, h42⟩ := hfan 0 1 4 (by decide) (by decide)
  obtain ⟨O₅, h51, h52⟩ := hfan 1 2 4 (by decide) (by decide)
  norm_num at h11 h12 h21 h22 h31 h32 h41 h42 h51 h52
  have hA₁ := angle_add_angle_eq_of_sbtw (p := p 0) h42
  rw [h41.angle_eq_right (p 1), h41.angle_eq_left (p 5)] at hA₁
  have hA₂ := angle_add_angle_eq_of_sbtw (p := p 0) h52
  rw [h51.angle_eq_right (p 2), h51.angle_eq_left (p 5)] at hA₂
  have hA₃ := angle_add_angle_eq_of_sbtw (p := p 0) h32
  rw [h31.angle_eq_right (p 3), h31.angle_eq_left (p 5)] at hA₃
  have hC := angle_add_angle_eq_of_sbtw (p := p 2) h12
  rw [h11.symm.angle_eq_right (p 1), h11.symm.angle_eq_left (p 3)] at hC
  have hD := angle_add_angle_eq_of_sbtw (p := p 3) h22
  rw [h21.symm.angle_eq_right (p 2), h21.symm.angle_eq_left (p 4)] at hD
  have hE := angle_add_angle_eq_of_sbtw (p := p 4) h32
  rw [h31.symm.angle_eq_right (p 3), h31.symm.angle_eq_left (p 5)] at hE
  have hABC := angle_add_angle_add_angle_eq_pi (p 2) (hp.ne (by decide : (1 : Fin 6) ≠ 0))
  have hACD := angle_add_angle_add_angle_eq_pi (p 3) (hp.ne (by decide : (2 : Fin 6) ≠ 0))
  have hADE := angle_add_angle_add_angle_eq_pi (p 4) (hp.ne (by decide : (3 : Fin 6) ≠ 0))
  have hAEF := angle_add_angle_add_angle_eq_pi (p 5) (hp.ne (by decide : (4 : Fin 6) ≠ 0))
  rw [angle_comm (p 2) (p 0) (p 1)] at hABC
  rw [angle_comm (p 3) (p 0) (p 2)] at hACD
  rw [angle_comm (p 4) (p 0) (p 3)] at hADE
  rw [angle_comm (p 5) (p 0) (p 4)] at hAEF
  rw [angle_comm (p 5) (p 0) (p 1)]
  linarith

theorem not_six_convexIndependent_of_angle_lt {p : Fin 6 → Plane}
    (hp : ConvexIndependent ℝ p)
    (ha : ∀ i j k, i ≠ j → i ≠ k → j ≠ k →
      angle (p i) (p j) (p k) < (2 / 3 : ℝ) * Real.pi) : False := by
  obtain ⟨e, hfan⟩ := exists_convexFanCrossings_reindex p hp
  have hs := hfan.hexagon_angle_sum (hp.injective.comp e.injective)
  have hb (i j k : Fin 6) (hij : i ≠ j) (hik : i ≠ k) (hjk : j ≠ k) :=
    ha (e i) (e j) (e k) (e.injective.ne hij) (e.injective.ne hik) (e.injective.ne hjk)
  have h0 := hb 5 0 1 (by decide) (by decide) (by decide)
  have h1 := hb 0 1 2 (by decide) (by decide) (by decide)
  have h2 := hb 1 2 3 (by decide) (by decide) (by decide)
  have h3 := hb 2 3 4 (by decide) (by decide) (by decide)
  have h4 := hb 3 4 5 (by decide) (by decide) (by decide)
  have h5 := hb 4 5 0 (by decide) (by decide) (by decide)
  simp only [Function.comp_apply] at hs
  linarith

theorem card_le_five_of_angle_bound {s : Finset Plane} {t : ℝ}
    (ht : 0 < t) (ht3 : t < 3)
    (ha : ∀ A ∈ s, ∀ B ∈ s, ∀ C ∈ s, A ≠ B → A ≠ C → B ≠ C →
      angle A B C ≤ (1 - 1 / t) * Real.pi) : s.card ≤ 5 := by
  classical
  by_contra hn
  have hc : Fintype.card (Fin 6) ≤ Fintype.card s := by
    simp only [Fintype.card_fin, Fintype.card_coe]
    omega
  obtain ⟨e⟩ := Function.Embedding.nonempty_of_card_le hc
  have hp := (convexIndependent_of_angle_bound ht ht3 ha).comp_embedding e
  apply not_six_convexIndependent_of_angle_lt hp
  intro i j k hij hik hjk
  have he : Function.Injective (fun i : Fin 6 => (e i).val) :=
    Subtype.val_injective.comp e.injective
  have hb := ha _ (e i).property _ (e j).property _ (e k).property
    (he.ne hij) (he.ne hik) (he.ne hjk)
  have hinv : (1 / 3 : ℝ) < 1 / t := one_div_lt_one_div_of_lt ht ht3
  have hcap : (1 - 1 / t) * Real.pi < (2 / 3 : ℝ) * Real.pi := by
    nlinarith [Real.pi_pos]
  exact hb.trans_lt hcap

theorem FiniteClusterModel.centres_card_le_five_of_lt_three {V : Type*} {n : ℕ}
    (M : FiniteClusterModel V n) {t : ℝ} (ht : 0 < t) (ht3 : t < 3)
    (hbound : M.directions.AngleBound ((1 - 1 / t) * Real.pi)) : n + 2 ≤ 5 := by
  rw [← M.centres_card]
  exact card_le_five_of_angle_bound ht ht3 (M.centres_angle_bound hbound)

end Prize.JSP404
