import Prize.JSP404.FourCentreClassification
import Mathlib.Analysis.Convex.Independent

/-! The three possible diagonal pairings of a convex-independent quadruple. -/

namespace Prize.JSP404

open EuclideanGeometry
open scoped Classical

theorem radon_side_card_ge_two (p : Fin 4 → Plane) (hp : ConvexIndependent ℝ p)
    {I : Set (Fin 4)} {O : Plane} (hI : O ∈ convexHull ℝ (p '' I))
    (hc : O ∈ convexHull ℝ (p '' Iᶜ)) : 2 ≤ I.toFinset.card := by
  classical
  have hpos : 0 < I.toFinset.card := Finset.card_pos.mpr (by
    simpa using Set.image_nonempty.mp (convexHull_nonempty_iff.mp ⟨O, hI⟩))
  by_contra h
  obtain ⟨i, hi⟩ := Finset.card_eq_one.mp (show I.toFinset.card = 1 by omega)
  have he : I = {i} := by
    have hh := congrArg (fun s : Finset (Fin 4) => (s : Set (Fin 4))) hi
    simpa using hh
  have ho : O = p i := by simpa [he] using hI
  have hm := hp Iᶜ i (by simpa [ho] using hc)
  simpa [he] using hm

theorem convex_four_weak_crossing_cases (p : Fin 4 → Plane) (hp : ConvexIndependent ℝ p) :
    (∃ O, Wbtw ℝ (p 0) O (p 1) ∧ Wbtw ℝ (p 2) O (p 3)) ∨
    (∃ O, Wbtw ℝ (p 0) O (p 2) ∧ Wbtw ℝ (p 1) O (p 3)) ∨
    (∃ O, Wbtw ℝ (p 0) O (p 3) ∧ Wbtw ℝ (p 1) O (p 2)) := by
  classical
  have hdep : ¬ AffineIndependent ℝ p := by
    intro h
    have hc := h.card_le_finrank_succ
    have hd := Submodule.finrank_le (vectorSpan ℝ (Set.range p))
    have he : Module.finrank ℝ Plane = 2 := by simp [Plane]
    rw [he] at hd
    simp only [Fintype.card_fin] at hc
    omega
  obtain ⟨I, O, hI, hIc⟩ := Convex.radon_partition hdep
  have hj : ∃ J : Set (Fin 4), 0 ∈ J ∧ O ∈ convexHull ℝ (p '' J) ∧
      O ∈ convexHull ℝ (p '' Jᶜ) := by
    by_cases hz : 0 ∈ I
    · exact ⟨I, hz, hI, hIc⟩
    · exact ⟨Iᶜ, hz, hIc, by simpa using hI⟩
  obtain ⟨J, hz, hJ, hJc⟩ := hj
  have htwo : J.toFinset.card = 2 := by
    have h1 := radon_side_card_ge_two p hp hJ hJc
    have h2 := radon_side_card_ge_two p hp hJc (by simpa using hJ)
    rw [Set.toFinset_compl, Finset.card_compl] at h2
    simp only [Fintype.card_fin] at h2
    omega
  have hpair : ∃ j : Fin 4, j ≠ 0 ∧ J = {0, j} := by
    obtain ⟨a, b, hab, he⟩ := Finset.card_eq_two.mp htwo
    have hset : J = {a, b} := by
      have hh := congrArg (fun s : Finset (Fin 4) => (s : Set (Fin 4))) he
      simpa using hh
    have hz' : 0 = a ∨ 0 = b := by simpa [hset] using hz
    rcases hz' with rfl | rfl
    · exact ⟨b, hab.symm, hset⟩
    · exact ⟨a, hab, by simpa [Set.pair_comm] using hset⟩
  obtain ⟨j, hj0, rfl⟩ := hpair
  fin_cases j
  · exact (hj0 rfl).elim
  · change O ∈ convexHull ℝ (p '' ({0, 1} : Set (Fin 4))) at hJ
    change O ∈ convexHull ℝ (p '' ({0, 1} : Set (Fin 4))ᶜ) at hJc
    have hc : ({0, 1} : Set (Fin 4))ᶜ = {2, 3} := by ext i; fin_cases i <;> decide
    rw [hc] at hJc
    exact Or.inl ⟨O, mem_segment_iff_wbtw.mp (by simpa [Set.image_pair, convexHull_pair] using hJ),
      mem_segment_iff_wbtw.mp (by simpa [Set.image_pair, convexHull_pair] using hJc)⟩
  · change O ∈ convexHull ℝ (p '' ({0, 2} : Set (Fin 4))) at hJ
    change O ∈ convexHull ℝ (p '' ({0, 2} : Set (Fin 4))ᶜ) at hJc
    have hc : ({0, 2} : Set (Fin 4))ᶜ = {1, 3} := by ext i; fin_cases i <;> decide
    rw [hc] at hJc
    exact Or.inr (Or.inl ⟨O, mem_segment_iff_wbtw.mp (by simpa [Set.image_pair, convexHull_pair] using hJ),
      mem_segment_iff_wbtw.mp (by simpa [Set.image_pair, convexHull_pair] using hJc)⟩)
  · change O ∈ convexHull ℝ (p '' ({0, 3} : Set (Fin 4))) at hJ
    change O ∈ convexHull ℝ (p '' ({0, 3} : Set (Fin 4))ᶜ) at hJc
    have hc : ({0, 3} : Set (Fin 4))ᶜ = {1, 2} := by ext i; fin_cases i <;> decide
    rw [hc] at hJc
    exact Or.inr (Or.inr ⟨O, mem_segment_iff_wbtw.mp (by simpa [Set.image_pair, convexHull_pair] using hJ),
      mem_segment_iff_wbtw.mp (by simpa [Set.image_pair, convexHull_pair] using hJc)⟩)

theorem strict_crossing_of_convexIndependent {ι : Type*} {p : ι → Plane}
    (hp : ConvexIndependent ℝ p) {a b c d : ι}
    (hd : Disjoint ({a, c} : Set ι) {b, d}) {O : Plane}
    (h1 : Wbtw ℝ (p a) O (p c)) (h2 : Wbtw ℝ (p b) O (p d)) :
    Sbtw ℝ (p a) O (p c) ∧ Sbtw ℝ (p b) O (p d) := by
  have hc1 : O ∈ convexHull ℝ (p '' ({a, c} : Set ι)) := by
    simpa [Set.image_pair, convexHull_pair] using mem_segment_iff_wbtw.mpr h1
  have hc2 : O ∈ convexHull ℝ (p '' ({b, d} : Set ι)) := by
    simpa [Set.image_pair, convexHull_pair] using mem_segment_iff_wbtw.mpr h2
  have hne1 {i : ι} (hi : i ∈ ({a, c} : Set ι)) : O ≠ p i := by
    intro he
    exact Set.disjoint_left.mp hd hi (hp _ i (he ▸ hc2))
  have hne2 {i : ι} (hi : i ∈ ({b, d} : Set ι)) : O ≠ p i := by
    intro he
    exact Set.disjoint_left.mp hd (hp _ i (he ▸ hc1)) hi
  exact ⟨⟨h1, hne1 (by simp), hne1 (by simp)⟩,
    ⟨h2, hne2 (by simp), hne2 (by simp)⟩⟩

end Prize.JSP404
