import Prize.JSP404.SixPoints

/-! Exact five-point sharpness from explicit golden-ratio coordinates. -/

namespace Prize.JSP404

open EuclideanGeometry
open scoped RealInnerProductSpace

theorem angle_le_of_inner_certificate {u v : Plane} {A c : ℝ}
    (hA0 : 0 ≤ A) (hApi : A ≤ Real.pi) (hc : 0 ≤ c) (hcos : Real.cos A = -c)
    (h : 0 ≤ ⟪u, v⟫ ∨ ⟪u, v⟫ ^ 2 ≤ c ^ 2 * ⟪u, u⟫ * ⟪v, v⟫) :
    InnerProductGeometry.angle u v ≤ A := by
  have hlower : -c ≤ Real.cos (InnerProductGeometry.angle u v) := by
    rw [InnerProductGeometry.cos_angle]
    rcases h with h | h
    · exact (neg_nonpos.mpr hc).trans
        (div_nonneg h (mul_nonneg (norm_nonneg u) (norm_nonneg v)))
    · rw [real_inner_self_eq_norm_sq, real_inner_self_eq_norm_sq] at h
      have hn : 0 ≤ ‖u‖ * ‖v‖ := mul_nonneg (norm_nonneg u) (norm_nonneg v)
      have hs : ⟪u, v⟫ ^ 2 ≤ (c * (‖u‖ * ‖v‖)) ^ 2 := by nlinarith [h]
      have hab := (abs_le_of_sq_le_sq' hs (mul_nonneg hc hn)).1
      by_cases hz : ‖u‖ * ‖v‖ = 0
      · simpa [hz] using neg_nonpos.mpr hc
      · apply (le_div_iff₀ (lt_of_le_of_ne hn (Ne.symm hz))).mpr
        linarith
  by_contra hn
  have hh := Real.strictAntiOn_cos ⟨hA0, hApi⟩
    ⟨InnerProductGeometry.angle_nonneg u v, InnerProductGeometry.angle_le_pi u v⟩
    (lt_of_not_ge hn)
  rw [hcos] at hh
  linarith

def goldenPentagonVertex (a b : ℝ) : Fin 5 → Plane :=
  ![!₂[-1, 0], !₂[1, 0], !₂[a, b], !₂[0, a * b], !₂[-a, b]]

theorem goldenPentagonVertex_injective {a b : ℝ} (ha : 1 < a) (hb : 0 < b) :
    Function.Injective (goldenPentagonVertex a b) := by
  intro i j h
  have h0 := congrArg (fun v : Plane => v 0) h
  have h1 := congrArg (fun v : Plane => v 1) h
  fin_cases i <;> fin_cases j <;> norm_num [goldenPentagonVertex] at h0 <;>
    norm_num [goldenPentagonVertex] at h1
  all_goals first | rfl | nlinarith

set_option maxHeartbeats 4000000 in
theorem goldenPentagon_inner_certificate {a b : ℝ}
    (ha : 1 < a) (ha2 : a ^ 2 = a + 1) (hb2 : b ^ 2 = a + 2)
    (i j k : Fin 5) :
    let u := goldenPentagonVertex a b i - goldenPentagonVertex a b j
    let v := goldenPentagonVertex a b k - goldenPentagonVertex a b j
    0 ≤ ⟪u, v⟫ ∨ 4 * ⟪u, v⟫ ^ 2 ≤ (2 - a) * ⟪u, u⟫ * ⟪v, v⟫ := by
  have ha3 : a ^ 3 = 2 * a + 1 := by rw [pow_succ, ha2]; nlinarith [ha2]
  have ha4 : a ^ 4 = 3 * a + 2 := by rw [pow_succ, ha3]; nlinarith [ha2]
  have ha5 : a ^ 5 = 5 * a + 3 := by rw [pow_succ, ha4]; nlinarith [ha2]
  have ha6 : a ^ 6 = 8 * a + 5 := by rw [pow_succ, ha5]; nlinarith [ha2]
  have hb4 : b ^ 4 = 5 * a + 5 := by
    rw [show b ^ 4 = (b ^ 2) ^ 2 by ring, hb2]
    nlinarith [ha2]
  have haa4 : |a| ^ 4 = a ^ 4 := pow_abs_two_mul (n := 2) a
  have hbb4 : |b| ^ 4 = b ^ 4 := pow_abs_two_mul (n := 2) b
  have haa : |a| = a := abs_of_pos (by linarith)
  have hbb2 : |b| ^ 2 = a + 2 := (sq_abs b).trans hb2
  have hbabs : 1 ≤ |b| := by nlinarith [abs_nonneg b]
  have hprod : 1 ≤ a * |b| := by
    calc
      1 = 1 * 1 := by norm_num
      _ ≤ a * |b| := mul_le_mul ha.le hbabs (by norm_num) (by linarith)
  dsimp only
  simp only [PiLp.inner_apply, Fin.sum_univ_two]
  fin_cases i <;> fin_cases j <;> fin_cases k <;>
    norm_num [goldenPentagonVertex] <;> (try ring_nf) <;>
    (try simp only [haa, sq_abs, haa4, hbb4, ha2, ha3, ha4, ha5, ha6, hb2, hb4]) <;>
    (try ring_nf) <;>
    (try simp only [ha2, ha3, ha4, ha5, ha6]) <;> (try ring_nf)
  all_goals first | left; nlinarith | right; nlinarith

noncomputable def pentagonRatio : ℝ := (1 + Real.sqrt 5) / 2
noncomputable def pentagonHeight : ℝ := Real.sqrt (pentagonRatio + 2)
noncomputable def pentagonVertex : Fin 5 → Plane :=
  goldenPentagonVertex pentagonRatio pentagonHeight

theorem pentagonRatio_gt_one : 1 < pentagonRatio := by
  have hs := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 5)
  have hn := Real.sqrt_nonneg (5 : ℝ)
  dsimp [pentagonRatio]
  nlinarith

theorem pentagonRatio_sq : pentagonRatio ^ 2 = pentagonRatio + 1 := by
  dsimp [pentagonRatio]
  nlinarith [Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 5)]

theorem pentagonHeight_pos : 0 < pentagonHeight :=
  Real.sqrt_pos.mpr (by linarith [pentagonRatio_gt_one])

theorem pentagonHeight_sq : pentagonHeight ^ 2 = pentagonRatio + 2 :=
  Real.sq_sqrt (by linarith [pentagonRatio_gt_one])

theorem cos_three_pi_div_five :
    Real.cos ((3 / 5 : ℝ) * Real.pi) = -(pentagonRatio - 1) / 2 := by
  have hcos : Real.cos (Real.pi / 5) = pentagonRatio / 2 := by
    rw [Real.cos_pi_div_five]
    dsimp [pentagonRatio]
    ring
  rw [show (3 / 5 : ℝ) * Real.pi = Real.pi - 2 * (Real.pi / 5) by ring,
    Real.cos_pi_sub, Real.cos_two_mul, hcos]
  nlinarith [pentagonRatio_sq]

theorem pentagonVertex_angle (i j k : Fin 5) :
    angle (pentagonVertex i) (pentagonVertex j) (pentagonVertex k) ≤
      (3 / 5 : ℝ) * Real.pi := by
  change InnerProductGeometry.angle (pentagonVertex i - pentagonVertex j)
    (pentagonVertex k - pentagonVertex j) ≤ (3 / 5 : ℝ) * Real.pi
  apply angle_le_of_inner_certificate (c := (pentagonRatio - 1) / 2)
    (by positivity) (by linarith [Real.pi_pos])
    (by linarith [pentagonRatio_gt_one])
    (by simpa only [neg_div] using cos_three_pi_div_five)
  have h := goldenPentagon_inner_certificate pentagonRatio_gt_one pentagonRatio_sq
    pentagonHeight_sq i j k
  change 0 ≤ ⟪pentagonVertex i - pentagonVertex j, pentagonVertex k - pentagonVertex j⟫ ∨
    4 * ⟪pentagonVertex i - pentagonVertex j, pentagonVertex k - pentagonVertex j⟫ ^ 2 ≤
      (2 - pentagonRatio) * ⟪pentagonVertex i - pentagonVertex j, pentagonVertex i - pentagonVertex j⟫ *
        ⟪pentagonVertex k - pentagonVertex j, pentagonVertex k - pentagonVertex j⟫ at h
  rcases h with h | h
  · exact Or.inl h
  · right
    have hc : ((pentagonRatio - 1) / 2) ^ 2 = (2 - pentagonRatio) / 4 := by
      nlinarith [pentagonRatio_sq]
    rw [hc]
    nlinarith [h]

noncomputable def pentagonSet : Finset Plane := Finset.univ.image pentagonVertex

theorem pentagonSet_card : pentagonSet.card = 5 := by
  rw [pentagonSet, pentagonVertex, Finset.card_image_of_injective _
    (goldenPentagonVertex_injective pentagonRatio_gt_one pentagonHeight_pos)]
  simp

theorem pentagonSet_angle {x y z : Plane}
    (hx : x ∈ pentagonSet) (hy : y ∈ pentagonSet) (hz : z ∈ pentagonSet) :
    angle x y z ≤ (3 / 5 : ℝ) * Real.pi := by
  obtain ⟨i, _, rfl⟩ := Finset.mem_image.mp hx
  obtain ⟨j, _, rfl⟩ := Finset.mem_image.mp hy
  obtain ⟨k, _, rfl⟩ := Finset.mem_image.mp hz
  exact pentagonVertex_angle i j k

theorem fivePoints_sharp : IsSharpBound 5 ((3 / 5 : ℝ) * Real.pi) := by
  refine ⟨by positivity, by linarith [Real.pi_pos],
    guaranteedAngle_three_pi_div_five (by decide), ?_⟩
  intro b hb h
  obtain ⟨x, hx, y, hy, z, hz, _, _, _, hangle⟩ := h pentagonSet pentagonSet_card
  have := pentagonSet_angle hx hy hz
  linarith

theorem alpha_five : alpha 5 = (3 / 5 : ℝ) * Real.pi := fivePoints_sharp.alpha_eq

end Prize.JSP404
