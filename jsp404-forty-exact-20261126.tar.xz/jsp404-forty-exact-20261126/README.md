# The sharp maximum-angle guarantee for forty points

For every set of 40 distinct points in the Euclidean plane, at least one angle determined by three of the points is at least 9π/11. Every higher threshold has a 40-point counterexample. Thus α(40) equals 1620/11 degrees.

Bl. Sendov gives this numerical value in *Minimax of the angles in a plane configuration of points*, Acta Mathematica Hungarica 69 (1995), Theorem 4.1, p. 42. This project provides a Lean proof for 40 points. The classification at arbitrary cardinalities still requires a formal proof in the larger project. [Paper](https://doi.org/10.1007/BF01874605) · [Journal volume](https://real-j.mtak.hu/7467/)

## Check the proof

This archive contains the 41 project modules used by the theorem, together with the pinned Lean and mathlib versions. With Elan and Git installed, run these commands from the extracted directory.

```sh
shasum -a 256 -c MANIFEST.sha256
lake exe cache get
lake build
lake env lean Prize/Audit.lean
```

The last command reports the axioms for 30 declarations. The final equality and sharpness theorem use propext, Classical.choice and Quot.sound. The proof entry points are in [FortyExact.lean](Prize/JSP404/FortyExact.lean). The [verification record](verification/record.json) includes the checksums, dependency pins and axiom reports from the 9,098-declaration full project audit and the standalone build. To regenerate the finite tables run `python3 scripts/export_sector22_forty.py` before checking the manifest.

## The lower and upper bounds

Measure directions in units of π/11. If every angle is less than nine units, dividing the full circle into 22 sectors gives a classification of the rays from each vertex. Single-arc vertices have starting directions more than two units apart, so there are at most ten. For the middle family, each vertex uses four distinct slots in a set of 110. Opposite directions at the ends of every segment make the slots at different vertices disjoint. This gives at most 27 vertices. At any remaining vertex all angles fall in [0,1), (4,5) or (8,9). Three such angles cannot add to eleven, so a triangle cannot have three vertices in this final family. The total is at most 39. The existing planar three-cluster construction supplies the matching upper bound at 40.

The ordinary point counts from 3 to 32 were verified in earlier work. This package also certifies the intervals [(2117/2645)π, (9/11)π] for 33 to 39 points and [(9/11)π, (5/6)π] for 41 to 62 points.
