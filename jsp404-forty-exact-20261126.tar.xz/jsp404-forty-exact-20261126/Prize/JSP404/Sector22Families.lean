import Prize.JSP404.Sector22Angles
import Mathlib.Data.Fintype.Prod

/-! Partition the vertices and count the middle and single-arc families. -/
namespace Prize.JSP404.Sector22
open FiniteCliqueCertificate
variable {V : Type*} [Fintype V]

def Model.Fits (M : Model V) (u : V) (i : Pattern) : Prop :=
  ∀ v, u ≠ v → has i (M.bin u v) = true
def Model.Star (M : Model V) (u : V) (r : Sector) : Prop :=
  M.Fits u (8, r) ∧ ∀ j : Fin 5, ∃ v, u ≠ v ∧ localGroup j r (M.bin u v) = true

theorem Model.classify (M : Model V) (u : V) :
    (∃ r, M.Fits u (0, r)) ∨ (∃ m, M.Fits u (middle m)) ∨ ∃ r, M.Star u r := by
  classical
  by_cases hm : ∃ m, M.Fits u (middle m)
  · exact Or.inr (Or.inl hm)
  let s := (Finset.univ.erase u).image (M.bin u)
  have hc : Clique graph s := by
    intro b hb c hc hbc
    obtain ⟨v, hv, rfl⟩ := Finset.mem_image.mp hb
    obtain ⟨w, hw, rfl⟩ := Finset.mem_image.mp hc
    simpa [graph, hbc] using M.bin_close (Finset.mem_erase.mp hv).1.symm (Finset.mem_erase.mp hw).1.symm
  obtain ⟨⟨i, r⟩, hi⟩ := cover s hc
  have hf : M.Fits u (i,r) := fun v hv => hi _ (Finset.mem_image.mpr ⟨v, by simp [hv.symm], rfl⟩)
  by_cases hz : i = 0
  · exact Or.inl ⟨r, hz ▸ hf⟩
  by_cases he : i = 8
  · subst i
    refine Or.inr (Or.inr ⟨r, hf, ?_⟩)
    intro j
    by_contra h
    apply hm
    refine ⟨replacement j r, fun v hv => missing_covered j r _ (hf v hv) ?_⟩
    exact Bool.eq_false_iff.mpr (fun hh => h ⟨v, hv, hh⟩)
  · let m : Middle := (⟨i.val - 1, by have : i.val ≠ 8 := fun h => he (Fin.ext h); omega⟩,r)
    have hi' : middle m = (i,r) := by
      refine Prod.ext ?_ rfl
      apply Fin.ext
      have h : i.val ≠ 0 := fun h => hz (Fin.ext h)
      change i.val - 1 + 1 = i.val
      omega
    exact False.elim (hm ⟨m, hi' ▸ hf⟩)

omit [Fintype V] in
theorem Model.middle_card (M : Model V) (s : Finset V)
    (hs : ∀ u ∈ s, ∃ m, M.Fits u (middle m)) : s.card ≤ 27 := by
  classical
  choose m hm using fun u : s => hs u u.property
  let f : s × Fin 4 → Fin 110 := fun p => slot (m p.1) p.2
  have hinj : Function.Injective f := by
    rintro ⟨u,i⟩ ⟨v,j⟩ he
    change slot (m u) i = slot (m v) j at he
    have huv : u = v := by
      by_contra hn
      have hn' : (u : V) ≠ (v : V) := fun hx => hn (Subtype.ext hx)
      have hu := slot_accepts (m u) i _ (hm u v hn')
      have hv := slot_accepts (m v) j _ (hm v u hn'.symm)
      rw [M.bin_reverse hn', ← he, accepts_excludes_antipode _ _ hu] at hv
      exact Bool.false_ne_true hv
    subst v
    exact Prod.ext rfl (slot_injective _ _ _ he)
  have h := Fintype.card_le_of_injective f hinj
  simp only [Fintype.card_prod, Fintype.card_fin, Fintype.card_coe] at h
  omega

/-- Eleven points with mutual circular separations greater than two cannot
fit on a circle of length twenty-two. Anchor the half-open bins at one point. -/
theorem card_le_ten_of_separated {W : Type*} [Fintype W] (x : W → ℝ)
    (hs : ∀ i j, i ≠ j → ∀ k : ℤ, 2 < |x i - x j + 22*k|) : Fintype.card W ≤ 10 := by
  classical
  rcases isEmpty_or_nonempty W with h | ⟨⟨o⟩⟩
  · simp
  let q (i : W) := ⌊(x i-x o)/22⌋
  let r (i : W) := x i-x o-22*q i
  have hr (i : W) : 0 ≤ r i ∧ r i < 22 := by
    have h₁ := Int.floor_le ((x i-x o)/22)
    have h₂ := Int.lt_floor_add_one ((x i-x o)/22)
    dsimp [r,q]; constructor <;> linarith
  have h₀ : r o = 0 := by simp [r,q]
  have h₂₀ (i : W) : r i < 20 := by
    by_cases hi : i = o
    · rw [hi,h₀]; norm_num
    have h := hs i o hi (-q i-1)
    have he : x i - x o + 22*((-q i-1 : ℤ):ℝ) = r i-22 := by
      dsimp [r]; push_cast; ring
    rw [he, abs_of_neg (by linarith [(hr i).2])] at h
    linarith
  let f (i : W) : Fin 10 := ⟨⌊r i/2⌋₊, (Nat.floor_lt (by linarith [(hr i).1])).mpr
    (by norm_num; linarith [h₂₀ i])⟩
  apply (Fintype.card_le_of_injective f ?_).trans_eq (Fintype.card_fin 10)
  intro i j he
  by_contra hn
  have h := hs i j hn (-q i + q j)
  have he' : x i - x j + 22*((-q i + q j : ℤ) : ℝ) = r i-r j := by
    dsimp [r]; push_cast; ring
  rw [he'] at h
  have hf : ⌊r i/2⌋₊ = ⌊r j/2⌋₊ := congrArg Fin.val he
  have a := Nat.floor_le (show 0 ≤ r i/2 by linarith [(hr i).1])
  have b := Nat.lt_floor_add_one (r i/2)
  have c := Nat.floor_le (show 0 ≤ r j/2 by linarith [(hr j).1])
  have d := Nat.lt_floor_add_one (r j/2)
  rw [hf] at a b
  exact (not_le_of_gt h) (abs_le.mpr ⟨by linarith, by linarith⟩)

theorem Model.arc_start (M : Model V) {u : V} {r : Sector} (hf : M.Fits u (0,r)) :
    ∃ a : ℝ, ∀ v, u ≠ v → ∃ k : ℤ, a ≤ M.raw u v + 22*k ∧ M.raw u v + 22*k < a+9 := by
  classical
  let S := (Finset.univ.erase u).image (M.coord r u)
  have member {v} (h : u ≠ v) : M.coord r u v ∈ S :=
    Finset.mem_image.mpr ⟨v, by simp [h.symm], rfl⟩
  by_cases hn : S.Nonempty
  · obtain ⟨w, hw, hw'⟩ := Finset.mem_image.mp (Finset.min'_mem S hn)
    have huw : u ≠ w := (Finset.mem_erase.mp hw).1.symm
    refine ⟨r.val + M.coord r u w, ?_⟩
    intro v huv
    have hmin : M.coord r u w ≤ M.coord r u v := hw'.trans_le (Finset.min'_le _ _ (member huv))
    have hV := M.coord_mem r u v
    have hb : (offset r (M.bin u v) : ℝ) ≤ 9 := by exact_mod_cast arc_offsets r _ (hf v huv)
    have hW := (M.coord_range r u w).1
    have ha := M.bound u v w huv huw
    rw [M.ang_coord r huv huw, circleDist, abs_of_nonneg (sub_nonneg.mpr hmin),
      min_eq_left (by linarith [hV.2])] at ha
    obtain ⟨k,hk⟩ := M.raw_coord r u v
    exact ⟨-k, by push_cast; linarith, by push_cast; linarith⟩
  · exact ⟨0, fun v hv => False.elim (hn ⟨_,member hv⟩)⟩

theorem Model.arc_card (M : Model V) (s : Finset V)
    (hs : ∀ u ∈ s, ∃ r, M.Fits u (0,r)) : s.card ≤ 10 := by
  classical
  choose r hr using fun u : s => hs u u.property
  choose a ha using fun u : s => M.arc_start (hr u)
  have bound := card_le_ten_of_separated a (by
    intro u v huv k
    have hne : (u : V) ≠ (v : V) := fun he => huv (Subtype.ext he)
    obtain ⟨i, hi₁, hi₂⟩ := ha u v hne
    obtain ⟨j, hj₁, hj₂⟩ := ha v u hne.symm
    obtain ⟨l, hl⟩ := M.reverse u v hne
    by_contra! h
    have hab := abs_le.mp h
    by_cases hsign : 0 ≤ l+j-i-k
    · have hh : (0:ℝ) ≤ (l:ℝ)+j-i-k := by exact_mod_cast hsign
      linarith [hab.2]
    · have hh : (l:ℝ)+j-i-k ≤ -1 := by exact_mod_cast (show l+j-i-k ≤ -1 by omega)
      linarith [hab.1])
  simpa using bound

end Prize.JSP404.Sector22
