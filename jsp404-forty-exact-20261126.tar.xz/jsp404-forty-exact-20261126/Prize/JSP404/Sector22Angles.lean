import Prize.JSP404.Sector22Finite
import Prize.JSP404.Sector26Quantization
import Mathlib.Geometry.Euclidean.Triangle

/-! Lifted direction coordinates in units of π/11. The angle sum is
retained so the model can exclude triples of five-group vertices. -/
namespace Prize.JSP404.Sector22

structure Model (V : Type*) where
  raw : V → V → ℝ
  ang : V → V → V → ℝ
  reverse : ∀ u v, u ≠ v → ∃ k : ℤ, raw v u = raw u v + 11 + 22*k
  lift : ∀ u v w, u ≠ v → u ≠ w →
    ∃ k : ℤ, ang u v w = |raw u v - raw u w + 22*k|
  bound : ∀ u v w, u ≠ v → u ≠ w → ang u v w < 9
  triangle : ∀ u v w, u ≠ v → u ≠ w → v ≠ w →
    ang u v w + ang v w u + ang w u v = 11

noncomputable def scaled (x : ℝ) : ℝ := 11 * x / Real.pi

theorem model_of_complex {V : Type*} (p : V → ℂ) (hp : Function.Injective p)
    (h : ∀ u v w, u ≠ v → u ≠ w → v ≠ w →
      EuclideanGeometry.angle (p v) (p u) (p w) < 9 * Real.pi / 11) :
    Nonempty (Model V) := by
  let z (u v : V) := p v - p u
  have hn (u v : V) (hu : u ≠ v) : z u v ≠ 0 := sub_ne_zero.mpr (hp.ne hu.symm)
  refine ⟨{ raw := fun u v => scaled (z u v).arg
            ang := fun u v w => scaled (EuclideanGeometry.angle (p v) (p u) (p w))
            reverse := ?_, lift := ?_, bound := ?_, triangle := ?_ }⟩
  · intro u v huv
    have he : ((z v u).arg : Real.Angle) = (((z u v).arg + Real.pi : ℝ) : Real.Angle) := by
      rw [show z v u = -(z u v) by dsimp [z]; abel]
      simpa only [Real.Angle.coe_add] using Complex.arg_neg_coe_angle (hn u v huv)
    obtain ⟨k, hk⟩ := Real.Angle.angle_eq_iff_two_pi_dvd_sub.mp he
    refine ⟨k, ?_⟩
    unfold scaled
    field_simp
    nlinarith
  · intro u v w huv huw
    have he : ((z u v).arg : Real.Angle) =
        ((((z u w).arg + (z u v / z u w).arg) : ℝ) : Real.Angle) := by
      rw [Real.Angle.coe_add, Complex.arg_div_coe_angle (hn u v huv) (hn u w huw)]
      abel
    obtain ⟨k, hk⟩ := Real.Angle.angle_eq_iff_two_pi_dvd_sub.mp he
    refine ⟨-k, ?_⟩
    change scaled (InnerProductGeometry.angle (z u v) (z u w)) = _
    have hd : scaled (z u v).arg - scaled (z u w).arg + 22*((-k : ℤ) : ℝ) =
        scaled (z u v / z u w).arg := by
      unfold scaled
      push_cast
      field_simp
      nlinarith
    rw [hd, Complex.angle_eq_abs_arg (hn u v huv) (hn u w huw)]
    simp [scaled, abs_div, abs_mul, abs_of_pos Real.pi_pos]
  · intro u v w huv huw
    by_cases hvw : v = w
    · subst w
      change scaled (InnerProductGeometry.angle (z u v) (z u v)) < 9
      rw [InnerProductGeometry.angle_self (hn u v huv)]
      norm_num [scaled]
    · exact (div_lt_iff₀ Real.pi_pos).mpr (by linarith [h u v w huv huw hvw])
  · intro u v w huv huw hvw
    have ht := EuclideanGeometry.angle_add_angle_add_angle_eq_pi (p w) (hp.ne huv.symm)
    rw [EuclideanGeometry.angle_comm (p u) (p v) (p w),
      EuclideanGeometry.angle_comm (p v) (p w) (p u),
      EuclideanGeometry.angle_comm (p w) (p u) (p v)] at ht
    unfold scaled
    field_simp
    linarith

def residue (z : ℤ) : Sector := ⟨(z % 22).toNat, by omega⟩
noncomputable def Model.bin {V : Type*} (M : Model V) (u v : V) : Sector := residue ⌊M.raw u v⌋

theorem Model.bin_reverse {V : Type*} (M : Model V) {u v : V} (h : u ≠ v) :
    M.bin v u = antipode (M.bin u v) := by
  obtain ⟨k, hk⟩ := M.reverse u v h
  have he : M.raw v u = M.raw u v + ((11 + 22*k : ℤ) : ℝ) := by push_cast; linarith
  apply Fin.ext
  simp only [Model.bin, he, Int.floor_add_intCast, residue, antipode]
  omega

theorem Model.bin_close {V : Type*} (M : Model V) {u v w : V} (hv : u ≠ v) (hw : u ≠ w) :
    distance (M.bin u v) (M.bin u w) ≤ 9 := by
  obtain ⟨k, hk⟩ := M.lift u v w hv hw
  have ha := M.bound u v w hv hw
  rw [hk, abs_lt] at ha
  have hx := Int.floor_le (M.raw u v)
  have hx' := Int.lt_floor_add_one (M.raw u v)
  have hy := Int.floor_le (M.raw u w)
  have hy' := Int.lt_floor_add_one (M.raw u w)
  have hb : -10 < ⌊M.raw u v⌋ - ⌊M.raw u w⌋ + 22 * k ∧
      ⌊M.raw u v⌋ - ⌊M.raw u w⌋ + 22 * k < 10 := by
    constructor
    · have hh : (-10 : ℝ) < (⌊M.raw u v⌋ : ℝ) - (⌊M.raw u w⌋ : ℝ) + 22 * k := by linarith [ha.1]
      exact_mod_cast hh
    · have hh : (⌊M.raw u v⌋ : ℝ) - (⌊M.raw u w⌋ : ℝ) + 22 * k < 10 := by linarith [ha.2]
      exact_mod_cast hh
  simp only [distance, offset, Model.bin, residue]
  omega

noncomputable def Model.coord {V : Type*} (M : Model V) (r : Sector) (u v : V) : ℝ :=
  (offset r (M.bin u v) : ℝ) + Int.fract (M.raw u v)

theorem Model.coord_mem {V : Type*} (M : Model V) (r : Sector) (u v : V) :
    (offset r (M.bin u v) : ℝ) ≤ M.coord r u v ∧
    M.coord r u v < (offset r (M.bin u v) : ℝ) + 1 := by
  simpa [Model.coord] using And.intro (Int.fract_nonneg (M.raw u v)) (Int.fract_lt_one (M.raw u v))

theorem Model.coord_range {V : Type*} (M : Model V) (r : Sector) (u v : V) :
    0 ≤ M.coord r u v ∧ M.coord r u v < 22 := by
  have hh := M.coord_mem r u v
  have hl : (0 : ℝ) ≤ offset r (M.bin u v) := Nat.cast_nonneg _
  have hn : offset r (M.bin u v) < 22 := Nat.mod_lt _ (by decide)
  have hu : (offset r (M.bin u v) : ℝ) ≤ 21 := by exact_mod_cast (show offset r (M.bin u v) ≤ 21 by omega)
  constructor <;> linarith [hh.1, hh.2]

theorem Model.raw_coord {V : Type*} (M : Model V) (r : Sector) (u v : V) :
    ∃ k : ℤ, M.raw u v = r.val + M.coord r u v + 22*k := by
  let q := ⌊M.raw u v⌋
  have hq : q = (r.val : ℤ) + (offset r (M.bin u v) : ℤ) + 22 * ((q - r.val) / 22) := by
    dsimp [Model.bin, residue, offset, q]
    omega
  refine ⟨(q-r.val)/22, ?_⟩
  have hr := congrArg (Int.cast : ℤ → ℝ) hq
  push_cast at hr
  change M.raw u v = r.val + ((offset r (M.bin u v) : ℝ) + (M.raw u v - (q : ℝ))) + _
  linarith only [hr]

def circleDist (x y : ℝ) : ℝ := min |x-y| (22 - |x-y|)

theorem Model.ang_coord {V : Type*} (M : Model V) (r : Sector) {u v w : V}
    (hv : u ≠ v) (hw : u ≠ w) : M.ang u v w = circleDist (M.coord r u v) (M.coord r u w) := by
  obtain ⟨i, hi⟩ := M.raw_coord r u v
  obtain ⟨j, hj⟩ := M.raw_coord r u w
  obtain ⟨k, hk⟩ := M.lift u v w hv hw
  have he : M.ang u v w = |M.coord r u v - M.coord r u w + 22*((i-j+k : ℤ) : ℝ)| := by
    rw [hk, hi, hj]
    push_cast
    congr 1
    ring
  have ha := M.bound u v w hv hw
  have h₁ := M.coord_range r u v
  have h₂ := M.coord_range r u w
  generalize i - j + k = z at he
  have hh := abs_lt.mp (he.symm.trans_lt ha)
  have hl : -1 ≤ z := by
    by_contra! hn
    have hn' : (z : ℝ) ≤ -2 := by exact_mod_cast (show z ≤ -2 by omega)
    linarith [h₁.1,h₁.2,h₂.1,h₂.2,hh.2]
  have hu : z ≤ 1 := by
    by_contra! hn
    have hn' : (2 : ℝ) ≤ z := by exact_mod_cast (show 2 ≤ z by omega)
    linarith [h₁.1,h₁.2,h₂.1,h₂.2,hh.2]
  unfold circleDist
  interval_cases z <;> norm_num at he hh <;> rw [he] <;>
    simp only [min_def, abs_eq_max_neg, max_def] <;> split_ifs <;>
    linarith [h₁.1,h₁.2,h₂.1,h₂.2,hh.1,hh.2]

end Prize.JSP404.Sector22
