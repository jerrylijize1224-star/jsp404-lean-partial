import Prize.JSP404.Sector22Families

/-! A row meeting all five groups forces each angle into one of three
strict ranges. No three such vertices can form a planar triangle. -/
namespace Prize.JSP404.Sector22

def groupLo : Fin 5 → ℕ | 0 => 0 | 1 => 4 | 2 => 8 | 3 => 13 | 4 => 17
def groupHi : Fin 5 → ℕ | 0 => 1 | 1 => 5 | 2 => 10 | 3 => 14 | 4 => 18

theorem group_offsets : ∀ (i : Fin 5) (r b : Sector), localGroup i r b = true →
    groupLo i ≤ offset r b ∧ offset r b < groupHi i := by decide +kernel

def AngleBand (a : ℝ) : Prop := (0 ≤ a ∧ a < 1) ∨ (4 < a ∧ a < 5) ∨ (8 < a ∧ a < 9)

private theorem circle_near {x y : ℝ} (hl : 0 ≤ x-y) (hu : x-y ≤ 11) :
    circleDist x y = x-y := by
  rw [circleDist, abs_of_nonneg hl, min_eq_left (by linarith)]

private theorem circle_far {x y : ℝ} (hl : 11 ≤ x-y) : circleDist x y = 22-(x-y) := by
  rw [circleDist, abs_of_nonneg (by linarith), min_eq_right (by linarith)]

private theorem circle_symm (x y : ℝ) : circleDist x y = circleDist y x := by
  simp only [circleDist, abs_sub_comm x y]

private theorem band_same {x y : ℝ} (h₁ : x-y < 1) (h₂ : y-x < 1) : AngleBand (circleDist x y) := by
  have h : |x-y| < 1 := abs_lt.mpr ⟨by linarith, h₁⟩
  left
  rw [circleDist, min_eq_left (by linarith)]
  exact ⟨abs_nonneg _, h⟩

private theorem band_four {x y : ℝ} (hl : 4 < y-x) (hu : y-x < 5) : AngleBand (circleDist x y) := by
  rw [circle_symm, circle_near (by linarith) (by linarith)]
  exact Or.inr (Or.inl ⟨hl,hu⟩)

private theorem band_eight {x y : ℝ} (hl : 8 < y-x) (hu : y-x < 9) : AngleBand (circleDist x y) := by
  rw [circle_symm, circle_near (by linarith) (by linarith)]
  exact Or.inr (Or.inr ⟨hl,hu⟩)

private theorem band_four_wrap {x y : ℝ} (hl : 4 < 22-(y-x)) (hu : 22-(y-x) < 5) : AngleBand (circleDist x y) := by
  rw [circle_symm, circle_far (by linarith)]
  exact Or.inr (Or.inl ⟨hl,hu⟩)

private theorem band_eight_wrap {x y : ℝ} (hl : 8 < 22-(y-x)) (hu : 22-(y-x) < 9) : AngleBand (circleDist x y) := by
  rw [circle_symm, circle_far (by linarith)]
  exact Or.inr (Or.inr ⟨hl,hu⟩)

/-- The five directed gaps skipping one group are each shorter than nine.
Two disjoint such gaps leave more than four units in the complementary gap. -/
theorem five_window_band (lo hi : Fin 5 → ℝ)
    (ranges : ∀ i, (groupLo i : ℝ) ≤ lo i ∧ lo i ≤ hi i ∧ hi i < groupHi i)
    (close : ∀ i j, circleDist (hi i) (lo j) < 9)
    (i j : Fin 5) (x y : ℝ) (hx : lo i ≤ x ∧ x ≤ hi i) (hy : lo j ≤ y ∧ y ≤ hi j) :
    AngleBand (circleDist x y) := by
  wlog ordered : i.val ≤ j.val generalizing i j x y
  · rw [circle_symm]
    exact this j i y x hy hx (by omega)
  have b0 := ranges 0
  have b1 := ranges 1
  have b2 := ranges 2
  have b3 := ranges 3
  have b4 := ranges 4
  norm_num [groupLo,groupHi] at b0 b1 b2 b3 b4
  obtain ⟨l0,o0,h0⟩ := b0
  obtain ⟨l1,o1,h1⟩ := b1
  obtain ⟨l2,o2,h2⟩ := b2
  obtain ⟨l3,o3,h3⟩ := b3
  obtain ⟨l4,o4,h4⟩ := b4
  have c0 := close 2 0
  have c1 := close 3 1
  have c2 := close 4 2
  -- Wrapped bounds use the high endpoint after the cut and the low one before it.
  have c3 := close 0 3
  have c4 := close 1 4
  rw [circle_near (by linarith) (by linarith)] at c0 c1 c2
  rw [circle_symm, circle_far (by linarith)] at c3 c4
  obtain ⟨xl,xh⟩ := hx
  obtain ⟨yl,yh⟩ := hy
  have casesOf : ∀ t : Fin 5, t = 0 ∨ t = 1 ∨ t = 2 ∨ t = 3 ∨ t = 4 := by decide +kernel
  rcases casesOf i with rfl | rfl | rfl | rfl | rfl <;>
    rcases casesOf j with rfl | rfl | rfl | rfl | rfl <;> norm_num at ordered
  · apply band_same <;> linarith
  · apply band_four <;> linarith
  · apply band_eight <;> linarith
  · apply band_eight_wrap <;> linarith
  · apply band_four_wrap <;> linarith
  · apply band_same <;> linarith
  · apply band_four <;> linarith
  · apply band_eight <;> linarith
  · apply band_eight_wrap <;> linarith
  · apply band_same <;> linarith
  · apply band_four <;> linarith
  · apply band_eight <;> linarith
  · apply band_same <;> linarith
  · apply band_four <;> linarith
  · apply band_same <;> linarith

theorem triangle_not_banded {a b c : ℝ} (ha : AngleBand a) (hb : AngleBand b) (hc : AngleBand c) :
    a+b+c ≠ 11 := by
  rcases ha with ⟨_,_⟩ | ⟨_,_⟩ | ⟨_,_⟩ <;>
    rcases hb with ⟨_,_⟩ | ⟨_,_⟩ | ⟨_,_⟩ <;>
    rcases hc with ⟨_,_⟩ | ⟨_,_⟩ | ⟨_,_⟩ <;> linarith

variable {V : Type*} [Fintype V]

theorem Model.star_band (M : Model V) {u v w : V} {r : Sector}
    (star : M.Star u r) (hv : u ≠ v) (hw : u ≠ w) : AngleBand (M.ang u v w) := by
  classical
  let part (i : Fin 5) := ((Finset.univ.erase u).filter
    (fun z => localGroup i r (M.bin u z) = true)).image (M.coord r u)
  have mem (i : Fin 5) {z : V} (hz : u ≠ z) (h : localGroup i r (M.bin u z) = true) :
      M.coord r u z ∈ part i := Finset.mem_image.mpr ⟨z, by simp [hz.symm,h], rfl⟩
  have live (i : Fin 5) : (part i).Nonempty := by
    obtain ⟨z,hz,hg⟩ := star.2 i
    exact ⟨_,mem i hz hg⟩
  let lo (i : Fin 5) := (part i).min' (live i)
  let hi (i : Fin 5) := (part i).max' (live i)
  have source {i} {x : ℝ} (h : x ∈ part i) :
      ∃ z, u ≠ z ∧ localGroup i r (M.bin u z) = true ∧ M.coord r u z = x := by
    obtain ⟨z,hz,he⟩ := Finset.mem_image.mp h
    obtain ⟨hn,hg⟩ := Finset.mem_filter.mp hz
    exact ⟨z,(Finset.mem_erase.mp hn).1.symm,hg,he⟩
  have domain {i x} (hx : x ∈ part i) : (groupLo i : ℝ) ≤ x ∧ x < groupHi i := by
    obtain ⟨z,_,hg,rfl⟩ := source hx
    obtain ⟨hl,hh⟩ := group_offsets _ _ _ hg
    have hl' : (groupLo i : ℝ) ≤ offset r (M.bin u z) := by exact_mod_cast hl
    have hh' : (offset r (M.bin u z) : ℝ) + 1 ≤ groupHi i := by
      exact_mod_cast (show offset r (M.bin u z) + 1 ≤ groupHi i by omega)
    exact ⟨hl'.trans (M.coord_mem r u z).1,(M.coord_mem r u z).2.trans_le hh'⟩
  have extremes (i) : (groupLo i : ℝ) ≤ lo i ∧ lo i ≤ hi i ∧ hi i < groupHi i :=
    ⟨(domain (Finset.min'_mem _ (live i))).1,
      Finset.min'_le _ _ (Finset.max'_mem _ (live i)),(domain (Finset.max'_mem _ (live i))).2⟩
  have close (i j) : circleDist (hi i) (lo j) < 9 := by
    obtain ⟨a,ha,_,hea⟩ := source (Finset.max'_mem _ (live i))
    obtain ⟨b,hb,_,heb⟩ := source (Finset.min'_mem _ (live j))
    have h := M.bound u a b ha hb
    rwa [M.ang_coord r ha hb, hea, heb] at h
  obtain ⟨i,hi'⟩ := star_offsets _ _ (star.1 v hv)
  obtain ⟨j,hj'⟩ := star_offsets _ _ (star.1 w hw)
  rw [M.ang_coord r hv hw]
  exact five_window_band lo hi extremes close i j _ _
    ⟨Finset.min'_le _ _ (mem i hv hi'), Finset.le_max' _ _ (mem i hv hi')⟩
    ⟨Finset.min'_le _ _ (mem j hw hj'), Finset.le_max' _ _ (mem j hw hj')⟩

theorem Model.star_card (M : Model V) (s : Finset V)
    (hs : ∀ u ∈ s, ∃ r, M.Star u r) : s.card ≤ 2 := by
  classical
  by_contra! h
  obtain ⟨u,v,w,hu,hv,hw,huv,huw,hvw⟩ := Finset.two_lt_card_iff.mp h
  obtain ⟨_,su⟩ := hs u hu
  obtain ⟨_,sv⟩ := hs v hv
  obtain ⟨_,sw⟩ := hs w hw
  exact triangle_not_banded (M.star_band su huv huw) (M.star_band sv hvw huv.symm)
    (M.star_band sw huw.symm hvw.symm) (M.triangle u v w huv huw hvw)

end Prize.JSP404.Sector22
