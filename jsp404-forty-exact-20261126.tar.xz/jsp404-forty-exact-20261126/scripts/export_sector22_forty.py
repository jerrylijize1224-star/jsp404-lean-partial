"""Render the finite 22-sector data for the first band above 32 points.

Lean checks the cover tree, four distinct completions of each middle row,
antipodal disjointness of the completions, and the five missing-group covers.
The generator uses only Python's standard library.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
N = 22
FULL = (1 << N) - 1
MIDDLE = [9201, 17379, 25569, 33735, 50115, 58305, 99207]
BASES = [1023, *MIDDLE, 140049]
WORDS = [0x67F3, 0x67F3, 0x187CF, 0x1C7C7, 0x1E7C3]


def rotate(mask, n):
    return ((mask << n) | (mask >> (N - n))) & FULL


def bits(mask):
    return [j for j in range(N) if mask & (1 << j)]


types = [rotate(mask, r) for mask in BASES for r in range(N)]
words = [rotate(mask, r) for mask in WORDS for r in range(N)]
neighbors = [sum(1 << j for j in range(N)
                 if 0 < min((j-i) % N, (i-j) % N) <= 9) for i in range(N)]


def cover(pool, required):
    for i, row in enumerate(types):
        if (pool | required) & ~row == 0:
            return f'(.leaf ({i // N}, {i % N}))'
    v = max(bits(pool), key=lambda j: len(bits(pool & ~neighbors[j])))
    rest = pool ^ (1 << v)
    return f'(.split {v} {cover(rest, required)} {cover(rest & neighbors[v], required | (1 << v))})'


def lean_array(xs):
    return '#[' + ', '.join(map(str, xs)) + ']'


slots = []
for row in types[N:-N]:
    ids = [i for i, w in enumerate(words) if row & ~w == 0]
    assert len(ids) >= 4
    slots.append(lean_array(ids[:4]))

# Removing one whole group from the canonical five-group pattern leaves a
# subset of a checked middle pattern. Rotation supplies all 22 origins.
omission = []
for cluster in ([0], [4], [8, 9], [13], [17]):
    rest = BASES[-1] & ~sum(1 << j for j in cluster)
    i = next(i for i, row in enumerate(types[N:-N]) if rest & ~row == 0)
    omission.append(f'({i // N}, {i % N})')

data = '''import Prize.JSP404.IndexedCliqueCover

/-! The finite direction patterns at the angular threshold 9π/11. -/
namespace Prize.JSP404.Sector22
open FiniteCliqueCertificate
set_option maxRecDepth 65536
set_option maxHeartbeats 0

abbrev Sector := Fin 22
abbrev Pattern := Fin 9 × Sector
abbrev Middle := Fin 7 × Sector

def offset (r b : Sector) : ℕ := (b.val + 22 - r.val) % 22
def antipode (b : Sector) : Sector := ⟨(b.val + 11) % 22, by omega⟩
def distance (a b : Sector) : ℕ := min (offset a b) (offset b a)
def graph (a b : Sector) : Bool := decide (a ≠ b ∧ distance a b ≤ 9)
'''
data += 'def base : Array Nat := ' + lean_array(BASES) + '\n'
data += '''def has (i : Pattern) (b : Sector) : Bool := (base[i.1.val]?.getD 0).testBit (offset i.2 b)
def labels (i : Pattern) : List Sector := (List.finRange 22).filter (has i)
def middle (m : Middle) : Pattern := (⟨m.1.val + 1, by omega⟩, m.2)
def cluster (j : Fin 5) : List Nat := [[0], [4], [8, 9], [13], [17]][j.val]?.getD []
def localGroup (j : Fin 5) (r b : Sector) := (cluster j).contains (offset r b)
'''
data += 'def coverTree : IndexedCoverCertificate Sector Pattern := ' + cover(FULL, 0) + '\n'
data += '''theorem cover (s : Finset Sector) (hs : Clique graph s) :
    ∃ i : Pattern, ∀ b ∈ s, has i b = true := by
  have checked : indexedCoverCheck graph labels (List.finRange 22) [] coverTree = true := by
    decide +kernel
  obtain ⟨i, _, hi⟩ := indexedCoverCheck_sound graph labels coverTree _ _ checked s (by simp) hs
  exact ⟨i, fun b hb => (List.mem_filter.mp (hi b hb)).2⟩
'''
data += 'def missingGroup : Array Middle := ' + lean_array(omission) + '\n'
data += '''def replacement (j : Fin 5) (r : Sector) : Middle :=
  let m := missingGroup[j.val]?.getD (0, 0)
  (m.1, ⟨(m.2.val + r.val) % 22, by omega⟩)
theorem missing_covered : ∀ (j : Fin 5) (r b : Sector),
    has (8, r) b = true → localGroup j r b = false →
    has (middle (replacement j r)) b = true := by decide +kernel
theorem arc_offsets : ∀ r b : Sector, has (0, r) b = true → offset r b ≤ 9 := by
  decide +kernel
theorem star_offsets : ∀ r b : Sector, has (8, r) b = true →
    ∃ j : Fin 5, localGroup j r b = true := by decide +kernel
'''
data += 'def words : Array Nat := ' + lean_array(WORDS) + '\n'
data += '''def accepts (c : Fin 110) (b : Sector) : Bool :=
  (words[c.val / 22]?.getD 0).testBit (offset ⟨c.val % 22, by omega⟩ b)
'''
data += 'def slots : Array (Array (Fin 110)) := ' + lean_array(slots) + '\n'
data += '''def slot (m : Middle) (j : Fin 4) : Fin 110 :=
  ((slots[m.1.val * 22 + m.2.val]?.getD #[])[j.val]?).getD 0
theorem slot_injective : ∀ (m : Middle) (i j : Fin 4), slot m i = slot m j → i = j := by
  rw [Prod.forall]
  decide +kernel
theorem slot_accepts : ∀ (m : Middle) (j : Fin 4) (b : Sector),
    has (middle m) b = true → accepts (slot m j) b = true := by
  rw [Prod.forall]
  decide +kernel
theorem accepts_excludes_antipode : ∀ (c : Fin 110) (b : Sector),
    accepts c b = true → accepts c (antipode b) = false := by decide +kernel

end Prize.JSP404.Sector22
'''
(ROOT / 'Prize/JSP404/Sector22Finite.lean').write_text(data)
