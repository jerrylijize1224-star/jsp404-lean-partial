"""Explore necessary ordered-direction inequalities; not a Lean proof.

Label points by a generic projection. Forward edges have directions in (0,9).
For i<j<k, ij/ik/jk are strictly monotone; the middle angle is
9-|ij-jk| and the endpoint angles are |ij-ik| and |ik-jk|.
No claim that such an abstract assignment is geometrically realizable.
"""
import argparse
from fractions import Fraction as F
from itertools import combinations
import json
from pathlib import Path
import time
import z3


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--points', type=int, required=True)
    p.add_argument('--seconds', type=int, default=60)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--incremental', action='store_true', help='Check successive prefixes, retaining learned clauses')
    args = p.parse_args()
    assert args.points >= 3 and args.seconds > 0
    if args.output.exists():
        raise SystemExit('Output exists; choose a new path')
    n = args.points
    D = F(36,5)
    q = lambda x: z3.RealVal(str(x))
    s = z3.SolverFor('QF_RDL')
    s.set(timeout=args.seconds * 1000, random_seed=0)
    edges = {ij: z3.Real('q_%s_%s' % ij) for ij in combinations(range(n),2)}
    def add_prefix(k):
        for i in range(k):
            x = edges[i,k]
            s.add(0 < x, x < 9)
        for i,j in combinations(range(k),2):
            u,v,w = edges[i,j],edges[i,k],edges[j,k]
            s.add(z3.Or(z3.And(u<v,v<w,v-u<q(D),w-v<q(D),q(9-D)<w-u),
                        z3.And(w<v,v<u,u-v<q(D),v-w<q(D),q(9-D)<u-w)))
        if k == 2:
            # Reflection preserves projection order and reverses directions.
            s.add(edges[0,1] < edges[0,2])
    start=time.monotonic()
    stages=[]
    for k in range(n):
        add_prefix(k)
        if k == n-1 or (args.incremental and k >= 2):
            remaining=max(1,int(1000*(args.seconds-(time.monotonic()-start))))
            s.set(timeout=remaining)
            step=time.monotonic()
            result=s.check()
            stages.append({'points':k+1,'result':str(result),'seconds':time.monotonic()-step})
            if result != z3.sat:
                break
    checked=k+1
    edges={ij:x for ij,x in edges.items() if ij[1]<checked}
    out={'scope':'Exploratory ordered direction inequalities, not a proof',
         'requested_points':n,'points':checked,'edges':len(edges),
         'triangles':checked*(checked-1)*(checked-2)//6,
         'limit':str(D),'result':str(result),'elapsed_seconds':time.monotonic()-start,
         'incremental':args.incremental,'stages':stages,
         'solver':z3.get_version_string()}
    if result==z3.unknown:
        out['reason']=s.reason_unknown()
    elif result==z3.sat:
        m=s.model();ev={ij:m.eval(x).as_fraction() for ij,x in edges.items()}
        assert all(0<x<9 for x in ev.values())
        angles=[]
        for i,j,k in combinations(range(checked),3):
            u,v,w=ev[i,j],ev[i,k],ev[j,k]
            assert u<v<w or w<v<u
            tri=[abs(v-u),abs(w-v),9-abs(w-u)]
            assert sum(tri)==9 and all(0<a<D for a in tri)
            angles.extend(tri)
        max_angle=max(angles)
        out.update(maximum_angle_units=str(max_angle),maximum_degrees=str(20*max_angle),
                   independent_fraction_check=True,
                   edge_directions={str(ij):str(x) for ij,x in ev.items()})
    args.output.write_text(json.dumps(out,indent=2)+'\n')
    print({k:v for k,v in out.items() if k!='edge_directions'})


if __name__=='__main__':
    main()
