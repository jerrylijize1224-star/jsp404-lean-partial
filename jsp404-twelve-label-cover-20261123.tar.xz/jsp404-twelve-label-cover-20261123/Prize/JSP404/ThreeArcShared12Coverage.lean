import Prize.JSP404.ThreeArcShared12Refutation
import Prize.JSP404.ThreeArcShared12Blocks

namespace Prize.JSP404.ThreeArcShared12Coverage
open ThreeArcShared12Lists
set_option maxRecDepth 32768
set_option maxHeartbeats 12000000

theorem context_eq : coverRefutation.ctx = ThreeArcShared12Blocks.context := by rfl

theorem all_covered (s : Finset Label) (hs : 12 ≤ s.card) :
    ∃ i : Index, (coreList i).toFinset ⊆ s := by
  classical
  by_contra h
  have hn (i : Index) : ¬ (coreList i).toFinset ⊆ s := fun hi => h ⟨i, hi⟩
  apply coverRefutation.unsat (FiniteCardinalityCNF.valuation s)
  rw [context_eq]
  exact ThreeArcShared12Blocks.satisfied s hs hn

end Prize.JSP404.ThreeArcShared12Coverage
