import Mathlib.Tactic.Sat.FromLRAT
import Mathlib.Data.Fintype.Fin
import Mathlib.Data.Finset.Card
import Mathlib.Data.List.FinRange
import Lean.Elab.Tactic.Omega

/-! An interpretation of a unary cardinality counter for a finite set of type labels.
If the clause list "these core lists cannot be contained in the set" together
with a cardinality lower bound has a refutation, one of the core lists must lie
in any set of that size. This lemma makes no assumption about geometry. -/
namespace Prize.JSP404.FiniteCardinalityCNF

abbrev Label := Fin 20

def counter (i j : Nat) : Nat := 20 + 32 * i + j

def below (s : Finset Label) (i : Nat) : Finset Label :=
  s.filter (fun t => t.val < i)

def valuation (s : Finset Label) : Sat.Valuation := fun v =>
  if h : v < 20 then (⟨v,h⟩ : Label) ∈ s
  else (v - 20) % 32 ≤ (below s ((v - 20) / 32)).card

theorem val_label (s : Finset Label) (i : Label) :
    valuation s i.val ↔ i ∈ s := by simp [valuation, i.isLt]

private theorem val_counter (s : Finset Label) (i j : Nat) (hj : j < 32) :
    valuation s (counter i j) ↔ j ≤ (below s i).card := by
  have h : ¬ counter i j < 20 := by unfold counter; omega
  have h1 : (counter i j - 20) % 32 = j := by unfold counter; omega
  have h2 : (counter i j - 20) / 32 = i := by unfold counter; omega
  simp [valuation, h, h1, h2]

private theorem below_succ (s : Finset Label) (i : Label) :
    below s (i.val + 1) = if i ∈ s then insert i (below s i.val) else below s i.val := by
  ext t
  by_cases hs : i ∈ s <;> by_cases ht : t = i
  · subst t; simp [below, hs]
  · have hv : t.val ≠ i.val := fun h => ht (Fin.ext h)
    have he : t.val < i.val + 1 ↔ t.val < i.val := by omega
    simp [below, hs, ht, he]
  · subst t; simp [below, hs]
  · have hv : t.val ≠ i.val := fun h => ht (Fin.ext h)
    have he : t.val < i.val + 1 ↔ t.val < i.val := by omega
    simp [below, hs, he]

private theorem card_below_succ (s : Finset Label) (i : Label) :
    (below s (i.val + 1)).card = (below s i.val).card + if i ∈ s then 1 else 0 := by
  have h : i ∉ below s i.val := by simp [below]
  rw [below_succ]
  split <;> simp [*, Finset.card_insert_of_notMem]

private def initClauses (k : Nat) : Sat.Fmla :=
  (List.range' 1 k).map fun j => [Sat.Literal.neg (counter 0 j)]

private def step (i : Label) (j : Nat) : Sat.Fmla :=
  [[.neg (counter (i.val+1) j), .pos (counter i.val j), .pos i.val],
   [.neg (counter (i.val+1) j), .pos (counter i.val j), .pos (counter i.val (j-1))]]

def sizeClauses (k : Nat) : Sat.Fmla :=
  initClauses k ++ ((List.finRange 20).flatMap fun i =>
    (List.range' 1 k).flatMap fun j => step i j) ++ ([[Sat.Literal.pos (counter 20 k)]] : Sat.Fmla)

private theorem step_sat (s : Finset Label) (i : Label) (j : Nat) (hj : j < 32)
    {c : Sat.Clause} (hc : c ∈ step i j) : (valuation s).satisfies c := by
  have hj' : j-1 < 32 := by omega
  have hb := card_below_succ s i
  unfold step at hc
  rcases List.mem_cons.mp hc with hfirst | hrest
  · subst c
    change valuation s (counter (i.val+1) j) → ¬ valuation s (counter i.val j) →
      ¬ valuation s i.val → False
    rw [val_counter _ _ _ hj, val_counter _ _ _ hj, val_label]
    intro h1 h2 hn
    simp [hn] at hb
    omega
  · have hlast := List.mem_singleton.mp hrest
    subst c
    change valuation s (counter (i.val+1) j) → ¬ valuation s (counter i.val j) →
      ¬ valuation s (counter i.val (j-1)) → False
    rw [val_counter _ _ _ hj, val_counter _ _ _ hj, val_counter _ _ _ hj']
    split at hb <;> omega

theorem size_sat (s : Finset Label) (k : Nat) (hk : k < 32) (hs : k ≤ s.card) :
    (valuation s).satisfies_fmla (sizeClauses k) := by
  constructor
  intro c hc
  unfold sizeClauses at hc
  rcases List.mem_append.mp hc with h | h
  · rcases List.mem_append.mp h with hin | hstep
    · obtain ⟨j,hj,rfl⟩ := List.mem_map.mp hin
      have hj' := List.mem_range'_1.mp hj
      change ¬ valuation s (counter 0 j)
      rw [val_counter _ _ _ (by omega)]
      simp [below] <;> omega
    · obtain ⟨i,_,hi⟩ := List.mem_flatMap.mp hstep
      obtain ⟨j,hj,hc⟩ := List.mem_flatMap.mp hi
      have hj' := List.mem_range'_1.mp hj
      exact step_sat s i j (by omega) hc
  · have he := List.mem_singleton.mp h
    subst c
    have hs' : below s 20 = s := by ext i; simp [below]
    change ¬ ¬ valuation s (counter 20 k)
    exact fun hn => hn ((val_counter _ _ _ hk).2 (by rw [hs']; exact hs))

def forbids (core : List Label) : Sat.Clause :=
  core.map (fun t => Sat.Literal.neg t.val)

theorem forbids_sat (s : Finset Label) (core : List Label)
    (bad : ¬ core.toFinset ⊆ s) : (valuation s).satisfies (forbids core) := by
  induction core with
  | nil => exact (bad (by simp)).elim
  | cons a rest ih =>
    change valuation s a.val → (valuation s).satisfies (forbids rest)
    intro ha
    apply ih
    intro hr
    apply bad
    intro x hx
    have h := List.mem_toFinset.mp hx
    rcases List.mem_cons.mp h with rfl | ht
    · exact (val_label _ _).mp ha
    · exact hr (List.mem_toFinset.mpr ht)

def formula (k : Nat) (cores : List (List Label)) : Sat.Fmla :=
  sizeClauses k ++ cores.map forbids

theorem covered_of_refutation (k : Nat) (hk : k < 32) (cores : List (List Label))
    (refute : (formula k cores).proof []) (s : Finset Label) (hs : k ≤ s.card) :
    ∃ core ∈ cores, core.toFinset ⊆ s := by
  classical
  by_contra hn
  apply refute (valuation s)
  constructor
  intro c hc
  rcases List.mem_append.mp hc with h | h
  · exact (size_sat s k hk hs).1 c h
  · obtain ⟨core,hcore,he⟩ := List.mem_map.mp h
    subst c
    exact forbids_sat s core (fun hh => hn ⟨core,hcore,hh⟩)


/-- A balanced conjunction is satisfied if its children are. The concrete
cover certificate uses the same conjunction tree as the LRAT importer. -/
theorem sat_and {v : Sat.Valuation} {f g : Sat.Fmla}
    (hf : v.satisfies_fmla f) (hg : v.satisfies_fmla g) : v.satisfies_fmla (f.and g) := by
  constructor
  intro c hc
  rcases List.mem_append.mp hc with h | h
  · exact hf.1 c h
  · exact hg.1 c h

theorem sat_one {v : Sat.Valuation} {c : Sat.Clause} (h : v.satisfies c) :
    v.satisfies_fmla (Sat.Fmla.one c) := by
  constructor
  intro d hd
  exact (List.mem_singleton.mp hd) ▸ h

/-- Check a single cardinality clause by a bounded lookup, without reducing
the list of geometric exclusions. -/
theorem sat_size_at (s : Finset Label) (k : Nat) (hk : k < 32) (hs : k ≤ s.card)
    (j : Nat) (c : Sat.Clause) (hc : (sizeClauses k)[j]? = some c) :
    (valuation s).satisfies_fmla (Sat.Fmla.one c) :=
  sat_one ((size_sat s k hk hs).1 c (List.mem_of_getElem? hc))

end Prize.JSP404.FiniteCardinalityCNF
