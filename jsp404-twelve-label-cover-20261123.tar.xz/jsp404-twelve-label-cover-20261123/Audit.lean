import Prize
#print axioms Prize.JSP404.ThreeArcShared12Coverage.coverRefutation.unsat
#print axioms Prize.JSP404.ThreeArcShared12Coverage.context_eq
#print axioms Prize.JSP404.ThreeArcShared12Blocks.satisfied
#print axioms Prize.JSP404.ThreeArcShared12Coverage.all_covered
