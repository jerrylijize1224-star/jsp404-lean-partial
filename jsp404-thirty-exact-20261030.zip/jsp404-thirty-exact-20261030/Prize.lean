import Prize.JSP628.Basic
import Prize.JSP404.Basic
import Prize.JSP404.SmallAngleConvexPosition
import Prize.JSP404.ExteriorBudget
import Prize.JSP404.SemicircleGapCapacity
import Prize.JSP404.FiniteExteriorBound
import Prize.JSP404.PentagonExterior
import Prize.JSP404.ConvexRayCoordinates
import Prize.JSP404.ConvexFourCrossings
import Prize.JSP404.OrderedRayCrossing
import Prize.JSP404.PentagonOrder
import Prize.JSP404.ConvexFanOrder
import Prize.JSP404.SixPointObstruction
import Prize.JSP404.FirstBandLowerBounds
import Prize.JSP404.SixPoints
import Prize.JSP404.FivePoints
import Prize.JSP404.FiniteAngleApproximation
import Prize.JSP404.BinaryEightConstruction
import Prize.JSP404.BinaryScaleConstruction
import Prize.JSP404.SixteenPointUpperBound
import Prize.JSP404.EquallySpacedBinaryAxes
import Prize.JSP404.ClusterApproximation
import Prize.JSP404.FirstBandAxes
import Prize.JSP404.FirstBandTriangle
import Prize.JSP404.FirstBandConstruction
import Prize.JSP404.ThreePoints
import Prize.JSP404.Target
import Prize.JSP404.Counting
import Prize.JSP404.CountingCheck
import Prize.JSP404.GeneralPosition
import Prize.JSP404.Sharpness
import Prize.JSP404.SectorCapacity
import Prize.JSP404.DirectionCover
import Prize.JSP404.ThreeCentreCapacity
import Prize.JSP404.MaximalCentres
import Prize.JSP404.FourPoints
import Prize.JSP404.FourCentreInteriorGeometry
import Prize.JSP404.FourCentreConvexGeometry
import Prize.JSP404.FourCentreCapacity
import Prize.JSP404.FourCentreProjectiveGaps
import Prize.JSP404.GeneralizedDirectionCover
import Prize.JSP404.GapIntervalCover
import Prize.JSP404.GapSectorCounting
import Prize.JSP404.ThreeGapAllowed
import Prize.JSP404.FourClusterCounting
import Prize.JSP404.FiniteDirectionChart
import Prize.JSP404.FiniteClusterCounting
import Prize.JSP404.FiniteDirectionInvariance
import Prize.JSP404.FiniteGapRestriction
import Prize.JSP404.FiniteMaximalCentres
import Prize.JSP404.UniformSectorLowerBound
import Prize.JSP404.GeneralAngleBounds
import Prize.JSP404.CompactDirectionSpace
import Prize.JSP404.StrictUniformLowerBound
import Prize.JSP404.FinitePeriodicGap
import Prize.JSP404.QuantitativeSectorCover
import Prize.JSP404.QuantitativeLowerBound
import Prize.JSP404.EdgeDirectionLowerBound
import Prize.JSP404.SaturatedCover
import Prize.JSP404.RotatingSectorCover
import Prize.JSP404.DyadicSharp
import Prize.JSP404.WeightedDirectionCover
import Prize.JSP404.RotatingCoverDeficit
import Prize.JSP404.CoverDeficitBudget
import Prize.JSP404.RotatingDeficitObstruction
import Prize.JSP404.NineTenExact

import Prize.JSP404.ElevenSixteenExact

import Prize.JSP404.OddNearDyadicSharp

import Prize.JSP404.NearDyadicSharp

import Prize.JSP404.Sector26LowerBound
import Prize.JSP404.Sector44LowerBound
import Prize.JSP404.Sector62LowerBound
import Prize.JSP404.ThreeArcExclusion
import Prize.JSP404.SeventeenTwentyExact

import Prize.JSP404.Fixed144TriangleObstruction

import Prize.JSP404.PlanarReduction144

import Prize.JSP404.OrderedDirection144

import Prize.JSP404.ThirtyExact
