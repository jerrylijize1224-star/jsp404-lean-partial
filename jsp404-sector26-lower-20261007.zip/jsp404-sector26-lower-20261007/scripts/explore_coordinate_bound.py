"""Exact polynomial discovery on ordinary point coordinates; NOT a Lean proof.

Normalize a diameter to (0,0)--(1,0), order the remaining x coordinates,
and reflect so that the first interior label has nonnegative y. These
normalizations have not been connected to the Lean target in this script.
An UNSAT answer still needs a checked certificate and a formal transfer.
"""
import argparse
import itertools
import json
import time
import z3

p = argparse.ArgumentParser()
p.add_argument('--points', type=int, required=True)
p.add_argument('--degrees', type=int, choices=[90, 120, 135, 140, 144], required=True)
p.add_argument('--seconds', type=int, default=60)
p.add_argument('--fixture', choices=['square'], help='Fixed four-point square for encoding controls, not a universal search')
a = p.parse_args()
if a.points < 3:
    p.error('--points must be at least 3')
if a.fixture and a.points != 4:
    p.error('--fixture square requires --points 4')
s = z3.SolverFor('QF_NRA')
s.set(timeout=1000*a.seconds)
q = [(z3.RealVal(0), z3.RealVal(0))]
q += [(z3.Real(f'x_{i}'), z3.Real(f'y_{i}')) for i in range(1, a.points-1)]
q += [(z3.RealVal(1), z3.RealVal(0))]
for i in range(1, a.points-1):
    s.add(0 <= q[i][0], q[i][0] <= 1)
    if i > 1:
        s.add(q[i-1][0] <= q[i][0])
s.add(q[1][1] >= 0)
if a.fixture == 'square':
    s.add(q[1][0] == z3.RealVal('1/2'), q[1][1] == z3.RealVal('1/2'),
          q[2][0] == z3.RealVal('1/2'), q[2][1] == z3.RealVal('-1/2'))

def displacement(i, j):
    return (q[i][0]-q[j][0], q[i][1]-q[j][1])

def dot(v, w):
    return v[0]*w[0]+v[1]*w[1]

dist2 = {}
for i, j in itertools.combinations(range(a.points), 2):
    d = displacement(i, j)
    dist2[i, j] = dot(d, d)
    s.add(dist2[i, j] > 0, dist2[i, j] <= 1)

if a.degrees in (140, 144):
    c = z3.Real('cos_squared')
    s.add(c > z3.RealVal('1/2'), c < z3.RealVal('3/4'))
    if a.degrees == 140:
        # cos(40 degrees)^2, isolated from the other two real roots.
        s.add(64*c**3-96*c**2+36*c-1 == 0)
    else:
        # cos(36 degrees)^2 = (3+sqrt(5))/8.
        s.add(16*c**2-12*c+1 == 0)
else:
    c = z3.RealVal({90:'0', 120:'1/4', 135:'1/2'}[a.degrees])

for i, j, k in itertools.combinations(range(a.points), 3):
    for vertex, left, right in ((i,j,k), (j,i,k), (k,i,j)):
        u, v = displacement(left, vertex), displacement(right, vertex)
        d = dot(u,v)
        if a.degrees == 90:
            s.add(d > 0)
        else:
            s.add(z3.Or(d >= 0, d*d < c*dot(u,u)*dot(v,v)))

started = time.monotonic()
r = s.check()
result = dict(points=a.points, strict_angle_cap_degrees=a.degrees,
              fixture=a.fixture,
              solver='z3 '+z3.get_version_string(), timeout_seconds=a.seconds,
              result=str(r), elapsed_seconds=round(time.monotonic()-started,3),
              status='EXPLORATORY ONLY: no Lean certificate or normalization bridge')
if r == z3.unknown:
    result['reason'] = s.reason_unknown()
if r == z3.sat:
    m = s.model()
    # Re-evaluate every exact polynomial assertion, not decimal approximations.
    assert all(z3.is_true(z3.simplify(m.eval(e, model_completion=True))) for e in s.assertions())
    result['exact_assertions_checked_by_z3'] = True
    result['model'] = [[m.eval(x).sexpr(),m.eval(y).sexpr()] for x,y in q]
    result['cos_squared'] = m.eval(c).sexpr()
print(json.dumps(result, indent=2))
