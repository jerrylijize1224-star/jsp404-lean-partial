"""Generate an exhaustive type-cover candidate; Lean export checks its soundness."""
from pathlib import Path
import sys,json,time
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import explore_sector_types as m
T=m.maximal_types();A=m.sector_adj();nodes=0
def rec(P,ts):
 global nodes
 nodes+=1
 for i in ts:
  if not P&~T[i]:return {'leaf':i}
 v=max(m.bits(P), key=lambda v:bin(P&~A[v]).count('1'))
 Q=P&~(1<<v)
 return {'v':v,'no':rec(Q,ts),'yes':rec(Q&A[v],[i for i in ts if T[i]>>v&1])}
c=rec(m.MASK,list(range(len(T))))
def verify(P,ts,c):
 if 'leaf' in c:
  assert c['leaf'] in ts and not P&~T[c['leaf']];return
 v=c['v'];assert P>>v&1;Q=P&~(1<<v)
 verify(Q,ts,c['no']);verify(Q&A[v],[i for i in ts if T[i]>>v&1],c['yes'])
verify(m.MASK,list(range(len(T))),c)
(ROOT/'research/logs/jsp404-sector26-type-cover.json').write_text(json.dumps({'types':T,'certificate':c},separators=(',',':'))+'\n')
print('Coverage certificate nodes:',nodes)
