"""Finite-sector candidate certificate, NOT a Lean proof.

No numerical lower bound may be claimed from this Python check alone.
The intended geometry bridge floors directions into 26 antipodal bins;
angles < 1800/13 degrees give circular bin distance <= 10.
"""
import argparse
import hashlib
import json
import time
from pathlib import Path

M, D, HALF = 26, 10, 13
MASK = (1 << M)-1

def bits(x):
    while x:
        b = x & -x
        yield b.bit_length()-1
        x ^= b

def rotate(x, r):
    return ((x << r) | (x >> (M-r))) & MASK

def sector_adj():
    return [sum(1 << j for j in range(M)
                if i != j and min((i-j) % M, (j-i) % M) <= D) for i in range(M)]

def maximal_types():
    """Enumerate every clique by increasing labels; independently test maximality."""
    adj = sector_adj()
    answer = []
    def visit(R, P):
        if not any(all(adj[v] >> u & 1 for u in bits(R))
                   for v in range(M) if not R >> v & 1):
            answer.append(R)
        while P:
            b = P & -P
            v = b.bit_length()-1
            P ^= b
            visit(R | b, P & adj[v])
    visit(0, MASK)
    return sorted(answer)

def graph(types):
    return [sum(1 << j for j,y in enumerate(types)
                if i != j and x & rotate(y, HALF)) for i,x in enumerate(types)]

def color_order(P, adj):
    order, bounds, groups = [], [], []
    while P:
        Q, group = P, 0
        while Q:
            b = Q & -Q
            v = b.bit_length()-1
            order.append(v)
            bounds.append(len(groups)+1)
            group |= b
            P ^= b
            Q &= ~(b | adj[v])
        groups.append(group)
    return order, bounds, groups

def certificate(P, need, adj):
    if need <= 0:
        raise ValueError('Counterexample clique found')
    order, bounds, _ = color_order(P, adj)
    children = []
    for pos in range(len(order)-1, -1, -1):
        if bounds[pos] < need:
            break
        v = order[pos]
        children.append([v, certificate(P & adj[v], need-1, adj)])
        P &= ~(1 << v)
    groups = color_order(P, adj)[2]
    assert len(groups) < need
    return {'branches': children, 'colors': groups}

def verify_node(P, need, cert, adj):
    """Check coverage and independence directly; do not trust greedy color bounds."""
    assert need > 0
    nodes = 1
    for v, child in cert['branches']:
        assert isinstance(v,int) and 0 <= v < len(adj) and P >> v & 1
        nodes += verify_node(P & adj[v], need-1, child, adj)
        P &= ~(1 << v)
    groups = cert['colors']
    assert len(groups) < need
    seen = 0
    for group in groups:
        assert isinstance(group,int) and group >= 0 and group & ~P == 0
        assert not seen & group
        seen |= group
        for v in bits(group):
            assert not adj[v] & group
    assert seen == P
    return nodes

def make_family(types, size):
    adj = graph(types)
    lookup = {x:i for i,x in enumerate(types)}
    remaining = set(range(len(types)))
    roots = []
    while remaining:
        rep = min(remaining)
        orbit = {lookup[rotate(types[rep],r)] for r in range(M)}
        remaining -= orbit
        # Including the representative, a forbidden clique would have size 9.
        roots.append({'representative':rep, 'certificate':certificate(adj[rep],8,adj)})
    return {'type_size':size, 'types':types, 'bound':8, 'roots':roots}

def verify_family(family):
    types = family['types']
    adj = graph(types)
    lookup = {x:i for i,x in enumerate(types)}
    assert family['bound'] == 8 and len(lookup) == len(types)
    assert all(bin(x).count('1') == family['type_size'] for x in types)
    covered, nodes = set(), 0
    # Verify each rotation is an actual graph automorphism.
    for r in range(M):
        perm = [lookup[rotate(x,r)] for x in types]
        assert len(set(perm)) == len(types)
        for i in range(len(types)):
            assert sum(1 << perm[j] for j in bits(adj[i])) == adj[perm[i]]
    for root in family['roots']:
        rep = root['representative']
        covered.update(lookup[rotate(types[rep],r)] for r in range(M))
        nodes += verify_node(adj[rep],8,root['certificate'],adj)
    assert covered == set(range(len(types)))
    return nodes

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--output', default='research/logs/jsp404-sector26-candidate.json')
    p.add_argument('--verify-only', action='store_true')
    args = p.parse_args()
    started = time.monotonic()
    types = maximal_types()
    assert len(types) == 156
    sizes = {bin(x).count('1') for x in types}
    assert sizes == {7,11}
    dest = Path(args.output)
    if args.verify_only:
        data = json.loads(dest.read_text())
    else:
        data = {'status':'CANDIDATE ONLY: neither the checker nor geometry bridge is Lean verified',
                'sectors':M, 'distance_bound':D,
                'families':[make_family([x for x in types if bin(x).count('1') == k],k) for k in sorted(sizes)]}
    assert data['sectors'] == M and data['distance_bound'] == D
    assert len(data['families']) == 2
    assert sorted(x for f in data['families'] for x in f['types']) == types
    counts = [verify_family(f) for f in data['families']]
    if not args.verify_only:
        dest.write_text(json.dumps(data,separators=(',',':'))+'\n')
    print(json.dumps({'maximal_types':len(types), 'family_sizes':[len(f['types']) for f in data['families']],
                      'checked_certificate_nodes':counts, 'candidate_total_bound':16,
                      'elapsed_seconds':round(time.monotonic()-started,3),
                      'bytes':dest.stat().st_size, 'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),
                      'status':'Python exploration only; no new Lean bound'}))

if __name__ == '__main__':
    main()
