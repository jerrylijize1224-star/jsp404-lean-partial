"""Sequentially rebuild the unchanged, attributed PR #647 dependency closure."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import time

root = Path(__file__).resolve().parents[1]
wrapper = root / 'scripts/lake.sh'
lake = str(wrapper) if wrapper.exists() and (root / '.tools/elan/bin/lake').exists() else 'lake'
p = argparse.ArgumentParser()
p.add_argument('--start', type=int, default=1, help='One-based position in the source lock')
a = p.parse_args()
lock = json.loads((root / 'research/jsp404-eleven-source-lock.json').read_text())
source = root / '.lake/external/jsp404-eleven-certificate'
for f in lock['files']:
    data = (source / (f['module'].replace('.', '/') + '.lean')).read_bytes()
    if hashlib.sha256(data).hexdigest() != f['sha256']:
        raise SystemExit('External source hash mismatch: ' + f['module'])
if not 1 <= a.start <= len(lock['files']):
    raise SystemExit('Invalid starting module')
logs = root / 'research/logs/jsp404-eleven-certificate'
logs.mkdir(parents=True, exist_ok=True)
for n, f in enumerate(lock['files'], 1):
    if n < a.start:
        continue
    module = f['module']
    started = time.monotonic()
    with (logs / (module + '.log')).open('w') as log:
        result = subprocess.run([lake, 'build', module], cwd=root,
                                stdout=log, stderr=subprocess.STDOUT)
    print(f'{n}/{len(lock["files"])} {module}: exit={result.returncode}, '
          f'{time.monotonic()-started:.1f}s', flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
