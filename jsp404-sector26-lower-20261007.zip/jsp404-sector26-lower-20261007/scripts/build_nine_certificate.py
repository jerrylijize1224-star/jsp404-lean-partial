"""Build the pinned external certificate in bounded, sequential phases."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import sys
import time

root = Path(__file__).resolve().parents[1]
wrapper = root / 'scripts/lake.sh'
lake = str(wrapper) if wrapper.exists() and (root / '.tools/elan/bin/lake').exists() else 'lake'
p = argparse.ArgumentParser()
p.add_argument('--phase', choices=['all', 'rup', 'cnf', 'geometry', 'bridge'], default='all')
a = p.parse_args()
lock = json.loads((root / 'research/jsp404-nine-source-lock.json').read_text())
source = root / '.lake/external/jsp404-nine-certificate'
for f in lock['files']:
    data = (source / (f['module'] + '.lean')).read_bytes()
    if hashlib.sha256(data).hexdigest() != f['sha256']:
        raise SystemExit('External source hash mismatch: ' + f['module'])
phases = {
    'theory': ['NineTheoryTrial'],
    'rup': [f'NineRUPChunk{i:03}' for i in range(35)],
    'cnf': [f'NineCNFDirectChunk{i:03}' for i in range(17)],
    'geometry': ['SendovFiveDirections', 'SendovDirectionGeometry', 'SendovDirectionModel'],
    'bridge': ['NineCNFDirectAll', 'NinePropositionalTrial', 'NineModelTrial'],
}
modules = sum(phases.values(), []) if a.phase == 'all' else phases[a.phase]
logs = root / 'research/logs/jsp404-nine-certificate'
logs.mkdir(parents=True, exist_ok=True)
for n, module in enumerate(modules, 1):
    started = time.monotonic()
    with (logs / (module + '.log')).open('w') as log:
        result = subprocess.run([lake, 'build', module], cwd=root,
                                stdout=log, stderr=subprocess.STDOUT)
    print(f'{a.phase} {n}/{len(modules)} {module}: exit={result.returncode}, '
          f'{time.monotonic()-started:.1f}s', flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
