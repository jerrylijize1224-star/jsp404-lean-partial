"""Export a checked clique cover; Python enumeration itself is not trusted."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
d=json.loads((ROOT/'research/logs/jsp404-sector26-type-cover.json').read_text())
def labels(mask):return [i for i in range(26) if mask>>i&1]
def emit(c):
 if 'leaf' in c:return '(.leaf '+str(labels(d['types'][c['leaf']]))+')'
 return f'(.split {c["v"]} {emit(c["no"])} {emit(c["yes"])})'
s='''import Prize.JSP404.FiniteCliqueCover

/-! A certified exhaustive cover of 26-sector direction sets. -/
namespace Prize.JSP404.FiniteCliqueCertificate.Sector26
set_option maxRecDepth 65536
set_option maxHeartbeats 0
abbrev Sector := Fin 26

def antipode (i : Sector) : Sector := ⟨(i.val+13)%26, Nat.mod_lt _ (by decide)⟩
def circularDistance (i j : Sector) : Nat :=
  min ((i.val+26-j.val)%26) ((j.val+26-i.val)%26)
def sectorGraph (i j : Sector) : Bool := decide (i ≠ j ∧ circularDistance i j ≤ 10)
'''
s+='def allTypes : List (List Sector) := '+str([labels(t) for t in d['types']])+'\n'
s+='def coverCert : CoverCertificate Sector := '+emit(d['certificate'])+'\n'
s+='''theorem allTypes_cover : Covers sectorGraph (List.finRange 26) allTypes := by
  apply coverCheck_sound sectorGraph coverCert
  decide +kernel

theorem allTypes_no_antipodes : ∀ T ∈ allTypes, ∀ i : Sector,
    i ∈ T → antipode i ∉ T := by decide +kernel

theorem antipode_involutive : Function.Involutive antipode := by
  change ∀ i : Sector, antipode (antipode i) = i
  decide +kernel

end Prize.JSP404.FiniteCliqueCertificate.Sector26
'''
(ROOT/'Prize/JSP404/Sector26Types.lean').write_text(s)
print('Sector26Types bytes:',len(s.encode()))
