"""Bounded exact-arithmetic discovery only; Z3 output is not a Lean proof.

The constraints weaken the attributed SendovDirectionModel.Model interface:
0 <= theta_ij < T; for every ordered triple, the long edge lies between
its two short edges, their separation is at least 1, and each adjacent
separation is strictly less than T-1. No realizability is assumed.
"""
import argparse
import itertools
import json
import time
import z3

p = argparse.ArgumentParser()
p.add_argument('--points', type=int, required=True)
p.add_argument('--threshold', required=True)
p.add_argument('--seconds', type=int, default=60)
p.add_argument('--proof', action='store_true')
p.add_argument('--core', action='store_true', help='Track assertion indices for an unsatisfiable core')
p.add_argument('--arith-solver', type=int, choices=[1,3,6])
p.add_argument('--normalize', action='store_true', help='Exploratory translation/reflection symmetry normalization; Lean bridge not implemented')
p.add_argument('--strict-between', action='store_true', help='Exclude degenerate triangles; added geometric bridge not yet formalized')
p.add_argument('--four-point-cuts', action='store_true', help='Exploratory four-label order clauses; not yet Lean-certified')
a = p.parse_args()
if a.proof:
    z3.set_param(proof=True)
T = z3.RealVal(a.threshold)
x = {(i,j): z3.Real(f'x_{i}_{j}') for i,j in itertools.combinations(range(a.points),2)}
s = z3.SolverFor('QF_RDL')
s.set(timeout=a.seconds*1000)
if a.arith_solver is not None:
    s.set(**{'arith.solver':a.arith_solver})
assertions = []
def add(*expressions):
    for e in expressions:
        index = len(assertions)
        assertions.append(e)
        if a.core:
            s.assert_and_track(e, z3.Bool(f'constraint_{index}'))
        else:
            s.add(e)
for v in x.values():
    add(v >= 0, v < T)
for i,j,k in itertools.combinations(range(a.points),3):
    u,v,w = x[i,j],x[i,k],x[j,k]
    between = (lambda u,v: u < v) if a.strict_between else (lambda u,v: u <= v)
    add(z3.Or(z3.And(between(u,v), between(v,w), w-u >= 1, v-u < T-1, w-v < T-1),
                z3.And(between(w,v), between(v,u), u-w >= 1, u-v < T-1, v-w < T-1)))
if a.four_point_cuts:
    bad = [(0,0,1,0),(0,1,0,0),(0,1,0,1),(0,1,1,0),
           (1,0,0,1),(1,0,1,0),(1,0,1,1),(1,1,0,1)]
    for block in itertools.combinations(range(a.points),4):
        signs = [x[i,j] < x[j,k] for i,j,k in itertools.combinations(block,3)]
        for pattern in bad:
            add(z3.Or([z3.Not(sign) if b else sign for sign,b in zip(signs,pattern)]))
if a.normalize:
    add(z3.Or([x[i,i+1] == 0 for i in range(a.points-1)]))
    add(x[0,1] <= x[1,2])
t = time.monotonic()
r = s.check()
result = {'points':a.points,'threshold':a.threshold,'solver':'z3 '+z3.get_version_string(),
          'timeout_seconds':a.seconds,'arithmetic_solver':a.arith_solver,'normalized':a.normalize,'result':str(r),'elapsed_seconds':round(time.monotonic()-t,3),
          'four_point_cuts':a.four_point_cuts,'strict_between':a.strict_between,'status':'EXPLORATORY ONLY: no Lean certificate; extra bridges unformalized'}
if r == z3.sat:
    from fractions import Fraction
    bound = Fraction(a.threshold)
    model = s.model()
    values = {ij: model.eval(v, model_completion=True).as_fraction() for ij,v in x.items()}
    assert all(0 <= q < bound for q in values.values())
    for i,j,k in itertools.combinations(range(a.points),3):
        u,v,w = values[i,j], values[i,k], values[j,k]
        assert ((u <= v <= w and w-u >= 1 and v-u < bound-1 and w-v < bound-1)
             or (w <= v <= u and u-w >= 1 and u-v < bound-1 and v-w < bound-1))
        if a.strict_between:
            assert (u < v < w) or (w < v < u)
    result['rational_model_checked'] = True
    result['model'] = {f'{i},{j}':str(v) for (i,j),v in values.items()}
if r == z3.unknown:
    result['reason'] = s.reason_unknown()
if r == z3.unsat and a.core:
    result['core_assertions'] = [str(v) for v in s.unsat_core()]
if r == z3.unsat and a.proof:
    proof = s.proof().sexpr()
    result['proof_bytes'] = len(proof.encode())
    from pathlib import Path
    dest=Path('/tmp')/f'jsp404-direction-{a.points}-{a.threshold.replace("/","_")}-{a.arith_solver}-{a.normalize}-strict{a.strict_between}-cuts{a.four_point_cuts}.z3proof'
    dest.write_text(proof)
    result['proof_path'] = str(dest)
print(json.dumps(result, indent=2))
