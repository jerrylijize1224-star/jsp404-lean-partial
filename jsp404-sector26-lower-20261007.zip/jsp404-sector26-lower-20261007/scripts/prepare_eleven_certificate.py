"""Fetch only hash-pinned Lean sources; never execute downloaded scripts.

The lower certificate is hit1190100321's attributed PR #647, kept outside Git.
Run this before lake on a fresh checkout or extracted release.
"""
from pathlib import Path
import argparse
import hashlib
import io
import json
import tarfile
import urllib.request

root = Path(__file__).resolve().parents[1]
p = argparse.ArgumentParser()
p.add_argument('--check-only', action='store_true', help='Verify local sources without downloading')
p.add_argument('--archive', type=Path, help='Use a previously downloaded fixed-commit archive')
a = p.parse_args()
lock = json.loads((root / 'research/jsp404-eleven-source-lock.json').read_text())
dest = root / '.lake/external/jsp404-eleven-certificate'
dest.mkdir(parents=True, exist_ok=True)
def matches(f):
    path = dest / (f['module'].replace('.', '/') + '.lean')
    return path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest() == f['sha256']
if not all(matches(f) for f in lock['files']):
    if a.check_only:
        raise SystemExit('Missing or altered eleven-point source. Run python3 scripts/prepare_eleven_certificate.py first.')
    if a.archive:
        data = a.archive.read_bytes()
    else:
        url = 'https://codeload.github.com/hit1190100321/awards/tar.gz/' + lock['commit']
        with urllib.request.urlopen(url, timeout=120) as response:
            data = response.read()
    with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
        expected = {f['path']: f for f in lock['files']}
        found = {}
        for member in archive:
            relative = '/'.join(Path(member.name).parts[1:])
            if relative not in expected or not member.isfile():
                continue
            f = expected[relative]
            content = archive.extractfile(member).read()
            if hashlib.sha256(content).hexdigest() != f['sha256']:
                raise SystemExit('Source hash mismatch: ' + relative)
            found[f['module']] = content
        if len(found) != len(expected):
            raise SystemExit('Archive missing expected pinned modules')
        for module, content in found.items():
            target = dest / (module.replace('.', '/') + '.lean')
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(content)
config = '''name = "jsp404ElevenCertificate"
version = "0.1.0"
moreLeanArgs = ["-j1", "-M5000", "--trust=0"]

[[require]]
name = "mathlib"
git = "https://github.com/leanprover-community/mathlib4.git"
rev = "5ed2965256430c3649e86755f9576b54eca72435"
'''
config += '\n[[lean_lib]]\nname = "SunPrize"\n'
config_path = dest / 'lakefile.toml'
if a.check_only:
    if not config_path.is_file() or config_path.read_text() != config:
        raise SystemExit('Certificate Lake configuration mismatch; rerun prepare_eleven_certificate.py.')
else:
    config_path.write_text(config)
print(f'Checked {len(lock["files"])} unchanged Lean sources from {lock["commit"]}.')
