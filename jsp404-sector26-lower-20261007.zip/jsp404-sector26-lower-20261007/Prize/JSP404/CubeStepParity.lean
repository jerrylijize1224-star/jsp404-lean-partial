import Prize.JSP404.NearSaturatedParity
import Mathlib.Logic.Equiv.Fin.Rotate

/-! A one-sector rotation permutes cube coordinates and flips exactly one bit.
For dimension at least three this is an even permutation reversing cube color. -/
namespace Prize.JSP404
open scoped Classical

def boolReindex {I : Type*} (p : Equiv.Perm I) : Equiv.Perm (I → Bool) where
  toFun c i := c (p i)
  invFun c i := c (p.symm i)
  left_inv c := by funext i; simp
  right_inv c := by funext i; simp

/-- A fixed coordinate duplicates the induced permutation on two equal fibers. -/
theorem boolReindex_even_of_fixed {I : Type*} [DecidableEq I] [Fintype I]
    (p : Equiv.Perm I) (z : I) (hz : p z = z) :
    Equiv.Perm.sign (boolReindex p) = 1 := by
  classical
  let q : Equiv.Perm {i : I // i ≠ z} := p.subtypeEquiv (by
    intro i
    simpa only [hz] using (p.injective.ne_iff : p i ≠ p z ↔ i ≠ z).symm)
  let e := Equiv.funSplitAt z Bool
  have he : (e.symm.trans (boolReindex p)).trans e =
      Equiv.prodCongrRight (fun _ : Bool => boolReindex q) := by
    apply Equiv.ext
    rintro ⟨b, c⟩
    apply Prod.ext
    · simp [e, boolReindex, hz]
    · funext i
      have hp : p i.val ≠ z := by
        exact fun h => i.property (p.injective (h.trans hz.symm))
      simp [e, boolReindex, q, hp]
  have hs := Equiv.Perm.sign_symm_trans_trans (boolReindex p) e
  rw [he, Equiv.Perm.sign_prodCongrRight] at hs
  simpa using hs.symm

theorem boolReindex_even {k : ℕ} (hk : 3 ≤ k) (p : Equiv.Perm (Fin k)) :
    Equiv.Perm.sign (boolReindex p) = 1 := by
  classical
  induction p using Equiv.Perm.swap_induction_on with
  | one =>
    have he : boolReindex (1 : Equiv.Perm (Fin k)) = 1 := rfl
    rw [he, Equiv.Perm.sign_one]
  | swap_mul p x y hxy ih =>
    have hz : ∃ z : Fin k, z ≠ x ∧ z ≠ y := by
      by_contra h
      have hall : (Finset.univ : Finset (Fin k)) ⊆ {x, y} := by
        intro z _
        simp only [Finset.mem_insert, Finset.mem_singleton]
        by_contra hz
        exact h ⟨z, fun hx => hz (Or.inl hx), fun hy => hz (Or.inr hy)⟩
      have hc := Finset.card_le_card hall
      have hb : ({x, y} : Finset (Fin k)).card ≤ 2 := Finset.card_le_two
      simp only [Finset.card_univ, Fintype.card_fin] at hc
      omega
    obtain ⟨z, hzx, hzy⟩ := hz
    have he : boolReindex (Equiv.swap x y * p) =
        (boolReindex (Equiv.swap x y)).trans (boolReindex p) := rfl
    rw [he, Equiv.Perm.sign_trans, ih, one_mul]
    exact boolReindex_even_of_fixed (Equiv.swap x y) z
      (Equiv.swap_apply_of_ne_of_ne hzx hzy)


def cubeFlip {k : ℕ} (i : Fin k) : Equiv.Perm (CubeCode k) where
  toFun c j := if j = i then !(c j) else c j
  invFun c j := if j = i then !(c j) else c j
  left_inv c := by funext j; by_cases h : j = i <;> simp [h]
  right_inv c := by funext j; by_cases h : j = i <;> simp [h]

theorem cubeFlip_even {k : ℕ} (hk : 2 ≤ k) (i : Fin k) :
    Equiv.Perm.sign (cubeFlip i) = 1 := by
  classical
  have hsq : cubeFlip i ^ 2 = 1 := by
    apply Equiv.ext
    intro c
    funext j
    by_cases h : j = i <;> simp [pow_two, cubeFlip, h]
  have hempty : IsEmpty (Function.fixedPoints (cubeFlip i)) := by
    constructor
    intro c
    have h := congrFun c.property i
    simp [cubeFlip] at h
  let := hempty
  rw [Equiv.Perm.sign_of_pow_two_eq_one hsq,
    Fintype.card_eq_zero (α := Function.fixedPoints (cubeFlip i))]
  simp only [Nat.sub_zero, Fintype.card_fun, Fintype.card_bool, Fintype.card_fin]
  obtain ⟨m, rfl⟩ := Nat.exists_eq_add_of_le hk
  simp [show (2 : ℕ) + m = m + 2 by omega, pow_succ,
    show ∀ a : ℤˣ, a ^ (2 ^ m * 2) = (a ^ (2 ^ m)) ^ 2 from fun a => pow_mul a _ _]

theorem cubeColor_flip {k : ℕ} (i : Fin k) (c : CubeCode k) :
    cubeColor (cubeFlip i c) = -cubeColor c := by
  apply cubeColor_adjacent _ _ i
  · simp [cubeFlip]
  · intro j hj
    simp [cubeFlip, hj]

theorem cubeColor_reindex {k : ℕ} (p : Equiv.Perm (Fin k)) (c : CubeCode k) :
    cubeColor (boolReindex p c) = cubeColor c := by
  exact Equiv.prod_comp p (fun i => cubeBitColor (c i))

def cubeStep (n : ℕ) : Equiv.Perm (CubeCode (n + 1)) :=
  (boolReindex (finRotate (n + 1))).trans (cubeFlip (Fin.last n))

theorem cubeStep_even {n : ℕ} (hn : 3 ≤ n + 1) :
    Equiv.Perm.sign (cubeStep n) = 1 := by
  rw [cubeStep, Equiv.Perm.sign_trans, cubeFlip_even (by omega),
    boolReindex_even hn, one_mul]

theorem cubeColor_step {n : ℕ} (c : CubeCode (n + 1)) :
    cubeColor (cubeStep n c) = -cubeColor c := by
  change cubeColor (cubeFlip _ (boolReindex _ c)) = _
  rw [cubeColor_flip, cubeColor_reindex]

/-- One cyclic relabeling with a single reversed relation obstructs a
near-saturated cover in every dimension at least three. -/
theorem not_card_succ_eq_of_open_step_cover
    {V T : Type*} [Fintype V] [TopologicalSpace T]
    {n : ℕ} (hn : 3 ≤ n + 1) (S : Set T) (hS : IsPreconnected S)
    (R : T → Fin (n + 1) → V → V → Prop)
    (hopen : ∀ i u v, IsOpen {t | R t i u v})
    (hcover : ∀ t ∈ S, ∀ u v, u ≠ v → ∃ i, R t i u v ∨ R t i v u)
    (hstep : ∀ t ∈ S, ∀ i u v w, R t i u v → R t i v w → False)
    {a b : T} (ha : a ∈ S) (hb : b ∈ S)
    (hshift : ∀ i, i ≠ Fin.last n → ∀ u v,
      R b i u v ↔ R a (finRotate (n + 1) i) u v)
    (hrev : ∀ u v, R b (Fin.last n) u v ↔ R a 0 v u) :
    Fintype.card V + 1 ≠ 2 ^ (n + 1) := by
  classical
  intro hcard
  let : PreconnectedSpace S := isPreconnected_iff_preconnectedSpace.mp hS
  let R' : S → Fin (n + 1) → V → V → Prop := fun t => R t.val
  apply no_near_saturated_even_color_reversal R'
    (fun i u v => (hopen i u v).preimage continuous_subtype_val)
    (fun t => hcover t.val t.property) (fun t => hstep t.val t.property)
    hcard cubeColor cubeColor_adjacent (cubeStep n) (cubeStep_even hn)
    cubeColor_step ⟨a, ha⟩ ⟨b, hb⟩
  intro e he v i
  by_cases hi : i = Fin.last n
  · subst i
    constructor
    · rintro ⟨w, hw⟩
      have hh := (he v 0).2 ⟨w, (hrev v w).mp hw⟩
      simp [cubeStep, boolReindex, cubeFlip, hh]
    · rintro ⟨w, hw⟩
      have hh := (he v 0).1 ⟨w, (hrev w v).mp hw⟩
      simp [cubeStep, boolReindex, cubeFlip, hh]
  · constructor
    · rintro ⟨w, hw⟩
      have hh := (he v (finRotate (n + 1) i)).1 ⟨w, (hshift i hi v w).mp hw⟩
      simpa [cubeStep, boolReindex, cubeFlip, hi] using hh
    · rintro ⟨w, hw⟩
      have hh := (he v (finRotate (n + 1) i)).2 ⟨w, (hshift i hi w v).mp hw⟩
      simpa [cubeStep, boolReindex, cubeFlip, hi] using hh

end Prize.JSP404
