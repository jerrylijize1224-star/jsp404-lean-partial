import Prize.JSP404.SaturatedCover
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Algebra.BigOperators.Group.Finset.Piecewise

/-! A weighted form of binary cover counting. A vertex with f unused
relations occupies a disjoint Boolean subcube of size 2^f. -/
namespace Prize.JSP404
open scoped Classical

/-- Allowed bits record both incoming and outgoing constraints. -/
def CompatibleCoverBit {V : Type*} {k : ℕ} (R : Fin k → V → V → Prop)
    (v : V) (i : Fin k) (b : Bool) : Prop :=
  ((∃ w, R i v w) → b = true) ∧ ((∃ w, R i w v) → b = false)

noncomputable def freeCoverIndices {V : Type*} {k : ℕ}
    (R : Fin k → V → V → Prop) (v : V) : Finset (Fin k) := by
  classical
  exact Finset.univ.filter (fun i => (¬ ∃ w, R i v w) ∧ (¬ ∃ w, R i w v))

/-- All admissible codes for one vertex, including every free-bit choice. -/
abbrev CompatibleCoverCode {V : Type*} {k : ℕ} (R : Fin k → V → V → Prop) (v : V) :=
  ∀ i : Fin k, {b : Bool // CompatibleCoverBit R v i b}

theorem compatibleCoverBit_card {V : Type*} {k : ℕ}
    (R : Fin k → V → V → Prop)
    (hstep : ∀ i u v w, R i u v → R i v w → False) (v : V) (i : Fin k) :
    Fintype.card {b : Bool // CompatibleCoverBit R v i b} =
      if i ∈ freeCoverIndices R v then 2 else 1 := by
  classical
  simp only [freeCoverIndices, Finset.mem_filter, Finset.mem_univ, true_and]
  by_cases ho : ∃ w, R i v w
  · have hi : ¬ ∃ w, R i w v := by
      rintro ⟨u, hu⟩
      obtain ⟨w, hw⟩ := ho
      exact hstep i u v w hu hw
    simp only [CompatibleCoverBit, ho, hi, true_implies, false_implies, and_true,
      not_true_eq_false, not_false_eq_true, ite_false]
    simp
  · by_cases hi : ∃ w, R i w v
    · simp only [CompatibleCoverBit, ho, hi, true_implies, false_implies,
        true_and, not_true_eq_false, not_false_eq_true, ite_false]
      simp
    · simp only [CompatibleCoverBit, ho, hi, false_implies, and_true,
        not_false_eq_true, ite_true]
      simp

theorem compatibleCoverCode_card {V : Type*} {k : ℕ}
    (R : Fin k → V → V → Prop)
    (hstep : ∀ i u v w, R i u v → R i v w → False) (v : V) :
    Fintype.card (CompatibleCoverCode R v) = 2 ^ (freeCoverIndices R v).card := by
  classical
  rw [Fintype.card_pi]
  simp_rw [compatibleCoverBit_card R hstep]
  simp

/-- Distinct vertices cannot share a compatible code. -/
theorem compatibleCoverCode_disjoint {V : Type*} {k : ℕ}
    (R : Fin k → V → V → Prop)
    (hcover : ∀ u v, u ≠ v → ∃ i, R i u v ∨ R i v u)
    {u v : V} (hu : CompatibleCoverCode R u) (hv : CompatibleCoverCode R v)
    (he : ∀ i, (hu i).val = (hv i).val) : u = v := by
  by_contra hn
  obtain ⟨i, hi⟩ := hcover u v hn
  have h := he i
  rcases hi with hi | hi
  · rw [(hu i).property.1 ⟨v, hi⟩, (hv i).property.2 ⟨u, hi⟩] at h
    contradiction
  · rw [(hu i).property.2 ⟨v, hi⟩, (hv i).property.1 ⟨u, hi⟩] at h
    contradiction

/-- Kraft-type capacity inequality for all vertices simultaneously. No
additional incidence or geometric premise is imposed. -/
theorem weighted_card_le_two_pow_of_no_two_step_cover
    {V : Type*} [Fintype V] {k : ℕ}
    (R : Fin k → V → V → Prop)
    (hcover : ∀ u v, u ≠ v → ∃ i, R i u v ∨ R i v u)
    (hstep : ∀ i u v w, R i u v → R i v w → False) :
    ∑ v : V, 2 ^ (freeCoverIndices R v).card ≤ 2 ^ k := by
  classical
  let code : (Σ v : V, CompatibleCoverCode R v) → (Fin k → Bool) := fun p i => (p.2 i).val
  have hinj : Function.Injective code := by
    rintro ⟨u, hu⟩ ⟨v, hv⟩ he
    have huv : u = v := compatibleCoverCode_disjoint R hcover hu hv (fun i => congrFun he i)
    subst v
    have hh : hu = hv := by
      funext i
      exact Subtype.ext (congrFun he i)
    subst hv
    rfl
  have hc := Fintype.card_le_of_injective code hinj
  simpa only [Fintype.card_sigma, compatibleCoverCode_card R hstep,
    Fintype.card_fun, Fintype.card_bool, Fintype.card_fin] using hc

/-- A quantitative deficit from one fixed relation: each vertex missing
that relation costs at least one extra Boolean code. -/
theorem card_add_isolated_le_two_pow {V : Type*} [Fintype V] {k : ℕ}
    (R : Fin k → V → V → Prop)
    (hcover : ∀ u v, u ≠ v → ∃ i, R i u v ∨ R i v u)
    (hstep : ∀ i u v w, R i u v → R i v w → False) (i : Fin k) :
    Fintype.card V + Fintype.card {v : V // i ∈ freeCoverIndices R v} ≤ 2 ^ k := by
  classical
  have hlocal (v : V) : 1 + (if i ∈ freeCoverIndices R v then 1 else 0) ≤
      2 ^ (freeCoverIndices R v).card := by
    by_cases hi : i ∈ freeCoverIndices R v
    · have hpos := Finset.card_pos.mpr ⟨i, hi⟩
      simpa only [hi, ite_true, pow_one] using
        (pow_le_pow_right₀ (by decide : 1 ≤ (2 : ℕ)) hpos : 2 ^ 1 ≤ 2 ^ (freeCoverIndices R v).card)
    · simp only [hi, ite_false, add_zero]
      exact Nat.one_le_two_pow
  have hs := Finset.sum_le_sum (fun v (_ : v ∈ (Finset.univ : Finset V)) => hlocal v)
  have hsum : Fintype.card V + Fintype.card {v : V // i ∈ freeCoverIndices R v} ≤
      ∑ v : V, 2 ^ (freeCoverIndices R v).card := by
    simpa [Finset.sum_add_distrib, Fintype.card_subtype] using hs
  exact hsum.trans (weighted_card_le_two_pow_of_no_two_step_cover R hcover hstep)

end Prize.JSP404
