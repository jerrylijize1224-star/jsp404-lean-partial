import Prize.JSP404.GeneralizedDirectionCover
import Mathlib.Topology.Order.Compact
import Mathlib.Topology.Order.Lattice
import Mathlib.Analysis.Normed.Module.RCLike.Basic

/-!
# A compact relaxation of finite direction data

All off-diagonal directions have unit norm, diagonal entries vanish, and
reversal negates directions. This space is larger than realizable ordinary or
nested point configurations. Its maximum triple angle attains a minimum;
no attainment assertion about the original alpha is made.
-/

namespace Prize.JSP404

abbrev DirectionAssignment (V : Type*) := V × V → Plane

noncomputable def UnitDirectionAssignments (V : Type*) : Set (DirectionAssignment V) := by
  classical
  exact {q | (∀ i j, ‖q (i, j)‖ = if i = j then 0 else 1) ∧
    ∀ i j, q (j, i) = -q (i, j)}

theorem isClosed_unitDirectionAssignments (V : Type*) :
    IsClosed (UnitDirectionAssignments V) := by
  classical
  unfold UnitDirectionAssignments
  simp only [Set.ofPred_and, Set.ofPred_forall]
  exact (isClosed_iInter fun i => isClosed_iInter fun j =>
    isClosed_eq (continuous_apply (i, j)).norm continuous_const).inter
    (isClosed_iInter fun i => isClosed_iInter fun j =>
      isClosed_eq (continuous_apply (j, i)) (continuous_apply (i, j)).neg)

theorem isCompact_unitDirectionAssignments (V : Type*) :
    IsCompact (UnitDirectionAssignments V) := by
  classical
  have hc := isCompact_univ_pi (fun _ : V × V => isCompact_closedBall (0 : Plane) 1)
  apply hc.of_isClosed_subset (isClosed_unitDirectionAssignments V)
  intro q hq ij _
  rw [Metric.mem_closedBall, dist_zero_right]
  change ‖q (ij.1, ij.2)‖ ≤ 1
  rw [hq.1 ij.1 ij.2]
  split_ifs <;> norm_num

theorem unitDirectionAssignments_nonzero {V : Type*} {q : DirectionAssignment V}
    (hq : q ∈ UnitDirectionAssignments V) {i j : V} (hij : i ≠ j) : q (i, j) ≠ 0 := by
  intro hz
  have h := hq.1 i j
  simp [hij, hz] at h

def UnitDirectionAssignments.toDirections {V : Type*} (q : DirectionAssignment V)
    (hq : q ∈ UnitDirectionAssignments V) : GeneralizedDirections V where
  direction i j := q (i, j)
  reverse := hq.2
  nonzero _ _ hij := unitDirectionAssignments_nonzero hq hij

/-- Only triples of pairwise distinct labels participate in the maximum. -/
def DirectionTriple (V : Type*) :=
  {t : V × V × V // t.1 ≠ t.2.1 ∧ t.1 ≠ t.2.2 ∧ t.2.1 ≠ t.2.2}

noncomputable instance {V : Type*} [Fintype V] : Fintype (DirectionTriple V) := by
  classical
  unfold DirectionTriple
  infer_instance

theorem directionTriple_nonempty {V : Type*} [Fintype V] (hV : 3 ≤ Fintype.card V) :
    Nonempty (DirectionTriple V) := by
  obtain ⟨i, j, k, hij, hik, hjk⟩ := Fintype.two_lt_card_iff.mp (by omega : 2 < Fintype.card V)
  exact ⟨⟨(i, j, k), hij, hik, hjk⟩⟩

noncomputable def assignmentTripleAngle {V : Type*} (q : DirectionAssignment V)
    (t : DirectionTriple V) : ℝ :=
  InnerProductGeometry.angle (q (t.val.2.1, t.val.1)) (q (t.val.2.1, t.val.2.2))

noncomputable def maximumAssignmentAngle {V : Type*} [Fintype V]
    [Nonempty (DirectionTriple V)] (q : DirectionAssignment V) : ℝ :=
  Finset.univ.sup' Finset.univ_nonempty (assignmentTripleAngle q)

theorem assignmentTripleAngle_le_maximum {V : Type*} [Fintype V]
    [Nonempty (DirectionTriple V)] (q : DirectionAssignment V) (t : DirectionTriple V) :
    assignmentTripleAngle q t ≤ maximumAssignmentAngle q :=
  Finset.le_sup' _ (Finset.mem_univ t)

theorem exists_maximumAssignmentAngle {V : Type*} [Fintype V]
    [Nonempty (DirectionTriple V)] (q : DirectionAssignment V) :
    ∃ t : DirectionTriple V, maximumAssignmentAngle q = assignmentTripleAngle q t := by
  obtain ⟨t, _, ht⟩ := Finset.exists_mem_eq_sup' Finset.univ_nonempty (assignmentTripleAngle q)
  exact ⟨t, ht⟩

theorem continuousOn_assignmentTripleAngle {V : Type*} (t : DirectionTriple V) :
    ContinuousOn (fun q : DirectionAssignment V => assignmentTripleAngle q t)
      (UnitDirectionAssignments V) := by
  intro q hq
  have hp : ContinuousAt (fun d : DirectionAssignment V =>
      (d (t.val.2.1, t.val.1), d (t.val.2.1, t.val.2.2))) q :=
    ((continuous_apply _).prodMk (continuous_apply _)).continuousAt
  have ha := InnerProductGeometry.continuousAt_angle
    (x := (q (t.val.2.1, t.val.1), q (t.val.2.1, t.val.2.2)))
    (unitDirectionAssignments_nonzero hq t.property.1.symm)
    (unitDirectionAssignments_nonzero hq t.property.2.2)
  exact (ContinuousAt.comp (f := fun d : DirectionAssignment V =>
    (d (t.val.2.1, t.val.1), d (t.val.2.1, t.val.2.2))) ha hp).continuousWithinAt

theorem continuousOn_maximumAssignmentAngle {V : Type*} [Fintype V]
    [Nonempty (DirectionTriple V)] :
    ContinuousOn (@maximumAssignmentAngle V _ _) (UnitDirectionAssignments V) := by
  apply ContinuousOn.finset_sup'_apply
  intro t _
  exact continuousOn_assignmentTripleAngle t

namespace GeneralizedDirections

noncomputable def normalizedAssignment {V : Type*} (D : GeneralizedDirections V) :
    DirectionAssignment V := fun ij => ‖D.direction ij.1 ij.2‖⁻¹ • D.direction ij.1 ij.2

theorem normalizedAssignment_mem {V : Type*} (D : GeneralizedDirections V) :
    D.normalizedAssignment ∈ UnitDirectionAssignments V := by
  classical
  constructor
  · intro i j
    by_cases hij : i = j
    · subst j
      have hz : D.direction i i = 0 := by
        have h := D.reverse i i
        have htwo : (2 : ℝ) • D.direction i i = 0 := by
          rw [two_smul]
          exact add_eq_zero_iff_eq_neg.mpr h
        exact (smul_eq_zero.mp htwo).resolve_left (by norm_num)
      simp [normalizedAssignment, hz]
    · simpa [normalizedAssignment, hij] using norm_smul_inv_norm (𝕜 := ℝ) (D.nonzero i j hij)
  · intro i j
    simp only [normalizedAssignment, D.reverse i j, norm_neg, smul_neg]

theorem normalizedAssignment_angle {V : Type*} (D : GeneralizedDirections V)
    (t : DirectionTriple V) :
    assignmentTripleAngle D.normalizedAssignment t = D.tripleAngle t.val.1 t.val.2.1 t.val.2.2 := by
  unfold assignmentTripleAngle normalizedAssignment tripleAngle
  rw [InnerProductGeometry.angle_smul_left_of_pos _ _
      (inv_pos.mpr (norm_pos_iff.mpr (D.nonzero _ _ t.property.1.symm))),
    InnerProductGeometry.angle_smul_right_of_pos _ _
      (inv_pos.mpr (norm_pos_iff.mpr (D.nonzero _ _ t.property.2.2)))]

end GeneralizedDirections
end Prize.JSP404
