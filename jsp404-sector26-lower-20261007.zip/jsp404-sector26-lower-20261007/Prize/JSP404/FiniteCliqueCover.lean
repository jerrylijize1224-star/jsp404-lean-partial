import Prize.JSP404.FiniteCliqueCertificate

/-! A checked cover of all finite graph cliques by an explicit list of types. -/
namespace Prize.JSP404.FiniteCliqueCertificate
variable {V : Type*} [DecidableEq V]

inductive CoverCertificate (V : Type*) where
  | leaf : List V → CoverCertificate V
  | split : V → CoverCertificate V → CoverCertificate V → CoverCertificate V

def coverCheck (G : V → V → Bool) (P : List V) (types : List (List V)) :
    CoverCertificate V → Bool
  | .leaf T => types.contains T && P.all (fun v => T.contains v)
  | .split v no yes => coverCheck G (P.erase v) types no &&
      coverCheck G ((P.erase v).filter (fun w => G v w))
        (types.filter (fun T => T.contains v)) yes

def Covers (G : V → V → Bool) (P : List V) (types : List (List V)) : Prop :=
  ∀ s : Finset V, (∀ v ∈ s, v ∈ P) → Clique G s →
    ∃ T ∈ types, ∀ v ∈ s, v ∈ T

theorem coverCheck_sound (G : V → V → Bool) (cert : CoverCertificate V) :
    ∀ P types, coverCheck G P types cert = true → Covers G P types := by
  induction cert with
  | leaf T =>
    intro P types h s hs hc
    have hh : T ∈ types ∧ ∀ v ∈ P, v ∈ T := by
      simpa [coverCheck, Bool.and_eq_true, List.all_eq_true] using h
    exact ⟨T, hh.1, fun v hv => hh.2 v (hs v hv)⟩
  | split v no yes ihno ihyes =>
    intro P types h s hs hc
    have hh : coverCheck G (P.erase v) types no = true ∧
        coverCheck G ((P.erase v).filter (fun w => G v w))
          (types.filter (fun T => T.contains v)) yes = true := by
      simpa [coverCheck, Bool.and_eq_true] using h
    by_cases hv : v ∈ s
    · have he : ∀ w ∈ s.erase v, w ∈ (P.erase v).filter (fun w => G v w) := by
        intro w hw
        obtain ⟨hne, hws⟩ := Finset.mem_erase.mp hw
        exact List.mem_filter.mpr
          ⟨(List.mem_erase_of_ne hne).mpr (hs w hws), hc v hv w hws hne.symm⟩
      have hce : Clique G (s.erase v) := by
        intro a ha b hb hab
        exact hc a (Finset.mem_of_mem_erase ha) b (Finset.mem_of_mem_erase hb) hab
      obtain ⟨T, hT, hcov⟩ := ihyes _ _ hh.2 (s.erase v) he hce
      have hT' : T ∈ types ∧ v ∈ T := by simpa using hT
      refine ⟨T, hT'.1, ?_⟩
      intro w hw
      by_cases hwv : w = v
      · simpa [hwv] using hT'.2
      · exact hcov w (Finset.mem_erase.mpr ⟨hwv, hw⟩)
    · apply ihno _ _ hh.1 s ?_ hc
      intro w hw
      have hne : w ≠ v := by intro h; subst w; exact hv hw
      exact (List.mem_erase_of_ne hne).mpr (hs w hw)

end Prize.JSP404.FiniteCliqueCertificate
