import Prize.JSP404.WeightedDirectionCover
import Mathlib.Data.Finset.Sigma

/-! Total free-bit budget and rigidity one vertex below saturation. -/
namespace Prize.JSP404
open scoped Classical

/-- Count free vertex-relation pairs, including multiple unused relations at one vertex. -/
noncomputable def freeCoverSlots {V : Type*} [Fintype V] {k : ℕ}
    (R : Fin k → V → V → Prop) : Finset (Σ _ : V, Fin k) :=
  Finset.univ.sigma (freeCoverIndices R)

theorem card_add_free_slots_le_two_pow {V : Type*} [Fintype V] {k : ℕ}
    (R : Fin k → V → V → Prop)
    (hcover : ∀ u v, u ≠ v → ∃ i, R i u v ∨ R i v u)
    (hstep : ∀ i u v w, R i u v → R i v w → False) :
    Fintype.card V + (freeCoverSlots R).card ≤ 2 ^ k := by
  classical
  have hpow (n : ℕ) : 1 + n ≤ 2 ^ n := by
    induction n with
    | zero => simp
    | succ n ih => rw [pow_succ]; omega
  have hs := Finset.sum_le_sum (fun v (_ : v ∈ (Finset.univ : Finset V)) =>
    hpow (freeCoverIndices R v).card)
  have hb : Fintype.card V + (freeCoverSlots R).card ≤
      ∑ v : V, 2 ^ (freeCoverIndices R v).card := by
    simpa [freeCoverSlots, Finset.card_sigma, Finset.sum_add_distrib] using hs
  exact hb.trans (weighted_card_le_two_pow_of_no_two_step_cover R hcover hstep)

theorem near_saturated_free_slots_le_one {V : Type*} [Fintype V] {k : ℕ}
    (R : Fin k → V → V → Prop)
    (hcover : ∀ u v, u ≠ v → ∃ i, R i u v ∨ R i v u)
    (hstep : ∀ i u v w, R i u v → R i v w → False)
    (hcard : Fintype.card V + 1 = 2 ^ k) : (freeCoverSlots R).card ≤ 1 := by
  have h := card_add_free_slots_le_two_pow R hcover hstep
  omega

/-- One below saturation, even two different free bits at the same vertex are impossible. -/
theorem near_saturated_free_slot_unique {V : Type*} [Fintype V] {k : ℕ}
    (R : Fin k → V → V → Prop)
    (hcover : ∀ u v, u ≠ v → ∃ i, R i u v ∨ R i v u)
    (hstep : ∀ i u v w, R i u v → R i v w → False)
    (hcard : Fintype.card V + 1 = 2 ^ k)
    {u v : V} {i j : Fin k} (hi : i ∈ freeCoverIndices R u)
    (hj : j ∈ freeCoverIndices R v) : u = v ∧ i = j := by
  have he : (⟨u, i⟩ : Σ _ : V, Fin k) = ⟨v, j⟩ :=
    Finset.card_le_one.mp (near_saturated_free_slots_le_one R hcover hstep hcard)
      _ (by simp [freeCoverSlots, hi]) _ (by simp [freeCoverSlots, hj])
  exact ⟨congrArg Sigma.fst he, congrArg (fun p : Σ _ : V, Fin k => p.2) he⟩

end Prize.JSP404
