import Prize.JSP404.FinitePeriodicGap
import Prize.JSP404.ProjectiveCoordinates
import Prize.JSP404.GapSectorCounting

/-! Explicitly shortened sectors for a finite family of nonzero directions.
The empty phase bin is chosen once for the entire family. -/

namespace Prize.JSP404

open InnerProductGeometry

theorem exists_short_sector_cover {J : Type*} [Fintype J] [Nonempty J]
    (p : J → Plane) (hp : ∀ j, p j ≠ 0) {k : ℕ} (hk : 0 < k) :
    ∃ C : Fin k → Set Plane,
      (∀ j, ∃ i, p j ∈ C i ∨ -p j ∈ C i) ∧
      (∀ i, ∀ u ∈ C i, ∀ v ∈ C i,
        angle u v < (Real.pi / k) * (1 - 1 / (Fintype.card J + 1 : ℝ))) := by
  classical
  let δ : ℝ := Real.pi / k
  let ε : ℝ := 1 / (Fintype.card J + 1 : ℝ)
  have hkR : (0 : ℝ) < k := by exact_mod_cast hk
  have hk1 : (1 : ℝ) ≤ k := by exact_mod_cast hk
  have hδ : 0 < δ := div_pos Real.pi_pos hkR
  have hδπ : δ ≤ Real.pi := (div_le_iff₀ hkR).mpr (by nlinarith [Real.pi_pos])
  have hδk : δ * k = Real.pi := div_mul_cancel₀ _ (ne_of_gt hkR)
  have hε : 0 < ε := by dsimp [ε]; positivity
  have hcard : (0 : ℝ) < Fintype.card J := by exact_mod_cast Fintype.card_pos
  have hε1 : ε < 1 := by
    dsimp [ε]
    exact (div_lt_one (by positivity)).mpr (by linarith)
  choose θ r b hθ hθπ hr hrep using fun j => exists_projective_coordinates (hp j)
  obtain ⟨β, hβε, hβ1, hgap⟩ := exists_empty_phase_bin (fun j => θ j / δ)
  change ε ≤ β at hβε
  have hβ0 : 0 < β := hε.trans_le hβε
  let left : ℝ := δ * β
  have hleft0 : 0 ≤ left := (mul_pos hδ hβ0).le
  have hleftπ : left ≤ Real.pi := by dsimp [left]; nlinarith
  have hshift (j : J) : ∃ φ : ℝ, ∃ c : Bool,
      left ≤ φ ∧ φ < left + Real.pi ∧ p j = r j • signedDirection φ c ∧
      Int.fract (φ / δ) ∉ Set.Ico (β - ε) β := by
    by_cases hle : left ≤ θ j
    · exact ⟨θ j, b j, hle, by linarith [hθπ j], hrep j, hgap j⟩
    · refine ⟨θ j + Real.pi, !(b j), by linarith [hθ j], by linarith, ?_, ?_⟩
      · have he : signedDirection (θ j + Real.pi) (!(b j)) = signedDirection (θ j) (b j) := by
          cases b j <;> simp [signedDirection, unitDirection_add_pi]
        rw [he]
        exact hrep j
      · have he : (θ j + Real.pi) / δ = θ j / δ + k := by
          apply (div_eq_iff (ne_of_gt hδ)).mpr
          nlinarith [div_mul_cancel₀ (θ j) (ne_of_gt hδ)]
        rw [he]
        exact phase_gap_add_nat (hgap j) k
  let C : Fin k → Set Plane := fun i =>
    parameterSector left δ (Set.Ico (i.val : ℝ) (i.val + 1 - ε))
  refine ⟨C, ?_, ?_⟩
  · intro j
    obtain ⟨φ, c, hlo, hhi, hφ, hg⟩ := hshift j
    let z : ℝ := (φ - left) / δ
    have hz0 : 0 ≤ z := div_nonneg (sub_nonneg.mpr hlo) hδ.le
    have hzk : z < k := by
      apply (div_lt_iff₀ hδ).mpr
      nlinarith
    let i : Fin k := ⟨⌊z⌋₊, (Nat.floor_lt hz0).mpr hzk⟩
    have hzi : (i.val : ℝ) ≤ z := Nat.floor_le hz0
    have hzi' : z < (i.val : ℝ) + 1 := Nat.lt_floor_add_one z
    have hxeq : φ / δ = z + β := by
      dsimp [z, left]
      field_simp [ne_of_gt hδ]
      ring
    have hxlo : (i.val : ℝ) + β ≤ φ / δ := by rw [hxeq]; linarith
    have hxhi : φ / δ < (i.val : ℝ) + β + 1 := by rw [hxeq]; linarith
    have hshort := shifted_unit_interval_shortening hε hβε hβ1 hg hxlo hxhi
    have hmem : z ∈ Set.Ico (i.val : ℝ) (i.val + 1 - ε) := by
      rw [hxeq] at hshort
      exact ⟨hzi, by linarith⟩
    have he : left + δ * z = φ := by
      dsimp [z]
      field_simp [ne_of_gt hδ]
      ring
    refine ⟨i, ?_⟩
    cases c
    · left
      exact ⟨z, hmem, r j, hr j, by simpa only [he, signedDirection, Bool.false_eq_true,
        ↓reduceIte] using hφ⟩
    · right
      refine ⟨z, hmem, r j, hr j, ?_⟩
      rw [he, hφ]
      simp [signedDirection]
  · intro i u hu v hv
    rcases hu with ⟨x, hx, a, ha, rfl⟩
    rcases hv with ⟨y, hy, d, hd, rfl⟩
    have hxy : |x - y| < 1 - ε :=
      abs_lt.mpr ⟨by linarith [hx.1, hy.2], by linarith [hx.2, hy.1]⟩
    have hdist : |(left + δ * x) - (left + δ * y)| < δ * (1 - ε) := by
      rw [show (left + δ * x) - (left + δ * y) = δ * (x - y) by ring,
        abs_mul, abs_of_pos hδ]
      exact mul_lt_mul_of_pos_left hxy hδ
    have hwπ : δ * (1 - ε) ≤ Real.pi := by nlinarith
    rw [angle_smul_left_of_pos _ _ ha, angle_smul_right_of_pos _ _ hd,
      unitDirection_angle_abs (hdist.le.trans hwπ)]
    exact hdist

end Prize.JSP404
