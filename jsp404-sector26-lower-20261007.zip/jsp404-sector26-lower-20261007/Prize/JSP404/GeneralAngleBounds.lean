import Prize.JSP404.UniformSectorLowerBound
import Prize.JSP404.FirstBandConstruction

/-! Verified intervals for both bands, retaining the gap between the elementary
uniform-sector lower bound and Sendov's proposed sharp values. -/

namespace Prize.JSP404

theorem low_band_alpha_bounds {k N : ℕ} (hk : 2 ≤ k)
    (hlo : 2 ^ k < N) (hhi : N ≤ 2 ^ k + 2 ^ (k - 2)) :
    (1 - 1 / (k : ℝ)) * Real.pi ≤ alpha N ∧
      alpha N ≤ (1 - 2 / (2 * (k : ℝ) + 1)) * Real.pi :=
  ⟨uniform_alpha_lower (by omega) hlo, sendov_low_band_upper hk hlo hhi⟩

theorem high_band_alpha_bounds {k N : ℕ} (hk : 2 ≤ k)
    (hlo : 2 ^ k + 2 ^ (k - 2) < N) (hhi : N ≤ 2 ^ (k + 1)) :
    (1 - 1 / (k : ℝ)) * Real.pi ≤ alpha N ∧
      alpha N ≤ (1 - 1 / ((k : ℝ) + 1)) * Real.pi :=
  ⟨uniform_alpha_lower (by omega) (lt_of_le_of_lt (Nat.le_add_right _ _) hlo),
    sendov_high_band_upper hk hlo hhi⟩

/-- 135 degrees <= alpha(17) <= 140 degrees; no equality is asserted. -/
theorem alpha_seventeen_bounds :
    (3 / 4 : ℝ) * Real.pi ≤ alpha 17 ∧ alpha 17 ≤ (7 / 9 : ℝ) * Real.pi := by
  have h := low_band_alpha_bounds (k := 4) (N := 17) (by decide) (by decide) (by decide)
  norm_num at h ⊢
  exact h

end Prize.JSP404
