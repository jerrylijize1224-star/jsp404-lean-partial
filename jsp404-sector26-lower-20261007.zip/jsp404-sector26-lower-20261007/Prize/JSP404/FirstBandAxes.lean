import Prize.JSP404.EquallySpacedBinaryAxes

/-! Axis certificates for the three-cluster construction of the first band.
The parameter n corresponds to k-2 in the original target. These are geometric
ingredients, not a completed first-band ordinary-configuration theorem. -/

namespace Prize.JSP404

theorem signed_circle_angle_le {a b w : ℝ} (hw : 0 ≤ w)
    (hlo : w ≤ b - a) (hhi : b - a ≤ Real.pi - w) (x y : Bool) :
    InnerProductGeometry.angle (signedBinaryAxis (circleDirection a) x)
      (signedBinaryAxis (circleDirection b) y) ≤ Real.pi - w := by
  have ha := circleDirection_angle (show a ≤ b by linarith) (show b - a ≤ Real.pi by linarith)
  cases x <;> cases y <;>
    simp only [signedBinaryAxis, Bool.false_eq_true, ↓reduceIte,
      InnerProductGeometry.angle_neg_left, InnerProductGeometry.angle_neg_right, ha] <;> linarith

noncomputable def firstBandStep (n : ℕ) : ℝ := Real.pi / (2 * (n : ℝ) + 5)

def firstBandDepth (n : ℕ) (i : Fin 3) : ℕ := if i = 2 then n else n + 1

def firstBandOffset (i : Fin 3) : ℝ := if i = 1 then 2 else 3

noncomputable def firstBandAxisAngle (n : ℕ) (i : Fin 3)
    (r : Fin (firstBandDepth n i)) : ℝ :=
  (2 * (r.val : ℝ) + firstBandOffset i) * firstBandStep n

noncomputable def firstBandAxis (n : ℕ) (i : Fin 3)
    (r : Fin (firstBandDepth n i)) : Plane := circleDirection (firstBandAxisAngle n i r)

theorem firstBandStep_pos (n : ℕ) : 0 < firstBandStep n := by
  unfold firstBandStep
  positivity

theorem firstBandStep_mul (n : ℕ) : (2 * (n : ℝ) + 5) * firstBandStep n = Real.pi := by
  unfold firstBandStep
  have : (2 * (n : ℝ) + 5) ≠ 0 := by positivity
  field_simp

theorem firstBandStep_small (n : ℕ) : 5 * firstBandStep n ≤ Real.pi := by
  have hp := firstBandStep_pos n
  have he := firstBandStep_mul n
  nlinarith [mul_nonneg (Nat.cast_nonneg n : (0 : ℝ) ≤ n) hp.le]

theorem firstBandDepth_le (n : ℕ) (i : Fin 3) : firstBandDepth n i ≤ n + 1 := by
  unfold firstBandDepth
  split_ifs <;> omega

theorem firstBandAxis_nonzero (n : ℕ) (i : Fin 3) (r : Fin (firstBandDepth n i)) :
    firstBandAxis n i r ≠ 0 := circleDirection_nonzero _

theorem firstBandAxis_angle (n : ℕ) (i : Fin 3)
    (r s : Fin (firstBandDepth n i)) (hrs : r ≠ s) (x y : Bool) :
    InnerProductGeometry.angle (signedBinaryAxis (firstBandAxis n i r) x)
      (signedBinaryAxis (firstBandAxis n i s) y) ≤ Real.pi - 2 * firstBandStep n := by
  have ordered (r s : Fin (firstBandDepth n i)) (hrs : r < s) (x y : Bool) :
      InnerProductGeometry.angle (signedBinaryAxis (firstBandAxis n i r) x)
        (signedBinaryAxis (firstBandAxis n i s) y) ≤ Real.pi - 2 * firstBandStep n := by
    have hd := firstBandStep_pos n
    have he := firstBandStep_mul n
    have hlow : (r.val : ℝ) + 1 ≤ s.val := by exact_mod_cast hrs
    have hsN : s.val ≤ n := by have := firstBandDepth_le n i; have := s.isLt; omega
    have hsR : (s.val : ℝ) ≤ n := by exact_mod_cast hsN
    have hr0 : (0 : ℝ) ≤ r.val := Nat.cast_nonneg _
    unfold firstBandAxis firstBandAxisAngle
    apply signed_circle_angle_le (by positivity)
    · nlinarith
    · nlinarith
  rcases lt_or_gt_of_ne hrs with h | h
  · exact ordered r s h x y
  · rw [InnerProductGeometry.angle_comm]
    exact ordered s r h y x

/-- Centre-edge lines: signs are treated separately, so a ray and its negative
use the same angle here. Only off-diagonal entries are used. -/
noncomputable def firstBandEdgeAngle (n : ℕ) (i j : Fin 3) : ℝ :=
  if (i = 0 ∧ j = 1) ∨ (i = 1 ∧ j = 0) then 0
  else if (i = 0 ∧ j = 2) ∨ (i = 2 ∧ j = 0) then firstBandStep n
  else Real.pi - firstBandStep n

/-- Both signs are allowed on the internal axis and on each outgoing line.
This is stronger than the mixed-angle condition needed by cluster realization. -/
theorem firstBandAxis_edge_angle (n : ℕ) (i j : Fin 3) (hij : i ≠ j)
    (r : Fin (firstBandDepth n i)) (x y : Bool) :
    InnerProductGeometry.angle (signedBinaryAxis (firstBandAxis n i r) x)
      (signedBinaryAxis (circleDirection (firstBandEdgeAngle n i j)) y) ≤
        Real.pi - 2 * firstBandStep n := by
  have hd := firstBandStep_pos n
  have he := firstBandStep_mul n
  have hsmall := firstBandStep_small n
  have hr0 : (0 : ℝ) ≤ r.val := Nat.cast_nonneg _
  have hrR : (r.val : ℝ) + 1 ≤ (firstBandDepth n i : ℝ) := by exact_mod_cast r.isLt
  have hrMul := mul_le_mul_of_nonneg_right hrR hd.le
  unfold firstBandAxis firstBandAxisAngle
  fin_cases i <;> fin_cases j <;> norm_num at hij
  all_goals norm_num [firstBandDepth, firstBandOffset, firstBandEdgeAngle] at hrMul ⊢
  all_goals first
    | (apply signed_circle_angle_le (by positivity) <;> nlinarith)
    | (rw [InnerProductGeometry.angle_comm]; apply signed_circle_angle_le (by positivity) <;> nlinarith)

end Prize.JSP404
