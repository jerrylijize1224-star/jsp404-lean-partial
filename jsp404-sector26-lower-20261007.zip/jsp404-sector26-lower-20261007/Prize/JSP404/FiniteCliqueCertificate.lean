import Mathlib.Data.Fintype.Card
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Lattice.Basic

/-! Soundness of a finite clique certificate checker. No numerical angle bound is claimed here. -/
namespace Prize.JSP404.FiniteCliqueCertificate
variable {V : Type*} [DecidableEq V]

def Clique (G : V → V → Bool) (s : Finset V) : Prop :=
  ∀ u ∈ s, ∀ v ∈ s, u ≠ v → G u v = true

def Bound (G : V → V → Bool) (P : List V) (k : ℕ) : Prop :=
  ∀ s : Finset V, (∀ v ∈ s, v ∈ P) → Clique G s → s.card ≤ k

def colorCheck (G : V → V → Bool) (P : List V) (k : ℕ)
    (colors : List (List V)) : Bool :=
  decide (colors.length ≤ k) &&
  P.all (fun v => colors.any (fun C => C.contains v)) &&
  colors.all (fun C => C.all (fun u => C.all (fun v => !(G u v))))

theorem colorCheck_sound (G : V → V → Bool) (P : List V) (k : ℕ)
    (colors : List (List V)) (h : colorCheck G P k colors = true) : Bound G P k := by
  classical
  have hh : (colors.length ≤ k ∧ (∀ v ∈ P, ∃ C ∈ colors, v ∈ C)) ∧
      (∀ C ∈ colors, ∀ u ∈ C, ∀ v ∈ C, G u v = false) := by
    simpa [colorCheck, Bool.and_eq_true, List.all_eq_true, List.any_eq_true] using h
  intro s hs hc
  have hex (v : s) : ∃ C ∈ colors, (v : V) ∈ C := hh.1.2 v (hs v v.property)
  let f : s → {C : List V // C ∈ colors.toFinset} := fun v =>
    ⟨Classical.choose (hex v), by
      simpa using (Classical.choose_spec (hex v)).1⟩
  have hf (v : s) : (v : V) ∈ (f v).val := (Classical.choose_spec (hex v)).2
  have hi : Function.Injective f := by
    intro u v he
    apply Subtype.ext
    by_contra hn
    have hg := hc u u.property v v.property hn
    have he' := congrArg Subtype.val he
    have hv : (v : V) ∈ (f u).val := he' ▸ hf v
    have hz := hh.2 (f u).val (List.mem_toFinset.mp (f u).property) u (hf u) v hv
    rw [hg] at hz
    contradiction
  have hcard := Fintype.card_le_of_injective f hi
  have hc' : s.card ≤ colors.toFinset.card := by simpa only [Fintype.card_coe] using hcard
  exact hc'.trans ((List.toFinset_card_le colors).trans hh.1.1)

inductive Certificate (V : Type*) where
  | color : List (List V) → Certificate V
  | split : V → Certificate V → Certificate V → Certificate V

def check (G : V → V → Bool) (P : List V) (k : ℕ) : Certificate V → Bool
  | .color cs => colorCheck G P k cs
  | .split v no yes => decide (0 < k) && check G (P.erase v) k no &&
      check G ((P.erase v).filter (fun w => G v w)) (k-1) yes

theorem check_sound (G : V → V → Bool) (cert : Certificate V) :
    ∀ P k, check G P k cert = true → Bound G P k := by
  induction cert with
  | color cs => intro P k h; exact colorCheck_sound G P k cs h
  | split v no yes ihno ihyes =>
    intro P k h
    have hh : (0 < k ∧ check G (P.erase v) k no = true) ∧
        check G ((P.erase v).filter (fun w => G v w)) (k-1) yes = true := by
      simpa [check, Bool.and_eq_true] using h
    intro s hs hc
    by_cases hv : v ∈ s
    · have he : ∀ w ∈ s.erase v, w ∈ (P.erase v).filter (fun w => G v w) := by
        intro w hw
        obtain ⟨hne, hws⟩ := Finset.mem_erase.mp hw
        apply List.mem_filter.mpr
        exact ⟨(List.mem_erase_of_ne hne).mpr (hs w hws), hc v hv w hws hne.symm⟩
      have hce : Clique G (s.erase v) := by
        intro a ha b hb hab
        exact hc a (Finset.mem_of_mem_erase ha) b (Finset.mem_of_mem_erase hb) hab
      have hb := ihyes _ _ hh.2 (s.erase v) he hce
      have hcsize := Finset.card_erase_add_one hv
      omega
    · apply ihno _ _ hh.1.2 s ?_ hc
      intro w hw
      have hne : w ≠ v := by intro h; subst w; exact hv hw
      exact (List.mem_erase_of_ne hne).mpr (hs w hw)


theorem bound_of_orbit_neighbors [Fintype V] (G : V → V → Bool)
    (f : V → V) (hf : Function.Injective f)
    (hG : ∀ u v, G u v = true → G (f u) (f v) = true)
    (R : List V) (hcover : ∀ v, ∃ n : ℕ, f^[n] v ∈ R) (k : ℕ)
    (hb : ∀ r ∈ R, ∀ s : Finset V, Clique G s →
      (∀ v ∈ s, G r v = true) → s.card ≤ k) :
    ∀ s : Finset V, Clique G s → s.card ≤ k+1 := by
  classical
  have hiter (n : ℕ) : ∀ u v, G u v = true → G (f^[n] u) (f^[n] v) = true := by
    induction n with
    | zero => intro u v h; exact h
    | succ n ih =>
      intro u v h
      simpa only [Function.iterate_succ_apply'] using hG _ _ (ih u v h)
  intro s hs
  by_cases he : s.Nonempty
  · obtain ⟨v, hv⟩ := he
    obtain ⟨n, hn⟩ := hcover v
    let t := s.image (f^[n])
    have hc : t.card = s.card := Finset.card_image_of_injective s (hf.iterate n)
    have ht : Clique G t := by
      intro a ha b hb hab
      obtain ⟨x, hx, rfl⟩ := Finset.mem_image.mp ha
      obtain ⟨y, hy, rfl⟩ := Finset.mem_image.mp hb
      exact hiter n x y (hs x hx y hy (fun h => hab (congrArg _ h)))
    have hmem : f^[n] v ∈ t := Finset.mem_image.mpr ⟨v, hv, rfl⟩
    have hce : Clique G (t.erase (f^[n] v)) := by
      intro a ha b hb hab
      exact ht a (Finset.mem_of_mem_erase ha) b (Finset.mem_of_mem_erase hb) hab
    have he := hb _ hn (t.erase (f^[n] v)) hce (by
      intro w hw
      exact ht _ hmem w (Finset.mem_of_mem_erase hw) (Finset.ne_of_mem_erase hw).symm)
    have hsize := Finset.card_erase_add_one hmem
    omega
  · have hs0 : s = ∅ := Finset.not_nonempty_iff_eq_empty.mp he
    simp [hs0]

end Prize.JSP404.FiniteCliqueCertificate
