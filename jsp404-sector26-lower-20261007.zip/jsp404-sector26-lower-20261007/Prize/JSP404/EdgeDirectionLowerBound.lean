import Prize.JSP404.QuantitativeLowerBound
import Mathlib.Data.Finset.Prod
import Mathlib.Data.Nat.Choose.Bounds

/-! Count one representative per unordered edge, with no diagonal dummy.
This improves the explicit non-sharp margin, not Sendov's sharp target. -/

namespace Prize.JSP404

open InnerProductGeometry

noncomputable def representativeAngle (k M : ℕ) : ℝ :=
  Real.pi - (Real.pi / k) * (1 - 1 / ((M : ℝ) + 1))

theorem representativeAngle_bounds {k M : ℕ} (hk : 0 < k) :
    0 ≤ representativeAngle k M ∧ representativeAngle k M ≤ Real.pi := by
  have hkR : (0 : ℝ) < k := by exact_mod_cast hk
  have hk1 : (1 : ℝ) ≤ k := by exact_mod_cast hk
  have hd : 0 < Real.pi / k := div_pos Real.pi_pos hkR
  have hdπ : Real.pi / k ≤ Real.pi := (div_le_iff₀ hkR).mpr (by nlinarith [Real.pi_pos])
  have he : 0 < 1 / ((M : ℝ) + 1) := by positivity
  have he1 : 1 / ((M : ℝ) + 1) ≤ 1 := (div_le_one (by positivity)).mpr (by have := Nat.cast_nonneg (α := ℝ) M; linarith)
  dsimp [representativeAngle]
  constructor <;> nlinarith

/-- Any nonzero family representing each directed edge up to sign suffices. -/
theorem GeneralizedDirections.card_le_of_representatives
    {V J : Type*} [Fintype V] [Fintype J] [Nonempty J]
    (D : GeneralizedDirections V) (p : J → Plane) (hp : ∀ j, p j ≠ 0)
    (hrep : ∀ u v, u ≠ v → ∃ j, D.direction u v = p j ∨ D.direction u v = -p j)
    {k : ℕ} (hk : 0 < k)
    (hbound : D.AngleBound (representativeAngle k (Fintype.card J))) :
    Fintype.card V ≤ 2 ^ k := by
  obtain ⟨C, hc, ht⟩ := exists_short_sector_cover p hp hk
  apply D.card_le_two_pow_of_cover (representativeAngle_bounds hk).1 C ?_ ?_ hbound
  · intro u v huv
    obtain ⟨j, hj⟩ := hrep u v huv
    obtain ⟨i, hi⟩ := hc j
    refine ⟨i, ?_⟩
    rw [D.reverse u v]
    rcases hj with hj | hj
    · rwa [hj]
    · rw [hj, neg_neg]
      exact hi.symm
  · intro i u hu v hv
    simpa [representativeAngle] using ht i u hu v hv

/-- Exactly one orientation for each unordered pair of distinct labels. -/
def increasingPairs (V : Type*) [Fintype V] [LinearOrder V] : Finset (V × V) :=
  (Finset.univ ×ˢ Finset.univ).filter (fun uv => uv.1 < uv.2)

theorem increasingPairs_card (V : Type*) [Fintype V] [LinearOrder V] :
    (increasingPairs V).card = (Fintype.card V).choose 2 := by
  simpa [increasingPairs] using (Finset.card_product_filter_lt (s := (Finset.univ : Finset V)))

theorem increasingPairs_nonempty (V : Type*) [Fintype V] [LinearOrder V] [Nontrivial V] :
    (increasingPairs V).Nonempty := by
  obtain ⟨u, v, huv⟩ := exists_pair_ne V
  rcases lt_or_gt_of_ne huv with h | h
  · exact ⟨(u, v), by simp [increasingPairs, h]⟩
  · exact ⟨(v, u), by simp [increasingPairs, h]⟩

noncomputable def edgeAngle (k N : ℕ) : ℝ := representativeAngle k (N.choose 2)

theorem edgeAngle_eq (k N : ℕ) :
    edgeAngle k N = (1 - 1 / (k : ℝ)) * Real.pi +
      Real.pi / ((k : ℝ) * ((N.choose 2 : ℝ) + 1)) := by
  simp only [edgeAngle, representativeAngle, div_mul_eq_div_div]
  ring

/-- Fewer representatives give a strictly larger certified angle. -/
theorem representativeAngle_strictAnti {k : ℕ} (hk : 0 < k) :
    StrictAnti (representativeAngle k) := by
  intro M L hML
  have hd : 0 < Real.pi / k := div_pos Real.pi_pos (by exact_mod_cast hk)
  have hMLR : (M : ℝ) < L := by exact_mod_cast hML
  have hi : 1 / ((L : ℝ) + 1) < 1 / ((M : ℝ) + 1) :=
    one_div_lt_one_div_of_lt (by positivity) (by linarith)
  dsimp [representativeAngle]
  nlinarith

/-- This bound is strictly stronger than the earlier ordered-pair estimate. -/
theorem quantitativeAngle_lt_edgeAngle {k N : ℕ} (hk : 0 < k) (hN : 0 < N) :
    quantitativeAngle k N < edgeAngle k N := by
  have h := representativeAngle_strictAnti hk (Nat.choose_lt_pow (Nat.ne_of_gt hN) (by decide : 2 ≤ 2))
  simpa [representativeAngle, quantitativeAngle, edgeAngle] using h

theorem GeneralizedDirections.card_le_two_pow_of_edge_angle
    {V : Type*} [Fintype V] [LinearOrder V] [Nontrivial V] (D : GeneralizedDirections V)
    {k : ℕ} (hk : 0 < k) (hbound : D.AngleBound (edgeAngle k (Fintype.card V))) :
    Fintype.card V ≤ 2 ^ k := by
  classical
  have : Nonempty (increasingPairs V) := (increasingPairs_nonempty V).to_subtype
  let p : increasingPairs V → Plane := fun uv => D.direction uv.val.1 uv.val.2
  have hp : ∀ uv, p uv ≠ 0 := by
    intro uv
    have hlt : uv.val.1 < uv.val.2 := (Finset.mem_filter.mp uv.property).2
    exact D.nonzero _ _ hlt.ne
  have hr : ∀ u v, u ≠ v → ∃ j, D.direction u v = p j ∨ D.direction u v = -p j := by
    intro u v huv
    rcases lt_or_gt_of_ne huv with h | h
    · exact ⟨⟨(u, v), by simp [increasingPairs, h]⟩, Or.inl rfl⟩
    · refine ⟨⟨(v, u), by simp [increasingPairs, h]⟩, Or.inr ?_⟩
      exact D.reverse v u
  apply D.card_le_of_representatives p hp hr hk
  simpa only [Fintype.card_coe, increasingPairs_card, edgeAngle] using hbound

theorem guaranteedAngle_edge {k N : ℕ} (hk : 0 < k) (hN : 2 ^ k < N) :
    GuaranteedAngle N (edgeAngle k N) := by
  classical
  have htwo : 2 ≤ (2 : ℕ) ^ k := by
    calc
      2 = (2 : ℕ) ^ 1 := by norm_num
      _ ≤ 2 ^ k := pow_le_pow_right₀ (by decide) hk
  have : Nontrivial (Fin N) := Fin.nontrivial_iff_two_le.mpr (by omega)
  intro s hs
  let e : s ≃ Fin N := (Fintype.equivFin s).trans (finCongr (by simpa using hs))
  let p : Fin N → Plane := fun i => (e.symm i).val
  have hp : Function.Injective p := Subtype.val_injective.comp e.symm.injective
  let D : GeneralizedDirections (Fin N) := {
    direction := fun i j => p j - p i
    reverse := fun i j => by abel
    nonzero := fun i j hij => sub_ne_zero.mpr (hp.ne hij.symm) }
  by_contra h
  have hb : D.AngleBound (edgeAngle k N) := by
    intro i j l hij hil hjl
    have hn : ¬ edgeAngle k N ≤ EuclideanGeometry.angle (p i) (p j) (p l) := by
      intro ha
      exact h ⟨p i, (e.symm i).property, p j, (e.symm j).property,
        p l, (e.symm l).property, hp.ne hij, hp.ne hil, hp.ne hjl, ha⟩
    exact (lt_of_not_ge hn).le
  have hc := D.card_le_two_pow_of_edge_angle hk (by simpa using hb)
  simp only [Fintype.card_fin] at hc
  omega

theorem edge_alpha_lower {k N : ℕ} (hk : 0 < k) (hN : 2 ^ k < N) :
    edgeAngle k N ≤ alpha N := by
  apply le_csSup (admissibleAngles_bddAbove N)
  exact ⟨(representativeAngle_bounds hk).1, (representativeAngle_bounds hk).2,
    guaranteedAngle_edge hk hN⟩

theorem edge_alpha_lower_uniform {k N : ℕ} (hk : 0 < k) (hN : 2 ^ k < N) :
    edgeAngle k (2 ^ k + 1) ≤ alpha N := by
  have htwo : 2 ≤ (2 : ℕ) ^ k := by
    calc
      2 = (2 : ℕ) ^ 1 := by norm_num
      _ ≤ 2 ^ k := pow_le_pow_right₀ (by decide) hk
  exact (edge_alpha_lower hk (Nat.lt_succ_self _)).trans (alpha_mono (by omega) (by omega))

theorem alpha_seventeen_edge_bounds :
    (103 / 137 : ℝ) * Real.pi ≤ alpha 17 ∧ alpha 17 ≤ (7 / 9 : ℝ) * Real.pi := by
  have hl := edge_alpha_lower (k := 4) (N := 17) (by decide) (by decide)
  norm_num [edgeAngle, representativeAngle, Nat.choose] at hl
  exact ⟨by linarith, alpha_seventeen_strict_bounds.2⟩

end Prize.JSP404
