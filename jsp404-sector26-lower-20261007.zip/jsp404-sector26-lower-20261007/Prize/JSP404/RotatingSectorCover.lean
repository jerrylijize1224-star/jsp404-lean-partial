import Prize.JSP404.SaturatedCover
import Prize.JSP404.GeneralizedDirectionCover
import Prize.JSP404.ProjectiveCoordinates
import Prize.JSP404.GapSectorCounting
import Mathlib.Geometry.Euclidean.Angle.Unoriented.TriangleInequality
import Mathlib.Topology.Instances.Real.Lemmas

/-! Open rotating sectors exclude equality in the binary count when the
angle cap is strictly below pi-pi/k. -/
namespace Prize.JSP404
open InnerProductGeometry

theorem continuous_unitDirection : Continuous unitDirection := by
  unfold unitDirection
  fun_prop

theorem unitDirection_ne_zero (t : ℝ) : unitDirection t ≠ 0 := by
  intro h
  have hn := unitDirection_norm t
  rw [h, norm_zero] at hn
  norm_num at hn

theorem continuous_angle_unitDirection {p : Plane} (hp : p ≠ 0) :
    Continuous (fun t => angle p (unitDirection t)) := by
  apply continuous_iff_continuousAt.mpr
  intro t
  exact ContinuousAt.comp (f := fun x : ℝ => (p, unitDirection x))
    (continuousAt_angle (x := (p, unitDirection t)) hp (unitDirection_ne_zero t))
    (continuous_const.prodMk continuous_unitDirection).continuousAt

theorem exists_projective_coordinates_closed_origin {p : Plane} (hp : p ≠ 0)
    {t : ℝ} (ht : 0 ≤ t) (htπ : t ≤ Real.pi) :
    ∃ θ r : ℝ, ∃ b : Bool, t ≤ θ ∧ θ < t + Real.pi ∧ 0 < r ∧
      p = r • signedDirection θ b := by
  obtain ⟨θ, r, b, hθ, hθπ, hr, he⟩ := exists_projective_coordinates hp
  by_cases h : t ≤ θ
  · exact ⟨θ, r, b, h, by linarith, hr, he⟩
  · refine ⟨θ + Real.pi, r, !b, by linarith, by linarith, hr, ?_⟩
    have hh : signedDirection (θ + Real.pi) (!b) = signedDirection θ b := by
      cases b <;> simp [signedDirection, unitDirection_add_pi]
    rwa [hh]

/-- Equally spaced open cones of radius greater than pi/(2k) cover all
unoriented directions, for every origin throughout a closed half-turn. -/
theorem exists_rotating_open_sector {k : ℕ} (hk : 0 < k)
    {r t : ℝ} (hr : Real.pi / k / 2 < r) (ht : 0 ≤ t) (htπ : t ≤ Real.pi)
    {p : Plane} (hp : p ≠ 0) :
    ∃ i : Fin k,
      angle p (unitDirection (t + (Real.pi / k) * (i.val + 1 / 2 : ℝ))) < r ∨
      angle (-p) (unitDirection (t + (Real.pi / k) * (i.val + 1 / 2 : ℝ))) < r := by
  obtain ⟨θ, s, b, hlo, hhi, hs, he⟩ := exists_projective_coordinates_closed_origin hp ht htπ
  let δ : ℝ := Real.pi / k
  have hkR : (0 : ℝ) < k := by exact_mod_cast hk
  have hk1 : (1 : ℝ) ≤ k := by exact_mod_cast hk
  have hd : 0 < δ := div_pos Real.pi_pos hkR
  have hdπ : δ ≤ Real.pi := (div_le_iff₀ hkR).mpr (by nlinarith [Real.pi_pos])
  have hdk : δ * k = Real.pi := div_mul_cancel₀ _ (ne_of_gt hkR)
  let z : ℝ := (θ - t) / δ
  have hz : 0 ≤ z := div_nonneg (sub_nonneg.mpr hlo) hd.le
  have hzk : z < k := by apply (div_lt_iff₀ hd).mpr; nlinarith
  let i : Fin k := ⟨⌊z⌋₊, (Nat.floor_lt hz).mpr hzk⟩
  have hi : (i.val : ℝ) ≤ z := Nat.floor_le hz
  have hi' : z < (i.val : ℝ) + 1 := Nat.lt_floor_add_one z
  have hθ : θ = t + δ * z := by dsimp [z]; field_simp; ring
  have habs : |θ - (t + δ * (i.val + 1 / 2 : ℝ))| ≤ δ / 2 := by
    rw [hθ]
    apply abs_le.mpr
    constructor <;> nlinarith
  have hang : angle (unitDirection θ) (unitDirection (t + δ * (i.val + 1 / 2 : ℝ))) < r := by
    rw [unitDirection_angle_abs (habs.trans (by linarith [Real.pi_pos]))]
    exact habs.trans_lt hr
  refine ⟨i, ?_⟩
  cases b
  · left
    simpa [he, signedDirection, angle_smul_left_of_pos _ _ hs] using hang
  · right
    simpa [he, signedDirection, angle_smul_left_of_pos _ _ hs] using hang

/-- Strict caps force strictly fewer than 2^k labels, including the equality
case left open by a fixed half-open sector partition. -/
theorem GeneralizedDirections.card_lt_two_pow_of_strict_angle
    {V : Type*} [Fintype V] [Nonempty V] (D : GeneralizedDirections V)
    {k : ℕ} (hk : 0 < k) {a : ℝ} (ha : 0 ≤ a)
    (halt : a < Real.pi - Real.pi / k) (hbound : D.AngleBound a) :
    Fintype.card V < 2 ^ k := by
  let r : ℝ := ((Real.pi / k) + (Real.pi - a)) / 4
  have hr : Real.pi / k / 2 < r := by dsimp [r]; linarith
  have hrw : 2 * r < Real.pi - a := by dsimp [r]; linarith
  let axis : ℝ → Fin k → Plane := fun t i => unitDirection (t + (Real.pi / k) * (i.val + 1 / 2 : ℝ))
  let R : ℝ → Fin k → V → V → Prop := fun t i u v =>
    u ≠ v ∧ angle (D.direction u v) (axis t i) < r
  apply card_lt_two_pow_of_open_reversing_cover hk (Set.Icc 0 Real.pi)
    isPreconnected_Icc R ?_ ?_ ?_ (a := 0) (b := Real.pi)
    ⟨le_rfl, Real.pi_pos.le⟩ ⟨Real.pi_pos.le, le_rfl⟩ ?_
  · intro i u v
    by_cases huv : u = v
    · simp [R, huv]
    · have hc : Continuous (fun t => angle (D.direction u v) (axis t i)) :=
        (continuous_angle_unitDirection (D.nonzero u v huv)).comp (by fun_prop)
      simpa only [R, Ne, huv, not_false_eq_true, true_and] using
        (isOpen_lt hc continuous_const)
  · intro t ht u v huv
    obtain ⟨i, hi⟩ := exists_rotating_open_sector hk hr ht.1 ht.2 (D.nonzero u v huv)
    refine ⟨i, ?_⟩
    rcases hi with hi | hi
    · exact Or.inl ⟨huv, hi⟩
    · exact Or.inr ⟨huv.symm, by simpa only [D.reverse u v] using hi⟩
  · intro t ht i u v w huv hvw
    have ht' := angle_le_angle_add_angle (D.direction u v) (axis t i) (D.direction v w)
    rw [angle_comm (axis t i) (D.direction v w)] at ht'
    have hsmall : angle (D.direction u v) (D.direction v w) < Real.pi - a := by
      linarith [huv.2, hvw.2]
    have hlarge : a < D.tripleAngle u v w := by
      unfold GeneralizedDirections.tripleAngle
      rw [D.reverse u v, angle_neg_left]
      linarith
    by_cases huw : u = w
    · subst w
      have hz : D.tripleAngle u v u = 0 := angle_self (D.nonzero v u huv.1.symm)
      linarith
    · exact (not_lt_of_ge (hbound u v w huv.1 huw hvw.1)) hlarge
  · intro i u v
    have he : axis Real.pi i = -axis 0 i := by
      dsimp [axis]
      rw [show Real.pi + Real.pi / k * (i.val + 1 / 2 : ℝ) =
        (0 + Real.pi / k * (i.val + 1 / 2 : ℝ)) + Real.pi by ring,
        unitDirection_add_pi]
    dsimp [R]
    rw [he, D.reverse u v, angle_neg_left, angle_neg_right]
    exact and_congr ne_comm Iff.rfl

end Prize.JSP404
