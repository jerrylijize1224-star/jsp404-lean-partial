import Prize.JSP404.Counting
import Mathlib.Data.Fintype.EquivFin
import Mathlib.Topology.Connected.Basic

/-! Equality and a connected-parameter obstruction for binary direction covers.
These are structural counting lemmas; geometric applicability is separate. -/
namespace Prize.JSP404

/-- At the binary bound, every vertex is incident to every relation. -/
theorem saturated_cover_incident {V : Type*} [Fintype V] {k : ℕ}
    (R : Fin k → V → V → Prop)
    (hcover : ∀ u v, u ≠ v → ∃ i, R i u v ∨ R i v u)
    (hstep : ∀ i u v w, R i u v → R i v w → False)
    (hcard : Fintype.card V = 2 ^ k) (i : Fin k) (u : V) :
    (∃ v, R i u v) ∨ (∃ v, R i v u) := by
  classical
  let code : V → (Fin k → Bool) := fun v j => decide (∃ w, R j v w)
  have hd (j : Fin k) (v w : V) (h : R j v w) : code v j = true ∧ code w j = false := by
    have hv : ∃ z, R j v z := ⟨w, h⟩
    have hw : ¬ ∃ z, R j w z := by rintro ⟨z, hz⟩; exact hstep j v w z h hz
    simp [code, hv, hw]
  have hi : Function.Injective code := by
    intro v w he
    by_contra hn
    obtain ⟨j, hj⟩ := hcover v w hn
    have hj' := congrFun he j
    rcases hj with hj | hj
    · obtain ⟨hv, hw⟩ := hd j v w hj
      rw [hv, hw] at hj'
      contradiction
    · obtain ⟨hw, hv⟩ := hd j w v hj
      rw [hv, hw] at hj'
      contradiction
  have hs : Function.Surjective code :=
    ((Fintype.bijective_iff_injective_and_card code).mpr ⟨hi, by simpa using hcard⟩).2
  by_contra hn
  have hout : ¬ ∃ v, R i u v := fun h => hn (Or.inl h)
  have hin : ¬ ∃ v, R i v u := fun h => hn (Or.inr h)
  have hu : code u i = false := by simp [code, hout]
  obtain ⟨v, hv⟩ := hs (Function.update (code u) i true)
  have hvi : code v i = true := by simpa using congrFun hv i
  have huv : u ≠ v := by intro he; subst v; rw [hu] at hvi; contradiction
  obtain ⟨j, hj⟩ := hcover u v huv
  by_cases hji : j = i
  · subst j
    exact hj.elim (fun h => hout ⟨v, h⟩) (fun h => hin ⟨v, h⟩)
  · have he : code v j = code u j := by simpa [Function.update, hji] using congrFun hv j
    rcases hj with hj | hj
    · obtain ⟨hu', hv'⟩ := hd j u v hj
      rw [hu', hv'] at he
      contradiction
    · obtain ⟨hv', hu'⟩ := hd j v u hj
      rw [hu', hv'] at he
      contradiction

/-- An open family of saturated covers cannot reverse all its arrows along
one connected parameter set. The strict cardinal bound is the conclusion. -/
theorem card_lt_two_pow_of_open_reversing_cover
    {V T : Type*} [Fintype V] [Nonempty V] [TopologicalSpace T]
    {k : ℕ} (hk : 0 < k) (S : Set T) (hS : IsPreconnected S)
    (R : T → Fin k → V → V → Prop)
    (hopen : ∀ i u v, IsOpen {t | R t i u v})
    (hcover : ∀ t ∈ S, ∀ u v, u ≠ v → ∃ i, R t i u v ∨ R t i v u)
    (hstep : ∀ t ∈ S, ∀ i u v w, R t i u v → R t i v w → False)
    {a b : T} (ha : a ∈ S) (hb : b ∈ S)
    (hrev : ∀ i u v, R b i u v ↔ R a i v u) :
    Fintype.card V < 2 ^ k := by
  classical
  have hle := card_le_two_pow_of_no_two_step_cover (R a) (hcover a ha) (hstep a ha)
  by_contra hn
  have he : Fintype.card V = 2 ^ k := le_antisymm hle (le_of_not_gt hn)
  let i : Fin k := ⟨0, hk⟩
  let u : V := Classical.choice inferInstance
  let A : Set T := {t | ∃ v, R t i u v}
  let B : Set T := {t | ∃ v, R t i v u}
  have hA : IsOpen A := by
    simpa only [A, Set.ofPred_exists] using isOpen_iUnion (fun v => hopen i u v)
  have hB : IsOpen B := by
    simpa only [B, Set.ofPred_exists] using isOpen_iUnion (fun v => hopen i v u)
  have hab : S ⊆ A ∪ B := by
    intro t ht
    exact saturated_cover_incident (R t) (hcover t ht) (hstep t ht) he i u
  have hdis : S ∩ (A ∩ B) = ∅ := by
    apply Set.eq_empty_iff_forall_notMem.mpr
    rintro t ⟨ht, ⟨v, hv⟩, ⟨w, hw⟩⟩
    exact hstep t ht i w u v hw hv
  have hr : (a ∈ A ↔ b ∈ B) ∧ (a ∈ B ↔ b ∈ A) := by
    dsimp [A, B]
    simp only [hrev, iff_self, and_self]
  have hconn := hS A B hA hB hab
  rcases hab ha with h | h
  · have hx := hconn ⟨a, ha, h⟩ ⟨b, hb, hr.1.mp h⟩
    rw [hdis] at hx
    exact Set.not_nonempty_empty hx
  · have hx := hconn ⟨b, hb, hr.2.mp h⟩ ⟨a, ha, h⟩
    rw [hdis] at hx
    exact Set.not_nonempty_empty hx

end Prize.JSP404
