import Prize.JSP404.RotatingSectorCover
import Prize.JSP404.CompactDirectionSpace
import Prize.JSP404.EquallySpacedBinaryAxes

/-! Sharp ordinary values at every binary cardinality. This is the classical
dyadic subfamily; the non-dyadic Sendov bands are not proved here. -/
namespace Prize.JSP404

theorem GeneralizedDirections.exists_angle_ge_dyadic_bound
    {V : Type*} [Fintype V] (D : GeneralizedDirections V)
    {k : ℕ} (hk : 2 ≤ k) (hV : 2 ^ k ≤ Fintype.card V) :
    ∃ i j l : V, i ≠ j ∧ i ≠ l ∧ j ≠ l ∧
      Real.pi - Real.pi / k ≤ D.tripleAngle i j l := by
  have hfour : 4 ≤ (2 : ℕ) ^ k := by
    calc
      4 = (2 : ℕ) ^ 2 := by norm_num
      _ ≤ 2 ^ k := pow_le_pow_right₀ (by decide) hk
  have : Nonempty (DirectionTriple V) := directionTriple_nonempty (by omega)
  obtain ⟨t, ht⟩ := exists_maximumAssignmentAngle D.normalizedAssignment
  have : Nonempty V := ⟨t.val.1⟩
  let a : ℝ := maximumAssignmentAngle D.normalizedAssignment
  have he : a = D.tripleAngle t.val.1 t.val.2.1 t.val.2.2 := by
    exact ht.trans (D.normalizedAssignment_angle t)
  have ha : 0 ≤ a := by rw [he]; exact InnerProductGeometry.angle_nonneg _ _
  have hb : D.AngleBound a := by
    intro i j l hij hil hjl
    have h := assignmentTripleAngle_le_maximum D.normalizedAssignment ⟨(i, j, l), hij, hil, hjl⟩
    rw [D.normalizedAssignment_angle ⟨(i, j, l), hij, hil, hjl⟩] at h
    exact h
  have hl : Real.pi - Real.pi / k ≤ a := by
    by_contra h
    have hc := D.card_lt_two_pow_of_strict_angle (by omega) ha (lt_of_not_ge h) hb
    omega
  exact ⟨t.val.1, t.val.2.1, t.val.2.2, t.property.1, t.property.2.1,
    t.property.2.2, he ▸ hl⟩

theorem guaranteedAngle_dyadic_bound {k N : ℕ} (hk : 2 ≤ k) (hN : 2 ^ k ≤ N) :
    GuaranteedAngle N ((1 - 1 / (k : ℝ)) * Real.pi) := by
  intro s hs
  let D : GeneralizedDirections s := {
    direction := fun u v => (v : Plane) - u
    reverse := fun u v => by abel
    nonzero := fun u v huv => sub_ne_zero.mpr (fun h => huv (Subtype.ext h.symm)) }
  obtain ⟨i, j, l, hij, hil, hjl, ha⟩ := D.exists_angle_ge_dyadic_bound hk (by simpa [hs] using hN)
  refine ⟨i, i.property, j, j.property, l, l.property,
    (fun h => hij (Subtype.ext h)), (fun h => hil (Subtype.ext h)),
    (fun h => hjl (Subtype.ext h)), ?_⟩
  have he : (1 - 1 / (k : ℝ)) * Real.pi = Real.pi - Real.pi / k := by ring
  rw [he]
  exact ha

theorem dyadic_alpha_lower {k N : ℕ} (hk : 2 ≤ k) (hN : 2 ^ k ≤ N) :
    (1 - 1 / (k : ℝ)) * Real.pi ≤ alpha N := by
  have hkR : (0 : ℝ) < k := by exact_mod_cast (show 0 < k by omega)
  have hk1 : (1 : ℝ) ≤ k := by exact_mod_cast (show 1 ≤ k by omega)
  have hi : 1 / (k : ℝ) ≤ 1 := (div_le_one hkR).mpr hk1
  apply le_csSup (admissibleAngles_bddAbove N)
  exact ⟨mul_nonneg (by linarith) Real.pi_pos.le,
    by nlinarith [div_pos (by norm_num : (0 : ℝ) < 1) hkR, Real.pi_pos],
    guaranteedAngle_dyadic_bound hk hN⟩

theorem alpha_dyadic {k : ℕ} (hk : 2 ≤ k) :
    alpha (2 ^ k) = (1 - 1 / (k : ℝ)) * Real.pi := by
  have hfour : 4 ≤ (2 : ℕ) ^ k := by
    calc
      4 = (2 : ℕ) ^ 2 := by norm_num
      _ ≤ 2 ^ k := pow_le_pow_right₀ (by decide) hk
  exact le_antisymm (dyadic_alpha_upper hk (by omega) le_rfl) (dyadic_alpha_lower hk le_rfl)

theorem dyadic_isSharpBound {k : ℕ} (hk : 2 ≤ k) :
    IsSharpBound (2 ^ k) ((1 - 1 / (k : ℝ)) * Real.pi) := by
  have hfour : 4 ≤ (2 : ℕ) ^ k := by
    calc
      4 = (2 : ℕ) ^ 2 := by norm_num
      _ ≤ 2 ^ k := pow_le_pow_right₀ (by decide) hk
  have hb := alpha_bounds (show 3 ≤ 2 ^ k by omega)
  rw [alpha_dyadic hk] at hb
  exact ⟨(by positivity : (0 : ℝ) ≤ Real.pi / 3).trans hb.1, hb.2,
    guaranteedAngle_dyadic_bound hk le_rfl,
    fun _ h => dyadic_not_guaranteed hk le_rfl h⟩

theorem alpha_sixteen : alpha 16 = (3 / 4 : ℝ) * Real.pi := by
  have h := alpha_dyadic (k := 4) (by decide)
  norm_num at h ⊢
  exact h

theorem alpha_thirty_two : alpha 32 = (4 / 5 : ℝ) * Real.pi := by
  have h := alpha_dyadic (k := 5) (by decide)
  norm_num at h ⊢
  exact h

end Prize.JSP404
