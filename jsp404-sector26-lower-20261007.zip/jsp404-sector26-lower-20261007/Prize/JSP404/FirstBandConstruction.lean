import Prize.JSP404.ClusterApproximation
import Prize.JSP404.FirstBandTriangle

/-! Three binary clusters give the first band's general upper bound.
This is the construction direction only; general universal lower bounds and
SendovClaim itself are not proved in this module. -/

namespace Prize.JSP404

open EuclideanGeometry

abbrev FirstBandLabel (n : ℕ) := Sigma (fun i : Fin 3 => BinaryLabel (firstBandDepth n i))

noncomputable def firstBandLabelCentre {n : ℕ} (u : FirstBandLabel n) : Plane :=
  firstBandCentre n u.1

noncomputable def firstBandLocalPoint {n : ℕ} (t : ℝ) (u : FirstBandLabel n) : Plane :=
  binaryScalePoint (firstBandAxis n u.1) t u.2

noncomputable def firstBandLocalNormal {n : ℕ} (t : ℝ) (u v : FirstBandLabel n) : Plane :=
  if h : u.1 = v.1 then binaryScaleNormal (firstBandAxis n u.1) t u.2 (h.symm ▸ v.2) else 0

noncomputable def firstBandLocalScale {n : ℕ} (t : ℝ) (u v : FirstBandLabel n) : ℝ :=
  if h : u.1 = v.1 then t ^ binaryScaleRank u.2 (h.symm ▸ v.2) else 1

theorem firstBandLocalNormal_continuous (n : ℕ) (u v : FirstBandLabel n)
    (h : firstBandLabelCentre u = firstBandLabelCentre v) :
    ContinuousAt (fun t => firstBandLocalNormal t u v) 0 := by
  rcases u with ⟨i, b⟩
  rcases v with ⟨j, c⟩
  have hij : i = j := firstBandCentre_injective n h
  subst j
  simpa [firstBandLocalNormal] using binaryScaleNormal_continuous (firstBandAxis n i) b c

theorem firstBandLocalNormal_nonzero (n : ℕ) (u v : FirstBandLabel n) (hne : u ≠ v)
    (h : firstBandLabelCentre u = firstBandLabelCentre v) : firstBandLocalNormal 0 u v ≠ 0 := by
  rcases u with ⟨i, b⟩
  rcases v with ⟨j, c⟩
  have hij : i = j := firstBandCentre_injective n h
  subst j
  have hbc : b ≠ c := fun he => hne (by cases he; rfl)
  simpa [firstBandLocalNormal] using binaryScaleNormal_nonzero (firstBandAxis_nonzero n i) b c hbc

theorem firstBandLocalScale_pos (n : ℕ) (t : ℝ) (ht : 0 < t) (u v : FirstBandLabel n) :
    0 < firstBandLocalScale t u v := by
  unfold firstBandLocalScale
  split_ifs
  · exact pow_pos ht _
  · norm_num

theorem firstBandLocal_difference (n : ℕ) (t : ℝ) (u v : FirstBandLabel n)
    (h : firstBandLabelCentre u = firstBandLabelCentre v) :
    firstBandLocalPoint t v - firstBandLocalPoint t u =
      firstBandLocalScale t u v • firstBandLocalNormal t u v := by
  rcases u with ⟨i, b⟩
  rcases v with ⟨j, c⟩
  have hij : i = j := firstBandCentre_injective n h
  subst j
  simpa [firstBandLocalPoint, firstBandLocalScale, firstBandLocalNormal] using
    binaryScale_difference (firstBandAxis n i) t b c

theorem firstBandLocal_angle (n : ℕ) (u v w : FirstBandLabel n)
    (huv : u ≠ v) (hvw : v ≠ w)
    (hvu : firstBandLabelCentre v = firstBandLabelCentre u)
    (hvwC : firstBandLabelCentre v = firstBandLabelCentre w) :
    InnerProductGeometry.angle (firstBandLocalNormal 0 v u) (firstBandLocalNormal 0 v w) ≤
      Real.pi - 2 * firstBandStep n := by
  rcases u with ⟨i, b⟩
  rcases v with ⟨j, c⟩
  rcases w with ⟨k, d⟩
  have hji : j = i := firstBandCentre_injective n hvu
  have hjk : j = k := firstBandCentre_injective n hvwC
  subst i
  subst k
  have hbc : b ≠ c := fun he => huv (by cases he; rfl)
  have hcd : c ≠ d := fun he => hvw (by cases he; rfl)
  have hA : 0 ≤ Real.pi - 2 * firstBandStep n := by
    have := firstBandStep_pos n
    have := firstBandStep_small n
    linarith
  simpa [firstBandLocalNormal] using binaryScaleNormal_angle (firstBandAxis_nonzero n j) hA
    (firstBandAxis_angle n j) b c d hbc hcd

theorem firstBandLocal_mixed_angle (n : ℕ) (v u w : FirstBandLabel n) (hvu : v ≠ u)
    (hC : firstBandLabelCentre v = firstBandLabelCentre u)
    (hw : firstBandLabelCentre v ≠ firstBandLabelCentre w) :
    InnerProductGeometry.angle (firstBandLocalNormal 0 v u)
      (firstBandLabelCentre w - firstBandLabelCentre v) ≤ Real.pi - 2 * firstBandStep n := by
  rcases v with ⟨i, b⟩
  rcases u with ⟨j, c⟩
  rcases w with ⟨k, d⟩
  have hij : i = j := firstBandCentre_injective n hC
  subst j
  have hbc : b ≠ c := fun he => hvu (by cases he; rfl)
  have hik : i ≠ k := fun he => hw (congrArg (firstBandCentre n) he)
  obtain ⟨r, _, hr⟩ := binaryScaleNormal_signed (firstBandAxis n i) hbc
  simpa [firstBandLocalNormal, firstBandLabelCentre, hr] using
    firstBandAxis_centre_angle n i k hik r (b r)

theorem exists_firstBand_approximation (n : ℕ) {ε : ℝ} (hε : 0 < ε) :
    ∃ t : ℝ, 0 < t ∧
      Function.Injective (clusteredPoint (firstBandLabelCentre (n := n)) firstBandLocalPoint t) ∧
      ∀ i j k : FirstBandLabel n, i ≠ j → i ≠ k → j ≠ k →
        angle (clusteredPoint firstBandLabelCentre firstBandLocalPoint t i)
          (clusteredPoint firstBandLabelCentre firstBandLocalPoint t j)
          (clusteredPoint firstBandLabelCentre firstBandLocalPoint t k) <
            Real.pi - 2 * firstBandStep n + ε := by
  apply exists_clustered_approximation firstBandLabelCentre firstBandLocalPoint
    firstBandLocalNormal firstBandLocalScale
    (fun u => binaryScalePoint_continuous (firstBandAxis n u.1) u.2)
    (firstBandLocalNormal_continuous n) (firstBandLocalNormal_nonzero n)
    (by intro t ht u v _; exact firstBandLocalScale_pos n t ht u v)
    (by intro t _ u v h; exact firstBandLocal_difference n t u v h)
    (by intro i j k hij _ hjk hji hjc; exact firstBandLocal_angle n i j k hij hjk hji hjc)
    (firstBandLocal_mixed_angle n) ?_ hε
  intro i j k hji hjk
  exact firstBandCentre_angle n i.1 j.1 k.1
    (fun h => hji (congrArg (firstBandCentre n) h))
    (fun h => hjk (congrArg (firstBandCentre n) h))

theorem firstBandLabel_card (n : ℕ) : Fintype.card (FirstBandLabel n) = 2 ^ (n + 2) + 2 ^ n := by
  classical
  have hcard (i : Fin 3) : Fintype.card (BinaryLabel (firstBandDepth n i)) =
      2 ^ firstBandDepth n i := by
    change Fintype.card (Fin (firstBandDepth n i) → Bool) = _
    rw [Fintype.card_fun, Fintype.card_bool, Fintype.card_fin]
  unfold FirstBandLabel
  rw [Fintype.card_sigma]
  simp only [hcard]
  norm_num [Fin.sum_univ_succ, firstBandDepth, pow_succ]
  ring

theorem exists_firstBand_counterexample (n : ℕ) {ε : ℝ} (hε : 0 < ε) :
    ∃ s : Finset Plane, s.card = 2 ^ (n + 2) + 2 ^ n ∧
      ¬ HasLargeAngle s (Real.pi - 2 * firstBandStep n + ε) := by
  classical
  obtain ⟨t, _, hinj, ha⟩ := exists_firstBand_approximation n hε
  let P := clusteredPoint (firstBandLabelCentre (n := n)) firstBandLocalPoint t
  refine ⟨Finset.univ.image P, ?_, ?_⟩
  · rw [Finset.card_image_of_injective _ hinj, Finset.card_univ, firstBandLabel_card]
  · rintro ⟨x, hx, y, hy, z, hz, hxy, hxz, hyz, hlarge⟩
    obtain ⟨i, _, rfl⟩ := Finset.mem_image.mp hx
    obtain ⟨j, _, rfl⟩ := Finset.mem_image.mp hy
    obtain ⟨k, _, rfl⟩ := Finset.mem_image.mp hz
    exact (not_lt_of_ge hlarge) (ha i j k (fun h => hxy (congrArg P h))
      (fun h => hxz (congrArg P h)) (fun h => hyz (congrArg P h)))

theorem sendov_low_band_upper {k N : ℕ} (hk : 2 ≤ k)
    (hlo : 2 ^ k < N) (hhi : N ≤ 2 ^ k + 2 ^ (k - 2)) :
    alpha N ≤ (1 - 2 / (2 * (k : ℝ) + 1)) * Real.pi := by
  have hfour : 4 ≤ (2 : ℕ) ^ k := by
    calc
      4 = (2 : ℕ) ^ 2 := by norm_num
      _ ≤ 2 ^ k := pow_le_pow_right₀ (by decide) hk
  have hN : 3 ≤ N := (by decide : 3 ≤ 4).trans (hfour.trans (Nat.le_of_lt hlo))
  have hkn : k - 2 + 2 = k := by omega
  have hknR : ((k - 2 : ℕ) : ℝ) + 2 = k := by exact_mod_cast hkn
  have hA : Real.pi - 2 * firstBandStep (k - 2) =
      (1 - 2 / (2 * (k : ℝ) + 1)) * Real.pi := by
    unfold firstBandStep
    rw [show 2 * ((k - 2 : ℕ) : ℝ) + 5 = 2 * (k : ℝ) + 1 by linarith]
    ring
  apply alpha_le_of_large_approximation hN
  intro ε hε
  obtain ⟨s, hs, hbad⟩ := exists_firstBand_counterexample (k - 2) hε
  rw [hkn] at hs
  rw [hA] at hbad
  exact ⟨s, hs ▸ hhi, hbad⟩

end Prize.JSP404
