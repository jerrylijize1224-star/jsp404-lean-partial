import Prize.JSP404.QuantitativeSectorCover
import Prize.JSP404.StrictUniformLowerBound

/-! A concrete, non-sharp improvement over the uniform sector lower bound.
All ordered pairs are used, including harmless dummy diagonal directions. -/

namespace Prize.JSP404

noncomputable def quantitativeAngle (k N : ℕ) : ℝ :=
  Real.pi - (Real.pi / k) * (1 - 1 / ((N : ℝ) ^ 2 + 1))

theorem quantitativeAngle_eq (k N : ℕ) :
    quantitativeAngle k N =
      (1 - 1 / (k : ℝ)) * Real.pi + Real.pi / ((k : ℝ) * ((N : ℝ) ^ 2 + 1)) := by
  simp only [quantitativeAngle, div_mul_eq_div_div]
  ring

theorem quantitativeAngle_gt_uniform {k N : ℕ} (hk : 0 < k) :
    (1 - 1 / (k : ℝ)) * Real.pi < quantitativeAngle k N := by
  rw [quantitativeAngle_eq]
  have hkR : (0 : ℝ) < k := by exact_mod_cast hk
  exact lt_add_of_pos_right _ (div_pos Real.pi_pos (by positivity))

theorem quantitativeAngle_bounds {k N : ℕ} (hk : 0 < k) :
    0 ≤ quantitativeAngle k N ∧ quantitativeAngle k N ≤ Real.pi := by
  have hkR : (0 : ℝ) < k := by exact_mod_cast hk
  have hk1 : (1 : ℝ) ≤ k := by exact_mod_cast hk
  have hd : 0 < Real.pi / k := div_pos Real.pi_pos hkR
  have hdπ : Real.pi / k ≤ Real.pi := (div_le_iff₀ hkR).mpr (by nlinarith [Real.pi_pos])
  have he : 0 < 1 / ((N : ℝ) ^ 2 + 1) := by positivity
  have he1 : 1 / ((N : ℝ) ^ 2 + 1) ≤ 1 := (div_le_one (by positivity)).mpr (by nlinarith [sq_nonneg (N : ℝ)])
  dsimp [quantitativeAngle]
  constructor <;> nlinarith

theorem GeneralizedDirections.card_le_two_pow_of_quantitative_angle
    {V : Type*} [Fintype V] [Nonempty V] (D : GeneralizedDirections V)
    {k : ℕ} (hk : 0 < k) (hbound : D.AngleBound (quantitativeAngle k (Fintype.card V))) :
    Fintype.card V ≤ 2 ^ k := by
  classical
  let p : V × V → Plane := fun ij => if ij.1 = ij.2 then unitDirection 0 else D.direction ij.1 ij.2
  have hp : ∀ ij, p ij ≠ 0 := by
    intro ij
    dsimp [p]
    split_ifs with h
    · intro hz
      have hn := unitDirection_norm 0
      rw [hz, norm_zero] at hn
      norm_num at hn
    · exact D.nonzero _ _ h
  obtain ⟨C, hc, ht⟩ := exists_short_sector_cover p hp hk
  apply D.card_le_two_pow_of_cover (quantitativeAngle_bounds hk).1 C ?_ ?_ hbound
  · intro u v huv
    obtain ⟨i, hi⟩ := hc (u, v)
    simp only [p, ite_eq_right huv] at hi
    exact ⟨i, by rwa [D.reverse u v]⟩
  · intro i u hu v hv
    have h := ht i u hu v hv
    simpa [quantitativeAngle, Fintype.card_prod, pow_two] using h

theorem guaranteedAngle_quantitative {k N : ℕ} (hk : 0 < k) (hN : 2 ^ k < N) :
    GuaranteedAngle N (quantitativeAngle k N) := by
  classical
  intro s hs
  have hn : 0 < s.card := by rw [hs]; exact (Nat.two_pow_pos k).trans hN
  have : Nonempty s := (Finset.card_pos.mp hn).to_subtype
  let D : GeneralizedDirections s := {
    direction := fun u v => (v : Plane) - u
    reverse := fun u v => by abel
    nonzero := fun u v huv => sub_ne_zero.mpr (fun h => huv (Subtype.ext h.symm)) }
  by_contra h
  have hb : D.AngleBound (quantitativeAngle k (Fintype.card s)) := by
    intro u v w huv huw hvw
    have hnot : ¬ quantitativeAngle k N ≤ EuclideanGeometry.angle (u : Plane) (v : Plane) (w : Plane) := by
      intro ha
      exact h ⟨u, u.property, v, v.property, w, w.property,
        (fun he => huv (Subtype.ext he)), (fun he => huw (Subtype.ext he)),
        (fun he => hvw (Subtype.ext he)), ha⟩
    have ha := (lt_of_not_ge hnot).le
    change InnerProductGeometry.angle ((u : Plane) - v) ((w : Plane) - v) ≤
      quantitativeAngle k N at ha
    change InnerProductGeometry.angle ((u : Plane) - v) ((w : Plane) - v) ≤
      quantitativeAngle k (Fintype.card s)
    simpa only [Fintype.card_coe, hs] using ha
  have hc := D.card_le_two_pow_of_quantitative_angle hk hb
  have hc' : s.card ≤ 2 ^ k := by simpa using hc
  omega

theorem quantitative_alpha_lower {k N : ℕ} (hk : 0 < k) (hN : 2 ^ k < N) :
    quantitativeAngle k N ≤ alpha N := by
  apply le_csSup (admissibleAngles_bddAbove N)
  exact ⟨(quantitativeAngle_bounds hk).1, (quantitativeAngle_bounds hk).2,
    guaranteedAngle_quantitative hk hN⟩

/-- The explicit margin at the smallest cardinality works at every larger one. -/
theorem quantitative_alpha_lower_uniform {k N : ℕ} (hk : 0 < k) (hN : 2 ^ k < N) :
    quantitativeAngle k (2 ^ k + 1) ≤ alpha N := by
  have htwo : 2 ≤ (2 : ℕ) ^ k := by
    calc
      2 = (2 : ℕ) ^ 1 := by norm_num
      _ ≤ 2 ^ k := pow_le_pow_right₀ (by decide) hk
  exact (quantitative_alpha_lower hk (Nat.lt_succ_self _)).trans
    (alpha_mono (by omega) (by omega))

theorem alpha_seventeen_quantitative_bounds :
    (871 / 1160 : ℝ) * Real.pi ≤ alpha 17 ∧ alpha 17 ≤ (7 / 9 : ℝ) * Real.pi := by
  have hl := quantitative_alpha_lower (k := 4) (N := 17) (by decide) (by decide)
  norm_num [quantitativeAngle] at hl
  constructor
  · nlinarith
  · exact alpha_seventeen_strict_bounds.2

end Prize.JSP404
