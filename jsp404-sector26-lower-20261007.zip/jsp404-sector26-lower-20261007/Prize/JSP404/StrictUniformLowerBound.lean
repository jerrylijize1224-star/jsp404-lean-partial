import Prize.JSP404.CompactDirectionSpace
import Prize.JSP404.GeneralAngleBounds

/-!
# A strict general lower bound from compact direction data

The compact set is a relaxation containing normalized ordinary differences.
A uniform positive margin on that larger set transfers to ordinary points.
We do not assume, or conclude, attainment of alpha by an ordinary configuration.
The positive margin is existential and does not equal Sendov's sharp gap.
-/

namespace Prize.JSP404

theorem maximumAssignmentAngle_gt_uniform_bound {V : Type*} [Fintype V]
    [Nonempty (DirectionTriple V)] {k : ℕ} (hk : 0 < k)
    (hV : 2 ^ k < Fintype.card V) {q : DirectionAssignment V}
    (hq : q ∈ UnitDirectionAssignments V) :
    Real.pi - Real.pi / k < maximumAssignmentAngle q := by
  by_contra h
  have hbound : (UnitDirectionAssignments.toDirections q hq).AngleBound
      (Real.pi - Real.pi / k) := by
    intro i j l hij hil hjl
    have hm := assignmentTripleAngle_le_maximum q ⟨(i, j, l), hij, hil, hjl⟩
    exact hm.trans (le_of_not_gt h)
  exact (not_le_of_gt hV)
    ((UnitDirectionAssignments.toDirections q hq).card_le_two_pow_of_uniform_angle hk hbound)

/-- A margin depending only on the finite label type and k, shared by all
nonzero antisymmetric direction assignments on that type. -/
theorem exists_uniform_direction_margin (V : Type*) [Fintype V]
    {k : ℕ} (hk : 0 < k) (hV : 2 ^ k < Fintype.card V) :
    ∃ ε : ℝ, 0 < ε ∧ ∀ D : GeneralizedDirections V,
      ∃ i j l : V, i ≠ j ∧ i ≠ l ∧ j ≠ l ∧
        Real.pi - Real.pi / k + ε ≤ D.tripleAngle i j l := by
  have htwo : 2 ≤ (2 : ℕ) ^ k := by
    calc
      2 = (2 : ℕ) ^ 1 := by norm_num
      _ ≤ 2 ^ k := pow_le_pow_right₀ (by decide) hk
  haveI : Nonempty (DirectionTriple V) := directionTriple_nonempty (by omega)
  obtain ⟨b, hb, hmin⟩ := (isCompact_unitDirectionAssignments V).exists_forall_le'
    continuousOn_maximumAssignmentAngle (fun q hq => maximumAssignmentAngle_gt_uniform_bound hk hV hq)
  refine ⟨b - (Real.pi - Real.pi / k), sub_pos.mpr hb, ?_⟩
  intro D
  obtain ⟨t, ht⟩ := exists_maximumAssignmentAngle D.normalizedAssignment
  have h := hmin _ D.normalizedAssignment_mem
  rw [ht, D.normalizedAssignment_angle t] at h
  exact ⟨t.val.1, t.val.2.1, t.val.2.2, t.property.1, t.property.2.1,
    t.property.2.2, by linarith⟩

theorem exists_guaranteedAngle_gt_uniform_bound {k N : ℕ}
    (hk : 0 < k) (hN : 2 ^ k < N) :
    ∃ b : ℝ, (1 - 1 / (k : ℝ)) * Real.pi < b ∧
      b ∈ admissibleAngles N := by
  classical
  obtain ⟨ε, hε, hmargin⟩ := exists_uniform_direction_margin (Fin N) hk (by simpa using hN)
  have hkR : (0 : ℝ) < k := by exact_mod_cast hk
  have hk1 : (1 : ℝ) ≤ k := by exact_mod_cast hk
  have hdiv : 0 < Real.pi / k := div_pos Real.pi_pos hkR
  have hbase0 : 0 ≤ Real.pi - Real.pi / k := by
    have h := (div_le_iff₀ hkR).mpr (show Real.pi ≤ Real.pi * k by nlinarith [Real.pi_pos])
    linarith
  let b : ℝ := min (Real.pi - Real.pi / k + ε) Real.pi
  have hbase : Real.pi - Real.pi / k < b := lt_min (by linarith) (by linarith)
  have he : (1 - 1 / (k : ℝ)) * Real.pi = Real.pi - Real.pi / k := by ring
  refine ⟨b, he ▸ hbase, le_trans hbase0 hbase.le, min_le_right _ _, ?_⟩
  intro s hs
  let e : s ≃ Fin N := (Fintype.equivFin s).trans (finCongr (by simpa using hs))
  let p : Fin N → Plane := fun i => (e.symm i).val
  have hp : Function.Injective p := Subtype.val_injective.comp e.symm.injective
  let D : GeneralizedDirections (Fin N) := {
    direction := fun i j => p j - p i
    reverse := fun i j => by abel
    nonzero := fun i j hij => sub_ne_zero.mpr (hp.ne hij.symm) }
  obtain ⟨i, j, l, hij, hil, hjl, hang⟩ := hmargin D
  refine ⟨p i, (e.symm i).property, p j, (e.symm j).property,
    p l, (e.symm l).property, hp.ne hij, hp.ne hil, hp.ne hjl, ?_⟩
  exact (min_le_left _ _).trans hang

/-- Strictness is uniform across configurations, not just pointwise. -/
theorem uniform_alpha_strict_lower {k N : ℕ} (hk : 0 < k) (hN : 2 ^ k < N) :
    (1 - 1 / (k : ℝ)) * Real.pi < alpha N := by
  obtain ⟨b, hb, hmem⟩ := exists_guaranteedAngle_gt_uniform_bound hk hN
  exact hb.trans_le (le_csSup (admissibleAngles_bddAbove N) hmem)

/-- One positive gap works for every cardinality above the same threshold.
The proof supplies existence, not a numerical value for the gap. -/
theorem exists_uniform_alpha_gap {k : ℕ} (hk : 0 < k) :
    ∃ ε : ℝ, 0 < ε ∧ ∀ N : ℕ, 2 ^ k < N →
      (1 - 1 / (k : ℝ)) * Real.pi + ε ≤ alpha N := by
  obtain ⟨b, hb, hmem⟩ := exists_guaranteedAngle_gt_uniform_bound (N := 2 ^ k + 1) hk (by omega)
  refine ⟨b - (1 - 1 / (k : ℝ)) * Real.pi, sub_pos.mpr hb, ?_⟩
  intro N hN
  have hc : b ∈ admissibleAngles N :=
    ⟨hmem.1, hmem.2.1, hmem.2.2.mono_card (by omega)⟩
  have h := le_csSup (admissibleAngles_bddAbove N) hc
  change b ≤ alpha N at h
  linarith

theorem low_band_alpha_strict_bounds {k N : ℕ} (hk : 2 ≤ k)
    (hlo : 2 ^ k < N) (hhi : N ≤ 2 ^ k + 2 ^ (k - 2)) :
    (1 - 1 / (k : ℝ)) * Real.pi < alpha N ∧
      alpha N ≤ (1 - 2 / (2 * (k : ℝ) + 1)) * Real.pi :=
  ⟨uniform_alpha_strict_lower (by omega) hlo, sendov_low_band_upper hk hlo hhi⟩

theorem high_band_alpha_strict_bounds {k N : ℕ} (hk : 2 ≤ k)
    (hlo : 2 ^ k + 2 ^ (k - 2) < N) (hhi : N ≤ 2 ^ (k + 1)) :
    (1 - 1 / (k : ℝ)) * Real.pi < alpha N ∧
      alpha N ≤ (1 - 1 / ((k : ℝ) + 1)) * Real.pi :=
  ⟨uniform_alpha_strict_lower (by omega) (lt_of_le_of_lt (Nat.le_add_right _ _) hlo),
    sendov_high_band_upper hk hlo hhi⟩

theorem alpha_seventeen_strict_bounds :
    (3 / 4 : ℝ) * Real.pi < alpha 17 ∧ alpha 17 ≤ (7 / 9 : ℝ) * Real.pi := by
  have h := low_band_alpha_strict_bounds (k := 4) (N := 17) (by decide) (by decide) (by decide)
  norm_num at h ⊢
  exact h

end Prize.JSP404
