import Prize.JSP404.BinaryScaleConstruction

/-! Realization of explicitly parametrized clusters around prescribed centres.
Internal, mixed and centre-angle certificates remain explicit hypotheses.
This does not assert that arbitrary abstract generalized directions are realizable. -/

namespace Prize.JSP404

open EuclideanGeometry

noncomputable def clusteredPoint {ι : Type*} (C : ι → Plane)
    (p : ℝ → ι → Plane) (t : ℝ) (i : ι) : Plane := C i + t • p t i

noncomputable def clusteredNormal {ι : Type*} (C : ι → Plane)
    (p : ℝ → ι → Plane) (q : ℝ → ι → ι → Plane) (t : ℝ) (i j : ι) : Plane :=
  if C i = C j then q t i j else C j - C i + t • (p t j - p t i)

noncomputable def clusteredScale {ι : Type*} (C : ι → Plane)
    (c : ℝ → ι → ι → ℝ) (t : ℝ) (i j : ι) : ℝ :=
  if C i = C j then t * c t i j else 1

theorem clusteredNormal_continuous {ι : Type*} (C : ι → Plane)
    (p : ℝ → ι → Plane) (q : ℝ → ι → ι → Plane)
    (hp : ∀ i, ContinuousAt (fun t => p t i) 0)
    (hq : ∀ i j, C i = C j → ContinuousAt (fun t => q t i j) 0) (i j : ι) :
    ContinuousAt (fun t => clusteredNormal C p q t i j) 0 := by
  classical
  unfold clusteredNormal
  split_ifs with h
  · exact hq i j h
  · fun_prop

theorem clustered_difference {ι : Type*} (C : ι → Plane)
    (p : ℝ → ι → Plane) (q : ℝ → ι → ι → Plane) (c : ℝ → ι → ι → ℝ)
    (hrep : ∀ t, 0 < t → ∀ i j, C i = C j → p t j - p t i = c t i j • q t i j)
    (t : ℝ) (ht : 0 < t) (i j : ι) :
    clusteredPoint C p t j - clusteredPoint C p t i =
      clusteredScale C c t i j • clusteredNormal C p q t i j := by
  classical
  unfold clusteredPoint clusteredScale clusteredNormal
  by_cases h : C i = C j
  · simp only [h, ↓reduceIte]
    rw [mul_smul, ← hrep t ht i j h, smul_sub]
    abel
  · simp only [h, ↓reduceIte, one_smul, smul_sub]
    abel

theorem clusteredNormal_nonzero {ι : Type*} (C : ι → Plane)
    (p : ℝ → ι → Plane) (q : ℝ → ι → ι → Plane)
    (hq : ∀ i j, i ≠ j → C i = C j → q 0 i j ≠ 0)
    (i j : ι) (hij : i ≠ j) : clusteredNormal C p q 0 i j ≠ 0 := by
  classical
  unfold clusteredNormal
  split_ifs with h
  · exact hq i j hij h
  · simpa using sub_ne_zero.mpr (Ne.symm h)

/-- Three separate geometric obligations cover every limiting triple:
internal angles, one internal and one outgoing ray, and two outgoing rays. -/
theorem clusteredNormal_angle {ι : Type*} (C : ι → Plane)
    (p : ℝ → ι → Plane) (q : ℝ → ι → ι → Plane) {A : ℝ}
    (hinternal : ∀ i j k, i ≠ j → i ≠ k → j ≠ k → C j = C i → C j = C k →
      InnerProductGeometry.angle (q 0 j i) (q 0 j k) ≤ A)
    (hmixed : ∀ j i k, j ≠ i → C j = C i → C j ≠ C k →
      InnerProductGeometry.angle (q 0 j i) (C k - C j) ≤ A)
    (hcentres : ∀ i j k, C j ≠ C i → C j ≠ C k →
      InnerProductGeometry.angle (C i - C j) (C k - C j) ≤ A)
    (i j k : ι) (hij : i ≠ j) (hik : i ≠ k) (hjk : j ≠ k) :
    InnerProductGeometry.angle (clusteredNormal C p q 0 j i)
      (clusteredNormal C p q 0 j k) ≤ A := by
  classical
  by_cases hji : C j = C i <;> by_cases hjc : C j = C k
  · simpa only [clusteredNormal, ite_eq_left hji, ite_eq_left hjc] using
      hinternal i j k hij hik hjk hji hjc
  · simpa only [clusteredNormal, ite_eq_left hji, ite_eq_right hjc, zero_smul, add_zero] using
      hmixed j i k (fun h => hij h.symm) hji hjc
  · simpa only [clusteredNormal, ite_eq_right hji, ite_eq_left hjc, zero_smul, add_zero,
      InnerProductGeometry.angle_comm] using hmixed j k i hjk hjc hji
  · simpa only [clusteredNormal, ite_eq_right hji, ite_eq_right hjc, zero_smul, add_zero] using
      hcentres i j k hji hjc

theorem exists_clustered_approximation {ι : Type*} [Fintype ι]
    (C : ι → Plane) (p : ℝ → ι → Plane)
    (q : ℝ → ι → ι → Plane) (c : ℝ → ι → ι → ℝ)
    (hp : ∀ i, ContinuousAt (fun t => p t i) 0)
    (hq : ∀ i j, C i = C j → ContinuousAt (fun t => q t i j) 0)
    (hne : ∀ i j, i ≠ j → C i = C j → q 0 i j ≠ 0)
    (hc : ∀ t, 0 < t → ∀ i j, C i = C j → 0 < c t i j)
    (hrep : ∀ t, 0 < t → ∀ i j, C i = C j → p t j - p t i = c t i j • q t i j)
    {A ε : ℝ}
    (hinternal : ∀ i j k, i ≠ j → i ≠ k → j ≠ k → C j = C i → C j = C k →
      InnerProductGeometry.angle (q 0 j i) (q 0 j k) ≤ A)
    (hmixed : ∀ j i k, j ≠ i → C j = C i → C j ≠ C k →
      InnerProductGeometry.angle (q 0 j i) (C k - C j) ≤ A)
    (hcentres : ∀ i j k, C j ≠ C i → C j ≠ C k →
      InnerProductGeometry.angle (C i - C j) (C k - C j) ≤ A)
    (hε : 0 < ε) :
    ∃ t : ℝ, 0 < t ∧ Function.Injective (clusteredPoint C p t) ∧
      ∀ i j k, i ≠ j → i ≠ k → j ≠ k →
        angle (clusteredPoint C p t i) (clusteredPoint C p t j) (clusteredPoint C p t k) < A + ε := by
  classical
  apply exists_finite_angle_approximation (clusteredPoint C p) (clusteredNormal C p q)
    (clusteredScale C c) (clusteredNormal_continuous C p q hp hq)
    (clusteredNormal_nonzero C p q hne) ?_
    (clustered_difference C p q c hrep)
    (clusteredNormal_angle C p q hinternal hmixed hcentres) hε
  intro t ht i j
  unfold clusteredScale
  split_ifs with h
  · exact mul_pos ht (hc t ht i j h)
  · norm_num

theorem binaryScalePoint_continuous {n : ℕ} (v : Fin n → Plane) (b : BinaryLabel n) :
    ContinuousAt (fun t => binaryScalePoint v t b) 0 := by
  unfold binaryScalePoint
  fun_prop

end Prize.JSP404
