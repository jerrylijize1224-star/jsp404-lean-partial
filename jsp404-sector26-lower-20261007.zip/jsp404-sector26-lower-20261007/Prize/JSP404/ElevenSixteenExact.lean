import SunPrize.ElevenModel
import SendovDirectionModel
import Prize.JSP404.EquallySpacedBinaryAxes
import Prize.JSP404.Sharpness

/-!
Exact ordinary values for 11 through 16 points. The eleven-point direction
certificate is imported unchanged from hit1190100321's PR #647 at
2d0c118ba083a5a75609e8dd586e7a478b4a6dab. The geometric reduction is zilan520's
PR #100 dependency already pinned in this project. This module connects these
attributed lower results to our original targets and existing upper bounds;
it does not claim an independently generated certificate or a first proof.
-/
namespace Prize.JSP404
open EuclideanGeometry

/-- The externally verified eleven-point certificate applies to arbitrary ordinary sets. -/
theorem guaranteedAngle_eleven_three_pi_fourths : GuaranteedAngle 11 (3 * Real.pi / 4) := by
  intro s hs
  obtain ⟨x, hx, y, hy, z, hz, hxy, hxz, hyz, hm⟩ :=
    exists_largest_angle (show 3 ≤ s.card by omega)
  refine ⟨x, hx, y, hy, z, hz, hxy, hxz, hyz, ?_⟩
  by_contra hn
  have hlt : angle x y z < 3 * Real.pi / 4 := lt_of_not_ge hn
  have hlam : 0 < Real.pi - angle x y z := by linarith [Real.pi_pos]
  have ht : Real.pi / (Real.pi - angle x y z) < 4 := by
    apply (div_lt_iff₀ hlam).mpr
    linarith
  have hmodel : Nonempty (SendovDirectionModel.Model 11
      (Real.pi / (Real.pi - angle x y z))) := by
    have h := SendovDirectionModel.model_of_finite_set s hlam (by
      intro u hu v hv w hw huv huw hvw
      simpa only [sub_sub_cancel] using hm u hu v hv w hw huv huw hvw)
    simpa only [hs] using h
  obtain ⟨m⟩ := hmodel
  let m' : SunPrize.DirectionModel 11 (Real.pi / (Real.pi - angle x y z)) := {
    theta := m.theta
    range := m.range
    triangle := fun i j k hij hjk => m.triangle i j k hij hjk }
  exact (not_lt_of_ge (SunPrize.eleven_point_direction_bound _ m')) ht

theorem guaranteedAngle_three_pi_fourths {N : ℕ} (hN : 11 ≤ N) :
    GuaranteedAngle N (3 * Real.pi / 4) :=
  guaranteedAngle_eleven_three_pi_fourths.mono_card hN

theorem eleven_sixteen_isSharpBound {N : ℕ} (hlo : 11 ≤ N) (hhi : N ≤ 16) :
    IsSharpBound N (3 * Real.pi / 4) := by
  refine ⟨by positivity, by linarith [Real.pi_pos],
    guaranteedAngle_three_pi_fourths hlo, ?_⟩
  intro b hb
  apply dyadic_not_guaranteed (n := 4) (by decide) (by norm_num; exact hhi)
  norm_num
  linarith

theorem alpha_eleven_to_sixteen {N : ℕ} (hlo : 11 ≤ N) (hhi : N ≤ 16) :
    alpha N = 3 * Real.pi / 4 := (eleven_sixteen_isSharpBound hlo hhi).alpha_eq

end Prize.JSP404
