import Prize.JSP404.Sector26DiscreteBound
import Prize.JSP404.Sector26Quantization
import Prize.JSP404.GeneralAngleBounds

/-!
A certified 26-sector lower bound for the original planar angle problem.
This improves the local numerical lower bound at 17 points; it does not prove
Sendov's exact value 7π/9 or the arbitrary-cardinality classification.
The real/complex conversion uses mathlib's standard plane isometry, also used
in the attributed SendovDirectionModel transfer. No external finite direction
certificate is imported by this module.
-/
namespace Prize.JSP404
open FiniteCliqueCertificate.Sector26

theorem card_le_sixteen_of_complex_angles {V : Type*} [Fintype V]
    (p : V → ℂ) (hp : Function.Injective p)
    (hangle : ∀ u v w, u ≠ v → u ≠ w → v ≠ w →
      EuclideanGeometry.angle (p u) (p v) (p w) < 10*Real.pi/13) :
    Fintype.card V ≤ 16 := by
  let q : V → V → Sector := fun u v => angleBin (p v-p u).arg
  apply card_le_sixteen_of_sector_assignment q
  · intro u v huv
    change angleBin (p u-p v).arg = antipode (angleBin (p v-p u).arg)
    rw [show p u-p v = -(p v-p u) by abel]
    exact argBin_neg (sub_ne_zero.mpr (hp.ne (Ne.symm huv)))
  · intro v u w hvu hvw huw
    apply argBin_close (sub_ne_zero.mpr (hp.ne (Ne.symm hvu)))
      (sub_ne_zero.mpr (hp.ne (Ne.symm hvw)))
    exact hangle u v w (Ne.symm hvu) huw hvw

theorem card_le_sixteen_of_plane_angles {V : Type*} [Fintype V]
    (p : V → Plane) (hp : Function.Injective p)
    (hangle : ∀ u v w, u ≠ v → u ≠ w → v ≠ w →
      EuclideanGeometry.angle (p u) (p v) (p w) < 10*Real.pi/13) :
    Fintype.card V ≤ 16 := by
  let e := Complex.orthonormalBasisOneI.repr.symm
  apply card_le_sixteen_of_complex_angles (fun v => e (p v)) (e.injective.comp hp)
  intro u v w huv huw hvw
  change InnerProductGeometry.angle (e (p u)-e (p v)) (e (p w)-e (p v)) < _
  rw [← map_sub, ← map_sub]
  change InnerProductGeometry.angle (e.toLinearIsometry (p u-p v))
    (e.toLinearIsometry (p w-p v)) < _
  rw [e.toLinearIsometry.angle_map]
  exact hangle u v w huv huw hvw

theorem guaranteedAngle_sector26 {N : ℕ} (hN : 17 ≤ N) :
    GuaranteedAngle N (10*Real.pi/13) := by
  intro s hs
  classical
  by_contra hn
  have hb : ∀ u v w : s, u ≠ v → u ≠ w → v ≠ w →
      EuclideanGeometry.angle (u : Plane) (v : Plane) (w : Plane) < 10*Real.pi/13 := by
    intro u v w huv huw hvw
    apply lt_of_not_ge
    intro ha
    apply hn
    exact ⟨u, u.property, v, v.property, w, w.property,
      (fun h => huv (Subtype.ext h)), (fun h => huw (Subtype.ext h)),
      (fun h => hvw (Subtype.ext h)), ha⟩
  have hc := card_le_sixteen_of_plane_angles (fun u : s => (u : Plane))
    Subtype.val_injective hb
  simp only [Fintype.card_coe] at hc
  omega

theorem sector26_alpha_lower {N : ℕ} (hN : 17 ≤ N) :
    (10/13 : ℝ)*Real.pi ≤ alpha N := by
  apply le_csSup (admissibleAngles_bddAbove N)
  refine ⟨by positivity, by linarith [Real.pi_pos], ?_⟩
  convert guaranteedAngle_sector26 hN using 1; ring

theorem alpha_seventeen_sector26_bounds :
    (10/13 : ℝ)*Real.pi ≤ alpha 17 ∧ alpha 17 ≤ (7/9 : ℝ)*Real.pi :=
  ⟨sector26_alpha_lower (by decide), alpha_seventeen_bounds.2⟩

end Prize.JSP404
