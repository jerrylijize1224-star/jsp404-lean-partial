import Prize.JSP404.ProjectiveCoordinates
import Prize.JSP404.GapSectorCounting
import Prize.JSP404.Sharpness

/-!
# Uniform half-open sectors and a general lower bound

Partition the projective semicircle into k half-open intervals. Directions in
one interval have angular distance strictly less than pi/k, even at integral
endpoints. Binary-cover counting then bounds configurations whose angles are
at most pi-pi/k by 2^k. This is a general, non-sharp lower bound; it does not
establish either matching lower bound in SendovClaim.
-/

namespace Prize.JSP404

open InnerProductGeometry

def uniformProjectiveSector (k : ℕ) (i : Fin k) : Set Plane :=
  parameterSector 0 (Real.pi / k) (Set.Ico (i.val : ℝ) (i.val + 1))

theorem uniformProjectiveSector_thin {k : ℕ} (hk : 0 < k) (i : Fin k)
    {p q : Plane} (hp : p ∈ uniformProjectiveSector k i)
    (hq : q ∈ uniformProjectiveSector k i) : angle p q < Real.pi / k := by
  have hkR : (0 : ℝ) < k := by exact_mod_cast hk
  have hk1 : (1 : ℝ) ≤ k := by exact_mod_cast hk
  apply parameterSector_thin (div_pos Real.pi_pos hkR)
    ((div_le_iff₀ hkR).mpr (by nlinarith [Real.pi_pos])) ?_ hp hq
  intro x hx y hy
  exact abs_lt.mpr ⟨by linarith [hx.1, hy.2], by linarith [hy.1, hx.2]⟩

theorem exists_uniformProjectiveSector {k : ℕ} (hk : 0 < k)
    {p : Plane} (hp : p ≠ 0) :
    ∃ i : Fin k, p ∈ uniformProjectiveSector k i ∨ -p ∈ uniformProjectiveSector k i := by
  obtain ⟨θ, r, b, hθ, hπ, hr, hrep⟩ := exists_projective_coordinates hp
  have hkR : (0 : ℝ) < k := by exact_mod_cast hk
  have hw : 0 < Real.pi / k := div_pos Real.pi_pos hkR
  let x : ℝ := θ / (Real.pi / k)
  have hx : 0 ≤ x := div_nonneg hθ hw.le
  have hxk : x < k := by
    dsimp [x]
    apply (div_lt_iff₀ hw).mpr
    simpa only [mul_div_cancel₀ _ (ne_of_gt hkR)] using hπ
  let i : Fin k := ⟨⌊x⌋₊, (Nat.floor_lt hx).mpr hxk⟩
  have hxi : x ∈ Set.Ico (i.val : ℝ) (i.val + 1) :=
    ⟨Nat.floor_le hx, Nat.lt_floor_add_one x⟩
  have he : 0 + (Real.pi / k) * x = θ := by
    dsimp [x]
    field_simp
    ring
  refine ⟨i, ?_⟩
  cases b
  · left
    exact ⟨x, hxi, r, hr, by simpa only [he, signedDirection, Bool.false_eq_true,
      ↓reduceIte] using hrep⟩
  · right
    refine ⟨x, hxi, r, hr, ?_⟩
    rw [he, hrep]
    simp [signedDirection]

/-- No cluster, realizability, or direction-cover premise remains. -/
theorem GeneralizedDirections.card_le_two_pow_of_uniform_angle
    {V : Type*} [Fintype V] (D : GeneralizedDirections V)
    {k : ℕ} (hk : 0 < k)
    (hbound : D.AngleBound (Real.pi - Real.pi / k)) : Fintype.card V ≤ 2 ^ k := by
  have hkR : (0 : ℝ) < k := by exact_mod_cast hk
  have hk1 : (1 : ℝ) ≤ k := by exact_mod_cast hk
  have hw : Real.pi / k ≤ Real.pi := (div_le_iff₀ hkR).mpr (by nlinarith [Real.pi_pos])
  apply D.card_le_two_pow_of_cover (sub_nonneg.mpr hw) (uniformProjectiveSector k) ?_ ?_ hbound
  · intro u v huv
    obtain ⟨i, hi⟩ := exists_uniformProjectiveSector hk (D.nonzero u v huv)
    exact ⟨i, by rwa [D.reverse u v]⟩
  · intro i p hp q hq
    simpa only [sub_sub_cancel] using uniformProjectiveSector_thin hk i hp hq

theorem card_le_two_pow_of_uniform_angle {s : Finset Plane} {k : ℕ} (hk : 0 < k)
    (hbound : ∀ u ∈ s, ∀ v ∈ s, ∀ w ∈ s,
      u ≠ v → u ≠ w → v ≠ w →
      EuclideanGeometry.angle u v w ≤ Real.pi - Real.pi / k) : s.card ≤ 2 ^ k := by
  let D : GeneralizedDirections s := {
    direction := fun u v => (v : Plane) - u
    reverse := fun u v => by abel
    nonzero := fun u v huv => sub_ne_zero.mpr (fun h => huv (Subtype.ext h.symm)) }
  have hD : D.AngleBound (Real.pi - Real.pi / k) := by
    intro u v w huv huw hvw
    exact hbound u u.property v v.property w w.property
      (fun h => huv (Subtype.ext h)) (fun h => huw (Subtype.ext h))
      (fun h => hvw (Subtype.ext h))
  simpa using D.card_le_two_pow_of_uniform_angle hk hD

/-- The individual configuration has an angle strictly larger than the bound.
The extremal infimum itself is only bounded non-strictly below. -/
theorem exists_angle_gt_uniform_bound {s : Finset Plane} {k : ℕ}
    (hk : 0 < k) (hs : 2 ^ k < s.card) :
    ∃ x ∈ s, ∃ y ∈ s, ∃ z ∈ s,
      x ≠ y ∧ x ≠ z ∧ y ≠ z ∧
        Real.pi - Real.pi / k < EuclideanGeometry.angle x y z := by
  by_contra h
  have hbound : ∀ u ∈ s, ∀ v ∈ s, ∀ w ∈ s,
      u ≠ v → u ≠ w → v ≠ w →
      EuclideanGeometry.angle u v w ≤ Real.pi - Real.pi / k := by
    intro u hu v hv w hw huv huw hvw
    exact le_of_not_gt (fun hgt => h ⟨u, hu, v, hv, w, hw, huv, huw, hvw, hgt⟩)
  exact (not_le_of_gt hs) (card_le_two_pow_of_uniform_angle hk hbound)

theorem guaranteedAngle_uniform_bound {k N : ℕ} (hk : 0 < k) (hN : 2 ^ k < N) :
    GuaranteedAngle N ((1 - 1 / (k : ℝ)) * Real.pi) := by
  intro s hs
  obtain ⟨x, hx, y, hy, z, hz, hxy, hxz, hyz, ha⟩ :=
    exists_angle_gt_uniform_bound hk (hs ▸ hN)
  refine ⟨x, hx, y, hy, z, hz, hxy, hxz, hyz, ?_⟩
  have he : (1 - 1 / (k : ℝ)) * Real.pi = Real.pi - Real.pi / k := by ring
  rw [he]
  exact ha.le

theorem uniform_alpha_lower {k N : ℕ} (hk : 0 < k) (hN : 2 ^ k < N) :
    (1 - 1 / (k : ℝ)) * Real.pi ≤ alpha N := by
  have hkR : (0 : ℝ) < k := by exact_mod_cast hk
  have hk1 : (1 : ℝ) ≤ k := by exact_mod_cast hk
  have hi : 1 / (k : ℝ) ≤ 1 := (div_le_one hkR).mpr hk1
  apply le_csSup (admissibleAngles_bddAbove N)
  exact ⟨mul_nonneg (by linarith) Real.pi_pos.le,
    by nlinarith [div_pos (by norm_num : (0 : ℝ) < 1) hkR, Real.pi_pos],
    guaranteedAngle_uniform_bound hk hN⟩

/-- A concrete accuracy guarantee for every sufficiently large cardinality. -/
theorem alpha_within_pi_div {k N : ℕ} (hk : 0 < k) (hN : 2 ^ k < N) :
    0 ≤ Real.pi - alpha N ∧ Real.pi - alpha N ≤ Real.pi / k := by
  have htwo : 2 ≤ (2 : ℕ) ^ k := by
    calc
      2 = (2 : ℕ) ^ 1 := by norm_num
      _ ≤ 2 ^ k := pow_le_pow_right₀ (by decide) hk
  have hupper := (alpha_bounds (show 3 ≤ N by omega)).2
  have hlower := uniform_alpha_lower hk hN
  have he : (1 - 1 / (k : ℝ)) * Real.pi = Real.pi - Real.pi / k := by ring
  rw [he] at hlower
  exact ⟨by linarith, by linarith⟩

/-- This asymptotic statement does not identify the exact finite-N values. -/
theorem alpha_tendsto_pi : Filter.Tendsto alpha Filter.atTop (nhds Real.pi) := by
  apply tendsto_order.mpr
  constructor
  · intro a ha
    obtain ⟨k, hk⟩ := exists_nat_gt (max 1 (Real.pi / (Real.pi - a)))
    have hk1 : (1 : ℝ) < k := lt_of_le_of_lt (le_max_left _ _) hk
    have hk0 : 0 < k := by exact_mod_cast (show (0 : ℝ) < k by linarith)
    have hratio : Real.pi / (Real.pi - a) < k := lt_of_le_of_lt (le_max_right _ _) hk
    have hmul := (div_lt_iff₀ (sub_pos.mpr ha)).mp hratio
    have hdiv : Real.pi / (k : ℝ) < Real.pi - a :=
      (div_lt_iff₀ (by linarith : (0 : ℝ) < k)).mpr (by nlinarith)
    apply Filter.eventually_atTop.mpr
    refine ⟨2 ^ k + 1, fun N hN => ?_⟩
    have hl := uniform_alpha_lower hk0 (show 2 ^ k < N by omega)
    have he : (1 - 1 / (k : ℝ)) * Real.pi = Real.pi - Real.pi / k := by ring
    rw [he] at hl
    linarith
  · intro a ha
    exact Filter.eventually_atTop.mpr ⟨3, fun N hN => (alpha_bounds hN).2.trans_lt ha⟩

end Prize.JSP404
