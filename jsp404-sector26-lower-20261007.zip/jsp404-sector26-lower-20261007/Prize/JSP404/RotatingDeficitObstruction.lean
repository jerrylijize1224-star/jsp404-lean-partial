import Prize.JSP404.CoverDeficitBudget
import Prize.JSP404.RotatingCoverDeficit
import Prize.JSP404.ThreePoints

/-! A genuine plane configuration where separate free slots never overlap.
This refutes a quantifier exchange, not the sharp angle conjecture. -/
namespace Prize.JSP404
open scoped Classical

/-- The actual difference directions of a finite ordinary point set. -/
def pointSetDirections (s : Finset Plane) : GeneralizedDirections s where
  direction u v := (v : Plane) - u
  reverse u v := by abel
  nonzero u v huv := sub_ne_zero.mpr (fun h => huv (Subtype.ext h.symm))

namespace GeneralizedDirections
variable {V : Type*} [Fintype V] (D : GeneralizedDirections V)

theorem rotating_free_slots_le_one {k : ℕ} (hk : 0 < k) {a r t : ℝ}
    (ha : 0 ≤ a) (hlo : Real.pi / k / 2 < r) (hhi : 2 * r < Real.pi - a)
    (hb : D.AngleBound a) (ht : t ∈ Set.Icc 0 Real.pi)
    (hcard : Fintype.card V + 1 = 2 ^ k) :
    (freeCoverSlots (D.rotatingRelation k r t)).card ≤ 1 :=
  near_saturated_free_slots_le_one _ (D.rotatingRelation_cover hk hlo ht)
    (D.rotatingRelation_no_two_step ha hhi hb t) hcard

/-- Each slot is uniquely free at some rotation, but different slots need different rotations. -/
theorem exists_rotating_unique_free_slot {k : ℕ} (hk : 0 < k) {a r : ℝ}
    (ha : 0 ≤ a) (hlo : Real.pi / k / 2 < r) (hhi : 2 * r < Real.pi - a)
    (hb : D.AngleBound a) (hcard : Fintype.card V + 1 = 2 ^ k)
    (i : Fin k) (u : V) :
    ∃ t ∈ Set.Icc 0 Real.pi, i ∈ freeCoverIndices (D.rotatingRelation k r t) u ∧
      ∀ v j, j ∈ freeCoverIndices (D.rotatingRelation k r t) v → v = u ∧ j = i := by
  obtain ⟨t, ht, hi⟩ := D.exists_rotating_unused ha hhi hb i u
  refine ⟨t, ht, hi, fun v j hj => ?_⟩
  exact near_saturated_free_slot_unique _ (D.rotatingRelation_cover hk hlo ht)
    (D.rotatingRelation_no_two_step ha hhi hb t) hcard hj hi

end GeneralizedDirections

/-- All six vertex-sector slots of an actual equilateral triangle have unused
positions, yet at every rotation at most one slot is unused. In particular,
separate existence cannot justify simultaneous deficits, even for actual sectors. -/
theorem exists_ordinary_rotating_deficit_obstruction :
    ∃ s : Finset Plane, s.card = 3 ∧
      (∀ i : Fin 2, ∀ u : s, ∃ t ∈ Set.Icc 0 Real.pi,
        i ∈ freeCoverIndices ((pointSetDirections s).rotatingRelation 2 (7 * Real.pi / 24) t) u) ∧
      (∀ t ∈ Set.Icc 0 Real.pi,
        (freeCoverSlots ((pointSetDirections s).rotatingRelation 2 (7 * Real.pi / 24) t)).card ≤ 1) := by
  obtain ⟨s, hs, heq⟩ := exists_three_point_equiangular
  have hb : (pointSetDirections s).AngleBound (Real.pi / 3) := by
    intro u v w huv huw hvw
    exact (heq u u.property v v.property w w.property
      (fun h => huv (Subtype.ext h)) (fun h => huw (Subtype.ext h))
      (fun h => hvw (Subtype.ext h))).le
  have ha : 0 ≤ Real.pi / 3 := by positivity
  have hlo : Real.pi / (2 : ℕ) / 2 < 7 * Real.pi / 24 := by
    norm_num; linarith [Real.pi_pos]
  have hhi : 2 * (7 * Real.pi / 24) < Real.pi - Real.pi / 3 := by
    linarith [Real.pi_pos]
  refine ⟨s, hs, ?_, ?_⟩
  · intro i u
    exact (pointSetDirections s).exists_rotating_unused ha hhi hb i u
  · intro t ht
    exact (pointSetDirections s).rotating_free_slots_le_one (by decide) ha hlo hhi hb ht
      (by simp [hs])

end Prize.JSP404
