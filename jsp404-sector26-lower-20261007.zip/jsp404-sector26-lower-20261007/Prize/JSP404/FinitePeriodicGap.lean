import Prize.JSP404.GapIntervalCover
import Mathlib.Data.Fintype.Card

/-! A finite family of phases leaves an explicit empty half-open bin.
The resulting periodic gap shortens each unit interval after a common shift. -/

namespace Prize.JSP404

theorem exists_empty_phase_bin {J : Type*} [Fintype J] (x : J → ℝ) :
    ∃ β : ℝ, 1 / (Fintype.card J + 1 : ℝ) ≤ β ∧ β ≤ 1 ∧
      ∀ j, Int.fract (x j) ∉ Set.Ico (β - 1 / (Fintype.card J + 1 : ℝ)) β := by
  classical
  let L : ℕ := Fintype.card J + 1
  have hL : (0 : ℝ) < L := by dsimp [L]; positivity
  let f : J → Fin L := fun j => ⟨⌊(L : ℝ) * Int.fract (x j)⌋₊,
    (Nat.floor_lt (mul_nonneg hL.le (Int.fract_nonneg _))).mpr
      (by nlinarith [Int.fract_lt_one (x j)])⟩
  have hn : ¬ Function.Surjective f := by
    intro hf
    have hc := Fintype.card_le_of_surjective f hf
    simp only [Fintype.card_fin] at hc
    dsimp [L] at hc
    omega
  simp only [Function.Surjective, not_forall, not_exists] at hn
  obtain ⟨i, hi⟩ := hn
  have hcast : (Fintype.card J : ℝ) + 1 = (L : ℝ) := by simp [L]
  rw [hcast]
  refine ⟨((i.val : ℝ) + 1) / L, ?_, ?_, ?_⟩
  · apply (div_le_div_iff_of_pos_right hL).mpr
    have hi0 : (0 : ℝ) ≤ i.val := Nat.cast_nonneg _
    linarith
  · apply (div_le_one hL).mpr
    exact_mod_cast i.isLt
  · intro j hj
    change Int.fract (x j) ∈ Set.Ico (((i.val : ℝ) + 1) / L - 1 / L)
      (((i.val : ℝ) + 1) / L) at hj
    have hlo : (i.val : ℝ) / L ≤ Int.fract (x j) := by
      have he : ((i.val : ℝ) + 1) / L - 1 / L = i.val / L := by ring
      simpa only [he] using hj.1
    have hlow := (div_le_iff₀ hL).mp hlo
    have hhigh := (lt_div_iff₀ hL).mp hj.2
    have he : ⌊(L : ℝ) * Int.fract (x j)⌋₊ = i.val :=
      (Nat.floor_eq_iff (mul_nonneg hL.le (Int.fract_nonneg _))).mpr
        ⟨by nlinarith, by nlinarith⟩
    exact hi j (Fin.ext he)

theorem shifted_unit_interval_shortening {x β ε : ℝ} {q : ℕ}
    (_hε : 0 < ε) (hβε : ε ≤ β) (hβ : β ≤ 1)
    (hgap : Int.fract x ∉ Set.Ico (β - ε) β)
    (_hlo : (q : ℝ) + β ≤ x) (hhi : x < (q : ℝ) + β + 1) :
    x < (q : ℝ) + β + 1 - ε := by
  by_contra h
  have hfloor : ⌊x⌋ = (q : ℤ) + 1 := by
    apply Int.floor_eq_iff.mpr
    push_cast
    constructor <;> linarith
  apply hgap
  simp only [Int.fract, hfloor, Int.cast_add, Int.cast_natCast, Int.cast_one]
  constructor <;> linarith

/-- Integer shifts preserve the excluded phase interval. -/
theorem phase_gap_add_nat {x β ε : ℝ}
    (h : Int.fract x ∉ Set.Ico (β - ε) β) (k : ℕ) :
    Int.fract (x + k) ∉ Set.Ico (β - ε) β := by
  simpa using (show Int.fract (x + (k : ℤ)) ∉ Set.Ico (β - ε) β by
    rwa [Int.fract_add_intCast])

end Prize.JSP404
