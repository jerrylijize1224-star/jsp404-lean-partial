import NineModelTrial
import Prize.JSP404.FirstBandConstruction
import Prize.JSP404.Sharpness

/-!
Exact ordinary nine- and ten-point values. The lower-bound certificate and
ordinary-point direction-model transfer are imported unchanged from zilan520's
PR #100 at d869ab901722fab0b2d980b38b7bd958cf52c128. See the source lock and
research/jsp404-nine-ten-exact.md. The upper constructions are this project's
previously verified ones. This integration is not an original lower proof.
-/
namespace Prize.JSP404
open EuclideanGeometry

/-- The pinned external certificate applies to the original ordinary point-set target. -/
theorem guaranteedAngle_nine_five_pi_sevenths : GuaranteedAngle 9 (5 * Real.pi / 7) := by
  intro s hs
  obtain ⟨x, hx, y, hy, z, hz, hxy, hxz, hyz, hm⟩ :=
    exists_largest_angle (show 3 ≤ s.card by omega)
  refine ⟨x, hx, y, hy, z, hz, hxy, hxz, hyz, ?_⟩
  by_contra hn
  have hlt : angle x y z < 5 * Real.pi / 7 := lt_of_not_ge hn
  have hlam : 0 < Real.pi - angle x y z := by linarith [Real.pi_pos]
  have ht : Real.pi / (Real.pi - angle x y z) < (7 : ℝ) / 2 := by
    apply (div_lt_iff₀ hlam).mpr
    linarith
  have hmodel : Nonempty (SendovDirectionModel.Model 9
      (Real.pi / (Real.pi - angle x y z))) := by
    have h := SendovDirectionModel.model_of_finite_set s hlam (by
      intro u hu v hv w hw huv huw hvw
      simpa only [sub_sub_cancel] using hm u hu v hv w hw huv huw hvw)
    simpa only [hs] using h
  obtain ⟨m⟩ := hmodel
  exact (not_lt_of_ge (NineModelTrial.model_nine_lower m)) ht

theorem guaranteedAngle_five_pi_sevenths {N : ℕ} (hN : 9 ≤ N) :
    GuaranteedAngle N (5 * Real.pi / 7) :=
  guaranteedAngle_nine_five_pi_sevenths.mono_card hN

theorem nine_ten_isSharpBound {N : ℕ} (hlo : 9 ≤ N) (hhi : N ≤ 10) :
    IsSharpBound N (5 * Real.pi / 7) := by
  apply isSharpBound_of_approximation (by positivity) (by linarith [Real.pi_pos])
    (guaranteedAngle_five_pi_sevenths hlo)
  intro ε hε
  obtain ⟨s, hs, hb⟩ := exists_firstBand_counterexample 1 hε
  refine ⟨s, ?_, ?_⟩
  · norm_num at hs
    omega
  · have he : Real.pi - 2 * firstBandStep 1 + ε = 5 * Real.pi / 7 + ε := by
      norm_num [firstBandStep]
      ring
    rw [he] at hb
    exact hb

theorem alpha_nine : alpha 9 = 5 * Real.pi / 7 :=
  (nine_ten_isSharpBound (by decide) (by decide)).alpha_eq

theorem alpha_ten : alpha 10 = 5 * Real.pi / 7 :=
  (nine_ten_isSharpBound (by decide) (by decide)).alpha_eq

end Prize.JSP404
