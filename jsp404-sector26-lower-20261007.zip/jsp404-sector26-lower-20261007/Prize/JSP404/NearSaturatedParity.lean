import Prize.JSP404.CoverDeficitBudget
import Mathlib.GroupTheory.Perm.Cycle.Type
import Mathlib.Topology.LocallyConstant.Basic

/-! Parity obstruction one below the binary capacity. The product of
permutation sign and vacancy color is invariant under every compatible swap.
Geometric and numerical consequences are in OddNearDyadicSharp.lean. -/
namespace Prize.JSP404
open scoped Classical

abbrev CubeCode (k : ℕ) := Fin k → Bool

def ValidCoverCompletion {V : Type*} {k : ℕ}
    (R : Fin k → V → V → Prop) (e : Option V ≃ CubeCode k) : Prop :=
  ∀ v i, CompatibleCoverBit R v i (e (some v) i)

/-- Distinct compatible bits imply that both incidence constraints are absent. -/
theorem free_of_compatible_ne {V : Type*} {k : ℕ}
    {R : Fin k → V → V → Prop} {v : V} {i : Fin k} {a b : Bool}
    (ha : CompatibleCoverBit R v i a) (hb : CompatibleCoverBit R v i b)
    (hne : a ≠ b) : i ∈ freeCoverIndices R v := by
  classical
  simp only [freeCoverIndices, Finset.mem_filter, Finset.mem_univ, true_and]
  exact ⟨fun h => hne ((ha.1 h).trans (hb.1 h).symm),
    fun h => hne ((ha.2 h).trans (hb.2 h).symm)⟩

/-- Any two compatible completions can differ on at most one vertex-bit pair. -/
theorem completion_difference_unique {V : Type*} [Fintype V] {k : ℕ}
    (R : Fin k → V → V → Prop)
    (hc : ∀ u v, u ≠ v → ∃ i, R i u v ∨ R i v u)
    (hs : ∀ i u v w, R i u v → R i v w → False)
    (hn : Fintype.card V + 1 = 2 ^ k)
    {e f : Option V ≃ CubeCode k} (he : ValidCoverCompletion R e)
    (hf : ValidCoverCompletion R f) {u v : V} {i j : Fin k}
    (hi : e (some u) i ≠ f (some u) i)
    (hj : e (some v) j ≠ f (some v) j) : u = v ∧ i = j :=
  near_saturated_free_slot_unique R hc hs hn
    (free_of_compatible_ne (he u i) (hf u i) hi)
    (free_of_compatible_ne (he v j) (hf v j) hj)

theorem exists_validCoverCompletion {V : Type*} [Fintype V] {k : ℕ}
    (R : Fin k → V → V → Prop)
    (hc : ∀ u v, u ≠ v → ∃ i, R i u v ∨ R i v u)
    (hs : ∀ i u v w, R i u v → R i v w → False)
    (hn : Fintype.card V + 1 = 2 ^ k) :
    ∃ e : Option V ≃ CubeCode k, ValidCoverCompletion R e := by
  classical
  let code : V → CubeCode k := fun v i => decide (∃ w, R i v w)
  have hv (v : V) (i : Fin k) : CompatibleCoverBit R v i (code v i) := by
    constructor
    · intro h; simp [code, h]
    · rintro ⟨u, hu⟩
      have h : ¬ ∃ w, R i v w := by rintro ⟨w, hw⟩; exact hs i u v w hu hw
      simp [code, h]
  have hi : Function.Injective code := by
    intro u v he
    exact compatibleCoverCode_disjoint R hc
      (fun i => ⟨code u i, hv u i⟩) (fun i => ⟨code v i, hv v i⟩)
      (fun i => congrFun he i)
  have hcard : Fintype.card (CubeCode k) = Fintype.card V + 1 := by
    simpa [CubeCode] using hn.symm
  obtain ⟨z, hz, _⟩ := Fintype.existsUnique_notMem_image_of_injective_of_card_eq_add_one code hi hcard
  have hz' (v : V) : z ≠ code v := by
    intro he; apply hz; exact Finset.mem_image.mpr ⟨v, Finset.mem_univ _, he.symm⟩
  let f : Option V → CubeCode k := Option.elim' z code
  have hfi : Function.Injective f := by
    intro a b he
    cases a with
    | none => cases b with
      | none => rfl
      | some b => exact False.elim (hz' b he)
    | some a => cases b with
      | none => exact False.elim (hz' a he.symm)
      | some b => exact congrArg some (hi he)
  have hfb : Function.Bijective f :=
    (Fintype.bijective_iff_injective_and_card f).mpr ⟨hfi, by simpa using hcard.symm⟩
  exact ⟨Equiv.ofBijective f hfb, hv⟩

/-- A change of completion swaps the unique vacancy with one vertex. -/
theorem completion_swap_of_difference {V : Type*} [Fintype V] {k : ℕ}
    (R : Fin k → V → V → Prop)
    (hc : ∀ u v, u ≠ v → ∃ i, R i u v ∨ R i v u)
    (hs : ∀ i u v w, R i u v → R i v w → False)
    (hn : Fintype.card V + 1 = 2 ^ k)
    {e f : Option V ≃ CubeCode k} (he : ValidCoverCompletion R e)
    (hf : ValidCoverCompletion R f) {v : V} {i : Fin k}
    (hi : e (some v) i ≠ f (some v) i) :
    f = (Equiv.swap none (some v)).trans e ∧
      ∀ j, j ≠ i → e (some v) j = f (some v) j := by
  classical
  have same (u : V) (hu : u ≠ v) : e (some u) = f (some u) := by
    funext j
    by_contra h
    exact hu (completion_difference_unique R hc hs hn he hf h hi).1
  have ne : e (some v) ≠ f (some v) := fun h => hi (congrFun h i)
  have hole : f none = e (some v) := by
    obtain ⟨w, hw⟩ := f.surjective (e (some v))
    cases w with
    | none => exact hw
    | some u =>
      by_cases huv : u = v
      · subst u; exact False.elim (ne hw.symm)
      · have eq := e.injective ((same u huv).trans hw)
        exact False.elim (huv (Option.some.inj eq))
  have vertex : f (some v) = e none := by
    obtain ⟨w, hw⟩ := f.surjective (e none)
    cases w with
    | none => exact False.elim ((Option.some_ne_none v) (e.injective (hole.symm.trans hw)))
    | some u =>
      by_cases huv : u = v
      · simpa [huv] using hw
      · exact False.elim ((Option.some_ne_none u) (e.injective ((same u huv).trans hw)))
  constructor
  · apply Equiv.ext
    intro w
    cases w with
    | none => simpa using hole
    | some u =>
      by_cases huv : u = v
      · subst u; simpa using vertex
      · simpa [Equiv.swap_apply_of_ne_of_ne (by simp : some u ≠ (none : Option V))
          (by simpa using huv : some u ≠ some v)] using (same u huv).symm
  · intro j hji
    by_contra h
    exact hji (completion_difference_unique R hc hs hn he hf h hi).2

noncomputable def completionParity {V : Type*} [Fintype V] {k : ℕ}
    (ref e : Option V ≃ CubeCode k) (χ : CubeCode k → ℤˣ) : ℤˣ := by
  classical
  exact Equiv.Perm.sign (e.trans ref.symm) * χ (e none)

/-- Swapping the vacancy along a cube edge preserves permutation sign times color. -/
theorem completionParity_swap {V : Type*} [Fintype V] {k : ℕ}
    (ref e : Option V ≃ CubeCode k) (χ : CubeCode k → ℤˣ) (v : V)
    (hχ : χ (e (some v)) = -χ (e none)) :
    completionParity ref ((Equiv.swap none (some v)).trans e) χ =
      completionParity ref e χ := by
  classical
  unfold completionParity
  rw [Equiv.trans_assoc, Equiv.Perm.sign_trans,
    Equiv.Perm.sign_swap (by simp : (none : Option V) ≠ some v)]
  simp [hχ]

theorem completionParity_eq {V : Type*} [Fintype V] {k : ℕ}
    (R : Fin k → V → V → Prop)
    (hc : ∀ u v, u ≠ v → ∃ i, R i u v ∨ R i v u)
    (hs : ∀ i u v w, R i u v → R i v w → False)
    (hn : Fintype.card V + 1 = 2 ^ k)
    (ref e f : Option V ≃ CubeCode k) (he : ValidCoverCompletion R e)
    (hf : ValidCoverCompletion R f) (χ : CubeCode k → ℤˣ)
    (hχ : ∀ c d : CubeCode k, ∀ i, c i ≠ d i →
      (∀ j, j ≠ i → c j = d j) → χ c = -χ d) :
    completionParity ref e χ = completionParity ref f χ := by
  classical
  by_cases hd : ∃ v i, e (some v) i ≠ f (some v) i
  · obtain ⟨v, i, hi⟩ := hd
    obtain ⟨heq, hj⟩ := completion_swap_of_difference R hc hs hn he hf hi
    have hcχ := hχ (e (some v)) (f (some v)) i hi hj
    rw [heq] at hcχ ⊢
    have hh : χ (e (some v)) = -χ (e none) := by simpa using hcχ
    exact (completionParity_swap ref e χ v hh).symm
  · have same (v : V) : e (some v) = f (some v) := by
      funext i
      by_contra h
      exact hd ⟨v, i, h⟩
    have hole : e none = f none := by
      obtain ⟨w, hw⟩ := f.surjective (e none)
      cases w with
      | none => exact hw.symm
      | some v => exact False.elim ((Option.some_ne_none v)
          (e.injective ((same v).trans hw)))
    have heq : e = f := by
      apply Equiv.ext
      intro w
      cases w with
      | none => exact hole
      | some v => exact same v
    rw [heq]

/-- The parity invariant is constant along any connected open family of covers. -/
theorem completionParity_constant {V T : Type*} [Fintype V]
    [TopologicalSpace T] [PreconnectedSpace T] {k : ℕ}
    (R : T → Fin k → V → V → Prop)
    (hopen : ∀ i u v, IsOpen {t | R t i u v})
    (hc : ∀ t u v, u ≠ v → ∃ i, R t i u v ∨ R t i v u)
    (hs : ∀ t i u v w, R t i u v → R t i v w → False)
    (hn : Fintype.card V + 1 = 2 ^ k)
    (ref : Option V ≃ CubeCode k) (χ : CubeCode k → ℤˣ)
    (hχ : ∀ c d : CubeCode k, ∀ i, c i ≠ d i →
      (∀ j, j ≠ i → c j = d j) → χ c = -χ d)
    (a b : T) (e f : Option V ≃ CubeCode k)
    (he : ValidCoverCompletion (R a) e) (hf : ValidCoverCompletion (R b) f) :
    completionParity ref e χ = completionParity ref f χ := by
  classical
  let E (t : T) := Classical.choose (exists_validCoverCompletion (R t) (hc t) (hs t) hn)
  have hE (t : T) : ValidCoverCompletion (R t) (E t) :=
    Classical.choose_spec (exists_validCoverCompletion (R t) (hc t) (hs t) hn)
  have hl : IsLocallyConstant (fun t => completionParity ref (E t) χ) := by
    apply (IsLocallyConstant.iff_eventually_eq _).mpr
    intro t
    have hp : ∀ᶠ s in nhds t, ∀ i u v, R t i u v → R s i u v := by
      simp only [Filter.eventually_all]
      intro i u v h
      exact (hopen i u v).mem_nhds h
    filter_upwards [hp] with s hst
    have hev : ValidCoverCompletion (R t) (E s) := by
      intro v i
      constructor
      · rintro ⟨w, hw⟩; exact (hE s v i).1 ⟨w, hst i v w hw⟩
      · rintro ⟨w, hw⟩; exact (hE s v i).2 ⟨w, hst i w v hw⟩
    exact completionParity_eq (R t) (hc t) (hs t) hn ref (E s) (E t) hev (hE t) χ hχ
  calc
    completionParity ref e χ = completionParity ref (E a) χ :=
      completionParity_eq (R a) (hc a) (hs a) hn ref e (E a) he (hE a) χ hχ
    _ = completionParity ref (E b) χ := hl.apply_eq_of_preconnectedSpace a b
    _ = completionParity ref f χ :=
      completionParity_eq (R b) (hc b) (hs b) hn ref (E b) f (hE b) hf χ hχ

/-- An even endpoint permutation reversing cube color contradicts one vacancy. -/
theorem no_near_saturated_even_color_reversal {V T : Type*} [Fintype V]
    [TopologicalSpace T] [PreconnectedSpace T] {k : ℕ}
    (R : T → Fin k → V → V → Prop)
    (hopen : ∀ i u v, IsOpen {t | R t i u v})
    (hc : ∀ t u v, u ≠ v → ∃ i, R t i u v ∨ R t i v u)
    (hs : ∀ t i u v w, R t i u v → R t i v w → False)
    (hn : Fintype.card V + 1 = 2 ^ k)
    (χ : CubeCode k → ℤˣ)
    (hχ : ∀ c d : CubeCode k, ∀ i, c i ≠ d i →
      (∀ j, j ≠ i → c j = d j) → χ c = -χ d)
    (τ : Equiv.Perm (CubeCode k)) (hτ : Equiv.Perm.sign τ = 1)
    (hflip : ∀ c, χ (τ c) = -χ c) (a b : T)
    (htransport : ∀ e, ValidCoverCompletion (R a) e →
      ValidCoverCompletion (R b) (e.trans τ)) : False := by
  classical
  obtain ⟨e, he⟩ := exists_validCoverCompletion (R a) (hc a) (hs a) hn
  have h := completionParity_constant R hopen hc hs hn e χ hχ a b e (e.trans τ)
    he (htransport e he)
  have heq : completionParity e (e.trans τ) χ = -completionParity e e χ := by
    unfold completionParity
    rw [Equiv.trans_assoc, Equiv.Perm.sign_trans_trans, hτ]
    simp [hflip]
  rw [heq] at h
  have hv := congrArg (fun u : ℤˣ => (u : ℤ)) h
  have hz : (completionParity e e χ : ℤ) ≠ 0 := Units.ne_zero _
  simp only [Units.val_neg] at hv
  omega

def cubeBitColor (b : Bool) : ℤˣ := if b then -1 else 1

def cubeColor {k : ℕ} (c : CubeCode k) : ℤˣ := ∏ i, cubeBitColor (c i)

def cubeComplement (k : ℕ) : Equiv.Perm (CubeCode k) :=
  { toFun := fun c i => !(c i)
    invFun := fun c i => !(c i)
    left_inv := by intro c; funext i; simp
    right_inv := by intro c; funext i; simp }

theorem cubeColor_adjacent {k : ℕ} (c d : CubeCode k) (i : Fin k)
    (hi : c i ≠ d i) (hj : ∀ j, j ≠ i → c j = d j) :
    cubeColor c = -cubeColor d := by
  have hb : cubeBitColor (c i) = -cubeBitColor (d i) := by
    cases hc : c i <;> cases hd : d i <;> simp_all [cubeBitColor]
  have hp : ∏ j ∈ Finset.univ.erase i, cubeBitColor (c j) =
      ∏ j ∈ Finset.univ.erase i, cubeBitColor (d j) := by
    apply Finset.prod_congr rfl
    intro j hj'
    rw [hj j (Finset.mem_erase.mp hj').1]
  unfold cubeColor
  rw [← Finset.mul_prod_erase _ _ (Finset.mem_univ i),
    ← Finset.mul_prod_erase _ _ (Finset.mem_univ i), hb, hp, neg_mul]

theorem cubeColor_complement {k : ℕ} (hk : Odd k) (c : CubeCode k) :
    cubeColor (cubeComplement k c) = -cubeColor c := by
  have hb (b : Bool) : cubeBitColor (!b) = -cubeBitColor b := by cases b <;> simp [cubeBitColor]
  unfold cubeColor
  simp only [cubeComplement, Equiv.coe_fn_mk, hb,
    Finset.prod_neg, Finset.card_univ, Fintype.card_fin, hk.neg_one_pow, neg_one_mul]

theorem cubeComplement_even {k : ℕ} (hk : 2 ≤ k) :
    Equiv.Perm.sign (cubeComplement k) = 1 := by
  classical
  have hsq : cubeComplement k ^ 2 = 1 := by
    apply Equiv.ext
    intro c
    funext i
    simp [pow_two, cubeComplement]
  have hempty : IsEmpty (Function.fixedPoints (cubeComplement k)) := by
    constructor
    intro c
    have h := congrFun c.property (⟨0, by omega⟩ : Fin k)
    simp [cubeComplement] at h
  let := hempty
  rw [Equiv.Perm.sign_of_pow_two_eq_one hsq,
    Fintype.card_eq_zero (α := Function.fixedPoints (cubeComplement k))]
  simp only [Nat.sub_zero, Fintype.card_fun, Fintype.card_bool, Fintype.card_fin]
  obtain ⟨m, rfl⟩ := Nat.exists_eq_add_of_le hk
  simp [show (2 : ℕ) + m = m + 2 by omega, pow_succ,
    show ∀ a : ℤˣ, a ^ (2 ^ m * 2) = (a ^ (2 ^ m)) ^ 2 from fun a => pow_mul a _ _]

/-- For an odd number of at least three relations, a connected reversal
cannot occur with exactly one unoccupied binary code. -/
theorem not_card_succ_eq_of_open_reversing_cover
    {V T : Type*} [Fintype V] [TopologicalSpace T]
    {k : ℕ} (hk : 2 ≤ k) (hodd : Odd k) (S : Set T) (hS : IsPreconnected S)
    (R : T → Fin k → V → V → Prop)
    (hopen : ∀ i u v, IsOpen {t | R t i u v})
    (hcover : ∀ t ∈ S, ∀ u v, u ≠ v → ∃ i, R t i u v ∨ R t i v u)
    (hstep : ∀ t ∈ S, ∀ i u v w, R t i u v → R t i v w → False)
    {a b : T} (ha : a ∈ S) (hb : b ∈ S)
    (hrev : ∀ i u v, R b i u v ↔ R a i v u) :
    Fintype.card V + 1 ≠ 2 ^ k := by
  classical
  intro hn
  let : PreconnectedSpace S := isPreconnected_iff_preconnectedSpace.mp hS
  let R' : S → Fin k → V → V → Prop := fun t => R t.val
  apply no_near_saturated_even_color_reversal R'
    (fun i u v => (hopen i u v).preimage continuous_subtype_val)
    (fun t => hcover t.val t.property) (fun t => hstep t.val t.property)
    hn cubeColor cubeColor_adjacent (cubeComplement k) (cubeComplement_even hk)
    (cubeColor_complement hodd) ⟨a, ha⟩ ⟨b, hb⟩
  intro e he v i
  constructor
  · rintro ⟨w, hw⟩
    have hh := (he v i).2 ⟨w, (hrev i v w).mp hw⟩
    simp [cubeComplement, hh]
  · rintro ⟨w, hw⟩
    have hh := (he v i).1 ⟨w, (hrev i w v).mp hw⟩
    simp [cubeComplement, hh]

end Prize.JSP404
