import Prize.JSP404.Sector26ArcCertificate
import Prize.JSP404.Sector26NonarcCertificate
import Mathlib.Data.Finset.Sum
import Mathlib.Data.Fintype.Sum

/-! Capacity 16 for an antipodal 26-sector assignment. The transfer from actual
Euclidean directions is a separate obligation, not an assumption hidden here. -/
namespace Prize.JSP404.FiniteCliqueCertificate.Sector26

abbrev Kind := Sector26Nonarc.Vertex ⊕ Sector26Arc.Vertex

def labels : Kind → List Sector
  | .inl i => Sector26Nonarc.labels i
  | .inr i => Sector26Arc.labels i

def kindGraph (i j : Kind) : Bool :=
  decide (i ≠ j) && (labels i).any (fun b => (labels j).contains (antipode b))

set_option maxRecDepth 65536
set_option maxHeartbeats 0

theorem types_classified : ∀ T ∈ allTypes, ∃ i : Kind, labels i = T := by
  decide +kernel

theorem kind_clique_card_le_sixteen (s : Finset Kind) (hs : Clique kindGraph s) :
    s.card ≤ 16 := by
  have hl : Clique Sector26Nonarc.graph s.toLeft := by
    intro a ha b hb hab
    have h := hs (.inl a) (Finset.mem_toLeft.mp ha) (.inl b) (Finset.mem_toLeft.mp hb)
      (fun he => hab (Sum.inl.inj he))
    rw [Sector26Nonarc.graph_correct]
    simpa [kindGraph, labels] using h
  have hr : Clique Sector26Arc.graph s.toRight := by
    intro a ha b hb hab
    have h := hs (.inr a) (Finset.mem_toRight.mp ha) (.inr b) (Finset.mem_toRight.mp hb)
      (fun he => hab (Sum.inr.inj he))
    rw [Sector26Arc.graph_correct]
    simpa [kindGraph, labels] using h
  have h₁ := Sector26Nonarc.clique_card_le_eight _ hl
  have h₂ := Sector26Arc.clique_card_le_eight _ hr
  have hcard := s.card_toLeft_add_card_toRight
  omega

theorem card_le_sixteen_of_sector_assignment {V : Type*} [Fintype V]
    (q : V → V → Sector)
    (hrev : ∀ u v, u ≠ v → q v u = antipode (q u v))
    (hsmall : ∀ v u w, v ≠ u → v ≠ w → u ≠ w →
      circularDistance (q v u) (q v w) ≤ 10) : Fintype.card V ≤ 16 := by
  classical
  let outgoing (v : V) : Finset Sector := (Finset.univ.erase v).image (q v)
  have ho (v : V) : Clique sectorGraph (outgoing v) := by
    intro a ha b hb hab
    obtain ⟨u, hu, rfl⟩ := Finset.mem_image.mp ha
    obtain ⟨w, hw, rfl⟩ := Finset.mem_image.mp hb
    have huv : u ≠ v := (Finset.mem_erase.mp hu).1
    have hwv : w ≠ v := (Finset.mem_erase.mp hw).1
    have huw : u ≠ w := fun he => hab (congrArg (q v) he)
    simpa [sectorGraph, hab] using hsmall v u w (Ne.symm huv) hwv.symm huw
  have hex (v : V) : ∃ i : Kind, labels i ∈ allTypes ∧
      ∀ w, w ≠ v → q v w ∈ labels i := by
    obtain ⟨T, hT, hc⟩ := allTypes_cover (outgoing v) (by simp) (ho v)
    obtain ⟨i, hi⟩ := types_classified T hT
    refine ⟨i, hi ▸ hT, ?_⟩
    intro w hw
    rw [hi]
    exact hc _ (Finset.mem_image.mpr ⟨w, by simp [hw], rfl⟩)
  let t : V → Kind := fun v => Classical.choose (hex v)
  have ht (v : V) : labels (t v) ∈ allTypes ∧ ∀ w, w ≠ v → q v w ∈ labels (t v) :=
    Classical.choose_spec (hex v)
  have hi : Function.Injective t := by
    intro u v he
    by_contra huv
    have h₁ := (ht u).2 v (Ne.symm huv)
    have h₂ := (ht v).2 u huv
    rw [hrev u v huv, ← he] at h₂
    exact allTypes_no_antipodes _ (ht u).1 _ h₁ h₂
  let s : Finset Kind := Finset.univ.image t
  have hs : Clique kindGraph s := by
    intro a ha b hb hab
    obtain ⟨u, hu, rfl⟩ := Finset.mem_image.mp ha
    obtain ⟨v, hv, rfl⟩ := Finset.mem_image.mp hb
    have huv : u ≠ v := fun he => hab (congrArg t he)
    have h₁ := (ht u).2 v (Ne.symm huv)
    have h₂ := (ht v).2 u huv
    rw [hrev u v huv] at h₂
    simp only [kindGraph, ne_eq, hab, not_false_eq_true, decide_true, Bool.true_and,
      List.any_eq_true]
    exact ⟨q u v, h₁, by simpa using h₂⟩
  have hc : s.card = Fintype.card V := by
    simpa [s] using Finset.card_image_of_injective (Finset.univ : Finset V) hi
  rw [← hc]
  exact kind_clique_card_le_sixteen s hs

end Prize.JSP404.FiniteCliqueCertificate.Sector26
