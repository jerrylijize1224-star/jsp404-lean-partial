import Prize.JSP404.NearSaturatedParity
import Prize.JSP404.DyadicSharp

/-!
Sharp values one below an odd binary exponent, via the vacancy parity argument.
The mathematical values are a subfamily of the classical Erdős–Szekeres result,
not a new mathematical discovery or a claim of first formalization. This local
argument uses our rotating sector cover and does not import the finite 9/11-point
certificates. It does not establish Sendov's full classification.
-/
namespace Prize.JSP404
open InnerProductGeometry

theorem GeneralizedDirections.card_add_one_ne_two_pow_of_strict_angle_odd
    {V : Type*} [Fintype V] [Nonempty V] (D : GeneralizedDirections V)
    {k : ℕ} (hk : 2 ≤ k) (hodd : Odd k) {a : ℝ} (ha : 0 ≤ a)
    (halt : a < Real.pi - Real.pi / k) (hbound : D.AngleBound a) :
    Fintype.card V + 1 ≠ 2 ^ k := by
  let r : ℝ := ((Real.pi / k) + (Real.pi - a)) / 4
  have hr : Real.pi / k / 2 < r := by dsimp [r]; linarith
  have hrw : 2 * r < Real.pi - a := by dsimp [r]; linarith
  let axis : ℝ → Fin k → Plane := fun t i => unitDirection (t + (Real.pi / k) * (i.val + 1 / 2 : ℝ))
  let R : ℝ → Fin k → V → V → Prop := fun t i u v =>
    u ≠ v ∧ angle (D.direction u v) (axis t i) < r
  apply not_card_succ_eq_of_open_reversing_cover hk hodd (Set.Icc 0 Real.pi)
    isPreconnected_Icc R ?_ ?_ ?_ (a := 0) (b := Real.pi)
    ⟨le_rfl, Real.pi_pos.le⟩ ⟨Real.pi_pos.le, le_rfl⟩ ?_
  · intro i u v
    by_cases huv : u = v
    · simp [R, huv]
    · have hc : Continuous (fun t => angle (D.direction u v) (axis t i)) :=
        (continuous_angle_unitDirection (D.nonzero u v huv)).comp (by fun_prop)
      simpa only [R, Ne, huv, not_false_eq_true, true_and] using
        (isOpen_lt hc continuous_const)
  · intro t ht u v huv
    obtain ⟨i, hi⟩ := exists_rotating_open_sector (by omega : 0 < k) hr ht.1 ht.2 (D.nonzero u v huv)
    refine ⟨i, ?_⟩
    rcases hi with hi | hi
    · exact Or.inl ⟨huv, hi⟩
    · exact Or.inr ⟨huv.symm, by simpa only [D.reverse u v] using hi⟩
  · intro t ht i u v w huv hvw
    have ht' := angle_le_angle_add_angle (D.direction u v) (axis t i) (D.direction v w)
    rw [angle_comm (axis t i) (D.direction v w)] at ht'
    have hsmall : angle (D.direction u v) (D.direction v w) < Real.pi - a := by
      linarith [huv.2, hvw.2]
    have hlarge : a < D.tripleAngle u v w := by
      unfold GeneralizedDirections.tripleAngle
      rw [D.reverse u v, angle_neg_left]
      linarith
    by_cases huw : u = w
    · subst w
      have hz : D.tripleAngle u v u = 0 := angle_self (D.nonzero v u huv.1.symm)
      linarith
    · exact (not_lt_of_ge (hbound u v w huv.1 huw hvw.1)) hlarge
  · intro i u v
    have he : axis Real.pi i = -axis 0 i := by
      dsimp [axis]
      rw [show Real.pi + Real.pi / k * (i.val + 1 / 2 : ℝ) =
        (0 + Real.pi / k * (i.val + 1 / 2 : ℝ)) + Real.pi by ring,
        unitDirection_add_pi]
    dsimp [R]
    rw [he, D.reverse u v, angle_neg_left, angle_neg_right]
    exact and_congr ne_comm Iff.rfl


theorem GeneralizedDirections.exists_angle_ge_odd_pred_bound
    {V : Type*} [Fintype V] (D : GeneralizedDirections V)
    {k : ℕ} (hk : 2 ≤ k) (hodd : Odd k) (hV : Fintype.card V + 1 = 2 ^ k) :
    ∃ i j l : V, i ≠ j ∧ i ≠ l ∧ j ≠ l ∧
      Real.pi - Real.pi / k ≤ D.tripleAngle i j l := by
  have hfour : 4 ≤ (2 : ℕ) ^ k := by
    calc
      4 = (2 : ℕ) ^ 2 := by norm_num
      _ ≤ 2 ^ k := pow_le_pow_right₀ (by decide) hk
  have : Nonempty (DirectionTriple V) := directionTriple_nonempty (by omega)
  obtain ⟨t, ht⟩ := exists_maximumAssignmentAngle D.normalizedAssignment
  have : Nonempty V := ⟨t.val.1⟩
  let a : ℝ := maximumAssignmentAngle D.normalizedAssignment
  have he : a = D.tripleAngle t.val.1 t.val.2.1 t.val.2.2 := by
    exact ht.trans (D.normalizedAssignment_angle t)
  have ha : 0 ≤ a := by rw [he]; exact InnerProductGeometry.angle_nonneg _ _
  have hb : D.AngleBound a := by
    intro i j l hij hil hjl
    have h := assignmentTripleAngle_le_maximum D.normalizedAssignment ⟨(i, j, l), hij, hil, hjl⟩
    rw [D.normalizedAssignment_angle ⟨(i, j, l), hij, hil, hjl⟩] at h
    exact h
  have hl : Real.pi - Real.pi / k ≤ a := by
    by_contra h
    exact D.card_add_one_ne_two_pow_of_strict_angle_odd hk hodd ha (lt_of_not_ge h) hb hV
  exact ⟨t.val.1, t.val.2.1, t.val.2.2, t.property.1, t.property.2.1,
    t.property.2.2, he ▸ hl⟩

theorem guaranteedAngle_odd_pred_bound {k N : ℕ} (hk : 2 ≤ k) (hodd : Odd k) (hN : N + 1 = 2 ^ k) :
    GuaranteedAngle N ((1 - 1 / (k : ℝ)) * Real.pi) := by
  intro s hs
  let D : GeneralizedDirections s := {
    direction := fun u v => (v : Plane) - u
    reverse := fun u v => by abel
    nonzero := fun u v huv => sub_ne_zero.mpr (fun h => huv (Subtype.ext h.symm)) }
  obtain ⟨i, j, l, hij, hil, hjl, ha⟩ := D.exists_angle_ge_odd_pred_bound hk hodd (by simpa [hs] using hN)
  refine ⟨i, i.property, j, j.property, l, l.property,
    (fun h => hij (Subtype.ext h)), (fun h => hil (Subtype.ext h)),
    (fun h => hjl (Subtype.ext h)), ?_⟩
  have he : (1 - 1 / (k : ℝ)) * Real.pi = Real.pi - Real.pi / k := by ring
  rw [he]
  exact ha

/-- Exact ordinary values for the infinite subfamily 2^k-1 with odd k≥3. -/
theorem odd_dyadic_pred_isSharpBound {k : ℕ} (hk : 2 ≤ k) (hodd : Odd k) :
    IsSharpBound (2 ^ k - 1) ((1 - 1 / (k : ℝ)) * Real.pi) := by
  have hkR : (0 : ℝ) < k := by exact_mod_cast (show 0 < k by omega)
  have hk1 : (1 : ℝ) ≤ k := by exact_mod_cast (show 1 ≤ k by omega)
  have hi : 1 / (k : ℝ) ≤ 1 := (div_le_one hkR).mpr hk1
  refine ⟨mul_nonneg (by linarith) Real.pi_pos.le,
    by nlinarith [div_pos (by norm_num : (0 : ℝ) < 1) hkR, Real.pi_pos],
    guaranteedAngle_odd_pred_bound hk hodd ?_, ?_⟩
  · apply Nat.sub_add_cancel
    have hpos : 0 < (2 : ℕ) ^ k := by positivity
    omega
  · intro b hb
    exact dyadic_not_guaranteed hk (Nat.sub_le _ _) hb

theorem alpha_odd_dyadic_pred {k : ℕ} (hk : 2 ≤ k) (hodd : Odd k) :
    alpha (2 ^ k - 1) = (1 - 1 / (k : ℝ)) * Real.pi :=
  (odd_dyadic_pred_isSharpBound hk hodd).alpha_eq

theorem alpha_thirty_one : alpha 31 = (4 / 5 : ℝ) * Real.pi := by
  have h := alpha_odd_dyadic_pred (k := 5) (by decide) (by decide)
  norm_num at h ⊢
  exact h

theorem alpha_one_twenty_seven : alpha 127 = (6 / 7 : ℝ) * Real.pi := by
  have h := alpha_odd_dyadic_pred (k := 7) (by decide) (by decide)
  norm_num at h ⊢
  exact h

end Prize.JSP404
