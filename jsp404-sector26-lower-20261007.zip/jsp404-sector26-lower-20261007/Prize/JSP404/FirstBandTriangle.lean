import Prize.JSP404.FirstBandAxes

/-! Actual centre coordinates and mixed-angle certificates for the first-band
three-cluster plan. Assembly of the differently sized binary label sets is
separate from these geometric results. -/

namespace Prize.JSP404

noncomputable def firstBandCentre (n : ℕ) : Fin 3 → Plane :=
  ![!₂[-Real.cos (firstBandStep n), 0], !₂[Real.cos (firstBandStep n), 0],
    !₂[0, Real.sin (firstBandStep n)]]

def firstBandEdgeSign (i j : Fin 3) : Bool := decide (j < i)

noncomputable def firstBandEdgeScale (n : ℕ) (i j : Fin 3) : ℝ :=
  if i = j then 0 else if (i = 0 ∧ j = 1) ∨ (i = 1 ∧ j = 0)
    then 2 * Real.cos (firstBandStep n) else 1

theorem firstBandStep_cos_pos (n : ℕ) : 0 < Real.cos (firstBandStep n) := by
  have hd := firstBandStep_pos n
  have hs := firstBandStep_small n
  apply Real.cos_pos_of_mem_Ioo
  constructor <;> linarith [Real.pi_pos]

theorem firstBandEdgeScale_pos (n : ℕ) (i j : Fin 3) (hij : i ≠ j) :
    0 < firstBandEdgeScale n i j := by
  unfold firstBandEdgeScale
  rw [ite_eq_right hij]
  split_ifs
  · exact mul_pos (by norm_num) (firstBandStep_cos_pos n)
  · norm_num

theorem firstBandCentre_difference (n : ℕ) (i j : Fin 3) :
    firstBandCentre n j - firstBandCentre n i = firstBandEdgeScale n i j •
      signedBinaryAxis (circleDirection (firstBandEdgeAngle n i j)) (firstBandEdgeSign i j) := by
  fin_cases i <;> fin_cases j <;> ext r <;> fin_cases r <;>
    norm_num [firstBandCentre, firstBandEdgeScale, firstBandEdgeAngle, firstBandEdgeSign,
      signedBinaryAxis, circleDirection, Real.cos_pi_sub, Real.sin_pi_sub] <;> ring

theorem firstBandCentre_injective (n : ℕ) : Function.Injective (firstBandCentre n) := by
  intro i j he
  by_contra hij
  have hzero : firstBandCentre n j - firstBandCentre n i = 0 := sub_eq_zero.mpr he.symm
  rw [firstBandCentre_difference] at hzero
  exact (smul_ne_zero (ne_of_gt (firstBandEdgeScale_pos n i j hij))
    (signedBinaryAxis_ne_zero (circleDirection_nonzero _) _)) hzero

theorem firstBandAxis_centre_angle (n : ℕ) (i j : Fin 3) (hij : i ≠ j)
    (r : Fin (firstBandDepth n i)) (b : Bool) :
    InnerProductGeometry.angle (signedBinaryAxis (firstBandAxis n i r) b)
      (firstBandCentre n j - firstBandCentre n i) ≤ Real.pi - 2 * firstBandStep n := by
  rw [firstBandCentre_difference,
    InnerProductGeometry.angle_smul_right_of_pos _ _ (firstBandEdgeScale_pos n i j hij)]
  exact firstBandAxis_edge_angle n i j hij r b _

set_option maxHeartbeats 1000000 in
theorem firstBandCentre_angle (n : ℕ) (i j k : Fin 3) (hji : j ≠ i) (hjk : j ≠ k) :
    InnerProductGeometry.angle (firstBandCentre n i - firstBandCentre n j)
      (firstBandCentre n k - firstBandCentre n j) ≤ Real.pi - 2 * firstBandStep n := by
  have hd := firstBandStep_pos n
  have hs := firstBandStep_small n
  have hself (a : ℝ) : InnerProductGeometry.angle (circleDirection a) (circleDirection a) = 0 :=
    InnerProductGeometry.angle_self (circleDirection_nonzero a)
  have h0d : InnerProductGeometry.angle (circleDirection 0) (circleDirection (firstBandStep n)) =
      firstBandStep n := by
    simpa using circleDirection_angle (show 0 ≤ firstBandStep n by linarith)
      (show firstBandStep n - 0 ≤ Real.pi by linarith)
  have h0p : InnerProductGeometry.angle (circleDirection 0)
      (circleDirection (Real.pi - firstBandStep n)) = Real.pi - firstBandStep n := by
    simpa using circleDirection_angle (show 0 ≤ Real.pi - firstBandStep n by linarith)
      (show Real.pi - firstBandStep n - 0 ≤ Real.pi by linarith)
  have hdp : InnerProductGeometry.angle (circleDirection (firstBandStep n))
      (circleDirection (Real.pi - firstBandStep n)) = Real.pi - 2 * firstBandStep n := by
    rw [circleDirection_angle (by linarith) (by linarith)]
    ring
  have hd0 := h0d
  rw [InnerProductGeometry.angle_comm] at hd0
  have hp0 := h0p
  rw [InnerProductGeometry.angle_comm] at hp0
  have hpd := hdp
  rw [InnerProductGeometry.angle_comm] at hpd
  rw [firstBandCentre_difference, firstBandCentre_difference,
    InnerProductGeometry.angle_smul_left_of_pos _ _ (firstBandEdgeScale_pos n j i hji),
    InnerProductGeometry.angle_smul_right_of_pos _ _ (firstBandEdgeScale_pos n j k hjk)]
  fin_cases i <;> fin_cases j <;> fin_cases k <;> norm_num at hji <;> norm_num at hjk
  all_goals simp [firstBandEdgeAngle, firstBandEdgeSign, signedBinaryAxis,
    InnerProductGeometry.angle_neg_left, InnerProductGeometry.angle_neg_right,
    hself, h0d, h0p, hdp, hd0, hp0, hpd]
  all_goals linarith

end Prize.JSP404
