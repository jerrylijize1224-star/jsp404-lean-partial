import Prize.JSP404.WeightedDirectionCover
import Prize.JSP404.RotatingSectorCover

/-! Actual rotating covers satisfy a weighted Boolean-capacity bound.
No lower estimate of the total geometric deficit is assumed or proved. -/
namespace Prize.JSP404
open InnerProductGeometry
open scoped Classical

/-- A relation is unused at a vertex for some parameter during reversal.
The parameter may depend on both the vertex and the relation. -/
theorem exists_unused_relation_of_open_reversal
    {V T : Type*} [TopologicalSpace T] {k : ℕ}
    (S : Set T) (hS : IsPreconnected S) (R : T → Fin k → V → V → Prop)
    (hopen : ∀ i u v, IsOpen {t | R t i u v})
    (hstep : ∀ t ∈ S, ∀ i u v w, R t i u v → R t i v w → False)
    {a b : T} (ha : a ∈ S) (hb : b ∈ S)
    (hrev : ∀ i u v, R b i u v ↔ R a i v u) (i : Fin k) (u : V) :
    ∃ t ∈ S, i ∈ freeCoverIndices (R t) u := by
  classical
  by_contra hn
  let A : Set T := {t | ∃ v, R t i u v}
  let B : Set T := {t | ∃ v, R t i v u}
  have hA : IsOpen A := by
    simpa only [A, Set.ofPred_exists] using isOpen_iUnion (fun v => hopen i u v)
  have hB : IsOpen B := by
    simpa only [B, Set.ofPred_exists] using isOpen_iUnion (fun v => hopen i v u)
  have hab : S ⊆ A ∪ B := by
    intro t ht
    by_contra h
    apply hn
    refine ⟨t, ht, ?_⟩
    simp only [freeCoverIndices, Finset.mem_filter, Finset.mem_univ, true_and]
    exact ⟨fun ho => h (Or.inl ho), fun hi => h (Or.inr hi)⟩
  have hd : S ∩ (A ∩ B) = ∅ := by
    apply Set.eq_empty_iff_forall_notMem.mpr
    rintro t ⟨ht, ⟨v, hv⟩, ⟨w, hw⟩⟩
    exact hstep t ht i w u v hw hv
  have hr : (a ∈ A ↔ b ∈ B) ∧ (a ∈ B ↔ b ∈ A) := by
    dsimp [A, B]
    simp only [hrev, iff_self, and_self]
  have hc := hS A B hA hB hab
  rcases hab ha with h | h
  · have hx := hc ⟨a, ha, h⟩ ⟨b, hb, hr.1.mp h⟩
    rw [hd] at hx
    exact Set.not_nonempty_empty hx
  · have hx := hc ⟨b, hb, hr.2.mp h⟩ ⟨a, ha, h⟩
    rw [hd] at hx
    exact Set.not_nonempty_empty hx

namespace GeneralizedDirections
variable {V : Type*} (D : GeneralizedDirections V)

noncomputable def rotatingRelation (k : ℕ) (r t : ℝ) (i : Fin k) (u v : V) : Prop :=
  u ≠ v ∧ angle (D.direction u v)
    (unitDirection (t + (Real.pi / k) * (i.val + 1 / 2 : ℝ))) < r

theorem rotatingRelation_open (k : ℕ) (r : ℝ) (i : Fin k) (u v : V) :
    IsOpen {t | D.rotatingRelation k r t i u v} := by
  by_cases huv : u = v
  · simp [rotatingRelation, huv]
  · have hc : Continuous (fun t => angle (D.direction u v)
        (unitDirection (t + (Real.pi / k) * (i.val + 1 / 2 : ℝ)))) :=
      (continuous_angle_unitDirection (D.nonzero u v huv)).comp (by fun_prop)
    simpa only [rotatingRelation, Ne, huv, not_false_eq_true, true_and] using
      isOpen_lt hc continuous_const

theorem rotatingRelation_reverse (k : ℕ) (r : ℝ) (i : Fin k) (u v : V) :
    D.rotatingRelation k r Real.pi i u v ↔ D.rotatingRelation k r 0 i v u := by
  unfold rotatingRelation
  rw [show Real.pi + Real.pi / k * (i.val + 1 / 2 : ℝ) =
    (0 + Real.pi / k * (i.val + 1 / 2 : ℝ)) + Real.pi by ring,
    unitDirection_add_pi, D.reverse u v, angle_neg_left, angle_neg_right]
  exact and_congr ne_comm Iff.rfl

theorem rotatingRelation_no_two_step {k : ℕ} {a r : ℝ}
    (ha : 0 ≤ a) (hr : 2 * r < Real.pi - a) (hb : D.AngleBound a)
    (t : ℝ) (i : Fin k) (u v w : V)
    (huv : D.rotatingRelation k r t i u v) (hvw : D.rotatingRelation k r t i v w) : False := by
  have ht := angle_le_angle_add_angle (D.direction u v)
    (unitDirection (t + (Real.pi / k) * (i.val + 1 / 2 : ℝ))) (D.direction v w)
  rw [angle_comm (unitDirection (t + (Real.pi / k) * (i.val + 1 / 2 : ℝ)))
    (D.direction v w)] at ht
  have hsmall : angle (D.direction u v) (D.direction v w) < Real.pi - a := by
    linarith [huv.2, hvw.2]
  have hlarge : a < D.tripleAngle u v w := by
    unfold tripleAngle
    rw [D.reverse u v, angle_neg_left]
    linarith
  by_cases huw : u = w
  · subst w
    have hz : D.tripleAngle u v u = 0 := angle_self (D.nonzero v u huv.1.symm)
    linarith
  · exact (not_lt_of_ge (hb u v w huv.1 huw hvw.1)) hlarge

theorem rotatingRelation_cover {k : ℕ} (hk : 0 < k) {r t : ℝ}
    (hr : Real.pi / k / 2 < r) (ht : t ∈ Set.Icc 0 Real.pi)
    (u v : V) (huv : u ≠ v) :
    ∃ i, D.rotatingRelation k r t i u v ∨ D.rotatingRelation k r t i v u := by
  obtain ⟨i, hi⟩ := exists_rotating_open_sector hk hr ht.1 ht.2 (D.nonzero u v huv)
  refine ⟨i, ?_⟩
  rcases hi with hi | hi
  · exact Or.inl ⟨huv, hi⟩
  · exact Or.inr ⟨huv.symm, by simpa only [D.reverse u v] using hi⟩

theorem rotating_weighted_capacity [Fintype V] {k : ℕ} (hk : 0 < k) {a r t : ℝ}
    (ha : 0 ≤ a) (hlo : Real.pi / k / 2 < r) (hhi : 2 * r < Real.pi - a)
    (hb : D.AngleBound a) (ht : t ∈ Set.Icc 0 Real.pi) :
    ∑ v : V, 2 ^ (freeCoverIndices (D.rotatingRelation k r t) v).card ≤ 2 ^ k :=
  weighted_card_le_two_pow_of_no_two_step_cover _ (D.rotatingRelation_cover hk hlo ht)
    (D.rotatingRelation_no_two_step ha hhi hb t)

/-- Each chosen vertex and sector has an unused position. This does not
assert a single position making all vertices or sectors unused together. -/
theorem exists_rotating_unused {k : ℕ} {a r : ℝ}
    (ha : 0 ≤ a) (hr : 2 * r < Real.pi - a) (hb : D.AngleBound a)
    (i : Fin k) (u : V) :
    ∃ t ∈ Set.Icc 0 Real.pi, i ∈ freeCoverIndices (D.rotatingRelation k r t) u := by
  apply exists_unused_relation_of_open_reversal (Set.Icc 0 Real.pi) isPreconnected_Icc
    (D.rotatingRelation k r) (D.rotatingRelation_open k r)
    (fun t _ => D.rotatingRelation_no_two_step ha hr hb t)
    (a := 0) (b := Real.pi) ⟨le_rfl, Real.pi_pos.le⟩ ⟨Real.pi_pos.le, le_rfl⟩
    (D.rotatingRelation_reverse k r) i u

end GeneralizedDirections
end Prize.JSP404
