# 九点与十点精确值：引用证书并连接本项目目标

日期：2026-10-04（来源核对始于 2026-09-30）。完整构建已通过（2768 项含依赖）；373 项公理审计全部通过，实际依赖仅为 propext、Classical.choice、Quot.sound。记录见本轮构建、公理日志和发布记录。

## 目标与引用来源

本轮集中处理 alpha 9 = alpha 10 = 5π/7，即约 128.571428571°。
该值是经典结果；本项目此前已有上界，但尚未补齐九点下界。

[PR #100](https://github.com/TheJustinSunPrize/awards/pull/100) 的作者 zilan520
公开了九点下界的 Lean 证书和从普通平面点集到方向模型的严格转移。
本轮固定到 [提交 d869ab901722fab0b2d980b38b7bd958cf52c128](https://github.com/zilan520/awards/tree/d869ab901722fab0b2d980b38b7bd958cf52c128/submissions/jsp-000404-five-point/lean434-nine)。
引用的证书及几何转移按原样使用，不作为本项目独立证明或原创成果。
该提交的说明将其工作标为借助 Codex 完成；底层经典数学归属原作者。

## 最小引用范围

从 `lean434-nine` 取 56 个模块，排除对方的最终上下界整合模块
`NinePointExactTrial.lean`；从相邻 `lean434` 取
`SendovFiveDirections`、`SendovDirectionGeometry` 和 `SendovDirectionModel`。
总计 59 个未改写的外部 Lean 文件。它们均仅依赖这组文件及本项目相同版本的 mathlib。
本轮不引用对方基于 PR #42 的上界包，也不以其 alpha 定义替换本项目定义。

文件保存在忽略目录 `.lake/external/jsp404-nine-certificate`，不提交或捆绑第三方源码。
`jsp404-nine-source-lock.json` 记录公开仓库、固定提交及每个文件的 SHA-256。
`prepare_nine_certificate.py` 只提取锁定源码、逐文件核验并生成本地 Lake 配置，
不运行下载的脚本。配置要求 `--trust=0`，每个 Lean 进程用一个工作线程。
`build_nine_certificate.py` 提供分阶段顺序构建，避免一次启动几十个大模块。
没有把求解器、外部声称的验证日志或预编译证书当成可信证明。

## 本项目的连接

`NineTenExact.lean` 直接使用本项目的 `Plane`、`HasLargeAngle`、
`GuaranteedAngle`、`alpha` 和 `IsSharpBound`。

1. 任意九点有限集有最大三点角 A。
2. 假设 A<5π/7，则 λ=π−A>0 且 t=π/λ<7/2。
3. 外部几何转移从这九个实际点构造 `SendovDirectionModel.Model 9 t`。
   该转移不要求凸性或一般位置。
4. 外部 `NineModelTrial.model_nine_lower` 给出 t≥7/2，矛盾。
5. 九点下界通过基数单调性适用于十点。
6. 本项目已经验证的第一分段十点逼近构造给出尖锐上界。

已得到普通点集的保证角、完整 `IsSharpBound` 和两个 alpha 等式。
本地贡献为固定来源复核、重新编译、命题连接和重现流程；不是独立生成九点证书。

## 检索与剩余范围

本轮定向读取了 PR #100 当前说明及固定提交源码，没有做全面新颖性或优先权检索。
浏览工具读取 PR 超时后，通过 GitHub 公开 API 取得同一 PR 元数据与文件清单。
原论文与其他公开提交的既有访问范围见本项目其他来源笔记。

任意点数的完整 Sendov 分类仍未证明，十七点当前上下界也不会因此改善。
