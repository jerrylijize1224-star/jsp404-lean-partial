# Explicit non-sharp lower bound from an empty phase bin

Date: 2026-09-28. Full project build and axiom audit passed.

## Mathematical statement

For k > 0 and N > 2^k, the proved inequality is

    alpha N >= (1 - 1/k)*pi + pi / (k*(N^2 + 1)).

Monotonicity permits replacing N in the denominator by 2^k+1, giving a
single explicit positive margin for every cardinality above the threshold.
For k=4 and N=17 this is 871*pi/1160, or 135 + 9/58 degrees
(approximately 135.155172 degrees). The established upper bound is 140 degrees.
The exact value at 17 and the matching general lower bounds remain unproved.

## Proof mechanism

1. For M real phases modulo 1, divide [0,1) into M+1 half-open bins.
   The finite pigeonhole principle gives an empty bin [beta-epsilon,beta),
   where epsilon=1/(M+1) and epsilon <= beta <= 1.
2. Give every nonzero direction a projective angle theta in [0,pi).
   Apply the empty-bin lemma to theta/(pi/k). Start the projective partition
   at (pi/k)*beta. Each occupied sector has parameter range
   [i,i+1-epsilon), so any two directions in it have angular distance
   strictly less than (pi/k)*(1-epsilon). Endpoint cases are retained.
3. For an antisymmetric direction assignment on N labels, index the family
   by all N^2 ordered pairs. Use a fixed unit direction on each diagonal.
   The dummy entries only make the bound weaker; they impose no hypothesis
   on the assignment. The existing binary-cover theorem implies that an
   angle cap pi-(pi/k)*(1-epsilon) forces N <= 2^k.
4. Apply the contrapositive to actual point differences, then pass to the
   original supremum definition of alpha. No cluster assumption or
   realization theorem is needed.

## Files and scope

- `FinitePeriodicGap.lean`: empty bin and periodic interval shortening.
- `QuantitativeSectorCover.lean`: a common finite cover by shortened sectors.
- `QuantitativeLowerBound.lean`: counting, ordinary configurations, explicit
  alpha bounds, and the seventeen-point specialization.

These are auxiliary non-sharp bounds. `SendovClaim` remains an unproved
`Prop`; the original target has not been weakened or replaced. Exact values
are still established only for N=3 through N=8.

## Sources and contribution

The underlying direction-sector and binary counting argument follows
Sendov, *Minimax of the angles in a plane configuration of points*,
Acta Mathematica Hungarica 69 (1995), 27–46, especially Section 3, pp. 33–34,
DOI https://doi.org/10.1007/BF01874605. The full English paper is available
from the public collection https://real-j.mtak.hu/7467/ and has been read
locally. The strict threshold inequality is already discussed in its
introduction; see the earlier strict-lower note for the precise distinction.

The present development supplies a concrete empty-bin refinement and its
Lean formalization. No claim that this numerical estimate is new mathematics
is made. No fresh exhaustive literature or competing-repository search was
performed in this step; existing source-access and search limits still apply.

## Verification

`./scripts/lake.sh build` succeeded (2589 jobs, including dependencies), followed
by `./scripts/lake.sh env lean Prize/Audit.lean` with exit status 0. All 320
audited declarations match the audit log. The twelve new theorems each depend
only on `propext`, `Classical.choice`, and `Quot.sound`. No proof placeholders,
new axioms, or unchecked proof shortcuts are used. This is local verification,
not an independent external review or fresh-machine rebuild.
