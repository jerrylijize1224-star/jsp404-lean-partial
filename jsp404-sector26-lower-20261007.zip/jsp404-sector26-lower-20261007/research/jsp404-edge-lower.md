# One representative per unordered edge

Date: 2026-09-29. Full build and axiom audit passed.

## Statement and scope

For k > 0 and N > 2^k, the improved bound is

    alpha N >= (1-1/k)*pi + pi / (k*(choose(N,2)+1)).

Monotonicity again permits replacing N on the right by 2^k+1 for every
larger cardinality. For seventeen points, this yields 103*pi/137, equivalently
135+45/137 degrees (approximately 135.328467 degrees). The upper bound is
still 140 degrees. This does not prove the exact seventeen-point value or
the sharp general lower bound in SendovClaim.

The previous estimate used N^2 direction entries, including both orientations
of each pair and dummy diagonal directions. Projective sectors cover a vector
up to sign, so only choose(N,2) nonzero entries are needed. This strictly
improves the previous numerical bound for every positive k and N; it does
not resolve the principal sharp-counting difficulty.

## Verified interfaces

`EdgeDirectionLowerBound.lean` provides:

- `GeneralizedDirections.card_le_of_representatives`: any finite nonempty
  nonzero direction family representing every edge up to sign can be used.
  Its size, rather than the square of the vertex count, controls the margin.
- `increasingPairs_card` and `increasingPairs_nonempty`: a finite linear order
  selects exactly one orientation of each unordered edge. The order is only
  on labels and imposes no geometric or general-position assumption.
- `GeneralizedDirections.card_le_two_pow_of_edge_angle`: the improved
  representative family feeds into the existing shortened-sector proof.
- `guaranteedAngle_edge`, `edge_alpha_lower`, `edge_alpha_lower_uniform`:
  ordinary finite point sets are labelled by Fin N, all directions are actual
  nonzero differences, and the lower bound uses the original alpha definition.
- `representativeAngle_strictAnti` and `quantitativeAngle_lt_edgeAngle`:
  a formal comparison with the previously published explicit bound.
- `alpha_seventeen_edge_bounds`: the stated seventeen-point interval.

No theorem claims that arbitrary abstract direction data can be realized by
ordinary points. No premise has been added to SendovClaim. Its definition
remains an unproved Prop, and exact values remain verified only for N=3 to 8.

## Attribution and search limits

This is a refinement of the finite-phase proof documented in
`jsp404-quantitative-lower.md`. The underlying sector/binary-counting method
comes from Sendov, *Minimax of the angles in a plane configuration of points*,
Acta Mathematica Hungarica 69 (1995), 27–46, Section 3, pp. 33–34,
DOI https://doi.org/10.1007/BF01874605. The full paper has been read locally
from https://real-j.mtak.hu/7467/; no purchase or new source access was needed.

Mathlib supplies the exact cardinality of strictly ordered pairs and the
binomial coefficient bounds. The contribution here is this local Lean
integration and explicit comparison. There was no fresh exhaustive literature
or competing-repository search in this step, and no mathematical novelty,
first-formalization, priority, or award-completion claim is made.

## Verification

The required full build succeeded (2590 jobs including dependencies), followed
by the axiom audit with exit status 0. All 332 requested declarations match the
audit log. Each of the twelve new theorems depends only on `propext`,
`Classical.choice`, and `Quot.sound`. The original target file is byte-for-byte
unchanged from the preceding published snapshot. No proof placeholders, new
axioms, or unchecked proof shortcuts are used. This is local verification,
not an independent external review or a fresh-machine rebuild.
