# 26 扇区证书：17 点的已验证数值下界

日期：2026-10-07。

## 结论和边界

在本项目原始普通平面点集定义下，已经证明：

    N ≥ 17 → GuaranteedAngle N (10π/13)
    N ≥ 17 → (10/13)π ≤ alpha N
    (10/13)π ≤ alpha 17 ≤ (7/9)π

即 **138.461538…°≤alpha 17≤140°**。此前已验证下界为
(103/137)π≈135.328467°；本次把区间宽度从 640/137°≈4.671533°
缩至 **20/13°≈1.538462°**。
这是精确有理倍数的下界提升，不是 alpha 17 精确值的证明。
适用于任意有限点集，不增加凸性、一般位置或可实现性前提。
完整 `SendovClaim` 仍是未证明的命题定义。

## 证明链

1. 假设所有三点角都严格小于 10π/13。每个非零有向差向量用
   `floor(13*arg(z)/π) mod 26` 编号。反向编号恰好相差 13；
   同一顶点出发的任意两个方向，其编号循环距离至多 10。
   取整边界和跨越 ±π 的情况也在 Lean 中处理。
2. 在 26 个编号上建立循环距离至多 10 的图。
   每个顶点的全部出方向构成此图的团。
   一个含 491 个节点的覆盖证书证明每个这样的团都包含在列出的
   156 个类型之一中；不是信任外部程序报告的穷尽性。
3. 这 156 个类型分为 26 个弧型和 130 个非弧型。
   不同点的类型必须满足反向相容性；任何一个类型不能同时包含互为反向的编号，
   因而不同点不能分配到同一类型。点集便注入类型的相容图中的一个团。
4. 每族的团都至多含 8 个类型。证明利用循环旋转的图自同构：
   弧型只有一个顶点轨道；非弧型有五个代表。
   每个代表的邻居图中，分支和着色证书排除 8 团，故原图排除 9 团。
   检查器可靠性是一般 Lean 定理；具体检查通过 `decide +kernel` 完成。
   两族合起来至多容纳 16 个点，与 N≥17 矛盾。
5. mathlib 的实平面与复平面线性等距同构保角，将该结论接回
   `GuaranteedAngle`，进而得到原始 `alpha` 的下界。
   与本项目此前的 17 点上界组合，得到所列区间。

## 实现和复查入口

- `Prize/JSP404/FiniteCliqueCertificate.lean`：团上界证书、可靠性及轨道归约。
- `Prize/JSP404/FiniteCliqueCover.lean`：类型覆盖证书和可靠性。
- `Prize/JSP404/Sector26Types.lean`：156 个类型、覆盖检查、反向排除。
- `Prize/JSP404/Sector26ArcCertificate.lean`：26 个弧型的容量至多 8。
- `Prize/JSP404/Sector26NonarcCertificate.lean`：130 个非弧型的容量至多 8。
- `Prize/JSP404/Sector26DiscreteBound.lean`：类型分类、注入和总容量至多 16。
- `Prize/JSP404/Sector26Quantization.lean`：复方向的精确扇区编号。
- `Prize/JSP404/Sector26LowerBound.lean`：原题任意点集的下界和 17 点区间。

完整构建通过（3150 项任务，包含依赖），随后 458 项公理审计通过。
其中一项不依赖任何公理；其余实际依赖均包含于 `propext`、`Classical.choice`、`Quot.sound`。
八个新增模块的全部 46 个定理均列入 `Prize/Audit.lean`。
新结果的递归导入闭包为 33 个本地模块和 mathlib，不导入九点或十一点外部证书。
完整项目仍保留注明来源的其他成果；不能因此把整个项目都说成无外部证书。

在原工作区，发现和生成过程可以用以下脚本复查（发布归档的环境准备和直接 lake 命令见其 README）：

```sh
python3 scripts/explore_sector_types.py --verify-only
python3 scripts/generate_sector26_cover.py
python3 scripts/export_sector26_types.py
python3 scripts/export_sector26_certificate.py
./scripts/lake.sh build
./scripts/lake.sh env lean Prize/Audit.lean
```

后面三个 Python 脚本会重新生成有限数据或 Lean 文件；它们不属于可信证明基础。
普通构建无需运行生成脚本。原始候选 JSON 为
`research/logs/jsp404-sector26-candidate.json`，SHA-256：
`5ace6fa4a0f8cca8041275e0ea0c9aa6c7f127c0eb2115e7b85571db6106cb7b`。
它保留发现时“尚未 Lean 验证”的历史状态；当前证明见上述 Lean 模块。
有限相容图的 16 团仅是组合见证，不宣称能实现为 16 个实际点。

## 来源与贡献范围

原题和经典分段精确值来源于 Sendov，
*Minimax of the angles in a plane configuration of points*，Acta Mathematica
Hungarica 69 (1995), 27–46，[DOI](https://doi.org/10.1007/BF01874605)，
[公开馆藏](https://real-j.mtak.hu/7467/)。原文访问和证明路线复核记录在
`jsp404-english-source.md`、`jsp404-proof-map.md`。
本结果弱于该经典分类的 17 点值 140°。

本轮贡献是本地生成并形式化有限证书、证明量化及原题转移，以提高本项目
已验证的数值下界。实平面到复平面的标准转换也用于此前注明来源的
`SendovDirectionModel` 接口。本轮未复用九点或十一点的有限方向证书。
没有完成全面的优先权检索，不声称新数学发现、首次形式化、独立外部审查
或完整奖项解答。最近公开声明复核范围见 `jsp404-prior-work-20261005.md`。
