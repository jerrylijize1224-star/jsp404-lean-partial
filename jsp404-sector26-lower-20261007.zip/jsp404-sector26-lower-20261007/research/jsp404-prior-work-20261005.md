# 2026-10-05：完整形式化与已有部分成果复核

## 结论

不能确认“从来没人做出来”。经典数学问题已有文献解答；Lean 方面存在明确的部分形式化。
本轮所查公开材料中，尚未确认与原题几何极值定义一致的任意点数完整 Lean 证明。
这不是不存在性、首次形式化、优先权或奖金资格证明。

## 证据与范围

- 奖项题库当前 JSP-000404 条目仍为 Solved / Lean No / Eligible No。
  https://github.com/TheJustinSunPrize/awards/blob/main/problems/README.md
  No 表示未记录完整证明，不表示没有部分成果或尚未登记的完整成果。
- PR #100 已公开 5–10 点和全部二进制点数的精确值。
  https://github.com/TheJustinSunPrize/awards/pull/100
  九点所选依赖已在上一轮本地重新编译并连接本项目目标。
- PR #647 已公开十一点下界及 11–16 点等式；其中 11–15 是该提交声称新增的范围。
  https://github.com/TheJustinSunPrize/awards/pull/647
  本项目所选 368 个未改写依赖模块已全部逐个编译成功；尚未完成本项目最终连接及新增公理审计，不能据此更新本项目精确值覆盖范围。
- PR #2804 声称完整 Sendov 公式，但所固定源码直接将 alpha 定义为分段答案。
  固定版本 f7bf2cce3bd37fec9f1bce2d04c47b8b88c88061 的 Defs.lean 与 Main.lean
  显示最终定理只展开定义并确认二进制对数所在区间；没有在该定理的依赖中将其
  连接到任意平面有限点集的最大不可避免角。故该定理本身不是原题的完整形式化。
  https://github.com/Yi-111-a/jsp-000404-blumenthal-sendov/blob/f7bf2cce3bd37fec9f1bce2d04c47b8b88c88061/lean/JSP404/Defs.lean
  https://github.com/Yi-111-a/jsp-000404-blumenthal-sendov/blob/f7bf2cce3bd37fec9f1bce2d04c47b8b88c88061/lean/JSP404/Main.lean
  本轮仅作命题对应性审查，没有重编译此包。
- PR #2751 明确将 JSP-000404 映射到 Erdős #404；本项目题目对应 Erdős #504。
  其提交文字不能作为本题完整证明的证据。
  https://github.com/TheJustinSunPrize/awards/pull/2751
- PR #2785 的陈述只覆盖三点情形；PR #1774 自称 scoped component。
  https://github.com/TheJustinSunPrize/awards/pull/2785
  https://github.com/TheJustinSunPrize/awards/pull/1774

## 检索限制

GitHub 公共 API 对奖项仓库精确题号查询返回 9 项，未标记结果截断；
Blumenthal / Sendov / Erdos 504 别名查询返回 11 项，包含其他题目。
同时查阅题库、相关公开 PR 与上述固定源码，并使用通用网络搜索补查。
通用搜索噪声较多，不能排除未被索引、未提交奖项仓库、私有或后续更新的成果。
网页缓存与实时 API 的 PR 开闭状态存在差异；没有以是否合并判定数学正确性。

当前应将 11–15 点证书整合作为复核基础。若目标是新增形式化贡献，不能将其
包装成独立首证，后续重点应转向尚未由本轮材料确认完成的一般尖锐下界。
