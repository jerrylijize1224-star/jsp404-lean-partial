# Sharp values at all binary cardinalities

Date: 2026-09-30. Full build and axiom audit passed.

## Result and boundary

For every integer k >= 2, the development proves the full sharp statement

    IsSharpBound (2^k) ((1-1/k)*pi),
    alpha (2^k) = (1-1/k)*pi.

In particular, alpha 16 = 135 degrees and alpha 32 = 144 degrees.
The lower bound also holds at all N >= 2^k. The previously verified
non-dyadic exact cases N=3,5,6,7 remain available, as do the explicit
strict improvements above each binary threshold.

This resolves an infinite subfamily, not the arbitrary-N SendovClaim.
For example, alpha 17 remains bounded between 135+45/137 and 140 degrees;
this argument does not establish its exact value. The non-dyadic portions
of both general bands remain unproved.

## Proof structure

1. Encode each vertex of a k-relation no-two-step cover by its outgoing-edge
   bits. Pair coverage makes the encoding injective. At exactly 2^k vertices
   it is surjective onto the Boolean cube. Flipping just one bit shows that
   every vertex must have an incoming or outgoing edge in every relation.
2. Let these relations vary openly along a connected parameter set, with
   opposite endpoint orientations. At a fixed vertex and relation, parameters
   permitting outgoing and incoming edges form open sets. Saturation makes
   them cover the parameter set, and the no-two-step property makes them
   disjoint there. Reversal makes both nonempty, contradicting connectedness.
   The resulting abstract theorem forces strictly fewer than 2^k vertices.
3. If all angles are at most a < pi-pi/k, choose open cones with half-width r
   strictly between pi/(2k) and (pi-a)/2. At every rotation in [0,pi], their k
   axes cover all projective directions. Angular continuity makes the edge
   relations open; the angle triangle inequality excludes two-step paths.
   A half-turn reverses every relation. All abstract premises are discharged
   for arbitrary nonzero antisymmetric plane direction assignments.
4. A finite largest triple angle closes the lower-bound endpoint. Apply it
   to actual point differences and the original GuaranteedAngle/alpha
   definitions. Combine with the existing equally spaced binary-scale
   counterexamples to obtain both equality and IsSharpBound.

The finite maximum is for a single direction assignment. It does not assume
existence of an ordinary configuration attaining the global infimum. No
cluster-reduction, general-position, or realization hypothesis is added.

## Files

- `SaturatedCover.lean`: equality incidence and the connected reversing-cover obstruction.
- `RotatingSectorCover.lean`: actual continuous axes, open coverage, reversal,
  and strict binary counting for a strict angle cap.
- `DyadicSharp.lean`: transfer to ordinary configurations and sharp dyadic values.

## Attribution and source access

The mathematical formula is classical, not a new discovery. Sendov,
*Minimax of the angles in a plane configuration of points*, Acta Mathematica
Hungarica 69 (1995), 27–46, states the dyadic equality on p. 27 and attributes
it to G. Szekeres (1941) and P. Erdos/G. Szekeres (1960), references [9] and [4].
The binary graph-cover lemma is recalled on pp. 33–34. The full Sendov paper
was read locally from https://real-j.mtak.hu/7467/;
DOI https://doi.org/10.1007/BF01874605. The two earlier original papers were
not separately retrieved or checked during this step.

The contribution here is the local Lean proof connecting equality in binary
counting, connectedness of rotating open sectors, and the existing upper
construction. Earlier project notes already record overlapping public work
claiming all dyadic thresholds. There was no fresh exhaustive priority search
or independent rebuild of those packages. No first-formalization or award
completion claim is made. SendovClaim itself remains an unchanged unproved Prop.

## Verification

The required full build succeeded (2595 jobs including dependencies), followed
by the required axiom audit with exit status 0. All 347 requested declarations
match the audit log. Each of the fifteen new theorems depends only on
`propext`, `Classical.choice`, and `Quot.sound`. The original target file is
byte-for-byte unchanged from the preceding published snapshot. No proof
placeholders, added axioms, or unchecked proof shortcuts are used. This is
local verification, not independent external review or a fresh-machine rebuild.
