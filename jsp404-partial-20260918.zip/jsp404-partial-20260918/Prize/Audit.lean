import Prize

#print axioms Prize.JSP628.neighbor_mem_of_longest
#print axioms Prize.JSP628.no_outside_neighbor_of_longest
#print axioms Prize.JSP628.degree_start_le_of_no_pathFan
#print axioms Prize.JSP628.exists_low_degree_of_no_pathFan
#check Prize.JSP628.JiangClaim
#check Prize.JSP628.EventualExtremalClaim

#print axioms Prize.JSP404.guaranteedAngle_pi_div_three
#print axioms Prize.JSP404.alpha_bounds
#print axioms Prize.JSP404.alpha_mono
#print axioms Prize.JSP404.IsSharpBound.alpha_eq
#check Prize.JSP404.FullSolution
#print axioms Prize.JSP404.threePoints_sharp
#print axioms Prize.JSP404.alpha_three
#check Prize.JSP404.SendovClaim
#print axioms Prize.JSP404.card_le_two_pow_of_bipartite_cover
#print axioms Prize.JSP404.card_le_two_pow_of_even_walk_cover
#print axioms Prize.JSP404.card_le_two_pow_of_no_two_step_cover
#print axioms Prize.JSP404.CountingCheck.capacity_check
#print axioms Prize.JSP404.guaranteedAngle_iff_generalPosition
#print axioms Prize.JSP404.generalPosition_of_not_hasLargeAngle
#print axioms Prize.JSP404.exists_largest_angle
#print axioms Prize.JSP404.guaranteedAngle_of_forall_lt
#print axioms Prize.JSP404.isSharpBound_of_approximation
#print axioms Prize.JSP404.sectorCapacity_merge
#print axioms Prize.JSP404.sectorCapacity_merge_gain
#print axioms Prize.JSP404.card_le_two_pow_of_direction_cover
#print axioms Prize.JSP404.triangleVertexCapacity_control
#print axioms Prize.JSP404.twoCentre_capacity
#print axioms Prize.JSP404.threeCentre_capacity_low
#print axioms Prize.JSP404.threeCentre_capacity_high
#print axioms Prize.JSP404.threeCentre_capacity_low_of_angles
#print axioms Prize.JSP404.threeCentre_capacity_high_of_angles
#print axioms Prize.JSP404.threeCentre_capacity_high_attained
#print axioms Prize.JSP404.sectorCapacity_sum_le
#print axioms Prize.JSP404.capacity_le_triangle_of_gap_blocks
#print axioms Prize.JSP404.maximal_exponents_card_low
#print axioms Prize.JSP404.maximal_exponents_card_high
#print axioms Prize.JSP404.maximal_centres_low
#print axioms Prize.JSP404.maximal_centres_high
#print axioms Prize.JSP404.hasLargeAngle_pi_div_two
#print axioms Prize.JSP404.guaranteedAngle_pi_div_two
#print axioms Prize.JSP404.fourPoints_sharp
#print axioms Prize.JSP404.alpha_four
#print axioms Prize.JSP404.splitVertexBits_control
#print axioms Prize.JSP404.three_gapBits_le
#print axioms Prize.JSP404.splitVertexBits_le_of_small_complement
#print axioms Prize.JSP404.splitVertexBits_middle_dichotomy
#print axioms Prize.JSP404.InteriorAngleData.capacity_low
#print axioms Prize.JSP404.InteriorAngleData.capacity_high
#print axioms Prize.JSP404.angle_split_of_barycentric
#print axioms Prize.JSP404.InteriorFourGeometry.capacity_low
#print axioms Prize.JSP404.InteriorFourGeometry.capacity_high
#print axioms Prize.JSP404.ConvexFourAngleData.capacity_low
#print axioms Prize.JSP404.ConvexFourAngleData.capacity_high
#print axioms Prize.JSP404.ConvexFourGeometry.capacity_low
#print axioms Prize.JSP404.ConvexFourGeometry.capacity_high
