"""Prepare untrusted certificates for 17 selected masks, reusing verified tables.

Only standard-library Python is used. The existing exporter's canonical option
and width generation is reused. The generated Lean checks still need to run.
"""
from pathlib import Path
from itertools import combinations
from collections import Counter
import argparse,json,runpy,time,hashlib


def prepare(root):
    old = runpy.run_path(str(root / 'scripts/export_three_arc_order_certificate.py'))
    opts, width = old['options'], old['width_edges']
    O = {(i,j): tuple(tuple((3*x[0]+x[1],3*y[0]+y[1]) for x,y in sorted(c))
                       for c in opts(i,j)) for i,j in combinations(range(20),2)}
    W = {i: tuple(sorted((3*x[0]+x[1],3*y[0]+y[1]) for x,y in width(i))) for i in range(20)}
    return O,W


def add_edge(R,u,v):
    if u == v or R[v] >> u & 1:
        return None
    if R[u] >> v & 1:
        return R
    successor = R[v] | (1 << v)
    out = list(R)
    for p in range(60):
        if p == u or R[p] >> u & 1:
            out[p] |= successor
    return tuple(out)


def add_choice(R,E):
    for u,v in E:
        R=add_edge(R,u,v)
        if R is None:
            return None
    return R


def find_cycle(edges):
    adj={}
    for x,y in sorted(edges):
        adj.setdefault(x,[]).append(y)
    done, stack, loc = set(),[],{}
    def dfs(x):
        if x in loc:
            return stack[loc[x]:]+[x]
        if x in done:
            return None
        loc[x]=len(stack)
        stack.append(x)
        for y in adj.get(x,()):
            found=dfs(y)
            if found:
                return found
        stack.pop()
        del loc[x]
        done.add(x)
        return None
    for x in sorted(adj):
        found=dfs(x)
        if found:
            return found
    return None


def build(missing,O,W):
    present=[i for i in range(20) if i not in missing]
    clauses=[(i,j,O[i,j]) for i,j in combinations(present,2)]
    initial=frozenset(e for i in present for e in W[i])
    R=(0,)*60
    for i in present:
        R=add_choice(R,W[i])
        assert R is not None
    nodes=[]
    cache={}
    calls=0
    def leaf(edges):
        cycle=find_cycle(edges)
        assert cycle is not None
        key=('cycle',tuple(cycle))
        if key in cache:
            return cache[key]
        index=len(nodes)
        nodes.append({'cycle':cycle})
        cache[key]=index
        return index
    def go(edges,R):
        nonlocal calls
        calls+=1
        if edges in cache:
            return cache[edges]
        choices=[]
        for i,j,oo in clauses:
            if any(all(R[u]>>v&1 for u,v in E) for E in oo):
                continue
            viable=[]
            for E in oo:
                Rn=add_choice(R,E)
                if Rn is not None:
                    viable.append((E,Rn))
            score=(len(viable),len(oo),-sum(sum(not(R[u]>>v&1) for u,v in E) for E,_ in viable),i,j)
            choices.append((score,i,j,oo))
        if not choices:
            raise RuntimeError('Order model found, cannot export contradiction: '+str(missing))
        _,i,j,oo=min(choices,key=lambda x:x[0])
        children=[]
        for E in oo:
            Rn=add_choice(R,E)
            expanded=edges|frozenset(E)
            children.append(leaf(expanded) if Rn is None else go(expanded,Rn))
        index=len(nodes)
        nodes.append({'pair':[i,j],'children':children})
        cache[edges]=index
        return index
    root=go(initial,R)
    def replay(index,edges,ancestors):
        assert index not in ancestors and 0<=index<len(nodes)
        node=nodes[index]
        if 'cycle' in node:
            p=node['cycle']
            assert len(p)>=2 and p[0]==p[-1]
            assert all((x,y) in edges for x,y in zip(p,p[1:]))
            return
        i,j=node['pair']
        assert i in present and j in present and i<j
        assert len(node['children'])==len(O[i,j])
        for E,child in zip(O[i,j],node['children']):
            assert child<index
            replay(child,edges|frozenset(E),ancestors|{index})
    replay(root,initial,set())
    def height(index):
        n=nodes[index]
        return 0 if 'cycle' in n else 1+max(map(height,n['children']))
    assert root==len(nodes)-1
    return {'missing':missing,'root':root,'nodes':nodes,'height':height(root),'consistent_search_calls':calls}



def prune(c,O,W):
 old=c['nodes'];present=set(range(20))-set(c['missing']);initial=frozenset(e for i in present for e in W[i])
 nodes=[];supports=[];dedup={};memo={}
 def store(node,support,key):
  if key in dedup:return dedup[key]
  idx=len(nodes);nodes.append(node);supports.append(support);dedup[key]=idx;return idx
 def go(idx,ctx):
  key=(idx,ctx)
  if key in memo:return memo[key]
  n=old[idx]
  if 'cycle'in n:
   path=n['cycle'];support=frozenset(zip(path,path[1:]));assert support<=ctx
   ans=store(n,support,('cycle',tuple(path)))
  else:
   i,j=n['pair'];children=[go(ch,ctx|frozenset(E)) for ch,E in zip(n['children'],O[i,j])]
   bypass=[ch for ch in children if supports[ch]<=ctx]
   if bypass:ans=bypass[0]
   else:
    support=frozenset(e for ch,E in zip(children,O[i,j]) for e in supports[ch]-frozenset(E));assert support<=ctx
    ans=store({'pair':[i,j],'children':children},support,('branch',i,j,tuple(children)))
  memo[key]=ans;return ans
 root=go(c['root'],initial)
 out=[];mp={}
 def visit(idx):
  if idx in mp:return mp[idx]
  n=nodes[idx]
  n=n if 'cycle'in n else {'pair':n['pair'],'children':[visit(ch) for ch in n['children']]}
  a=len(out);out.append(n);mp[idx]=a;return a
 root=visit(root)
 def replay(idx,ctx):
  n=out[idx]
  if 'cycle'in n:
   p=n['cycle'];assert p[0]==p[-1] and len(p)>=2;assert all(e in ctx for e in zip(p,p[1:]));return
  i,j=n['pair'];assert i<j and i in present and j in present
  assert len(n['children'])==len(O[i,j])
  for ch,E in zip(n['children'],O[i,j]):assert ch<idx;replay(ch,ctx|frozenset(E))
 replay(root,initial)
 heights=[];visits=[]
 for n in out:
  heights.append(0 if 'cycle'in n else 1+max(heights[ch] for ch in n['children']))
  visits.append(1 if 'cycle'in n else 1+sum(visits[ch] for ch in n['children']))
 return {'missing':c['missing'],'nodes':out,'root':root,'height':heights[root],
         'expanded_visits':visits[root], 'source_nodes':len(c['nodes'])}

def ls(xs):
    return '['+', '.join(xs)+']'


def lean_edges(E):
    return ls('(%d, %d)'%(u,v) for u,v in E)


def export_data(cases,O):
    lines=['import Prize.JSP404.ThreeArcOrderData','','/-! Untrusted certificate data for kernel checking of 17 occupied masks. -/',
           'namespace Prize.JSP404.ThreeArcOrder17Data','open ThreeArcOrderCertificate','',
           'abbrev spec : Spec := ThreeArcOrderData.spec','']
    for case in cases:
        a,b,c=case['missing']
        lines.append('def cert%02d_%02d_%02d : Array Node := #['%(a,b,c))
        for n,node in enumerate(case['nodes']):
            if 'cycle' in node:
                body='.cycle '+ls(map(str,node['cycle']))
            else:
                i,j=node['pair']
                body='.branch %d %d '%(i,j)+ls('('+lean_edges(E)+', '+str(child)+')' for E,child in zip(O[i,j],node['children']))
            lines.append('  '+body+(',' if n+1<len(case['nodes']) else ''))
        lines+= [']','']
    lines+=['def certificate (a b c : Label) : Array Node :=','  match a.val, b.val, c.val with']
    for case in cases:
        a,b,c=case['missing']
        lines.append('  | %d, %d, %d => cert%02d_%02d_%02d'%(a,b,c,a,b,c))
    lines+=['  | _, _, _ => #[]','','end Prize.JSP404.ThreeArcOrder17Data','']
    return '\n'.join(lines)


def export_checks(cases):
    lines=['import Prize.JSP404.ThreeArcOrder17Data','import Mathlib.Tactic.FinCases','',
           '/-! Kernel checking and finite assembly for every missing triple. -/',
           'namespace Prize.JSP404.ThreeArcOrder17Data','open ThreeArcOrderCertificate','']
    for case in cases:
        a,b,c=case['missing']
        lines+=['theorem accepted%02d_%02d_%02d :'%(a,b,c),
                '    accepted spec (((Finset.univ.erase (%d : Label)).erase %d).erase %d)'%(a,b,c),
                '      (certificate %d %d %d) = true := by'%(a,b,c),
                '  decide +kernel','']
    for a in range(20):
        lines+=['set_option maxHeartbeats 1000000 in',
                'theorem row%02d_accepted : ∀ b c : Label, (%d : Label) < b → b < c →'%(a,a),
                '    accepted spec (((Finset.univ.erase (%d : Label)).erase b).erase c)'%a,
                '      (certificate %d b c) = true := by'%a,
                '  intro b c hab hbc','  fin_cases b']
        for b in range(20):
            if b<=a:
                lines+=['  · norm_num at hab']
            else:
                lines+=['  · fin_cases c']
                for c in range(20):
                    lines+=['    · '+('exact accepted%02d_%02d_%02d'%(a,b,c) if b<c else 'norm_num at hbc')]
        lines+=['']
    lines+=['theorem all_accepted : ∀ a b c : Label, a < b → b < c →',
            '    accepted spec (((Finset.univ.erase a).erase b).erase c)',
            '      (certificate a b c) = true := by','  intro a b c hab hbc','  fin_cases a']
    for a in range(20):
        lines.append('  · exact row%02d_accepted b c hab hbc'%a)
    lines+=['','end Prize.JSP404.ThreeArcOrder17Data','']
    return '\n'.join(lines)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    parser.add_argument('--out',type=Path)
    parser.add_argument('--summary',type=Path)
    parser.add_argument('--certificate-json',type=Path)
    args=parser.parse_args()
    args.out = args.out or args.root / 'Prize/JSP404'
    args.out.mkdir(exist_ok=True,parents=True)
    O,W=prepare(args.root)
    cpu=time.process_time();wall=time.monotonic()
    cases=[]
    for missing in combinations(range(20),3):
        case=prune(build(missing,O,W),O,W);cases.append(case)
        print(missing,len(case['nodes']),case['height'],flush=True)
    data=export_data(cases,O);checks=export_checks(cases)
    (args.out/'ThreeArcOrder17Data.lean').write_text(data)
    (args.out/'ThreeArcOrder17Checks.lean').write_text(checks)
    if args.certificate_json:
        args.certificate_json.write_text(json.dumps(cases,separators=(',',':'))+'\n')
    nodes=[n for c in cases for n in c['nodes']]
    stats={'scope':'Untrusted discovery; must compile table reuse, all certificates and original bridge before claiming alpha26',
           'selected_masks':17,'missing_masks':3,'cases':len(cases),'nodes':len(nodes),
           'source_nodes':sum(c['source_nodes'] for c in cases),
           'pruning':'Support-subset branch bypass; ordinary certificates independently replayed',
           'max_nodes':max(len(c['nodes']) for c in cases),'max_depth':max(c['height'] for c in cases),
           'expanded_visits':sum(c['expanded_visits'] for c in cases),
           'cycle_leaves':sum('cycle'in n for n in nodes),
           'branch_arities':dict(Counter(len(n['children']) for n in nodes if'children'in n)),
           'all_python_replays_passed':True,'cpu_seconds':time.process_time()-cpu,'wall_seconds':time.monotonic()-wall,
           'data_bytes':len(data.encode()),'checks_bytes':len(checks.encode()),'check_statements':checks.count('theorem '),
           'data_sha256':hashlib.sha256(data.encode()).hexdigest(),'checks_sha256':hashlib.sha256(checks.encode()).hexdigest()}
    if args.summary:
        args.summary.write_text(json.dumps(stats,indent=2)+'\n')
    print('SUMMARY',json.dumps(stats),flush=True)

if __name__=='__main__':main()
