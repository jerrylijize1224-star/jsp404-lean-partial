"""Export finite strict-order certificates; Lean checks every exported proof tree.

The discovery algorithm is untrusted.  It uses no external solver.  Each branch
chooses a pair clause and covers every feasible option; every leaf is a directed
cycle of strict fractional inequalities.  The generated Lean file also checks
its finite option/width tables against the canonical integer starts.
"""
from pathlib import Path
from itertools import combinations
from collections import Counter
import argparse
import json
import time

TYPES = [
    {0,1,2,4,8}, {0,1,3,4,7}, {0,1,3,7,9}, {0,1,4,7,8},
    {0,2,3,4,6}, {0,2,3,6,9}, {0,2,6,8,9}, {0,3,4,6,7},
    {0,3,6,7,9}, {0,4,6,7,8}, {1,2,3,5,9}, {1,2,4,5,8},
    {1,2,5,8,9}, {1,3,4,5,7}, {1,4,5,7,8}, {1,5,7,8,9},
    {2,3,5,6,9}, {2,4,5,6,8}, {2,5,6,8,9}, {3,5,6,7,9},
]
STARTS = [[i for i in sorted(t) if (i - 1) % 10 not in t] for t in TYPES]
OFFSETS = [10, 0, 0]
Point = tuple


def options(i, j):
    """All distinct feasible raw alternatives, without superset pruning."""
    out = set()
    for k in range(3):
        for l in range(3):
            for shift in (-5, 5):
                data = [
                    (STARTS[i][k] - STARTS[j][(l-1) % 3]
                     - (4 - OFFSETS[l] + shift), (i,k), (j,(l-1) % 3)),
                    (STARTS[j][l] + shift - STARTS[i][(k-1) % 3]
                     - (4 - OFFSETS[k]), (j,l), (i,(k-1) % 3)),
                ]
                if any(delta >= 1 for delta, _, _ in data):
                    continue
                out.add(frozenset((a, b) for delta, a, b in data if delta == 0))
    return sorted(out, key=lambda p: tuple(sorted(p)))


def width_edges(i):
    out = set()
    for k in range(3):
        delta = STARTS[i][k] - STARTS[i][(k-1) % 3] - (4 - OFFSETS[k])
        assert delta <= 0
        if delta == 0:
            out.add(((i,k), (i,(k-1) % 3)))
    return out


def find_cycle(edges):
    adj = {}
    for x, y in sorted(edges):
        adj.setdefault(x, []).append(y)
    done, stack, loc = set(), [], {}

    def dfs(x):
        if x in loc:
            return stack[loc[x]:] + [x]
        if x in done:
            return None
        loc[x] = len(stack)
        stack.append(x)
        for y in adj.get(x, ()):
            answer = dfs(y)
            if answer:
                return answer
        stack.pop()
        del loc[x]
        done.add(x)
        return None

    for x in sorted(adj):
        answer = dfs(x)
        if answer:
            return answer
    return None


def closure(edges):
    adj = {}
    for x, y in edges:
        adj.setdefault(x, set()).add(y)
    for x in list(adj):
        seen, pending = set(), list(adj[x])
        while pending:
            y = pending.pop()
            if y in seen:
                continue
            seen.add(y)
            pending += list(adj.get(y, ()))
        if x in seen:
            return None
        adj[x] = seen
    return frozenset((x, y) for x, ys in adj.items() for y in ys)


def build(missing):
    present = [i for i in range(20) if i not in missing]
    clauses = [(i, j, options(i, j)) for i, j in combinations(present, 2)]
    initial = set().union(*(width_edges(i) for i in present))
    nodes, cache = [], {}
    calls = 0

    def solve(edges):
        nonlocal calls
        calls += 1
        cycle = find_cycle(edges)
        if cycle:
            key = ('cycle', tuple(cycle))
            if key in cache:
                return cache[key]
            idx = len(nodes)
            nodes.append({'cycle': cycle})
            cache[key] = idx
            return idx
        reach = closure(edges)
        assert reach is not None
        if reach in cache:
            return cache[reach]
        choices = []
        for i, j, alternatives in clauses:
            if any(all(edge in reach for edge in choice) for choice in alternatives):
                continue
            viable = [choice for choice in alternatives if find_cycle(edges | choice) is None]
            new_edges = sum(len(choice - reach) for choice in viable)
            choices.append(((len(viable), len(alternatives), -new_edges, i, j),
                            i, j, alternatives))
        if not choices:
            raise RuntimeError('No order contradiction discovered for ' + str(missing))
        _, i, j, alternatives = min(choices)
        children = [solve(edges | choice) for choice in alternatives]
        idx = len(nodes)
        nodes.append({'pair': [i, j], 'children': children})
        cache[reach] = idx
        return idx

    root = solve(initial)

    def check(idx, edges, ancestors):
        """Independent certificate replay: all direct leaf edges are checked."""
        assert idx not in ancestors and 0 <= idx < len(nodes)
        node = nodes[idx]
        if 'cycle' in node:
            path = node['cycle']
            assert len(path) >= 2 and path[0] == path[-1]
            assert all((x, y) in edges for x, y in zip(path, path[1:]))
            return
        i, j = node['pair']
        assert i in present and j in present and i < j
        alternatives = options(i, j)
        assert len(alternatives) == len(node['children'])
        for child, choice in zip(node['children'], alternatives):
            assert child < idx
            check(child, edges | choice, ancestors | {idx})

    check(root, initial, set())

    def height(idx):
        node = nodes[idx]
        return 0 if 'cycle' in node else 1 + max(map(height, node['children']))

    assert root == len(nodes) - 1
    return {'missing': missing, 'root': root, 'nodes': nodes,
            'height': height(root), 'calls': calls}


def vertex(p):
    i, k = p
    assert 0 <= i < 20 and 0 <= k < 3
    return 3 * i + k


def lean_list(items):
    return '[' + ', '.join(items) + ']'


def lean_edges(edges):
    return lean_list('(%d, %d)' % (vertex(a), vertex(b)) for a, b in sorted(edges))


def export(cases):
    lines = [
        'import Prize.JSP404.ThreeArcOrderCertificate',
        'import Prize.JSP404.ThreeArcCanonical',
        'import Prize.JSP404.ThreeArcFractionOrder',
        '',
        '/-! Generated by scripts/export_three_arc_order_certificate.py.',
        'The generator is untrusted; finite table checks and the certificate',
        'checker establish the logical content inside the Lean kernel. -/',
        'namespace Prize.JSP404.ThreeArcOrderData',
        'open ThreeArcOrderCertificate',
        '',
        'def var (i : Label) (k : Fin 3) : Var := finProdFinEquiv (i, k)',
        '',
        'theorem var_decode (i : Label) (k : Fin 3) :',
        '    (finProdFinEquiv : Label × Fin 3 ≃ Var).symm (var i k) = (i, k) := by',
        '  exact (finProdFinEquiv : Label × Fin 3 ≃ Var).symm_apply_apply (i, k)',
        '',
        'theorem starts_bounds : ∀ i : Label, ∀ k : Fin 3,',
        '    0 ≤ ThreeArcCanonical.starts i k ∧ ThreeArcCanonical.starts i k ≤ 9 := by',
        '  decide +kernel',
        '',
        'def widthData : Label → List Edge := ![',
    ]
    lines += ['  ' + lean_edges(width_edges(i)) + (',' if i < 19 else '') for i in range(20)]
    lines += [']', '', 'def optionsData : Label → Label → List Choice := ![']
    for i in range(20):
        row = []
        for j in range(20):
            row.append(lean_list(lean_edges(o) for o in options(i, j)) if i < j else '[]')
        lines.append('  ![' + ', '.join(row) + ']' + (',' if i < 19 else ''))
    lines += [']', '', 'def spec : Spec := ⟨widthData, optionsData⟩', '',
              'def shift (z : Fin 2) : ℤ := (z.val : ℤ) - 1', '']
    lines += HOOK_SOURCE.splitlines() + ['']
    for case in cases:
        i, j = case['missing']
        lines.append('def cert%02d_%02d : Array Node := #[' % (i, j))
        for idx, node in enumerate(case['nodes']):
            if 'cycle' in node:
                rendered = '.cycle ' + lean_list(str(vertex(p)) for p in node['cycle'])
            else:
                a, b = node['pair']
                children = ['(' + lean_edges(choice) + ', ' + str(child) + ')'
                            for choice, child in zip(options(a, b), node['children'])]
                rendered = '.branch %d %d ' % (a, b) + lean_list(children)
            lines.append('  ' + rendered + (',' if idx + 1 < len(case['nodes']) else ''))
        lines += [']', '']
    lines += ['def certificate (i j : Label) : Array Node :=', '  match i.val, j.val with']
    for case in cases:
        i, j = case['missing']
        lines.append('  | %d, %d => cert%02d_%02d' % (i, j, i, j))
    lines += ['  | _, _ => #[]', '', 'end Prize.JSP404.ThreeArcOrderData', '']
    return '\n'.join(lines)


HOOK_SOURCE = r"""abbrev widthCondition (i : Label) (e : Edge) (k : Fin 3) : Prop :=
  ThreeArcCanonical.starts i k -
      ThreeArcCanonical.starts i (ContinuousThreeArc.previous k) =
    4 - ThreeArcFractionOrder.offset k ∧
  e = (var i k, var i (ContinuousThreeArc.previous k))

def widthCheck (i : Label) : Bool :=
  (spec.width i).all fun e =>
    (List.finRange 3).any fun k => decide (widthCondition i e k)

theorem widthCheck_true : ∀ i : Label, widthCheck i = true := by
  decide +kernel

theorem width_cover : ∀ i : Label, ∀ e ∈ spec.width i,
    ∃ k : Fin 3,
      ThreeArcCanonical.starts i k -
          ThreeArcCanonical.starts i (ContinuousThreeArc.previous k) =
        4 - ThreeArcFractionOrder.offset k ∧
      e = (var i k, var i (ContinuousThreeArc.previous k)) := by
  intro i e he
  have h := List.all_eq_true.mp (widthCheck_true i) e he
  obtain ⟨k, _, hk⟩ := List.any_eq_true.mp h
  exact ⟨k, of_decide_eq_true hk⟩

def firstDelta (i j : Label) (k l : Fin 3) : ℤ :=
  ThreeArcCanonical.starts i k -
    ThreeArcCanonical.starts j (ContinuousThreeArc.previous l)

def secondDelta (i j : Label) (k l : Fin 3) : ℤ :=
  ThreeArcCanonical.starts j l -
    ThreeArcCanonical.starts i (ContinuousThreeArc.previous k)

def firstBound (l : Fin 3) (z : Fin 2) : ℤ :=
  9 - ThreeArcFractionOrder.offset l + 10 * shift z

def secondBound (k : Fin 3) (z : Fin 2) : ℤ :=
  -1 - ThreeArcFractionOrder.offset k - 10 * shift z

abbrev optionCondition (i j : Label) (k l : Fin 3) (z : Fin 2) (e : Edge) : Prop :=
  (firstDelta i j k l = firstBound l z ∧
    e = (var i k, var j (ContinuousThreeArc.previous l))) ∨
  (secondDelta i j k l = secondBound k z ∧
    e = (var j l, var i (ContinuousThreeArc.previous k)))

def optionsCheck (i j : Label) (k l : Fin 3) (z : Fin 2) : Bool :=
  if i < j ∧ firstDelta i j k l ≤ firstBound l z ∧
      secondDelta i j k l ≤ secondBound k z then
    (spec.options i j).any fun alt => alt.all fun e =>
      decide (optionCondition i j k l z e)
  else true

theorem optionsCheck_true : ∀ i j : Label, ∀ k l : Fin 3, ∀ z : Fin 2,
    optionsCheck i j k l z = true := by
  decide +kernel

theorem options_cover : ∀ i j : Label, i < j → ∀ k l : Fin 3, ∀ z : Fin 2,
    ThreeArcCanonical.starts i k -
        ThreeArcCanonical.starts j (ContinuousThreeArc.previous l) ≤
      9 - ThreeArcFractionOrder.offset l + 10 * shift z →
    ThreeArcCanonical.starts j l -
        ThreeArcCanonical.starts i (ContinuousThreeArc.previous k) ≤
      -1 - ThreeArcFractionOrder.offset k - 10 * shift z →
    ∃ alt ∈ spec.options i j, ∀ e ∈ alt,
      (ThreeArcCanonical.starts i k -
          ThreeArcCanonical.starts j (ContinuousThreeArc.previous l) =
        9 - ThreeArcFractionOrder.offset l + 10 * shift z ∧
        e = (var i k, var j (ContinuousThreeArc.previous l))) ∨
      (ThreeArcCanonical.starts j l -
          ThreeArcCanonical.starts i (ContinuousThreeArc.previous k) =
        -1 - ThreeArcFractionOrder.offset k - 10 * shift z ∧
        e = (var j l, var i (ContinuousThreeArc.previous k))) := by
  intro i j hij k l z h0 h1
  have hc := optionsCheck_true i j k l z
  have hp : i < j ∧ firstDelta i j k l ≤ firstBound l z ∧
      secondDelta i j k l ≤ secondBound k z := ⟨hij, h0, h1⟩
  simp only [optionsCheck, if_pos hp] at hc
  obtain ⟨alt, halt, ha⟩ := List.any_eq_true.mp hc
  refine ⟨alt, halt, ?_⟩
  intro e he
  exact of_decide_eq_true (List.all_eq_true.mp ha e he)
"""

def export_checks(cases):
    lines = [
        'import Prize.JSP404.ThreeArcOrderData',
        'import Mathlib.Tactic.FinCases',
        '',
        '/-! Every finite missing-pair certificate is checked by the Lean kernel. -/',
        'namespace Prize.JSP404.ThreeArcOrderData',
        'open ThreeArcOrderCertificate', '',
    ]
    for case in cases:
        i, j = case['missing']
        lines += [
            'theorem accepted%02d_%02d :' % (i, j),
            '    accepted spec ((Finset.univ.erase (%d : Label)).erase %d)' % (i, j),
            '      (certificate %d %d) = true := by' % (i, j),
            '  decide +kernel', '',
        ]
    lines += [
        'set_option maxHeartbeats 1000000 in',
        'theorem all_accepted : ∀ a b : Label, a < b →',
        '    accepted spec ((Finset.univ.erase a).erase b) (certificate a b) = true := by',
        '  intro a b hab',
        '  fin_cases a',
    ]
    for i in range(20):
        lines.append('  · fin_cases b')
        for j in range(20):
            lines.append('    · ' + ('exact accepted%02d_%02d' % (i, j) if i < j
                                    else 'norm_num at hab'))
    lines += ['', 'end Prize.JSP404.ThreeArcOrderData', '']
    return '\n'.join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--summary', type=Path)
    parser.add_argument('--checks', type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    output = args.output or root / 'Prize/JSP404/ThreeArcOrderData.lean'
    before = time.monotonic()
    cases = [build(pair) for pair in combinations(range(20), 2)]
    rendered = export(cases)
    output.write_text(rendered)
    checks_output = args.checks or root / 'Prize/JSP404/ThreeArcOrderChecks.lean'
    checks_output.write_text(export_checks(cases))
    nodes = [node for case in cases for node in case['nodes']]
    report = {
        'scope': 'Discovery data; no capacity or original-problem claim without Lean checks',
        'cases': len(cases), 'nodes': len(nodes),
        'max_nodes': max(len(case['nodes']) for case in cases),
        'max_height': max(case['height'] for case in cases),
        'leaf_nodes': sum('cycle' in node for node in nodes),
        'branch_arity': dict(Counter(len(node['children']) for node in nodes if 'children' in node)),
        'all_python_replays_passed': True,
        'lean_bytes': len(rendered.encode()),
        'checks_bytes': len(export_checks(cases).encode()),
        'kernel_check_statements': len(cases) + 1,
        'seconds': round(time.monotonic() - before, 3),
    }
    text = json.dumps(report, indent=2) + '\n'
    if args.summary:
        args.summary.write_text(text)
    print(text, end='')


if __name__ == '__main__':
    main()
