import Prize.JSP404.ThreeArcOrderData
import Mathlib.Data.Finset.Sort

/-! Canonical continuous rows satisfy the finite strict-order specification.
The unoccupied type labels receive arbitrary values and impose no constraints. -/
namespace Prize.JSP404.ThreeArcOrderModelGeneral
open ContinuousDirection ThreeArcOrderCertificate
open ThreeArcFractionOrder

variable {n : ℕ}

def active (t : Fin n → Label) : Finset Label := Finset.univ.image t

variable [NeZero n]

noncomputable def fractions {d : ℝ} (S : Fin n → ThreeArcRow d)
    (t : Fin n → Label) (v : Var) : ℝ :=
  let p := (finProdFinEquiv : Label × Fin 3 ≃ Var).symm v
  fraction (S (Function.invFun t p.1)) p.2

theorem fractions_var {d : ℝ} (S : Fin n → ThreeArcRow d)
    (t : Fin n → Label) (ht : Function.Injective t) (i : Fin n) (k : Fin 3) :
    fractions S t (ThreeArcOrderData.var (t i) k) = fraction (S i) k := by
  unfold fractions
  rw [ThreeArcOrderData.var_decode]
  change fraction (S (Function.invFun t (t i))) k = fraction (S i) k
  rw [Function.leftInverse_invFun ht i]

omit [NeZero n] in
theorem active_card (t : Fin n → Label) (ht : Function.Injective t) :
    (active t).card = n := by
  classical
  simpa only [active, Finset.card_univ, Fintype.card_fin] using
    Finset.card_image_of_injective (Finset.univ : Finset (Fin n)) ht

theorem model_of_canonical {d : ℝ} (S : Fin n → ThreeArcRow d) (hd : d < 36 / 5)
    (t : Fin n → Label) (ht : Function.Injective t)
    (hfloor : ∀ i k, ⌊5 * (S i).start k / 9⌋ = ThreeArcCanonical.starts (t i) k)
    (hpair : ∀ i j, i ≠ j → ∃ x y : ℝ, ∃ z : ℤ,
      (S i).Mem x ∧ (S j).Mem y ∧ y = x + 9 + 18 * z) :
    Model ThreeArcOrderData.spec (active t) (fractions S t) := by
  classical
  constructor
  · intro i hi e he
    obtain ⟨u, _, rfl⟩ := Finset.mem_image.mp hi
    obtain ⟨k, hk, rfl⟩ := ThreeArcOrderData.width_cover (t u) e he
    change fractions S t (ThreeArcOrderData.var (t u) k) <
      fractions S t (ThreeArcOrderData.var (t u) (ContinuousThreeArc.previous k))
    rw [fractions_var S t ht, fractions_var S t ht]
    exact gap_boundary
      (row_order_of_floor (S u) hd (ThreeArcCanonical.starts (t u)) (hfloor u) k) hk
  · intro i hi j hj hij
    obtain ⟨u, _, rfl⟩ := Finset.mem_image.mp hi
    obtain ⟨v, _, rfl⟩ := Finset.mem_image.mp hj
    have huv : u ≠ v := by
      intro h
      subst v
      exact (lt_irrefl (t u)) hij
    obtain ⟨k, l, z, hz, hk, hl⟩ :=
      pair_order_bounded_of_floor (S u) (S v) hd
        (ThreeArcCanonical.starts (t u)) (ThreeArcCanonical.starts (t v))
        (ThreeArcOrderData.starts_bounds (t u)) (ThreeArcOrderData.starts_bounds (t v))
        (hfloor u) (hfloor v) (hpair u v huv)
    obtain ⟨q, hq⟩ : ∃ q : Fin 2, ThreeArcOrderData.shift q = z := by
      rcases hz with rfl | rfl
      · exact ⟨0, by decide⟩
      · exact ⟨1, by decide⟩
    rw [← hq] at hk hl
    obtain ⟨alt, halt, hcover⟩ :=
      ThreeArcOrderData.options_cover (t u) (t v) hij k l q (gap_le hk) (gap_le hl)
    refine ⟨alt, halt, ?_⟩
    intro e he
    rcases hcover e he with ⟨hb, rfl⟩ | ⟨hb, rfl⟩
    · change fractions S t (ThreeArcOrderData.var (t u) k) <
        fractions S t (ThreeArcOrderData.var (t v) (ContinuousThreeArc.previous l))
      rw [fractions_var S t ht, fractions_var S t ht]
      exact gap_boundary hk hb
    · change fractions S t (ThreeArcOrderData.var (t v) l) <
        fractions S t (ThreeArcOrderData.var (t u) (ContinuousThreeArc.previous k))
      rw [fractions_var S t ht, fractions_var S t ht]
      exact gap_boundary hl hb

set_option maxHeartbeats 1000000 in
theorem exists_order_model {d : ℝ} (R : Fin n → ThreeArcRow d) (hd : d < 36 / 5)
    (hpair : ∀ i j, i ≠ j → ∃ x y : ℝ, ∃ z : ℤ,
      (R i).Mem x ∧ (R j).Mem y ∧ y = x + 9 + 18 * z) :
    ∃ t : Fin n → Label, Function.Injective t ∧
      ∃ x : Var → ℝ, Model ThreeArcOrderData.spec (active t) x := by
  obtain ⟨S, t, hfloor, ht, hp⟩ := ThreeArcCanonical.exists_canonical_family R hd hpair
  exact ⟨t, ht, fractions S t, model_of_canonical S hd t ht hfloor hp⟩

set_option maxHeartbeats 1000000 in
/-- Seventeen occupied labels leave exactly three omitted labels, in increasing order. -/
theorem active_erase_triple (t : Fin 17 → Label) (ht : Function.Injective t) :
    ∃ a b c : Label, a < b ∧ b < c ∧
      active t = (((Finset.univ : Finset Label).erase a).erase b).erase c := by
  classical
  let missing := (Finset.univ : Finset Label) \ active t
  have hc : missing.card = 3 := by
    dsimp [missing]
    rw [Finset.card_sdiff_of_subset (Finset.subset_univ _), active_card t ht]
    norm_num
  let e : Fin 3 ≃o missing := missing.orderIsoOfFin hc
  let a : Label := (e 0).val
  let b : Label := (e 1).val
  let c : Label := (e 2).val
  have hab : a < b := e.strictMono (by decide : (0 : Fin 3) < 1)
  have hbc : b < c := e.strictMono (by decide : (1 : Fin 3) < 2)
  have hmissing (i : Label) : i ∈ missing ↔ i = a ∨ i = b ∨ i = c := by
    constructor
    · intro hi
      obtain ⟨j, hj⟩ := e.surjective ⟨i, hi⟩
      have hv := congrArg Subtype.val hj
      fin_cases j
      · exact Or.inl hv.symm
      · exact Or.inr (Or.inl hv.symm)
      · exact Or.inr (Or.inr hv.symm)
    · intro hi
      rcases hi with rfl | rfl | rfl
      · exact (e 0).property
      · exact (e 1).property
      · exact (e 2).property
  have hmem (i : Label) : i ∈ active t ↔ i ≠ a ∧ i ≠ b ∧ i ≠ c := by
    have hn : i ∉ active t ↔ i = a ∨ i = b ∨ i = c := by
      simpa [missing] using hmissing i
    have he := not_congr hn
    simpa only [not_not, not_or] using he
  refine ⟨a, b, c, hab, hbc, ?_⟩
  ext i
  rw [hmem]
  simp [and_assoc, and_comm]

end Prize.JSP404.ThreeArcOrderModelGeneral
