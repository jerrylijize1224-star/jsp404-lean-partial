import Prize.JSP404.ThreeArcOrderData

/-! Canonical continuous rows satisfy the finite strict-order specification.
The unoccupied type labels receive arbitrary values and impose no constraints. -/
namespace Prize.JSP404.ThreeArcOrderModel
open ContinuousDirection ThreeArcOrderCertificate
open ThreeArcFractionOrder

def active (t : Fin 18 → Label) : Finset Label := Finset.univ.image t

noncomputable def fractions {d : ℝ} (S : Fin 18 → ThreeArcRow d)
    (t : Fin 18 → Label) (v : Var) : ℝ :=
  let p := (finProdFinEquiv : Label × Fin 3 ≃ Var).symm v
  fraction (S (Function.invFun t p.1)) p.2

theorem fractions_var {d : ℝ} (S : Fin 18 → ThreeArcRow d)
    (t : Fin 18 → Label) (ht : Function.Injective t) (i : Fin 18) (k : Fin 3) :
    fractions S t (ThreeArcOrderData.var (t i) k) = fraction (S i) k := by
  unfold fractions
  rw [ThreeArcOrderData.var_decode]
  change fraction (S (Function.invFun t (t i))) k = fraction (S i) k
  rw [Function.leftInverse_invFun ht i]

theorem active_card (t : Fin 18 → Label) (ht : Function.Injective t) :
    (active t).card = 18 := by
  classical
  simpa only [active, Finset.card_univ, Fintype.card_fin] using
    Finset.card_image_of_injective (Finset.univ : Finset (Fin 18)) ht

theorem model_of_canonical {d : ℝ} (S : Fin 18 → ThreeArcRow d) (hd : d < 36 / 5)
    (t : Fin 18 → Label) (ht : Function.Injective t)
    (hfloor : ∀ i k, ⌊5 * (S i).start k / 9⌋ = ThreeArcCanonical.starts (t i) k)
    (hpair : ∀ i j, i ≠ j → ∃ x y : ℝ, ∃ z : ℤ,
      (S i).Mem x ∧ (S j).Mem y ∧ y = x + 9 + 18 * z) :
    Model ThreeArcOrderData.spec (active t) (fractions S t) := by
  classical
  constructor
  · intro i hi e he
    obtain ⟨u, _, rfl⟩ := Finset.mem_image.mp hi
    obtain ⟨k, hk, rfl⟩ := ThreeArcOrderData.width_cover (t u) e he
    change fractions S t (ThreeArcOrderData.var (t u) k) <
      fractions S t (ThreeArcOrderData.var (t u) (ContinuousThreeArc.previous k))
    rw [fractions_var S t ht, fractions_var S t ht]
    exact gap_boundary
      (row_order_of_floor (S u) hd (ThreeArcCanonical.starts (t u)) (hfloor u) k) hk
  · intro i hi j hj hij
    obtain ⟨u, _, rfl⟩ := Finset.mem_image.mp hi
    obtain ⟨v, _, rfl⟩ := Finset.mem_image.mp hj
    have huv : u ≠ v := by
      intro h
      subst v
      exact (lt_irrefl (t u)) hij
    obtain ⟨k, l, z, hz, hk, hl⟩ :=
      pair_order_bounded_of_floor (S u) (S v) hd
        (ThreeArcCanonical.starts (t u)) (ThreeArcCanonical.starts (t v))
        (ThreeArcOrderData.starts_bounds (t u)) (ThreeArcOrderData.starts_bounds (t v))
        (hfloor u) (hfloor v) (hpair u v huv)
    obtain ⟨q, hq⟩ : ∃ q : Fin 2, ThreeArcOrderData.shift q = z := by
      rcases hz with rfl | rfl
      · exact ⟨0, by decide⟩
      · exact ⟨1, by decide⟩
    rw [← hq] at hk hl
    obtain ⟨alt, halt, hcover⟩ :=
      ThreeArcOrderData.options_cover (t u) (t v) hij k l q (gap_le hk) (gap_le hl)
    refine ⟨alt, halt, ?_⟩
    intro e he
    rcases hcover e he with ⟨hb, rfl⟩ | ⟨hb, rfl⟩
    · change fractions S t (ThreeArcOrderData.var (t u) k) <
        fractions S t (ThreeArcOrderData.var (t v) (ContinuousThreeArc.previous l))
      rw [fractions_var S t ht, fractions_var S t ht]
      exact gap_boundary hk hb
    · change fractions S t (ThreeArcOrderData.var (t v) l) <
        fractions S t (ThreeArcOrderData.var (t u) (ContinuousThreeArc.previous k))
      rw [fractions_var S t ht, fractions_var S t ht]
      exact gap_boundary hl hb

theorem exists_order_model {d : ℝ} (R : Fin 18 → ThreeArcRow d) (hd : d < 36 / 5)
    (hpair : ∀ i j, i ≠ j → ∃ x y : ℝ, ∃ z : ℤ,
      (R i).Mem x ∧ (R j).Mem y ∧ y = x + 9 + 18 * z) :
    ∃ t : Fin 18 → Label, Function.Injective t ∧
      ∃ x : Var → ℝ, Model ThreeArcOrderData.spec (active t) x := by
  obtain ⟨S, t, hfloor, ht, hp⟩ := ThreeArcCanonical.exists_canonical_family R hd hpair
  exact ⟨t, ht, fractions S t, model_of_canonical S hd t ht hfloor hp⟩

theorem active_erase_pair (t : Fin 18 → Label) (ht : Function.Injective t) :
    ∃ a b : Label, a < b ∧ active t = ((Finset.univ : Finset Label).erase a).erase b := by
  classical
  let missing := (Finset.univ : Finset Label) \ active t
  have hc : missing.card = 2 := by
    dsimp [missing]
    rw [Finset.card_sdiff_of_subset (Finset.subset_univ _), active_card t ht]
    norm_num
  obtain ⟨a, b, hab, hm⟩ := Finset.card_eq_two.mp hc
  have hmem (i : Label) : i ∈ active t ↔ i ≠ a ∧ i ≠ b := by
    have hn : i ∉ active t ↔ i = a ∨ i = b := by
      have he : i ∈ missing ↔ i ∈ ({a, b} : Finset Label) := by rw [hm]
      simpa [missing] using he
    have he := not_congr hn
    simpa only [not_not, not_or] using he
  rcases lt_or_gt_of_ne hab with hlt | hlt
  · refine ⟨a, b, hlt, ?_⟩
    ext i
    rw [hmem]
    simp [and_comm]
  · refine ⟨b, a, hlt, ?_⟩
    ext i
    rw [hmem]
    simp [and_comm]

end Prize.JSP404.ThreeArcOrderModel
