import Prize.JSP404.ThreeArcOrderData
import Mathlib.Tactic.FinCases

/-! Every finite missing-pair certificate is checked by the Lean kernel. -/
namespace Prize.JSP404.ThreeArcOrderData
open ThreeArcOrderCertificate

theorem accepted00_01 :
    accepted spec ((Finset.univ.erase (0 : Label)).erase 1)
      (certificate 0 1) = true := by
  decide +kernel

theorem accepted00_02 :
    accepted spec ((Finset.univ.erase (0 : Label)).erase 2)
      (certificate 0 2) = true := by
  decide +kernel

theorem accepted00_03 :
    accepted spec ((Finset.univ.erase (0 : Label)).erase 3)
      (certificate 0 3) = true := by
  decide +kernel

theorem accepted00_04 :
    accepted spec ((Finset.univ.erase (0 : Label)).erase 4)
      (certificate 0 4) = true := by
  decide +kernel

theorem accepted00_05 :
    accepted spec ((Finset.univ.erase (0 : Label)).erase 5)
      (certificate 0 5) = true := by
  decide +kernel

theorem accepted00_06 :
    accepted spec ((Finset.univ.erase (0 : Label)).erase 6)
      (certificate 0 6) = true := by
  decide +kernel

theorem accepted00_07 :
    accepted spec ((Finset.univ.erase (0 : Label)).erase 7)
      (certificate 0 7) = true := by
  decide +kernel

theorem accepted00_08 :
    accepted spec ((Finset.univ.erase (0 : Label)).erase 8)
      (certificate 0 8) = true := by
  decide +kernel

theorem accepted00_09 :
    accepted spec ((Finset.univ.erase (0 : Label)).erase 9)
      (certificate 0 9) = true := by
  decide +kernel

theorem accepted00_10 :
    accepted spec ((Finset.univ.erase (0 : Label)).erase 10)
      (certificate 0 10) = true := by
  decide +kernel

theorem accepted00_11 :
    accepted spec ((Finset.univ.erase (0 : Label)).erase 11)
      (certificate 0 11) = true := by
  decide +kernel

theorem accepted00_12 :
    accepted spec ((Finset.univ.erase (0 : Label)).erase 12)
      (certificate 0 12) = true := by
  decide +kernel

theorem accepted00_13 :
    accepted spec ((Finset.univ.erase (0 : Label)).erase 13)
      (certificate 0 13) = true := by
  decide +kernel

theorem accepted00_14 :
    accepted spec ((Finset.univ.erase (0 : Label)).erase 14)
      (certificate 0 14) = true := by
  decide +kernel

theorem accepted00_15 :
    accepted spec ((Finset.univ.erase (0 : Label)).erase 15)
      (certificate 0 15) = true := by
  decide +kernel

theorem accepted00_16 :
    accepted spec ((Finset.univ.erase (0 : Label)).erase 16)
      (certificate 0 16) = true := by
  decide +kernel

theorem accepted00_17 :
    accepted spec ((Finset.univ.erase (0 : Label)).erase 17)
      (certificate 0 17) = true := by
  decide +kernel

theorem accepted00_18 :
    accepted spec ((Finset.univ.erase (0 : Label)).erase 18)
      (certificate 0 18) = true := by
  decide +kernel

theorem accepted00_19 :
    accepted spec ((Finset.univ.erase (0 : Label)).erase 19)
      (certificate 0 19) = true := by
  decide +kernel

theorem accepted01_02 :
    accepted spec ((Finset.univ.erase (1 : Label)).erase 2)
      (certificate 1 2) = true := by
  decide +kernel

theorem accepted01_03 :
    accepted spec ((Finset.univ.erase (1 : Label)).erase 3)
      (certificate 1 3) = true := by
  decide +kernel

theorem accepted01_04 :
    accepted spec ((Finset.univ.erase (1 : Label)).erase 4)
      (certificate 1 4) = true := by
  decide +kernel

theorem accepted01_05 :
    accepted spec ((Finset.univ.erase (1 : Label)).erase 5)
      (certificate 1 5) = true := by
  decide +kernel

theorem accepted01_06 :
    accepted spec ((Finset.univ.erase (1 : Label)).erase 6)
      (certificate 1 6) = true := by
  decide +kernel

theorem accepted01_07 :
    accepted spec ((Finset.univ.erase (1 : Label)).erase 7)
      (certificate 1 7) = true := by
  decide +kernel

theorem accepted01_08 :
    accepted spec ((Finset.univ.erase (1 : Label)).erase 8)
      (certificate 1 8) = true := by
  decide +kernel

theorem accepted01_09 :
    accepted spec ((Finset.univ.erase (1 : Label)).erase 9)
      (certificate 1 9) = true := by
  decide +kernel

theorem accepted01_10 :
    accepted spec ((Finset.univ.erase (1 : Label)).erase 10)
      (certificate 1 10) = true := by
  decide +kernel

theorem accepted01_11 :
    accepted spec ((Finset.univ.erase (1 : Label)).erase 11)
      (certificate 1 11) = true := by
  decide +kernel

theorem accepted01_12 :
    accepted spec ((Finset.univ.erase (1 : Label)).erase 12)
      (certificate 1 12) = true := by
  decide +kernel

theorem accepted01_13 :
    accepted spec ((Finset.univ.erase (1 : Label)).erase 13)
      (certificate 1 13) = true := by
  decide +kernel

theorem accepted01_14 :
    accepted spec ((Finset.univ.erase (1 : Label)).erase 14)
      (certificate 1 14) = true := by
  decide +kernel

theorem accepted01_15 :
    accepted spec ((Finset.univ.erase (1 : Label)).erase 15)
      (certificate 1 15) = true := by
  decide +kernel

theorem accepted01_16 :
    accepted spec ((Finset.univ.erase (1 : Label)).erase 16)
      (certificate 1 16) = true := by
  decide +kernel

theorem accepted01_17 :
    accepted spec ((Finset.univ.erase (1 : Label)).erase 17)
      (certificate 1 17) = true := by
  decide +kernel

theorem accepted01_18 :
    accepted spec ((Finset.univ.erase (1 : Label)).erase 18)
      (certificate 1 18) = true := by
  decide +kernel

theorem accepted01_19 :
    accepted spec ((Finset.univ.erase (1 : Label)).erase 19)
      (certificate 1 19) = true := by
  decide +kernel

theorem accepted02_03 :
    accepted spec ((Finset.univ.erase (2 : Label)).erase 3)
      (certificate 2 3) = true := by
  decide +kernel

theorem accepted02_04 :
    accepted spec ((Finset.univ.erase (2 : Label)).erase 4)
      (certificate 2 4) = true := by
  decide +kernel

theorem accepted02_05 :
    accepted spec ((Finset.univ.erase (2 : Label)).erase 5)
      (certificate 2 5) = true := by
  decide +kernel

theorem accepted02_06 :
    accepted spec ((Finset.univ.erase (2 : Label)).erase 6)
      (certificate 2 6) = true := by
  decide +kernel

theorem accepted02_07 :
    accepted spec ((Finset.univ.erase (2 : Label)).erase 7)
      (certificate 2 7) = true := by
  decide +kernel

theorem accepted02_08 :
    accepted spec ((Finset.univ.erase (2 : Label)).erase 8)
      (certificate 2 8) = true := by
  decide +kernel

theorem accepted02_09 :
    accepted spec ((Finset.univ.erase (2 : Label)).erase 9)
      (certificate 2 9) = true := by
  decide +kernel

theorem accepted02_10 :
    accepted spec ((Finset.univ.erase (2 : Label)).erase 10)
      (certificate 2 10) = true := by
  decide +kernel

theorem accepted02_11 :
    accepted spec ((Finset.univ.erase (2 : Label)).erase 11)
      (certificate 2 11) = true := by
  decide +kernel

theorem accepted02_12 :
    accepted spec ((Finset.univ.erase (2 : Label)).erase 12)
      (certificate 2 12) = true := by
  decide +kernel

theorem accepted02_13 :
    accepted spec ((Finset.univ.erase (2 : Label)).erase 13)
      (certificate 2 13) = true := by
  decide +kernel

theorem accepted02_14 :
    accepted spec ((Finset.univ.erase (2 : Label)).erase 14)
      (certificate 2 14) = true := by
  decide +kernel

theorem accepted02_15 :
    accepted spec ((Finset.univ.erase (2 : Label)).erase 15)
      (certificate 2 15) = true := by
  decide +kernel

theorem accepted02_16 :
    accepted spec ((Finset.univ.erase (2 : Label)).erase 16)
      (certificate 2 16) = true := by
  decide +kernel

theorem accepted02_17 :
    accepted spec ((Finset.univ.erase (2 : Label)).erase 17)
      (certificate 2 17) = true := by
  decide +kernel

theorem accepted02_18 :
    accepted spec ((Finset.univ.erase (2 : Label)).erase 18)
      (certificate 2 18) = true := by
  decide +kernel

theorem accepted02_19 :
    accepted spec ((Finset.univ.erase (2 : Label)).erase 19)
      (certificate 2 19) = true := by
  decide +kernel

theorem accepted03_04 :
    accepted spec ((Finset.univ.erase (3 : Label)).erase 4)
      (certificate 3 4) = true := by
  decide +kernel

theorem accepted03_05 :
    accepted spec ((Finset.univ.erase (3 : Label)).erase 5)
      (certificate 3 5) = true := by
  decide +kernel

theorem accepted03_06 :
    accepted spec ((Finset.univ.erase (3 : Label)).erase 6)
      (certificate 3 6) = true := by
  decide +kernel

theorem accepted03_07 :
    accepted spec ((Finset.univ.erase (3 : Label)).erase 7)
      (certificate 3 7) = true := by
  decide +kernel

theorem accepted03_08 :
    accepted spec ((Finset.univ.erase (3 : Label)).erase 8)
      (certificate 3 8) = true := by
  decide +kernel

theorem accepted03_09 :
    accepted spec ((Finset.univ.erase (3 : Label)).erase 9)
      (certificate 3 9) = true := by
  decide +kernel

theorem accepted03_10 :
    accepted spec ((Finset.univ.erase (3 : Label)).erase 10)
      (certificate 3 10) = true := by
  decide +kernel

theorem accepted03_11 :
    accepted spec ((Finset.univ.erase (3 : Label)).erase 11)
      (certificate 3 11) = true := by
  decide +kernel

theorem accepted03_12 :
    accepted spec ((Finset.univ.erase (3 : Label)).erase 12)
      (certificate 3 12) = true := by
  decide +kernel

theorem accepted03_13 :
    accepted spec ((Finset.univ.erase (3 : Label)).erase 13)
      (certificate 3 13) = true := by
  decide +kernel

theorem accepted03_14 :
    accepted spec ((Finset.univ.erase (3 : Label)).erase 14)
      (certificate 3 14) = true := by
  decide +kernel

theorem accepted03_15 :
    accepted spec ((Finset.univ.erase (3 : Label)).erase 15)
      (certificate 3 15) = true := by
  decide +kernel

theorem accepted03_16 :
    accepted spec ((Finset.univ.erase (3 : Label)).erase 16)
      (certificate 3 16) = true := by
  decide +kernel

theorem accepted03_17 :
    accepted spec ((Finset.univ.erase (3 : Label)).erase 17)
      (certificate 3 17) = true := by
  decide +kernel

theorem accepted03_18 :
    accepted spec ((Finset.univ.erase (3 : Label)).erase 18)
      (certificate 3 18) = true := by
  decide +kernel

theorem accepted03_19 :
    accepted spec ((Finset.univ.erase (3 : Label)).erase 19)
      (certificate 3 19) = true := by
  decide +kernel

theorem accepted04_05 :
    accepted spec ((Finset.univ.erase (4 : Label)).erase 5)
      (certificate 4 5) = true := by
  decide +kernel

theorem accepted04_06 :
    accepted spec ((Finset.univ.erase (4 : Label)).erase 6)
      (certificate 4 6) = true := by
  decide +kernel

theorem accepted04_07 :
    accepted spec ((Finset.univ.erase (4 : Label)).erase 7)
      (certificate 4 7) = true := by
  decide +kernel

theorem accepted04_08 :
    accepted spec ((Finset.univ.erase (4 : Label)).erase 8)
      (certificate 4 8) = true := by
  decide +kernel

theorem accepted04_09 :
    accepted spec ((Finset.univ.erase (4 : Label)).erase 9)
      (certificate 4 9) = true := by
  decide +kernel

theorem accepted04_10 :
    accepted spec ((Finset.univ.erase (4 : Label)).erase 10)
      (certificate 4 10) = true := by
  decide +kernel

theorem accepted04_11 :
    accepted spec ((Finset.univ.erase (4 : Label)).erase 11)
      (certificate 4 11) = true := by
  decide +kernel

theorem accepted04_12 :
    accepted spec ((Finset.univ.erase (4 : Label)).erase 12)
      (certificate 4 12) = true := by
  decide +kernel

theorem accepted04_13 :
    accepted spec ((Finset.univ.erase (4 : Label)).erase 13)
      (certificate 4 13) = true := by
  decide +kernel

theorem accepted04_14 :
    accepted spec ((Finset.univ.erase (4 : Label)).erase 14)
      (certificate 4 14) = true := by
  decide +kernel

theorem accepted04_15 :
    accepted spec ((Finset.univ.erase (4 : Label)).erase 15)
      (certificate 4 15) = true := by
  decide +kernel

theorem accepted04_16 :
    accepted spec ((Finset.univ.erase (4 : Label)).erase 16)
      (certificate 4 16) = true := by
  decide +kernel

theorem accepted04_17 :
    accepted spec ((Finset.univ.erase (4 : Label)).erase 17)
      (certificate 4 17) = true := by
  decide +kernel

theorem accepted04_18 :
    accepted spec ((Finset.univ.erase (4 : Label)).erase 18)
      (certificate 4 18) = true := by
  decide +kernel

theorem accepted04_19 :
    accepted spec ((Finset.univ.erase (4 : Label)).erase 19)
      (certificate 4 19) = true := by
  decide +kernel

theorem accepted05_06 :
    accepted spec ((Finset.univ.erase (5 : Label)).erase 6)
      (certificate 5 6) = true := by
  decide +kernel

theorem accepted05_07 :
    accepted spec ((Finset.univ.erase (5 : Label)).erase 7)
      (certificate 5 7) = true := by
  decide +kernel

theorem accepted05_08 :
    accepted spec ((Finset.univ.erase (5 : Label)).erase 8)
      (certificate 5 8) = true := by
  decide +kernel

theorem accepted05_09 :
    accepted spec ((Finset.univ.erase (5 : Label)).erase 9)
      (certificate 5 9) = true := by
  decide +kernel

theorem accepted05_10 :
    accepted spec ((Finset.univ.erase (5 : Label)).erase 10)
      (certificate 5 10) = true := by
  decide +kernel

theorem accepted05_11 :
    accepted spec ((Finset.univ.erase (5 : Label)).erase 11)
      (certificate 5 11) = true := by
  decide +kernel

theorem accepted05_12 :
    accepted spec ((Finset.univ.erase (5 : Label)).erase 12)
      (certificate 5 12) = true := by
  decide +kernel

theorem accepted05_13 :
    accepted spec ((Finset.univ.erase (5 : Label)).erase 13)
      (certificate 5 13) = true := by
  decide +kernel

theorem accepted05_14 :
    accepted spec ((Finset.univ.erase (5 : Label)).erase 14)
      (certificate 5 14) = true := by
  decide +kernel

theorem accepted05_15 :
    accepted spec ((Finset.univ.erase (5 : Label)).erase 15)
      (certificate 5 15) = true := by
  decide +kernel

theorem accepted05_16 :
    accepted spec ((Finset.univ.erase (5 : Label)).erase 16)
      (certificate 5 16) = true := by
  decide +kernel

theorem accepted05_17 :
    accepted spec ((Finset.univ.erase (5 : Label)).erase 17)
      (certificate 5 17) = true := by
  decide +kernel

theorem accepted05_18 :
    accepted spec ((Finset.univ.erase (5 : Label)).erase 18)
      (certificate 5 18) = true := by
  decide +kernel

theorem accepted05_19 :
    accepted spec ((Finset.univ.erase (5 : Label)).erase 19)
      (certificate 5 19) = true := by
  decide +kernel

theorem accepted06_07 :
    accepted spec ((Finset.univ.erase (6 : Label)).erase 7)
      (certificate 6 7) = true := by
  decide +kernel

theorem accepted06_08 :
    accepted spec ((Finset.univ.erase (6 : Label)).erase 8)
      (certificate 6 8) = true := by
  decide +kernel

theorem accepted06_09 :
    accepted spec ((Finset.univ.erase (6 : Label)).erase 9)
      (certificate 6 9) = true := by
  decide +kernel

theorem accepted06_10 :
    accepted spec ((Finset.univ.erase (6 : Label)).erase 10)
      (certificate 6 10) = true := by
  decide +kernel

theorem accepted06_11 :
    accepted spec ((Finset.univ.erase (6 : Label)).erase 11)
      (certificate 6 11) = true := by
  decide +kernel

theorem accepted06_12 :
    accepted spec ((Finset.univ.erase (6 : Label)).erase 12)
      (certificate 6 12) = true := by
  decide +kernel

theorem accepted06_13 :
    accepted spec ((Finset.univ.erase (6 : Label)).erase 13)
      (certificate 6 13) = true := by
  decide +kernel

theorem accepted06_14 :
    accepted spec ((Finset.univ.erase (6 : Label)).erase 14)
      (certificate 6 14) = true := by
  decide +kernel

theorem accepted06_15 :
    accepted spec ((Finset.univ.erase (6 : Label)).erase 15)
      (certificate 6 15) = true := by
  decide +kernel

theorem accepted06_16 :
    accepted spec ((Finset.univ.erase (6 : Label)).erase 16)
      (certificate 6 16) = true := by
  decide +kernel

theorem accepted06_17 :
    accepted spec ((Finset.univ.erase (6 : Label)).erase 17)
      (certificate 6 17) = true := by
  decide +kernel

theorem accepted06_18 :
    accepted spec ((Finset.univ.erase (6 : Label)).erase 18)
      (certificate 6 18) = true := by
  decide +kernel

theorem accepted06_19 :
    accepted spec ((Finset.univ.erase (6 : Label)).erase 19)
      (certificate 6 19) = true := by
  decide +kernel

theorem accepted07_08 :
    accepted spec ((Finset.univ.erase (7 : Label)).erase 8)
      (certificate 7 8) = true := by
  decide +kernel

theorem accepted07_09 :
    accepted spec ((Finset.univ.erase (7 : Label)).erase 9)
      (certificate 7 9) = true := by
  decide +kernel

theorem accepted07_10 :
    accepted spec ((Finset.univ.erase (7 : Label)).erase 10)
      (certificate 7 10) = true := by
  decide +kernel

theorem accepted07_11 :
    accepted spec ((Finset.univ.erase (7 : Label)).erase 11)
      (certificate 7 11) = true := by
  decide +kernel

theorem accepted07_12 :
    accepted spec ((Finset.univ.erase (7 : Label)).erase 12)
      (certificate 7 12) = true := by
  decide +kernel

theorem accepted07_13 :
    accepted spec ((Finset.univ.erase (7 : Label)).erase 13)
      (certificate 7 13) = true := by
  decide +kernel

theorem accepted07_14 :
    accepted spec ((Finset.univ.erase (7 : Label)).erase 14)
      (certificate 7 14) = true := by
  decide +kernel

theorem accepted07_15 :
    accepted spec ((Finset.univ.erase (7 : Label)).erase 15)
      (certificate 7 15) = true := by
  decide +kernel

theorem accepted07_16 :
    accepted spec ((Finset.univ.erase (7 : Label)).erase 16)
      (certificate 7 16) = true := by
  decide +kernel

theorem accepted07_17 :
    accepted spec ((Finset.univ.erase (7 : Label)).erase 17)
      (certificate 7 17) = true := by
  decide +kernel

theorem accepted07_18 :
    accepted spec ((Finset.univ.erase (7 : Label)).erase 18)
      (certificate 7 18) = true := by
  decide +kernel

theorem accepted07_19 :
    accepted spec ((Finset.univ.erase (7 : Label)).erase 19)
      (certificate 7 19) = true := by
  decide +kernel

theorem accepted08_09 :
    accepted spec ((Finset.univ.erase (8 : Label)).erase 9)
      (certificate 8 9) = true := by
  decide +kernel

theorem accepted08_10 :
    accepted spec ((Finset.univ.erase (8 : Label)).erase 10)
      (certificate 8 10) = true := by
  decide +kernel

theorem accepted08_11 :
    accepted spec ((Finset.univ.erase (8 : Label)).erase 11)
      (certificate 8 11) = true := by
  decide +kernel

theorem accepted08_12 :
    accepted spec ((Finset.univ.erase (8 : Label)).erase 12)
      (certificate 8 12) = true := by
  decide +kernel

theorem accepted08_13 :
    accepted spec ((Finset.univ.erase (8 : Label)).erase 13)
      (certificate 8 13) = true := by
  decide +kernel

theorem accepted08_14 :
    accepted spec ((Finset.univ.erase (8 : Label)).erase 14)
      (certificate 8 14) = true := by
  decide +kernel

theorem accepted08_15 :
    accepted spec ((Finset.univ.erase (8 : Label)).erase 15)
      (certificate 8 15) = true := by
  decide +kernel

theorem accepted08_16 :
    accepted spec ((Finset.univ.erase (8 : Label)).erase 16)
      (certificate 8 16) = true := by
  decide +kernel

theorem accepted08_17 :
    accepted spec ((Finset.univ.erase (8 : Label)).erase 17)
      (certificate 8 17) = true := by
  decide +kernel

theorem accepted08_18 :
    accepted spec ((Finset.univ.erase (8 : Label)).erase 18)
      (certificate 8 18) = true := by
  decide +kernel

theorem accepted08_19 :
    accepted spec ((Finset.univ.erase (8 : Label)).erase 19)
      (certificate 8 19) = true := by
  decide +kernel

theorem accepted09_10 :
    accepted spec ((Finset.univ.erase (9 : Label)).erase 10)
      (certificate 9 10) = true := by
  decide +kernel

theorem accepted09_11 :
    accepted spec ((Finset.univ.erase (9 : Label)).erase 11)
      (certificate 9 11) = true := by
  decide +kernel

theorem accepted09_12 :
    accepted spec ((Finset.univ.erase (9 : Label)).erase 12)
      (certificate 9 12) = true := by
  decide +kernel

theorem accepted09_13 :
    accepted spec ((Finset.univ.erase (9 : Label)).erase 13)
      (certificate 9 13) = true := by
  decide +kernel

theorem accepted09_14 :
    accepted spec ((Finset.univ.erase (9 : Label)).erase 14)
      (certificate 9 14) = true := by
  decide +kernel

theorem accepted09_15 :
    accepted spec ((Finset.univ.erase (9 : Label)).erase 15)
      (certificate 9 15) = true := by
  decide +kernel

theorem accepted09_16 :
    accepted spec ((Finset.univ.erase (9 : Label)).erase 16)
      (certificate 9 16) = true := by
  decide +kernel

theorem accepted09_17 :
    accepted spec ((Finset.univ.erase (9 : Label)).erase 17)
      (certificate 9 17) = true := by
  decide +kernel

theorem accepted09_18 :
    accepted spec ((Finset.univ.erase (9 : Label)).erase 18)
      (certificate 9 18) = true := by
  decide +kernel

theorem accepted09_19 :
    accepted spec ((Finset.univ.erase (9 : Label)).erase 19)
      (certificate 9 19) = true := by
  decide +kernel

theorem accepted10_11 :
    accepted spec ((Finset.univ.erase (10 : Label)).erase 11)
      (certificate 10 11) = true := by
  decide +kernel

theorem accepted10_12 :
    accepted spec ((Finset.univ.erase (10 : Label)).erase 12)
      (certificate 10 12) = true := by
  decide +kernel

theorem accepted10_13 :
    accepted spec ((Finset.univ.erase (10 : Label)).erase 13)
      (certificate 10 13) = true := by
  decide +kernel

theorem accepted10_14 :
    accepted spec ((Finset.univ.erase (10 : Label)).erase 14)
      (certificate 10 14) = true := by
  decide +kernel

theorem accepted10_15 :
    accepted spec ((Finset.univ.erase (10 : Label)).erase 15)
      (certificate 10 15) = true := by
  decide +kernel

theorem accepted10_16 :
    accepted spec ((Finset.univ.erase (10 : Label)).erase 16)
      (certificate 10 16) = true := by
  decide +kernel

theorem accepted10_17 :
    accepted spec ((Finset.univ.erase (10 : Label)).erase 17)
      (certificate 10 17) = true := by
  decide +kernel

theorem accepted10_18 :
    accepted spec ((Finset.univ.erase (10 : Label)).erase 18)
      (certificate 10 18) = true := by
  decide +kernel

theorem accepted10_19 :
    accepted spec ((Finset.univ.erase (10 : Label)).erase 19)
      (certificate 10 19) = true := by
  decide +kernel

theorem accepted11_12 :
    accepted spec ((Finset.univ.erase (11 : Label)).erase 12)
      (certificate 11 12) = true := by
  decide +kernel

theorem accepted11_13 :
    accepted spec ((Finset.univ.erase (11 : Label)).erase 13)
      (certificate 11 13) = true := by
  decide +kernel

theorem accepted11_14 :
    accepted spec ((Finset.univ.erase (11 : Label)).erase 14)
      (certificate 11 14) = true := by
  decide +kernel

theorem accepted11_15 :
    accepted spec ((Finset.univ.erase (11 : Label)).erase 15)
      (certificate 11 15) = true := by
  decide +kernel

theorem accepted11_16 :
    accepted spec ((Finset.univ.erase (11 : Label)).erase 16)
      (certificate 11 16) = true := by
  decide +kernel

theorem accepted11_17 :
    accepted spec ((Finset.univ.erase (11 : Label)).erase 17)
      (certificate 11 17) = true := by
  decide +kernel

theorem accepted11_18 :
    accepted spec ((Finset.univ.erase (11 : Label)).erase 18)
      (certificate 11 18) = true := by
  decide +kernel

theorem accepted11_19 :
    accepted spec ((Finset.univ.erase (11 : Label)).erase 19)
      (certificate 11 19) = true := by
  decide +kernel

theorem accepted12_13 :
    accepted spec ((Finset.univ.erase (12 : Label)).erase 13)
      (certificate 12 13) = true := by
  decide +kernel

theorem accepted12_14 :
    accepted spec ((Finset.univ.erase (12 : Label)).erase 14)
      (certificate 12 14) = true := by
  decide +kernel

theorem accepted12_15 :
    accepted spec ((Finset.univ.erase (12 : Label)).erase 15)
      (certificate 12 15) = true := by
  decide +kernel

theorem accepted12_16 :
    accepted spec ((Finset.univ.erase (12 : Label)).erase 16)
      (certificate 12 16) = true := by
  decide +kernel

theorem accepted12_17 :
    accepted spec ((Finset.univ.erase (12 : Label)).erase 17)
      (certificate 12 17) = true := by
  decide +kernel

theorem accepted12_18 :
    accepted spec ((Finset.univ.erase (12 : Label)).erase 18)
      (certificate 12 18) = true := by
  decide +kernel

theorem accepted12_19 :
    accepted spec ((Finset.univ.erase (12 : Label)).erase 19)
      (certificate 12 19) = true := by
  decide +kernel

theorem accepted13_14 :
    accepted spec ((Finset.univ.erase (13 : Label)).erase 14)
      (certificate 13 14) = true := by
  decide +kernel

theorem accepted13_15 :
    accepted spec ((Finset.univ.erase (13 : Label)).erase 15)
      (certificate 13 15) = true := by
  decide +kernel

theorem accepted13_16 :
    accepted spec ((Finset.univ.erase (13 : Label)).erase 16)
      (certificate 13 16) = true := by
  decide +kernel

theorem accepted13_17 :
    accepted spec ((Finset.univ.erase (13 : Label)).erase 17)
      (certificate 13 17) = true := by
  decide +kernel

theorem accepted13_18 :
    accepted spec ((Finset.univ.erase (13 : Label)).erase 18)
      (certificate 13 18) = true := by
  decide +kernel

theorem accepted13_19 :
    accepted spec ((Finset.univ.erase (13 : Label)).erase 19)
      (certificate 13 19) = true := by
  decide +kernel

theorem accepted14_15 :
    accepted spec ((Finset.univ.erase (14 : Label)).erase 15)
      (certificate 14 15) = true := by
  decide +kernel

theorem accepted14_16 :
    accepted spec ((Finset.univ.erase (14 : Label)).erase 16)
      (certificate 14 16) = true := by
  decide +kernel

theorem accepted14_17 :
    accepted spec ((Finset.univ.erase (14 : Label)).erase 17)
      (certificate 14 17) = true := by
  decide +kernel

theorem accepted14_18 :
    accepted spec ((Finset.univ.erase (14 : Label)).erase 18)
      (certificate 14 18) = true := by
  decide +kernel

theorem accepted14_19 :
    accepted spec ((Finset.univ.erase (14 : Label)).erase 19)
      (certificate 14 19) = true := by
  decide +kernel

theorem accepted15_16 :
    accepted spec ((Finset.univ.erase (15 : Label)).erase 16)
      (certificate 15 16) = true := by
  decide +kernel

theorem accepted15_17 :
    accepted spec ((Finset.univ.erase (15 : Label)).erase 17)
      (certificate 15 17) = true := by
  decide +kernel

theorem accepted15_18 :
    accepted spec ((Finset.univ.erase (15 : Label)).erase 18)
      (certificate 15 18) = true := by
  decide +kernel

theorem accepted15_19 :
    accepted spec ((Finset.univ.erase (15 : Label)).erase 19)
      (certificate 15 19) = true := by
  decide +kernel

theorem accepted16_17 :
    accepted spec ((Finset.univ.erase (16 : Label)).erase 17)
      (certificate 16 17) = true := by
  decide +kernel

theorem accepted16_18 :
    accepted spec ((Finset.univ.erase (16 : Label)).erase 18)
      (certificate 16 18) = true := by
  decide +kernel

theorem accepted16_19 :
    accepted spec ((Finset.univ.erase (16 : Label)).erase 19)
      (certificate 16 19) = true := by
  decide +kernel

theorem accepted17_18 :
    accepted spec ((Finset.univ.erase (17 : Label)).erase 18)
      (certificate 17 18) = true := by
  decide +kernel

theorem accepted17_19 :
    accepted spec ((Finset.univ.erase (17 : Label)).erase 19)
      (certificate 17 19) = true := by
  decide +kernel

theorem accepted18_19 :
    accepted spec ((Finset.univ.erase (18 : Label)).erase 19)
      (certificate 18 19) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem all_accepted : ∀ a b : Label, a < b →
    accepted spec ((Finset.univ.erase a).erase b) (certificate a b) = true := by
  intro a b hab
  fin_cases a
  · fin_cases b
    · norm_num at hab
    · exact accepted00_01
    · exact accepted00_02
    · exact accepted00_03
    · exact accepted00_04
    · exact accepted00_05
    · exact accepted00_06
    · exact accepted00_07
    · exact accepted00_08
    · exact accepted00_09
    · exact accepted00_10
    · exact accepted00_11
    · exact accepted00_12
    · exact accepted00_13
    · exact accepted00_14
    · exact accepted00_15
    · exact accepted00_16
    · exact accepted00_17
    · exact accepted00_18
    · exact accepted00_19
  · fin_cases b
    · norm_num at hab
    · norm_num at hab
    · exact accepted01_02
    · exact accepted01_03
    · exact accepted01_04
    · exact accepted01_05
    · exact accepted01_06
    · exact accepted01_07
    · exact accepted01_08
    · exact accepted01_09
    · exact accepted01_10
    · exact accepted01_11
    · exact accepted01_12
    · exact accepted01_13
    · exact accepted01_14
    · exact accepted01_15
    · exact accepted01_16
    · exact accepted01_17
    · exact accepted01_18
    · exact accepted01_19
  · fin_cases b
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · exact accepted02_03
    · exact accepted02_04
    · exact accepted02_05
    · exact accepted02_06
    · exact accepted02_07
    · exact accepted02_08
    · exact accepted02_09
    · exact accepted02_10
    · exact accepted02_11
    · exact accepted02_12
    · exact accepted02_13
    · exact accepted02_14
    · exact accepted02_15
    · exact accepted02_16
    · exact accepted02_17
    · exact accepted02_18
    · exact accepted02_19
  · fin_cases b
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · exact accepted03_04
    · exact accepted03_05
    · exact accepted03_06
    · exact accepted03_07
    · exact accepted03_08
    · exact accepted03_09
    · exact accepted03_10
    · exact accepted03_11
    · exact accepted03_12
    · exact accepted03_13
    · exact accepted03_14
    · exact accepted03_15
    · exact accepted03_16
    · exact accepted03_17
    · exact accepted03_18
    · exact accepted03_19
  · fin_cases b
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · exact accepted04_05
    · exact accepted04_06
    · exact accepted04_07
    · exact accepted04_08
    · exact accepted04_09
    · exact accepted04_10
    · exact accepted04_11
    · exact accepted04_12
    · exact accepted04_13
    · exact accepted04_14
    · exact accepted04_15
    · exact accepted04_16
    · exact accepted04_17
    · exact accepted04_18
    · exact accepted04_19
  · fin_cases b
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · exact accepted05_06
    · exact accepted05_07
    · exact accepted05_08
    · exact accepted05_09
    · exact accepted05_10
    · exact accepted05_11
    · exact accepted05_12
    · exact accepted05_13
    · exact accepted05_14
    · exact accepted05_15
    · exact accepted05_16
    · exact accepted05_17
    · exact accepted05_18
    · exact accepted05_19
  · fin_cases b
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · exact accepted06_07
    · exact accepted06_08
    · exact accepted06_09
    · exact accepted06_10
    · exact accepted06_11
    · exact accepted06_12
    · exact accepted06_13
    · exact accepted06_14
    · exact accepted06_15
    · exact accepted06_16
    · exact accepted06_17
    · exact accepted06_18
    · exact accepted06_19
  · fin_cases b
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · exact accepted07_08
    · exact accepted07_09
    · exact accepted07_10
    · exact accepted07_11
    · exact accepted07_12
    · exact accepted07_13
    · exact accepted07_14
    · exact accepted07_15
    · exact accepted07_16
    · exact accepted07_17
    · exact accepted07_18
    · exact accepted07_19
  · fin_cases b
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · exact accepted08_09
    · exact accepted08_10
    · exact accepted08_11
    · exact accepted08_12
    · exact accepted08_13
    · exact accepted08_14
    · exact accepted08_15
    · exact accepted08_16
    · exact accepted08_17
    · exact accepted08_18
    · exact accepted08_19
  · fin_cases b
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · exact accepted09_10
    · exact accepted09_11
    · exact accepted09_12
    · exact accepted09_13
    · exact accepted09_14
    · exact accepted09_15
    · exact accepted09_16
    · exact accepted09_17
    · exact accepted09_18
    · exact accepted09_19
  · fin_cases b
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · exact accepted10_11
    · exact accepted10_12
    · exact accepted10_13
    · exact accepted10_14
    · exact accepted10_15
    · exact accepted10_16
    · exact accepted10_17
    · exact accepted10_18
    · exact accepted10_19
  · fin_cases b
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · exact accepted11_12
    · exact accepted11_13
    · exact accepted11_14
    · exact accepted11_15
    · exact accepted11_16
    · exact accepted11_17
    · exact accepted11_18
    · exact accepted11_19
  · fin_cases b
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · exact accepted12_13
    · exact accepted12_14
    · exact accepted12_15
    · exact accepted12_16
    · exact accepted12_17
    · exact accepted12_18
    · exact accepted12_19
  · fin_cases b
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · exact accepted13_14
    · exact accepted13_15
    · exact accepted13_16
    · exact accepted13_17
    · exact accepted13_18
    · exact accepted13_19
  · fin_cases b
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · exact accepted14_15
    · exact accepted14_16
    · exact accepted14_17
    · exact accepted14_18
    · exact accepted14_19
  · fin_cases b
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · exact accepted15_16
    · exact accepted15_17
    · exact accepted15_18
    · exact accepted15_19
  · fin_cases b
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · exact accepted16_17
    · exact accepted16_18
    · exact accepted16_19
  · fin_cases b
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · exact accepted17_18
    · exact accepted17_19
  · fin_cases b
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · exact accepted18_19
  · fin_cases b
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab
    · norm_num at hab

end Prize.JSP404.ThreeArcOrderData
