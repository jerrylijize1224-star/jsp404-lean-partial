import Prize.JSP404.ThreeArcMaskSteps
import Prize.JSP404.ThreeArcPerturb
import Prize.JSP404.ThreeArcNineteen
import Mathlib.Data.Fin.VecNotation

/-! Period translations and cyclic renaming normalize a three-arc row without
changing its periodic cover. Its normalized floor triple belongs to an explicit
twenty-entry table, in the same order as the existing mask list. -/
namespace Prize.JSP404.ThreeArcCanonical
open ContinuousDirection ThreeArcTwenty

def Covers {d : ℝ} (R S : ThreeArcRow d) : Prop :=
  ∀ x, R.Mem x → ∃ z : ℤ, S.Mem (x + 18 * z)

theorem covers_refl {d : ℝ} (R : ThreeArcRow d) : Covers R R := by
  intro x hx
  exact ⟨0, by simpa using hx⟩

theorem covers_trans {d : ℝ} {R S T : ThreeArcRow d}
    (hRS : Covers R S) (hST : Covers S T) : Covers R T := by
  intro x hx
  obtain ⟨z, hz⟩ := hRS x hx
  obtain ⟨w, hw⟩ := hST _ hz
  refine ⟨z + w, ?_⟩
  have he : x + 18 * ((z + w : ℤ) : ℝ) = (x + 18 * z) + 18 * w := by
    push_cast
    ring
  rw [he]
  exact hw

def periodTranslate {d : ℝ} (R : ThreeArcRow d) (q : ℤ) : ThreeArcRow d :=
  R.widenTranslate le_rfl (18 * q)

theorem covers_periodTranslate {d : ℝ} (R : ThreeArcRow d) (q : ℤ) :
    Covers R (periodTranslate R q) := by
  intro x hx
  exact ⟨q, R.mem_widenTranslate le_rfl hx le_rfl (by simp)⟩

def rotate {d : ℝ} (R : ThreeArcRow d) : ThreeArcRow d where
  a := R.b
  b := R.c
  c := R.a + 18
  ab := R.bc
  bc := R.ca
  ca := by linarith [R.ab]
  width0 := by linarith [R.width1]
  width1 := R.width2
  width2 := by linarith [R.width0]

theorem covers_rotate {d : ℝ} (R : ThreeArcRow d) : Covers R (rotate R) := by
  intro x hx
  rcases hx with hx | hx | hx
  · refine ⟨1, Or.inr (Or.inr ?_)⟩
    change (R.a + 18 ≤ x + 18 * (1 : ℤ) ∧
      x + 18 * (1 : ℤ) ≤ R.c + d)
    constructor <;> norm_num <;> linarith [hx.1, hx.2]
  · refine ⟨0, Or.inl ?_⟩
    change R.b ≤ x + 18 * (0 : ℤ) ∧ x + 18 * (0 : ℤ) ≤ R.a + 18 + d - 18
    constructor <;> norm_num <;> linarith [hx.1, hx.2]
  · refine ⟨0, Or.inr (Or.inl ?_)⟩
    change R.c ≤ x + 18 * (0 : ℤ) ∧ x + 18 * (0 : ℤ) ≤ R.b + d
    constructor <;> norm_num <;> linarith [hx.1, hx.2]

/-- Choose a cyclic first anchor so that all three starts lie in one period. -/
theorem exists_normalized {d : ℝ} (R : ThreeArcRow d) :
    ∃ S : ThreeArcRow d, 0 ≤ S.a ∧ S.c < 18 ∧ Covers R S := by
  let q : ℤ := ⌊R.a / 18⌋
  let T := periodTranslate R (-q)
  have hTa : T.a = R.a - 18 * q := by
    dsimp [T, periodTranslate, ThreeArcRow.widenTranslate]
    push_cast
    ring
  have hT0 : 0 ≤ T.a := by
    have h := Int.floor_le (R.a / 18)
    change (q : ℝ) ≤ R.a / 18 at h
    rw [hTa]
    linarith
  have hT18 : T.a < 18 := by
    have h := Int.lt_floor_add_one (R.a / 18)
    change R.a / 18 < (q : ℝ) + 1 at h
    rw [hTa]
    linarith
  have hRT : Covers R T := covers_periodTranslate R (-q)
  by_cases hc : T.c < 18
  · exact ⟨T, hT0, hc, hRT⟩
  · by_cases hb : T.b < 18
    · let S := periodTranslate (rotate (rotate T)) (-1)
      have hSa : S.a = T.c - 18 := by
        dsimp [S, periodTranslate, rotate, ThreeArcRow.widenTranslate]
        norm_num <;> ring
      have hSc : S.c = T.b := by
        dsimp [S, periodTranslate, rotate, ThreeArcRow.widenTranslate]
        norm_num
      refine ⟨S, ?_, ?_, ?_⟩
      · rw [hSa]; linarith
      · rw [hSc]; exact hb
      · exact covers_trans hRT (covers_trans (covers_rotate T)
          (covers_trans (covers_rotate (rotate T)) (covers_periodTranslate _ (-1))))
    · let S := periodTranslate (rotate T) (-1)
      have hSa : S.a = T.b - 18 := by
        dsimp [S, periodTranslate, rotate, ThreeArcRow.widenTranslate]
        norm_num <;> ring
      have hSc : S.c = T.a := by
        dsimp [S, periodTranslate, rotate, ThreeArcRow.widenTranslate]
        norm_num
      refine ⟨S, ?_, ?_, ?_⟩
      · rw [hSa]; linarith
      · rw [hSc]; exact hT18
      · exact covers_trans hRT (covers_trans (covers_rotate T)
          (covers_periodTranslate _ (-1)))

def starts : Fin 20 → Fin 3 → ℤ := ![
  ![0, 4, 8], ![0, 3, 7], ![3, 7, 9], ![0, 4, 7],
  ![0, 2, 6], ![2, 6, 9], ![2, 6, 8], ![0, 3, 6],
  ![3, 6, 9], ![0, 4, 6], ![1, 5, 9], ![1, 4, 8],
  ![1, 5, 8], ![1, 3, 7], ![1, 4, 7], ![1, 5, 7],
  ![2, 5, 9], ![2, 4, 8], ![2, 5, 8], ![3, 5, 9] ]

theorem normalized_triples_exhaustive : ∀ a b c : Fin 10,
    TripleValid a.val b.val c.val →
      ∃ t : Fin 20, starts t 0 = a.val ∧ starts t 1 = b.val ∧ starts t 2 = c.val := by
  unfold TripleValid
  decide +kernel

theorem normalized_row_floors {d : ℝ} (R : ThreeArcRow d) (hd : d < 36 / 5)
    (ha : 0 ≤ R.a) (hc : R.c < 18) :
    ∃ t : Fin 20, ∀ k : Fin 3, ⌊5 * R.start k / 9⌋ = starts t k := by
  have hv := rowFloors_valid R hd
  have ha0 : 0 ≤ ⌊5 * R.a / 9⌋ := Int.floor_nonneg.mpr (by linarith)
  have hc10 : ⌊5 * R.c / 9⌋ < 10 := by
    apply Int.floor_lt.mpr
    norm_num
    linarith
  have hb0 : 0 ≤ ⌊5 * R.b / 9⌋ := Int.floor_nonneg.mpr (by linarith [R.ab])
  have hc0 : 0 ≤ ⌊5 * R.c / 9⌋ := Int.floor_nonneg.mpr (by linarith [R.ab, R.bc])
  have hb10 : ⌊5 * R.b / 9⌋ < 10 := by
    apply Int.floor_lt.mpr
    norm_num
    linarith [R.bc]
  have ha10 : ⌊5 * R.a / 9⌋ < 10 := by
    apply Int.floor_lt.mpr
    norm_num
    linarith [R.ab, R.bc]
  let a : Fin 10 := ⟨(⌊5 * R.a / 9⌋).toNat, by omega⟩
  let b : Fin 10 := ⟨(⌊5 * R.b / 9⌋).toNat, by omega⟩
  let c : Fin 10 := ⟨(⌊5 * R.c / 9⌋).toNat, by omega⟩
  have heA : (a.val : ℤ) = ⌊5 * R.a / 9⌋ := by dsimp [a]; omega
  have heB : (b.val : ℤ) = ⌊5 * R.b / 9⌋ := by dsimp [b]; omega
  have heC : (c.val : ℤ) = ⌊5 * R.c / 9⌋ := by dsimp [c]; omega
  have hvalid : TripleValid a.val b.val c.val := by rw [heA, heB, heC]; exact hv
  obtain ⟨t, htA, htB, htC⟩ := normalized_triples_exhaustive a b c hvalid
  rw [heA] at htA
  rw [heB] at htB
  rw [heC] at htC
  refine ⟨t, ?_⟩
  intro k
  fin_cases k
  · simpa [ThreeArcRow.start] using htA.symm
  · simpa [ThreeArcRow.start] using htB.symm
  · simpa [ThreeArcRow.start] using htC.symm

theorem covers_pair_transfer {V : Type*} {d : ℝ} (R S : V → ThreeArcRow d)
    (hcover : ∀ i, Covers (R i) (S i))
    (hpair : ∀ i j, i ≠ j → ∃ x y : ℝ, ∃ z : ℤ,
      (R i).Mem x ∧ (R j).Mem y ∧ y = x + 9 + 18 * z) :
    ∀ i j, i ≠ j → ∃ x y : ℝ, ∃ z : ℤ,
      (S i).Mem x ∧ (S j).Mem y ∧ y = x + 9 + 18 * z := by
  intro i j hij
  obtain ⟨x, y, z, hx, hy, hxy⟩ := hpair i j hij
  obtain ⟨k, hk⟩ := hcover i x hx
  obtain ⟨l, hl⟩ := hcover j y hy
  refine ⟨x + 18 * k, y + 18 * l, z + l - k, hk, hl, ?_⟩
  push_cast
  linarith

theorem shape_of_floors {d : ℝ} (R : ThreeArcRow d) (t : Fin 20)
    (hf : ∀ k : Fin 3, ⌊5 * R.start k / 9⌋ = starts t k) :
    rowShape R = tripleShape (starts t 0) (starts t 1) (starts t 2) := by
  have h0 := hf 0
  have h1 := hf 1
  have h2 := hf 2
  simp only [ThreeArcRow.start] at h0 h1 h2
  norm_num at h0 h1 h2
  rw [rowShape_eq_tripleShape, h0, h1, h2]

theorem exists_canonical_family {V : Type*} {d : ℝ}
    (R : V → ThreeArcRow d) (hd : d < 36 / 5)
    (hpair : ∀ i j, i ≠ j → ∃ x y : ℝ, ∃ z : ℤ,
      (R i).Mem x ∧ (R j).Mem y ∧ y = x + 9 + 18 * z) :
    ∃ S : V → ThreeArcRow d, ∃ t : V → Fin 20,
      (∀ i k, ⌊5 * (S i).start k / 9⌋ = starts (t i) k) ∧
      Function.Injective t ∧
      (∀ i j, i ≠ j → ∃ x y : ℝ, ∃ z : ℤ,
        (S i).Mem x ∧ (S j).Mem y ∧ y = x + 9 + 18 * z) := by
  classical
  let S (i : V) := Classical.choose (exists_normalized (R i))
  have hS (i : V) := Classical.choose_spec (exists_normalized (R i))
  have hex (i : V) := normalized_row_floors (S i) hd (hS i).1 (hS i).2.1
  let t (i : V) := Classical.choose (hex i)
  have hf (i : V) : ∀ k, ⌊5 * (S i).start k / 9⌋ = starts (t i) k :=
    Classical.choose_spec (hex i)
  have hp := covers_pair_transfer R S (fun i => (hS i).2.2) hpair
  refine ⟨S, t, hf, ?_, hp⟩
  intro i j he
  apply family_masks_injective hd S hp
  change rowShape (S i) = rowShape (S j)
  rw [shape_of_floors (S i) (t i) (hf i), shape_of_floors (S j) (t j) (hf j), he]

end Prize.JSP404.ThreeArcCanonical
