import Prize.JSP404.ThreeArcOrder17Checks
import Prize.JSP404.ThreeArcOrderModelGeneral

/-! Checked strict-order refutations for all missing triples of the twenty
mask types exclude seventeen pairwise antipodally compatible three-arc rows.
The canonical continuous-to-order-model bridge adds no geometric hypothesis. -/
namespace Prize.JSP404.ThreeArcTwenty
open ContinuousDirection ThreeArcOrderCertificate

theorem no_seventeen_family {d : ℝ} (hd : d < 36 / 5)
    (R : Fin 17 → ThreeArcRow d)
    (hpair : ∀ i j, i ≠ j → ∃ x y : ℝ, ∃ z : ℤ,
      (R i).Mem x ∧ (R j).Mem y ∧ y = x + 9 + 18 * z) : False := by
  obtain ⟨t, ht, x, hx⟩ := ThreeArcOrderModelGeneral.exists_order_model R hd hpair
  obtain ⟨a, b, c, hab, hbc, ha⟩ := ThreeArcOrderModelGeneral.active_erase_triple t ht
  have hcheck := ThreeArcOrder17Data.all_accepted a b c hab hbc
  apply accepted_false ThreeArcOrder17Data.spec _
    (ThreeArcOrder17Data.certificate a b c) hcheck
  rw [← ha]
  exact ⟨x, hx⟩

theorem family_card_le_sixteen {V : Type*} [Fintype V] {d : ℝ}
    (hd : d < 36 / 5) (R : V → ThreeArcRow d)
    (hpair : ∀ i j, i ≠ j → ∃ x y : ℝ, ∃ z : ℤ,
      (R i).Mem x ∧ (R j).Mem y ∧ y = x + 9 + 18 * z) :
    Fintype.card V ≤ 16 := by
  by_contra hn
  have h17 : 17 ≤ Fintype.card V := by omega
  let e : Fin 17 → V := fun i => (Fintype.equivFin V).symm (Fin.castLE h17 i)
  have he : Function.Injective e := by
    intro i j h
    apply Fin.ext
    have hval := congrArg Fin.val ((Fintype.equivFin V).symm.injective h)
    exact hval
  exact no_seventeen_family hd (fun i => R (e i))
    (fun i j hij => hpair (e i) (e j) (he.ne hij))

end Prize.JSP404.ThreeArcTwenty
