import Prize.JSP404.ThreeArcOrderChecks
import Prize.JSP404.ThreeArcOrderModel

/-! All 190 possible missing pairs of the twenty masks have checked strict
order refutations. Canonicalization connects this finite exclusion to every
continuous three-arc family below 144 degrees. -/
namespace Prize.JSP404.ThreeArcTwenty
open ContinuousDirection ThreeArcOrderCertificate

theorem no_eighteen_family {d : ℝ} (hd : d < 36 / 5)
    (R : Fin 18 → ThreeArcRow d)
    (hpair : ∀ i j, i ≠ j → ∃ x y : ℝ, ∃ z : ℤ,
      (R i).Mem x ∧ (R j).Mem y ∧ y = x + 9 + 18 * z) : False := by
  obtain ⟨t, ht, x, hx⟩ := ThreeArcOrderModel.exists_order_model R hd hpair
  obtain ⟨a, b, hab, ha⟩ := ThreeArcOrderModel.active_erase_pair t ht
  have hcheck := ThreeArcOrderData.all_accepted a b hab
  apply accepted_false ThreeArcOrderData.spec _ (ThreeArcOrderData.certificate a b) hcheck
  rw [← ha]
  exact ⟨x, hx⟩

theorem family_card_le_seventeen {V : Type*} [Fintype V] {d : ℝ}
    (hd : d < 36 / 5) (R : V → ThreeArcRow d)
    (hpair : ∀ i j, i ≠ j → ∃ x y : ℝ, ∃ z : ℤ,
      (R i).Mem x ∧ (R j).Mem y ∧ y = x + 9 + 18 * z) :
    Fintype.card V ≤ 17 := by
  by_contra hn
  have h18 : 18 ≤ Fintype.card V := by omega
  let e : Fin 18 → V := fun i => (Fintype.equivFin V).symm (Fin.castLE h18 i)
  have he : Function.Injective e := by
    intro i j h
    apply Fin.ext
    have hval := congrArg Fin.val ((Fintype.equivFin V).symm.injective h)
    exact hval
  exact no_eighteen_family hd (fun i => R (e i))
    (fun i j hij => hpair (e i) (e j) (he.ne hij))

end Prize.JSP404.ThreeArcTwenty
