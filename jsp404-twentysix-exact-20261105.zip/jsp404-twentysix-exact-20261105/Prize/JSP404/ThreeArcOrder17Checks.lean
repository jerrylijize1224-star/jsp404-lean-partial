import Prize.JSP404.ThreeArcOrder17Data
import Mathlib.Tactic.FinCases

/-! Kernel checking and finite assembly for every missing triple. -/
namespace Prize.JSP404.ThreeArcOrder17Data
open ThreeArcOrderCertificate

theorem accepted00_01_02 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 1).erase 2)
      (certificate 0 1 2) = true := by
  decide +kernel

theorem accepted00_01_03 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 1).erase 3)
      (certificate 0 1 3) = true := by
  decide +kernel

theorem accepted00_01_04 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 1).erase 4)
      (certificate 0 1 4) = true := by
  decide +kernel

theorem accepted00_01_05 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 1).erase 5)
      (certificate 0 1 5) = true := by
  decide +kernel

theorem accepted00_01_06 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 1).erase 6)
      (certificate 0 1 6) = true := by
  decide +kernel

theorem accepted00_01_07 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 1).erase 7)
      (certificate 0 1 7) = true := by
  decide +kernel

theorem accepted00_01_08 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 1).erase 8)
      (certificate 0 1 8) = true := by
  decide +kernel

theorem accepted00_01_09 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 1).erase 9)
      (certificate 0 1 9) = true := by
  decide +kernel

theorem accepted00_01_10 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 1).erase 10)
      (certificate 0 1 10) = true := by
  decide +kernel

theorem accepted00_01_11 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 1).erase 11)
      (certificate 0 1 11) = true := by
  decide +kernel

theorem accepted00_01_12 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 1).erase 12)
      (certificate 0 1 12) = true := by
  decide +kernel

theorem accepted00_01_13 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 1).erase 13)
      (certificate 0 1 13) = true := by
  decide +kernel

theorem accepted00_01_14 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 1).erase 14)
      (certificate 0 1 14) = true := by
  decide +kernel

theorem accepted00_01_15 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 1).erase 15)
      (certificate 0 1 15) = true := by
  decide +kernel

theorem accepted00_01_16 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 1).erase 16)
      (certificate 0 1 16) = true := by
  decide +kernel

theorem accepted00_01_17 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 1).erase 17)
      (certificate 0 1 17) = true := by
  decide +kernel

theorem accepted00_01_18 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 1).erase 18)
      (certificate 0 1 18) = true := by
  decide +kernel

theorem accepted00_01_19 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 1).erase 19)
      (certificate 0 1 19) = true := by
  decide +kernel

theorem accepted00_02_03 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 2).erase 3)
      (certificate 0 2 3) = true := by
  decide +kernel

theorem accepted00_02_04 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 2).erase 4)
      (certificate 0 2 4) = true := by
  decide +kernel

theorem accepted00_02_05 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 2).erase 5)
      (certificate 0 2 5) = true := by
  decide +kernel

theorem accepted00_02_06 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 2).erase 6)
      (certificate 0 2 6) = true := by
  decide +kernel

theorem accepted00_02_07 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 2).erase 7)
      (certificate 0 2 7) = true := by
  decide +kernel

theorem accepted00_02_08 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 2).erase 8)
      (certificate 0 2 8) = true := by
  decide +kernel

theorem accepted00_02_09 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 2).erase 9)
      (certificate 0 2 9) = true := by
  decide +kernel

theorem accepted00_02_10 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 2).erase 10)
      (certificate 0 2 10) = true := by
  decide +kernel

theorem accepted00_02_11 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 2).erase 11)
      (certificate 0 2 11) = true := by
  decide +kernel

theorem accepted00_02_12 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 2).erase 12)
      (certificate 0 2 12) = true := by
  decide +kernel

theorem accepted00_02_13 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 2).erase 13)
      (certificate 0 2 13) = true := by
  decide +kernel

theorem accepted00_02_14 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 2).erase 14)
      (certificate 0 2 14) = true := by
  decide +kernel

theorem accepted00_02_15 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 2).erase 15)
      (certificate 0 2 15) = true := by
  decide +kernel

theorem accepted00_02_16 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 2).erase 16)
      (certificate 0 2 16) = true := by
  decide +kernel

theorem accepted00_02_17 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 2).erase 17)
      (certificate 0 2 17) = true := by
  decide +kernel

theorem accepted00_02_18 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 2).erase 18)
      (certificate 0 2 18) = true := by
  decide +kernel

theorem accepted00_02_19 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 2).erase 19)
      (certificate 0 2 19) = true := by
  decide +kernel

theorem accepted00_03_04 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 3).erase 4)
      (certificate 0 3 4) = true := by
  decide +kernel

theorem accepted00_03_05 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 3).erase 5)
      (certificate 0 3 5) = true := by
  decide +kernel

theorem accepted00_03_06 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 3).erase 6)
      (certificate 0 3 6) = true := by
  decide +kernel

theorem accepted00_03_07 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 3).erase 7)
      (certificate 0 3 7) = true := by
  decide +kernel

theorem accepted00_03_08 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 3).erase 8)
      (certificate 0 3 8) = true := by
  decide +kernel

theorem accepted00_03_09 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 3).erase 9)
      (certificate 0 3 9) = true := by
  decide +kernel

theorem accepted00_03_10 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 3).erase 10)
      (certificate 0 3 10) = true := by
  decide +kernel

theorem accepted00_03_11 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 3).erase 11)
      (certificate 0 3 11) = true := by
  decide +kernel

theorem accepted00_03_12 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 3).erase 12)
      (certificate 0 3 12) = true := by
  decide +kernel

theorem accepted00_03_13 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 3).erase 13)
      (certificate 0 3 13) = true := by
  decide +kernel

theorem accepted00_03_14 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 3).erase 14)
      (certificate 0 3 14) = true := by
  decide +kernel

theorem accepted00_03_15 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 3).erase 15)
      (certificate 0 3 15) = true := by
  decide +kernel

theorem accepted00_03_16 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 3).erase 16)
      (certificate 0 3 16) = true := by
  decide +kernel

theorem accepted00_03_17 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 3).erase 17)
      (certificate 0 3 17) = true := by
  decide +kernel

theorem accepted00_03_18 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 3).erase 18)
      (certificate 0 3 18) = true := by
  decide +kernel

theorem accepted00_03_19 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 3).erase 19)
      (certificate 0 3 19) = true := by
  decide +kernel

theorem accepted00_04_05 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 4).erase 5)
      (certificate 0 4 5) = true := by
  decide +kernel

theorem accepted00_04_06 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 4).erase 6)
      (certificate 0 4 6) = true := by
  decide +kernel

theorem accepted00_04_07 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 4).erase 7)
      (certificate 0 4 7) = true := by
  decide +kernel

theorem accepted00_04_08 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 4).erase 8)
      (certificate 0 4 8) = true := by
  decide +kernel

theorem accepted00_04_09 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 4).erase 9)
      (certificate 0 4 9) = true := by
  decide +kernel

theorem accepted00_04_10 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 4).erase 10)
      (certificate 0 4 10) = true := by
  decide +kernel

theorem accepted00_04_11 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 4).erase 11)
      (certificate 0 4 11) = true := by
  decide +kernel

theorem accepted00_04_12 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 4).erase 12)
      (certificate 0 4 12) = true := by
  decide +kernel

theorem accepted00_04_13 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 4).erase 13)
      (certificate 0 4 13) = true := by
  decide +kernel

theorem accepted00_04_14 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 4).erase 14)
      (certificate 0 4 14) = true := by
  decide +kernel

theorem accepted00_04_15 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 4).erase 15)
      (certificate 0 4 15) = true := by
  decide +kernel

theorem accepted00_04_16 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 4).erase 16)
      (certificate 0 4 16) = true := by
  decide +kernel

theorem accepted00_04_17 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 4).erase 17)
      (certificate 0 4 17) = true := by
  decide +kernel

theorem accepted00_04_18 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 4).erase 18)
      (certificate 0 4 18) = true := by
  decide +kernel

theorem accepted00_04_19 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 4).erase 19)
      (certificate 0 4 19) = true := by
  decide +kernel

theorem accepted00_05_06 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 5).erase 6)
      (certificate 0 5 6) = true := by
  decide +kernel

theorem accepted00_05_07 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 5).erase 7)
      (certificate 0 5 7) = true := by
  decide +kernel

theorem accepted00_05_08 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 5).erase 8)
      (certificate 0 5 8) = true := by
  decide +kernel

theorem accepted00_05_09 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 5).erase 9)
      (certificate 0 5 9) = true := by
  decide +kernel

theorem accepted00_05_10 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 5).erase 10)
      (certificate 0 5 10) = true := by
  decide +kernel

theorem accepted00_05_11 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 5).erase 11)
      (certificate 0 5 11) = true := by
  decide +kernel

theorem accepted00_05_12 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 5).erase 12)
      (certificate 0 5 12) = true := by
  decide +kernel

theorem accepted00_05_13 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 5).erase 13)
      (certificate 0 5 13) = true := by
  decide +kernel

theorem accepted00_05_14 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 5).erase 14)
      (certificate 0 5 14) = true := by
  decide +kernel

theorem accepted00_05_15 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 5).erase 15)
      (certificate 0 5 15) = true := by
  decide +kernel

theorem accepted00_05_16 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 5).erase 16)
      (certificate 0 5 16) = true := by
  decide +kernel

theorem accepted00_05_17 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 5).erase 17)
      (certificate 0 5 17) = true := by
  decide +kernel

theorem accepted00_05_18 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 5).erase 18)
      (certificate 0 5 18) = true := by
  decide +kernel

theorem accepted00_05_19 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 5).erase 19)
      (certificate 0 5 19) = true := by
  decide +kernel

theorem accepted00_06_07 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 6).erase 7)
      (certificate 0 6 7) = true := by
  decide +kernel

theorem accepted00_06_08 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 6).erase 8)
      (certificate 0 6 8) = true := by
  decide +kernel

theorem accepted00_06_09 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 6).erase 9)
      (certificate 0 6 9) = true := by
  decide +kernel

theorem accepted00_06_10 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 6).erase 10)
      (certificate 0 6 10) = true := by
  decide +kernel

theorem accepted00_06_11 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 6).erase 11)
      (certificate 0 6 11) = true := by
  decide +kernel

theorem accepted00_06_12 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 6).erase 12)
      (certificate 0 6 12) = true := by
  decide +kernel

theorem accepted00_06_13 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 6).erase 13)
      (certificate 0 6 13) = true := by
  decide +kernel

theorem accepted00_06_14 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 6).erase 14)
      (certificate 0 6 14) = true := by
  decide +kernel

theorem accepted00_06_15 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 6).erase 15)
      (certificate 0 6 15) = true := by
  decide +kernel

theorem accepted00_06_16 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 6).erase 16)
      (certificate 0 6 16) = true := by
  decide +kernel

theorem accepted00_06_17 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 6).erase 17)
      (certificate 0 6 17) = true := by
  decide +kernel

theorem accepted00_06_18 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 6).erase 18)
      (certificate 0 6 18) = true := by
  decide +kernel

theorem accepted00_06_19 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 6).erase 19)
      (certificate 0 6 19) = true := by
  decide +kernel

theorem accepted00_07_08 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 7).erase 8)
      (certificate 0 7 8) = true := by
  decide +kernel

theorem accepted00_07_09 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 7).erase 9)
      (certificate 0 7 9) = true := by
  decide +kernel

theorem accepted00_07_10 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 7).erase 10)
      (certificate 0 7 10) = true := by
  decide +kernel

theorem accepted00_07_11 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 7).erase 11)
      (certificate 0 7 11) = true := by
  decide +kernel

theorem accepted00_07_12 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 7).erase 12)
      (certificate 0 7 12) = true := by
  decide +kernel

theorem accepted00_07_13 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 7).erase 13)
      (certificate 0 7 13) = true := by
  decide +kernel

theorem accepted00_07_14 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 7).erase 14)
      (certificate 0 7 14) = true := by
  decide +kernel

theorem accepted00_07_15 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 7).erase 15)
      (certificate 0 7 15) = true := by
  decide +kernel

theorem accepted00_07_16 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 7).erase 16)
      (certificate 0 7 16) = true := by
  decide +kernel

theorem accepted00_07_17 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 7).erase 17)
      (certificate 0 7 17) = true := by
  decide +kernel

theorem accepted00_07_18 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 7).erase 18)
      (certificate 0 7 18) = true := by
  decide +kernel

theorem accepted00_07_19 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 7).erase 19)
      (certificate 0 7 19) = true := by
  decide +kernel

theorem accepted00_08_09 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 8).erase 9)
      (certificate 0 8 9) = true := by
  decide +kernel

theorem accepted00_08_10 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 8).erase 10)
      (certificate 0 8 10) = true := by
  decide +kernel

theorem accepted00_08_11 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 8).erase 11)
      (certificate 0 8 11) = true := by
  decide +kernel

theorem accepted00_08_12 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 8).erase 12)
      (certificate 0 8 12) = true := by
  decide +kernel

theorem accepted00_08_13 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 8).erase 13)
      (certificate 0 8 13) = true := by
  decide +kernel

theorem accepted00_08_14 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 8).erase 14)
      (certificate 0 8 14) = true := by
  decide +kernel

theorem accepted00_08_15 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 8).erase 15)
      (certificate 0 8 15) = true := by
  decide +kernel

theorem accepted00_08_16 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 8).erase 16)
      (certificate 0 8 16) = true := by
  decide +kernel

theorem accepted00_08_17 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 8).erase 17)
      (certificate 0 8 17) = true := by
  decide +kernel

theorem accepted00_08_18 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 8).erase 18)
      (certificate 0 8 18) = true := by
  decide +kernel

theorem accepted00_08_19 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 8).erase 19)
      (certificate 0 8 19) = true := by
  decide +kernel

theorem accepted00_09_10 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 9).erase 10)
      (certificate 0 9 10) = true := by
  decide +kernel

theorem accepted00_09_11 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 9).erase 11)
      (certificate 0 9 11) = true := by
  decide +kernel

theorem accepted00_09_12 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 9).erase 12)
      (certificate 0 9 12) = true := by
  decide +kernel

theorem accepted00_09_13 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 9).erase 13)
      (certificate 0 9 13) = true := by
  decide +kernel

theorem accepted00_09_14 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 9).erase 14)
      (certificate 0 9 14) = true := by
  decide +kernel

theorem accepted00_09_15 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 9).erase 15)
      (certificate 0 9 15) = true := by
  decide +kernel

theorem accepted00_09_16 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 9).erase 16)
      (certificate 0 9 16) = true := by
  decide +kernel

theorem accepted00_09_17 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 9).erase 17)
      (certificate 0 9 17) = true := by
  decide +kernel

theorem accepted00_09_18 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 9).erase 18)
      (certificate 0 9 18) = true := by
  decide +kernel

theorem accepted00_09_19 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 9).erase 19)
      (certificate 0 9 19) = true := by
  decide +kernel

theorem accepted00_10_11 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 10).erase 11)
      (certificate 0 10 11) = true := by
  decide +kernel

theorem accepted00_10_12 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 10).erase 12)
      (certificate 0 10 12) = true := by
  decide +kernel

theorem accepted00_10_13 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 10).erase 13)
      (certificate 0 10 13) = true := by
  decide +kernel

theorem accepted00_10_14 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 10).erase 14)
      (certificate 0 10 14) = true := by
  decide +kernel

theorem accepted00_10_15 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 10).erase 15)
      (certificate 0 10 15) = true := by
  decide +kernel

theorem accepted00_10_16 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 10).erase 16)
      (certificate 0 10 16) = true := by
  decide +kernel

theorem accepted00_10_17 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 10).erase 17)
      (certificate 0 10 17) = true := by
  decide +kernel

theorem accepted00_10_18 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 10).erase 18)
      (certificate 0 10 18) = true := by
  decide +kernel

theorem accepted00_10_19 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 10).erase 19)
      (certificate 0 10 19) = true := by
  decide +kernel

theorem accepted00_11_12 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 11).erase 12)
      (certificate 0 11 12) = true := by
  decide +kernel

theorem accepted00_11_13 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 11).erase 13)
      (certificate 0 11 13) = true := by
  decide +kernel

theorem accepted00_11_14 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 11).erase 14)
      (certificate 0 11 14) = true := by
  decide +kernel

theorem accepted00_11_15 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 11).erase 15)
      (certificate 0 11 15) = true := by
  decide +kernel

theorem accepted00_11_16 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 11).erase 16)
      (certificate 0 11 16) = true := by
  decide +kernel

theorem accepted00_11_17 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 11).erase 17)
      (certificate 0 11 17) = true := by
  decide +kernel

theorem accepted00_11_18 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 11).erase 18)
      (certificate 0 11 18) = true := by
  decide +kernel

theorem accepted00_11_19 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 11).erase 19)
      (certificate 0 11 19) = true := by
  decide +kernel

theorem accepted00_12_13 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 12).erase 13)
      (certificate 0 12 13) = true := by
  decide +kernel

theorem accepted00_12_14 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 12).erase 14)
      (certificate 0 12 14) = true := by
  decide +kernel

theorem accepted00_12_15 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 12).erase 15)
      (certificate 0 12 15) = true := by
  decide +kernel

theorem accepted00_12_16 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 12).erase 16)
      (certificate 0 12 16) = true := by
  decide +kernel

theorem accepted00_12_17 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 12).erase 17)
      (certificate 0 12 17) = true := by
  decide +kernel

theorem accepted00_12_18 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 12).erase 18)
      (certificate 0 12 18) = true := by
  decide +kernel

theorem accepted00_12_19 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 12).erase 19)
      (certificate 0 12 19) = true := by
  decide +kernel

theorem accepted00_13_14 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 13).erase 14)
      (certificate 0 13 14) = true := by
  decide +kernel

theorem accepted00_13_15 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 13).erase 15)
      (certificate 0 13 15) = true := by
  decide +kernel

theorem accepted00_13_16 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 13).erase 16)
      (certificate 0 13 16) = true := by
  decide +kernel

theorem accepted00_13_17 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 13).erase 17)
      (certificate 0 13 17) = true := by
  decide +kernel

theorem accepted00_13_18 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 13).erase 18)
      (certificate 0 13 18) = true := by
  decide +kernel

theorem accepted00_13_19 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 13).erase 19)
      (certificate 0 13 19) = true := by
  decide +kernel

theorem accepted00_14_15 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 14).erase 15)
      (certificate 0 14 15) = true := by
  decide +kernel

theorem accepted00_14_16 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 14).erase 16)
      (certificate 0 14 16) = true := by
  decide +kernel

theorem accepted00_14_17 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 14).erase 17)
      (certificate 0 14 17) = true := by
  decide +kernel

theorem accepted00_14_18 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 14).erase 18)
      (certificate 0 14 18) = true := by
  decide +kernel

theorem accepted00_14_19 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 14).erase 19)
      (certificate 0 14 19) = true := by
  decide +kernel

theorem accepted00_15_16 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 15).erase 16)
      (certificate 0 15 16) = true := by
  decide +kernel

theorem accepted00_15_17 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 15).erase 17)
      (certificate 0 15 17) = true := by
  decide +kernel

theorem accepted00_15_18 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 15).erase 18)
      (certificate 0 15 18) = true := by
  decide +kernel

theorem accepted00_15_19 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 15).erase 19)
      (certificate 0 15 19) = true := by
  decide +kernel

theorem accepted00_16_17 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 16).erase 17)
      (certificate 0 16 17) = true := by
  decide +kernel

theorem accepted00_16_18 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 16).erase 18)
      (certificate 0 16 18) = true := by
  decide +kernel

theorem accepted00_16_19 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 16).erase 19)
      (certificate 0 16 19) = true := by
  decide +kernel

theorem accepted00_17_18 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 17).erase 18)
      (certificate 0 17 18) = true := by
  decide +kernel

theorem accepted00_17_19 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 17).erase 19)
      (certificate 0 17 19) = true := by
  decide +kernel

theorem accepted00_18_19 :
    accepted spec (((Finset.univ.erase (0 : Label)).erase 18).erase 19)
      (certificate 0 18 19) = true := by
  decide +kernel

theorem accepted01_02_03 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 2).erase 3)
      (certificate 1 2 3) = true := by
  decide +kernel

theorem accepted01_02_04 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 2).erase 4)
      (certificate 1 2 4) = true := by
  decide +kernel

theorem accepted01_02_05 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 2).erase 5)
      (certificate 1 2 5) = true := by
  decide +kernel

theorem accepted01_02_06 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 2).erase 6)
      (certificate 1 2 6) = true := by
  decide +kernel

theorem accepted01_02_07 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 2).erase 7)
      (certificate 1 2 7) = true := by
  decide +kernel

theorem accepted01_02_08 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 2).erase 8)
      (certificate 1 2 8) = true := by
  decide +kernel

theorem accepted01_02_09 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 2).erase 9)
      (certificate 1 2 9) = true := by
  decide +kernel

theorem accepted01_02_10 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 2).erase 10)
      (certificate 1 2 10) = true := by
  decide +kernel

theorem accepted01_02_11 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 2).erase 11)
      (certificate 1 2 11) = true := by
  decide +kernel

theorem accepted01_02_12 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 2).erase 12)
      (certificate 1 2 12) = true := by
  decide +kernel

theorem accepted01_02_13 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 2).erase 13)
      (certificate 1 2 13) = true := by
  decide +kernel

theorem accepted01_02_14 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 2).erase 14)
      (certificate 1 2 14) = true := by
  decide +kernel

theorem accepted01_02_15 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 2).erase 15)
      (certificate 1 2 15) = true := by
  decide +kernel

theorem accepted01_02_16 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 2).erase 16)
      (certificate 1 2 16) = true := by
  decide +kernel

theorem accepted01_02_17 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 2).erase 17)
      (certificate 1 2 17) = true := by
  decide +kernel

theorem accepted01_02_18 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 2).erase 18)
      (certificate 1 2 18) = true := by
  decide +kernel

theorem accepted01_02_19 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 2).erase 19)
      (certificate 1 2 19) = true := by
  decide +kernel

theorem accepted01_03_04 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 3).erase 4)
      (certificate 1 3 4) = true := by
  decide +kernel

theorem accepted01_03_05 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 3).erase 5)
      (certificate 1 3 5) = true := by
  decide +kernel

theorem accepted01_03_06 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 3).erase 6)
      (certificate 1 3 6) = true := by
  decide +kernel

theorem accepted01_03_07 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 3).erase 7)
      (certificate 1 3 7) = true := by
  decide +kernel

theorem accepted01_03_08 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 3).erase 8)
      (certificate 1 3 8) = true := by
  decide +kernel

theorem accepted01_03_09 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 3).erase 9)
      (certificate 1 3 9) = true := by
  decide +kernel

theorem accepted01_03_10 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 3).erase 10)
      (certificate 1 3 10) = true := by
  decide +kernel

theorem accepted01_03_11 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 3).erase 11)
      (certificate 1 3 11) = true := by
  decide +kernel

theorem accepted01_03_12 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 3).erase 12)
      (certificate 1 3 12) = true := by
  decide +kernel

theorem accepted01_03_13 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 3).erase 13)
      (certificate 1 3 13) = true := by
  decide +kernel

theorem accepted01_03_14 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 3).erase 14)
      (certificate 1 3 14) = true := by
  decide +kernel

theorem accepted01_03_15 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 3).erase 15)
      (certificate 1 3 15) = true := by
  decide +kernel

theorem accepted01_03_16 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 3).erase 16)
      (certificate 1 3 16) = true := by
  decide +kernel

theorem accepted01_03_17 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 3).erase 17)
      (certificate 1 3 17) = true := by
  decide +kernel

theorem accepted01_03_18 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 3).erase 18)
      (certificate 1 3 18) = true := by
  decide +kernel

theorem accepted01_03_19 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 3).erase 19)
      (certificate 1 3 19) = true := by
  decide +kernel

theorem accepted01_04_05 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 4).erase 5)
      (certificate 1 4 5) = true := by
  decide +kernel

theorem accepted01_04_06 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 4).erase 6)
      (certificate 1 4 6) = true := by
  decide +kernel

theorem accepted01_04_07 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 4).erase 7)
      (certificate 1 4 7) = true := by
  decide +kernel

theorem accepted01_04_08 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 4).erase 8)
      (certificate 1 4 8) = true := by
  decide +kernel

theorem accepted01_04_09 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 4).erase 9)
      (certificate 1 4 9) = true := by
  decide +kernel

theorem accepted01_04_10 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 4).erase 10)
      (certificate 1 4 10) = true := by
  decide +kernel

theorem accepted01_04_11 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 4).erase 11)
      (certificate 1 4 11) = true := by
  decide +kernel

theorem accepted01_04_12 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 4).erase 12)
      (certificate 1 4 12) = true := by
  decide +kernel

theorem accepted01_04_13 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 4).erase 13)
      (certificate 1 4 13) = true := by
  decide +kernel

theorem accepted01_04_14 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 4).erase 14)
      (certificate 1 4 14) = true := by
  decide +kernel

theorem accepted01_04_15 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 4).erase 15)
      (certificate 1 4 15) = true := by
  decide +kernel

theorem accepted01_04_16 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 4).erase 16)
      (certificate 1 4 16) = true := by
  decide +kernel

theorem accepted01_04_17 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 4).erase 17)
      (certificate 1 4 17) = true := by
  decide +kernel

theorem accepted01_04_18 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 4).erase 18)
      (certificate 1 4 18) = true := by
  decide +kernel

theorem accepted01_04_19 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 4).erase 19)
      (certificate 1 4 19) = true := by
  decide +kernel

theorem accepted01_05_06 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 5).erase 6)
      (certificate 1 5 6) = true := by
  decide +kernel

theorem accepted01_05_07 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 5).erase 7)
      (certificate 1 5 7) = true := by
  decide +kernel

theorem accepted01_05_08 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 5).erase 8)
      (certificate 1 5 8) = true := by
  decide +kernel

theorem accepted01_05_09 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 5).erase 9)
      (certificate 1 5 9) = true := by
  decide +kernel

theorem accepted01_05_10 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 5).erase 10)
      (certificate 1 5 10) = true := by
  decide +kernel

theorem accepted01_05_11 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 5).erase 11)
      (certificate 1 5 11) = true := by
  decide +kernel

theorem accepted01_05_12 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 5).erase 12)
      (certificate 1 5 12) = true := by
  decide +kernel

theorem accepted01_05_13 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 5).erase 13)
      (certificate 1 5 13) = true := by
  decide +kernel

theorem accepted01_05_14 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 5).erase 14)
      (certificate 1 5 14) = true := by
  decide +kernel

theorem accepted01_05_15 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 5).erase 15)
      (certificate 1 5 15) = true := by
  decide +kernel

theorem accepted01_05_16 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 5).erase 16)
      (certificate 1 5 16) = true := by
  decide +kernel

theorem accepted01_05_17 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 5).erase 17)
      (certificate 1 5 17) = true := by
  decide +kernel

theorem accepted01_05_18 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 5).erase 18)
      (certificate 1 5 18) = true := by
  decide +kernel

theorem accepted01_05_19 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 5).erase 19)
      (certificate 1 5 19) = true := by
  decide +kernel

theorem accepted01_06_07 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 6).erase 7)
      (certificate 1 6 7) = true := by
  decide +kernel

theorem accepted01_06_08 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 6).erase 8)
      (certificate 1 6 8) = true := by
  decide +kernel

theorem accepted01_06_09 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 6).erase 9)
      (certificate 1 6 9) = true := by
  decide +kernel

theorem accepted01_06_10 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 6).erase 10)
      (certificate 1 6 10) = true := by
  decide +kernel

theorem accepted01_06_11 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 6).erase 11)
      (certificate 1 6 11) = true := by
  decide +kernel

theorem accepted01_06_12 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 6).erase 12)
      (certificate 1 6 12) = true := by
  decide +kernel

theorem accepted01_06_13 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 6).erase 13)
      (certificate 1 6 13) = true := by
  decide +kernel

theorem accepted01_06_14 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 6).erase 14)
      (certificate 1 6 14) = true := by
  decide +kernel

theorem accepted01_06_15 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 6).erase 15)
      (certificate 1 6 15) = true := by
  decide +kernel

theorem accepted01_06_16 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 6).erase 16)
      (certificate 1 6 16) = true := by
  decide +kernel

theorem accepted01_06_17 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 6).erase 17)
      (certificate 1 6 17) = true := by
  decide +kernel

theorem accepted01_06_18 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 6).erase 18)
      (certificate 1 6 18) = true := by
  decide +kernel

theorem accepted01_06_19 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 6).erase 19)
      (certificate 1 6 19) = true := by
  decide +kernel

theorem accepted01_07_08 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 7).erase 8)
      (certificate 1 7 8) = true := by
  decide +kernel

theorem accepted01_07_09 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 7).erase 9)
      (certificate 1 7 9) = true := by
  decide +kernel

theorem accepted01_07_10 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 7).erase 10)
      (certificate 1 7 10) = true := by
  decide +kernel

theorem accepted01_07_11 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 7).erase 11)
      (certificate 1 7 11) = true := by
  decide +kernel

theorem accepted01_07_12 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 7).erase 12)
      (certificate 1 7 12) = true := by
  decide +kernel

theorem accepted01_07_13 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 7).erase 13)
      (certificate 1 7 13) = true := by
  decide +kernel

theorem accepted01_07_14 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 7).erase 14)
      (certificate 1 7 14) = true := by
  decide +kernel

theorem accepted01_07_15 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 7).erase 15)
      (certificate 1 7 15) = true := by
  decide +kernel

theorem accepted01_07_16 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 7).erase 16)
      (certificate 1 7 16) = true := by
  decide +kernel

theorem accepted01_07_17 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 7).erase 17)
      (certificate 1 7 17) = true := by
  decide +kernel

theorem accepted01_07_18 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 7).erase 18)
      (certificate 1 7 18) = true := by
  decide +kernel

theorem accepted01_07_19 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 7).erase 19)
      (certificate 1 7 19) = true := by
  decide +kernel

theorem accepted01_08_09 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 8).erase 9)
      (certificate 1 8 9) = true := by
  decide +kernel

theorem accepted01_08_10 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 8).erase 10)
      (certificate 1 8 10) = true := by
  decide +kernel

theorem accepted01_08_11 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 8).erase 11)
      (certificate 1 8 11) = true := by
  decide +kernel

theorem accepted01_08_12 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 8).erase 12)
      (certificate 1 8 12) = true := by
  decide +kernel

theorem accepted01_08_13 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 8).erase 13)
      (certificate 1 8 13) = true := by
  decide +kernel

theorem accepted01_08_14 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 8).erase 14)
      (certificate 1 8 14) = true := by
  decide +kernel

theorem accepted01_08_15 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 8).erase 15)
      (certificate 1 8 15) = true := by
  decide +kernel

theorem accepted01_08_16 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 8).erase 16)
      (certificate 1 8 16) = true := by
  decide +kernel

theorem accepted01_08_17 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 8).erase 17)
      (certificate 1 8 17) = true := by
  decide +kernel

theorem accepted01_08_18 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 8).erase 18)
      (certificate 1 8 18) = true := by
  decide +kernel

theorem accepted01_08_19 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 8).erase 19)
      (certificate 1 8 19) = true := by
  decide +kernel

theorem accepted01_09_10 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 9).erase 10)
      (certificate 1 9 10) = true := by
  decide +kernel

theorem accepted01_09_11 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 9).erase 11)
      (certificate 1 9 11) = true := by
  decide +kernel

theorem accepted01_09_12 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 9).erase 12)
      (certificate 1 9 12) = true := by
  decide +kernel

theorem accepted01_09_13 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 9).erase 13)
      (certificate 1 9 13) = true := by
  decide +kernel

theorem accepted01_09_14 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 9).erase 14)
      (certificate 1 9 14) = true := by
  decide +kernel

theorem accepted01_09_15 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 9).erase 15)
      (certificate 1 9 15) = true := by
  decide +kernel

theorem accepted01_09_16 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 9).erase 16)
      (certificate 1 9 16) = true := by
  decide +kernel

theorem accepted01_09_17 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 9).erase 17)
      (certificate 1 9 17) = true := by
  decide +kernel

theorem accepted01_09_18 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 9).erase 18)
      (certificate 1 9 18) = true := by
  decide +kernel

theorem accepted01_09_19 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 9).erase 19)
      (certificate 1 9 19) = true := by
  decide +kernel

theorem accepted01_10_11 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 10).erase 11)
      (certificate 1 10 11) = true := by
  decide +kernel

theorem accepted01_10_12 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 10).erase 12)
      (certificate 1 10 12) = true := by
  decide +kernel

theorem accepted01_10_13 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 10).erase 13)
      (certificate 1 10 13) = true := by
  decide +kernel

theorem accepted01_10_14 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 10).erase 14)
      (certificate 1 10 14) = true := by
  decide +kernel

theorem accepted01_10_15 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 10).erase 15)
      (certificate 1 10 15) = true := by
  decide +kernel

theorem accepted01_10_16 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 10).erase 16)
      (certificate 1 10 16) = true := by
  decide +kernel

theorem accepted01_10_17 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 10).erase 17)
      (certificate 1 10 17) = true := by
  decide +kernel

theorem accepted01_10_18 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 10).erase 18)
      (certificate 1 10 18) = true := by
  decide +kernel

theorem accepted01_10_19 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 10).erase 19)
      (certificate 1 10 19) = true := by
  decide +kernel

theorem accepted01_11_12 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 11).erase 12)
      (certificate 1 11 12) = true := by
  decide +kernel

theorem accepted01_11_13 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 11).erase 13)
      (certificate 1 11 13) = true := by
  decide +kernel

theorem accepted01_11_14 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 11).erase 14)
      (certificate 1 11 14) = true := by
  decide +kernel

theorem accepted01_11_15 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 11).erase 15)
      (certificate 1 11 15) = true := by
  decide +kernel

theorem accepted01_11_16 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 11).erase 16)
      (certificate 1 11 16) = true := by
  decide +kernel

theorem accepted01_11_17 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 11).erase 17)
      (certificate 1 11 17) = true := by
  decide +kernel

theorem accepted01_11_18 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 11).erase 18)
      (certificate 1 11 18) = true := by
  decide +kernel

theorem accepted01_11_19 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 11).erase 19)
      (certificate 1 11 19) = true := by
  decide +kernel

theorem accepted01_12_13 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 12).erase 13)
      (certificate 1 12 13) = true := by
  decide +kernel

theorem accepted01_12_14 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 12).erase 14)
      (certificate 1 12 14) = true := by
  decide +kernel

theorem accepted01_12_15 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 12).erase 15)
      (certificate 1 12 15) = true := by
  decide +kernel

theorem accepted01_12_16 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 12).erase 16)
      (certificate 1 12 16) = true := by
  decide +kernel

theorem accepted01_12_17 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 12).erase 17)
      (certificate 1 12 17) = true := by
  decide +kernel

theorem accepted01_12_18 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 12).erase 18)
      (certificate 1 12 18) = true := by
  decide +kernel

theorem accepted01_12_19 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 12).erase 19)
      (certificate 1 12 19) = true := by
  decide +kernel

theorem accepted01_13_14 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 13).erase 14)
      (certificate 1 13 14) = true := by
  decide +kernel

theorem accepted01_13_15 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 13).erase 15)
      (certificate 1 13 15) = true := by
  decide +kernel

theorem accepted01_13_16 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 13).erase 16)
      (certificate 1 13 16) = true := by
  decide +kernel

theorem accepted01_13_17 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 13).erase 17)
      (certificate 1 13 17) = true := by
  decide +kernel

theorem accepted01_13_18 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 13).erase 18)
      (certificate 1 13 18) = true := by
  decide +kernel

theorem accepted01_13_19 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 13).erase 19)
      (certificate 1 13 19) = true := by
  decide +kernel

theorem accepted01_14_15 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 14).erase 15)
      (certificate 1 14 15) = true := by
  decide +kernel

theorem accepted01_14_16 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 14).erase 16)
      (certificate 1 14 16) = true := by
  decide +kernel

theorem accepted01_14_17 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 14).erase 17)
      (certificate 1 14 17) = true := by
  decide +kernel

theorem accepted01_14_18 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 14).erase 18)
      (certificate 1 14 18) = true := by
  decide +kernel

theorem accepted01_14_19 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 14).erase 19)
      (certificate 1 14 19) = true := by
  decide +kernel

theorem accepted01_15_16 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 15).erase 16)
      (certificate 1 15 16) = true := by
  decide +kernel

theorem accepted01_15_17 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 15).erase 17)
      (certificate 1 15 17) = true := by
  decide +kernel

theorem accepted01_15_18 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 15).erase 18)
      (certificate 1 15 18) = true := by
  decide +kernel

theorem accepted01_15_19 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 15).erase 19)
      (certificate 1 15 19) = true := by
  decide +kernel

theorem accepted01_16_17 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 16).erase 17)
      (certificate 1 16 17) = true := by
  decide +kernel

theorem accepted01_16_18 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 16).erase 18)
      (certificate 1 16 18) = true := by
  decide +kernel

theorem accepted01_16_19 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 16).erase 19)
      (certificate 1 16 19) = true := by
  decide +kernel

theorem accepted01_17_18 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 17).erase 18)
      (certificate 1 17 18) = true := by
  decide +kernel

theorem accepted01_17_19 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 17).erase 19)
      (certificate 1 17 19) = true := by
  decide +kernel

theorem accepted01_18_19 :
    accepted spec (((Finset.univ.erase (1 : Label)).erase 18).erase 19)
      (certificate 1 18 19) = true := by
  decide +kernel

theorem accepted02_03_04 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 3).erase 4)
      (certificate 2 3 4) = true := by
  decide +kernel

theorem accepted02_03_05 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 3).erase 5)
      (certificate 2 3 5) = true := by
  decide +kernel

theorem accepted02_03_06 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 3).erase 6)
      (certificate 2 3 6) = true := by
  decide +kernel

theorem accepted02_03_07 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 3).erase 7)
      (certificate 2 3 7) = true := by
  decide +kernel

theorem accepted02_03_08 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 3).erase 8)
      (certificate 2 3 8) = true := by
  decide +kernel

theorem accepted02_03_09 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 3).erase 9)
      (certificate 2 3 9) = true := by
  decide +kernel

theorem accepted02_03_10 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 3).erase 10)
      (certificate 2 3 10) = true := by
  decide +kernel

theorem accepted02_03_11 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 3).erase 11)
      (certificate 2 3 11) = true := by
  decide +kernel

theorem accepted02_03_12 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 3).erase 12)
      (certificate 2 3 12) = true := by
  decide +kernel

theorem accepted02_03_13 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 3).erase 13)
      (certificate 2 3 13) = true := by
  decide +kernel

theorem accepted02_03_14 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 3).erase 14)
      (certificate 2 3 14) = true := by
  decide +kernel

theorem accepted02_03_15 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 3).erase 15)
      (certificate 2 3 15) = true := by
  decide +kernel

theorem accepted02_03_16 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 3).erase 16)
      (certificate 2 3 16) = true := by
  decide +kernel

theorem accepted02_03_17 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 3).erase 17)
      (certificate 2 3 17) = true := by
  decide +kernel

theorem accepted02_03_18 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 3).erase 18)
      (certificate 2 3 18) = true := by
  decide +kernel

theorem accepted02_03_19 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 3).erase 19)
      (certificate 2 3 19) = true := by
  decide +kernel

theorem accepted02_04_05 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 4).erase 5)
      (certificate 2 4 5) = true := by
  decide +kernel

theorem accepted02_04_06 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 4).erase 6)
      (certificate 2 4 6) = true := by
  decide +kernel

theorem accepted02_04_07 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 4).erase 7)
      (certificate 2 4 7) = true := by
  decide +kernel

theorem accepted02_04_08 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 4).erase 8)
      (certificate 2 4 8) = true := by
  decide +kernel

theorem accepted02_04_09 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 4).erase 9)
      (certificate 2 4 9) = true := by
  decide +kernel

theorem accepted02_04_10 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 4).erase 10)
      (certificate 2 4 10) = true := by
  decide +kernel

theorem accepted02_04_11 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 4).erase 11)
      (certificate 2 4 11) = true := by
  decide +kernel

theorem accepted02_04_12 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 4).erase 12)
      (certificate 2 4 12) = true := by
  decide +kernel

theorem accepted02_04_13 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 4).erase 13)
      (certificate 2 4 13) = true := by
  decide +kernel

theorem accepted02_04_14 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 4).erase 14)
      (certificate 2 4 14) = true := by
  decide +kernel

theorem accepted02_04_15 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 4).erase 15)
      (certificate 2 4 15) = true := by
  decide +kernel

theorem accepted02_04_16 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 4).erase 16)
      (certificate 2 4 16) = true := by
  decide +kernel

theorem accepted02_04_17 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 4).erase 17)
      (certificate 2 4 17) = true := by
  decide +kernel

theorem accepted02_04_18 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 4).erase 18)
      (certificate 2 4 18) = true := by
  decide +kernel

theorem accepted02_04_19 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 4).erase 19)
      (certificate 2 4 19) = true := by
  decide +kernel

theorem accepted02_05_06 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 5).erase 6)
      (certificate 2 5 6) = true := by
  decide +kernel

theorem accepted02_05_07 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 5).erase 7)
      (certificate 2 5 7) = true := by
  decide +kernel

theorem accepted02_05_08 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 5).erase 8)
      (certificate 2 5 8) = true := by
  decide +kernel

theorem accepted02_05_09 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 5).erase 9)
      (certificate 2 5 9) = true := by
  decide +kernel

theorem accepted02_05_10 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 5).erase 10)
      (certificate 2 5 10) = true := by
  decide +kernel

theorem accepted02_05_11 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 5).erase 11)
      (certificate 2 5 11) = true := by
  decide +kernel

theorem accepted02_05_12 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 5).erase 12)
      (certificate 2 5 12) = true := by
  decide +kernel

theorem accepted02_05_13 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 5).erase 13)
      (certificate 2 5 13) = true := by
  decide +kernel

theorem accepted02_05_14 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 5).erase 14)
      (certificate 2 5 14) = true := by
  decide +kernel

theorem accepted02_05_15 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 5).erase 15)
      (certificate 2 5 15) = true := by
  decide +kernel

theorem accepted02_05_16 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 5).erase 16)
      (certificate 2 5 16) = true := by
  decide +kernel

theorem accepted02_05_17 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 5).erase 17)
      (certificate 2 5 17) = true := by
  decide +kernel

theorem accepted02_05_18 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 5).erase 18)
      (certificate 2 5 18) = true := by
  decide +kernel

theorem accepted02_05_19 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 5).erase 19)
      (certificate 2 5 19) = true := by
  decide +kernel

theorem accepted02_06_07 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 6).erase 7)
      (certificate 2 6 7) = true := by
  decide +kernel

theorem accepted02_06_08 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 6).erase 8)
      (certificate 2 6 8) = true := by
  decide +kernel

theorem accepted02_06_09 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 6).erase 9)
      (certificate 2 6 9) = true := by
  decide +kernel

theorem accepted02_06_10 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 6).erase 10)
      (certificate 2 6 10) = true := by
  decide +kernel

theorem accepted02_06_11 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 6).erase 11)
      (certificate 2 6 11) = true := by
  decide +kernel

theorem accepted02_06_12 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 6).erase 12)
      (certificate 2 6 12) = true := by
  decide +kernel

theorem accepted02_06_13 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 6).erase 13)
      (certificate 2 6 13) = true := by
  decide +kernel

theorem accepted02_06_14 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 6).erase 14)
      (certificate 2 6 14) = true := by
  decide +kernel

theorem accepted02_06_15 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 6).erase 15)
      (certificate 2 6 15) = true := by
  decide +kernel

theorem accepted02_06_16 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 6).erase 16)
      (certificate 2 6 16) = true := by
  decide +kernel

theorem accepted02_06_17 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 6).erase 17)
      (certificate 2 6 17) = true := by
  decide +kernel

theorem accepted02_06_18 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 6).erase 18)
      (certificate 2 6 18) = true := by
  decide +kernel

theorem accepted02_06_19 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 6).erase 19)
      (certificate 2 6 19) = true := by
  decide +kernel

theorem accepted02_07_08 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 7).erase 8)
      (certificate 2 7 8) = true := by
  decide +kernel

theorem accepted02_07_09 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 7).erase 9)
      (certificate 2 7 9) = true := by
  decide +kernel

theorem accepted02_07_10 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 7).erase 10)
      (certificate 2 7 10) = true := by
  decide +kernel

theorem accepted02_07_11 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 7).erase 11)
      (certificate 2 7 11) = true := by
  decide +kernel

theorem accepted02_07_12 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 7).erase 12)
      (certificate 2 7 12) = true := by
  decide +kernel

theorem accepted02_07_13 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 7).erase 13)
      (certificate 2 7 13) = true := by
  decide +kernel

theorem accepted02_07_14 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 7).erase 14)
      (certificate 2 7 14) = true := by
  decide +kernel

theorem accepted02_07_15 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 7).erase 15)
      (certificate 2 7 15) = true := by
  decide +kernel

theorem accepted02_07_16 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 7).erase 16)
      (certificate 2 7 16) = true := by
  decide +kernel

theorem accepted02_07_17 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 7).erase 17)
      (certificate 2 7 17) = true := by
  decide +kernel

theorem accepted02_07_18 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 7).erase 18)
      (certificate 2 7 18) = true := by
  decide +kernel

theorem accepted02_07_19 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 7).erase 19)
      (certificate 2 7 19) = true := by
  decide +kernel

theorem accepted02_08_09 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 8).erase 9)
      (certificate 2 8 9) = true := by
  decide +kernel

theorem accepted02_08_10 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 8).erase 10)
      (certificate 2 8 10) = true := by
  decide +kernel

theorem accepted02_08_11 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 8).erase 11)
      (certificate 2 8 11) = true := by
  decide +kernel

theorem accepted02_08_12 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 8).erase 12)
      (certificate 2 8 12) = true := by
  decide +kernel

theorem accepted02_08_13 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 8).erase 13)
      (certificate 2 8 13) = true := by
  decide +kernel

theorem accepted02_08_14 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 8).erase 14)
      (certificate 2 8 14) = true := by
  decide +kernel

theorem accepted02_08_15 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 8).erase 15)
      (certificate 2 8 15) = true := by
  decide +kernel

theorem accepted02_08_16 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 8).erase 16)
      (certificate 2 8 16) = true := by
  decide +kernel

theorem accepted02_08_17 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 8).erase 17)
      (certificate 2 8 17) = true := by
  decide +kernel

theorem accepted02_08_18 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 8).erase 18)
      (certificate 2 8 18) = true := by
  decide +kernel

theorem accepted02_08_19 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 8).erase 19)
      (certificate 2 8 19) = true := by
  decide +kernel

theorem accepted02_09_10 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 9).erase 10)
      (certificate 2 9 10) = true := by
  decide +kernel

theorem accepted02_09_11 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 9).erase 11)
      (certificate 2 9 11) = true := by
  decide +kernel

theorem accepted02_09_12 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 9).erase 12)
      (certificate 2 9 12) = true := by
  decide +kernel

theorem accepted02_09_13 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 9).erase 13)
      (certificate 2 9 13) = true := by
  decide +kernel

theorem accepted02_09_14 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 9).erase 14)
      (certificate 2 9 14) = true := by
  decide +kernel

theorem accepted02_09_15 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 9).erase 15)
      (certificate 2 9 15) = true := by
  decide +kernel

theorem accepted02_09_16 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 9).erase 16)
      (certificate 2 9 16) = true := by
  decide +kernel

theorem accepted02_09_17 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 9).erase 17)
      (certificate 2 9 17) = true := by
  decide +kernel

theorem accepted02_09_18 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 9).erase 18)
      (certificate 2 9 18) = true := by
  decide +kernel

theorem accepted02_09_19 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 9).erase 19)
      (certificate 2 9 19) = true := by
  decide +kernel

theorem accepted02_10_11 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 10).erase 11)
      (certificate 2 10 11) = true := by
  decide +kernel

theorem accepted02_10_12 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 10).erase 12)
      (certificate 2 10 12) = true := by
  decide +kernel

theorem accepted02_10_13 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 10).erase 13)
      (certificate 2 10 13) = true := by
  decide +kernel

theorem accepted02_10_14 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 10).erase 14)
      (certificate 2 10 14) = true := by
  decide +kernel

theorem accepted02_10_15 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 10).erase 15)
      (certificate 2 10 15) = true := by
  decide +kernel

theorem accepted02_10_16 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 10).erase 16)
      (certificate 2 10 16) = true := by
  decide +kernel

theorem accepted02_10_17 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 10).erase 17)
      (certificate 2 10 17) = true := by
  decide +kernel

theorem accepted02_10_18 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 10).erase 18)
      (certificate 2 10 18) = true := by
  decide +kernel

theorem accepted02_10_19 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 10).erase 19)
      (certificate 2 10 19) = true := by
  decide +kernel

theorem accepted02_11_12 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 11).erase 12)
      (certificate 2 11 12) = true := by
  decide +kernel

theorem accepted02_11_13 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 11).erase 13)
      (certificate 2 11 13) = true := by
  decide +kernel

theorem accepted02_11_14 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 11).erase 14)
      (certificate 2 11 14) = true := by
  decide +kernel

theorem accepted02_11_15 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 11).erase 15)
      (certificate 2 11 15) = true := by
  decide +kernel

theorem accepted02_11_16 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 11).erase 16)
      (certificate 2 11 16) = true := by
  decide +kernel

theorem accepted02_11_17 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 11).erase 17)
      (certificate 2 11 17) = true := by
  decide +kernel

theorem accepted02_11_18 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 11).erase 18)
      (certificate 2 11 18) = true := by
  decide +kernel

theorem accepted02_11_19 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 11).erase 19)
      (certificate 2 11 19) = true := by
  decide +kernel

theorem accepted02_12_13 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 12).erase 13)
      (certificate 2 12 13) = true := by
  decide +kernel

theorem accepted02_12_14 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 12).erase 14)
      (certificate 2 12 14) = true := by
  decide +kernel

theorem accepted02_12_15 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 12).erase 15)
      (certificate 2 12 15) = true := by
  decide +kernel

theorem accepted02_12_16 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 12).erase 16)
      (certificate 2 12 16) = true := by
  decide +kernel

theorem accepted02_12_17 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 12).erase 17)
      (certificate 2 12 17) = true := by
  decide +kernel

theorem accepted02_12_18 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 12).erase 18)
      (certificate 2 12 18) = true := by
  decide +kernel

theorem accepted02_12_19 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 12).erase 19)
      (certificate 2 12 19) = true := by
  decide +kernel

theorem accepted02_13_14 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 13).erase 14)
      (certificate 2 13 14) = true := by
  decide +kernel

theorem accepted02_13_15 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 13).erase 15)
      (certificate 2 13 15) = true := by
  decide +kernel

theorem accepted02_13_16 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 13).erase 16)
      (certificate 2 13 16) = true := by
  decide +kernel

theorem accepted02_13_17 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 13).erase 17)
      (certificate 2 13 17) = true := by
  decide +kernel

theorem accepted02_13_18 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 13).erase 18)
      (certificate 2 13 18) = true := by
  decide +kernel

theorem accepted02_13_19 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 13).erase 19)
      (certificate 2 13 19) = true := by
  decide +kernel

theorem accepted02_14_15 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 14).erase 15)
      (certificate 2 14 15) = true := by
  decide +kernel

theorem accepted02_14_16 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 14).erase 16)
      (certificate 2 14 16) = true := by
  decide +kernel

theorem accepted02_14_17 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 14).erase 17)
      (certificate 2 14 17) = true := by
  decide +kernel

theorem accepted02_14_18 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 14).erase 18)
      (certificate 2 14 18) = true := by
  decide +kernel

theorem accepted02_14_19 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 14).erase 19)
      (certificate 2 14 19) = true := by
  decide +kernel

theorem accepted02_15_16 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 15).erase 16)
      (certificate 2 15 16) = true := by
  decide +kernel

theorem accepted02_15_17 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 15).erase 17)
      (certificate 2 15 17) = true := by
  decide +kernel

theorem accepted02_15_18 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 15).erase 18)
      (certificate 2 15 18) = true := by
  decide +kernel

theorem accepted02_15_19 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 15).erase 19)
      (certificate 2 15 19) = true := by
  decide +kernel

theorem accepted02_16_17 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 16).erase 17)
      (certificate 2 16 17) = true := by
  decide +kernel

theorem accepted02_16_18 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 16).erase 18)
      (certificate 2 16 18) = true := by
  decide +kernel

theorem accepted02_16_19 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 16).erase 19)
      (certificate 2 16 19) = true := by
  decide +kernel

theorem accepted02_17_18 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 17).erase 18)
      (certificate 2 17 18) = true := by
  decide +kernel

theorem accepted02_17_19 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 17).erase 19)
      (certificate 2 17 19) = true := by
  decide +kernel

theorem accepted02_18_19 :
    accepted spec (((Finset.univ.erase (2 : Label)).erase 18).erase 19)
      (certificate 2 18 19) = true := by
  decide +kernel

theorem accepted03_04_05 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 4).erase 5)
      (certificate 3 4 5) = true := by
  decide +kernel

theorem accepted03_04_06 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 4).erase 6)
      (certificate 3 4 6) = true := by
  decide +kernel

theorem accepted03_04_07 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 4).erase 7)
      (certificate 3 4 7) = true := by
  decide +kernel

theorem accepted03_04_08 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 4).erase 8)
      (certificate 3 4 8) = true := by
  decide +kernel

theorem accepted03_04_09 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 4).erase 9)
      (certificate 3 4 9) = true := by
  decide +kernel

theorem accepted03_04_10 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 4).erase 10)
      (certificate 3 4 10) = true := by
  decide +kernel

theorem accepted03_04_11 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 4).erase 11)
      (certificate 3 4 11) = true := by
  decide +kernel

theorem accepted03_04_12 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 4).erase 12)
      (certificate 3 4 12) = true := by
  decide +kernel

theorem accepted03_04_13 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 4).erase 13)
      (certificate 3 4 13) = true := by
  decide +kernel

theorem accepted03_04_14 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 4).erase 14)
      (certificate 3 4 14) = true := by
  decide +kernel

theorem accepted03_04_15 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 4).erase 15)
      (certificate 3 4 15) = true := by
  decide +kernel

theorem accepted03_04_16 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 4).erase 16)
      (certificate 3 4 16) = true := by
  decide +kernel

theorem accepted03_04_17 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 4).erase 17)
      (certificate 3 4 17) = true := by
  decide +kernel

theorem accepted03_04_18 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 4).erase 18)
      (certificate 3 4 18) = true := by
  decide +kernel

theorem accepted03_04_19 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 4).erase 19)
      (certificate 3 4 19) = true := by
  decide +kernel

theorem accepted03_05_06 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 5).erase 6)
      (certificate 3 5 6) = true := by
  decide +kernel

theorem accepted03_05_07 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 5).erase 7)
      (certificate 3 5 7) = true := by
  decide +kernel

theorem accepted03_05_08 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 5).erase 8)
      (certificate 3 5 8) = true := by
  decide +kernel

theorem accepted03_05_09 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 5).erase 9)
      (certificate 3 5 9) = true := by
  decide +kernel

theorem accepted03_05_10 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 5).erase 10)
      (certificate 3 5 10) = true := by
  decide +kernel

theorem accepted03_05_11 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 5).erase 11)
      (certificate 3 5 11) = true := by
  decide +kernel

theorem accepted03_05_12 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 5).erase 12)
      (certificate 3 5 12) = true := by
  decide +kernel

theorem accepted03_05_13 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 5).erase 13)
      (certificate 3 5 13) = true := by
  decide +kernel

theorem accepted03_05_14 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 5).erase 14)
      (certificate 3 5 14) = true := by
  decide +kernel

theorem accepted03_05_15 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 5).erase 15)
      (certificate 3 5 15) = true := by
  decide +kernel

theorem accepted03_05_16 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 5).erase 16)
      (certificate 3 5 16) = true := by
  decide +kernel

theorem accepted03_05_17 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 5).erase 17)
      (certificate 3 5 17) = true := by
  decide +kernel

theorem accepted03_05_18 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 5).erase 18)
      (certificate 3 5 18) = true := by
  decide +kernel

theorem accepted03_05_19 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 5).erase 19)
      (certificate 3 5 19) = true := by
  decide +kernel

theorem accepted03_06_07 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 6).erase 7)
      (certificate 3 6 7) = true := by
  decide +kernel

theorem accepted03_06_08 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 6).erase 8)
      (certificate 3 6 8) = true := by
  decide +kernel

theorem accepted03_06_09 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 6).erase 9)
      (certificate 3 6 9) = true := by
  decide +kernel

theorem accepted03_06_10 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 6).erase 10)
      (certificate 3 6 10) = true := by
  decide +kernel

theorem accepted03_06_11 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 6).erase 11)
      (certificate 3 6 11) = true := by
  decide +kernel

theorem accepted03_06_12 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 6).erase 12)
      (certificate 3 6 12) = true := by
  decide +kernel

theorem accepted03_06_13 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 6).erase 13)
      (certificate 3 6 13) = true := by
  decide +kernel

theorem accepted03_06_14 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 6).erase 14)
      (certificate 3 6 14) = true := by
  decide +kernel

theorem accepted03_06_15 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 6).erase 15)
      (certificate 3 6 15) = true := by
  decide +kernel

theorem accepted03_06_16 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 6).erase 16)
      (certificate 3 6 16) = true := by
  decide +kernel

theorem accepted03_06_17 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 6).erase 17)
      (certificate 3 6 17) = true := by
  decide +kernel

theorem accepted03_06_18 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 6).erase 18)
      (certificate 3 6 18) = true := by
  decide +kernel

theorem accepted03_06_19 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 6).erase 19)
      (certificate 3 6 19) = true := by
  decide +kernel

theorem accepted03_07_08 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 7).erase 8)
      (certificate 3 7 8) = true := by
  decide +kernel

theorem accepted03_07_09 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 7).erase 9)
      (certificate 3 7 9) = true := by
  decide +kernel

theorem accepted03_07_10 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 7).erase 10)
      (certificate 3 7 10) = true := by
  decide +kernel

theorem accepted03_07_11 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 7).erase 11)
      (certificate 3 7 11) = true := by
  decide +kernel

theorem accepted03_07_12 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 7).erase 12)
      (certificate 3 7 12) = true := by
  decide +kernel

theorem accepted03_07_13 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 7).erase 13)
      (certificate 3 7 13) = true := by
  decide +kernel

theorem accepted03_07_14 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 7).erase 14)
      (certificate 3 7 14) = true := by
  decide +kernel

theorem accepted03_07_15 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 7).erase 15)
      (certificate 3 7 15) = true := by
  decide +kernel

theorem accepted03_07_16 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 7).erase 16)
      (certificate 3 7 16) = true := by
  decide +kernel

theorem accepted03_07_17 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 7).erase 17)
      (certificate 3 7 17) = true := by
  decide +kernel

theorem accepted03_07_18 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 7).erase 18)
      (certificate 3 7 18) = true := by
  decide +kernel

theorem accepted03_07_19 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 7).erase 19)
      (certificate 3 7 19) = true := by
  decide +kernel

theorem accepted03_08_09 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 8).erase 9)
      (certificate 3 8 9) = true := by
  decide +kernel

theorem accepted03_08_10 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 8).erase 10)
      (certificate 3 8 10) = true := by
  decide +kernel

theorem accepted03_08_11 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 8).erase 11)
      (certificate 3 8 11) = true := by
  decide +kernel

theorem accepted03_08_12 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 8).erase 12)
      (certificate 3 8 12) = true := by
  decide +kernel

theorem accepted03_08_13 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 8).erase 13)
      (certificate 3 8 13) = true := by
  decide +kernel

theorem accepted03_08_14 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 8).erase 14)
      (certificate 3 8 14) = true := by
  decide +kernel

theorem accepted03_08_15 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 8).erase 15)
      (certificate 3 8 15) = true := by
  decide +kernel

theorem accepted03_08_16 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 8).erase 16)
      (certificate 3 8 16) = true := by
  decide +kernel

theorem accepted03_08_17 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 8).erase 17)
      (certificate 3 8 17) = true := by
  decide +kernel

theorem accepted03_08_18 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 8).erase 18)
      (certificate 3 8 18) = true := by
  decide +kernel

theorem accepted03_08_19 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 8).erase 19)
      (certificate 3 8 19) = true := by
  decide +kernel

theorem accepted03_09_10 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 9).erase 10)
      (certificate 3 9 10) = true := by
  decide +kernel

theorem accepted03_09_11 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 9).erase 11)
      (certificate 3 9 11) = true := by
  decide +kernel

theorem accepted03_09_12 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 9).erase 12)
      (certificate 3 9 12) = true := by
  decide +kernel

theorem accepted03_09_13 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 9).erase 13)
      (certificate 3 9 13) = true := by
  decide +kernel

theorem accepted03_09_14 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 9).erase 14)
      (certificate 3 9 14) = true := by
  decide +kernel

theorem accepted03_09_15 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 9).erase 15)
      (certificate 3 9 15) = true := by
  decide +kernel

theorem accepted03_09_16 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 9).erase 16)
      (certificate 3 9 16) = true := by
  decide +kernel

theorem accepted03_09_17 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 9).erase 17)
      (certificate 3 9 17) = true := by
  decide +kernel

theorem accepted03_09_18 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 9).erase 18)
      (certificate 3 9 18) = true := by
  decide +kernel

theorem accepted03_09_19 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 9).erase 19)
      (certificate 3 9 19) = true := by
  decide +kernel

theorem accepted03_10_11 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 10).erase 11)
      (certificate 3 10 11) = true := by
  decide +kernel

theorem accepted03_10_12 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 10).erase 12)
      (certificate 3 10 12) = true := by
  decide +kernel

theorem accepted03_10_13 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 10).erase 13)
      (certificate 3 10 13) = true := by
  decide +kernel

theorem accepted03_10_14 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 10).erase 14)
      (certificate 3 10 14) = true := by
  decide +kernel

theorem accepted03_10_15 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 10).erase 15)
      (certificate 3 10 15) = true := by
  decide +kernel

theorem accepted03_10_16 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 10).erase 16)
      (certificate 3 10 16) = true := by
  decide +kernel

theorem accepted03_10_17 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 10).erase 17)
      (certificate 3 10 17) = true := by
  decide +kernel

theorem accepted03_10_18 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 10).erase 18)
      (certificate 3 10 18) = true := by
  decide +kernel

theorem accepted03_10_19 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 10).erase 19)
      (certificate 3 10 19) = true := by
  decide +kernel

theorem accepted03_11_12 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 11).erase 12)
      (certificate 3 11 12) = true := by
  decide +kernel

theorem accepted03_11_13 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 11).erase 13)
      (certificate 3 11 13) = true := by
  decide +kernel

theorem accepted03_11_14 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 11).erase 14)
      (certificate 3 11 14) = true := by
  decide +kernel

theorem accepted03_11_15 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 11).erase 15)
      (certificate 3 11 15) = true := by
  decide +kernel

theorem accepted03_11_16 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 11).erase 16)
      (certificate 3 11 16) = true := by
  decide +kernel

theorem accepted03_11_17 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 11).erase 17)
      (certificate 3 11 17) = true := by
  decide +kernel

theorem accepted03_11_18 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 11).erase 18)
      (certificate 3 11 18) = true := by
  decide +kernel

theorem accepted03_11_19 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 11).erase 19)
      (certificate 3 11 19) = true := by
  decide +kernel

theorem accepted03_12_13 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 12).erase 13)
      (certificate 3 12 13) = true := by
  decide +kernel

theorem accepted03_12_14 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 12).erase 14)
      (certificate 3 12 14) = true := by
  decide +kernel

theorem accepted03_12_15 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 12).erase 15)
      (certificate 3 12 15) = true := by
  decide +kernel

theorem accepted03_12_16 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 12).erase 16)
      (certificate 3 12 16) = true := by
  decide +kernel

theorem accepted03_12_17 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 12).erase 17)
      (certificate 3 12 17) = true := by
  decide +kernel

theorem accepted03_12_18 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 12).erase 18)
      (certificate 3 12 18) = true := by
  decide +kernel

theorem accepted03_12_19 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 12).erase 19)
      (certificate 3 12 19) = true := by
  decide +kernel

theorem accepted03_13_14 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 13).erase 14)
      (certificate 3 13 14) = true := by
  decide +kernel

theorem accepted03_13_15 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 13).erase 15)
      (certificate 3 13 15) = true := by
  decide +kernel

theorem accepted03_13_16 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 13).erase 16)
      (certificate 3 13 16) = true := by
  decide +kernel

theorem accepted03_13_17 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 13).erase 17)
      (certificate 3 13 17) = true := by
  decide +kernel

theorem accepted03_13_18 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 13).erase 18)
      (certificate 3 13 18) = true := by
  decide +kernel

theorem accepted03_13_19 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 13).erase 19)
      (certificate 3 13 19) = true := by
  decide +kernel

theorem accepted03_14_15 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 14).erase 15)
      (certificate 3 14 15) = true := by
  decide +kernel

theorem accepted03_14_16 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 14).erase 16)
      (certificate 3 14 16) = true := by
  decide +kernel

theorem accepted03_14_17 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 14).erase 17)
      (certificate 3 14 17) = true := by
  decide +kernel

theorem accepted03_14_18 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 14).erase 18)
      (certificate 3 14 18) = true := by
  decide +kernel

theorem accepted03_14_19 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 14).erase 19)
      (certificate 3 14 19) = true := by
  decide +kernel

theorem accepted03_15_16 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 15).erase 16)
      (certificate 3 15 16) = true := by
  decide +kernel

theorem accepted03_15_17 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 15).erase 17)
      (certificate 3 15 17) = true := by
  decide +kernel

theorem accepted03_15_18 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 15).erase 18)
      (certificate 3 15 18) = true := by
  decide +kernel

theorem accepted03_15_19 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 15).erase 19)
      (certificate 3 15 19) = true := by
  decide +kernel

theorem accepted03_16_17 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 16).erase 17)
      (certificate 3 16 17) = true := by
  decide +kernel

theorem accepted03_16_18 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 16).erase 18)
      (certificate 3 16 18) = true := by
  decide +kernel

theorem accepted03_16_19 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 16).erase 19)
      (certificate 3 16 19) = true := by
  decide +kernel

theorem accepted03_17_18 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 17).erase 18)
      (certificate 3 17 18) = true := by
  decide +kernel

theorem accepted03_17_19 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 17).erase 19)
      (certificate 3 17 19) = true := by
  decide +kernel

theorem accepted03_18_19 :
    accepted spec (((Finset.univ.erase (3 : Label)).erase 18).erase 19)
      (certificate 3 18 19) = true := by
  decide +kernel

theorem accepted04_05_06 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 5).erase 6)
      (certificate 4 5 6) = true := by
  decide +kernel

theorem accepted04_05_07 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 5).erase 7)
      (certificate 4 5 7) = true := by
  decide +kernel

theorem accepted04_05_08 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 5).erase 8)
      (certificate 4 5 8) = true := by
  decide +kernel

theorem accepted04_05_09 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 5).erase 9)
      (certificate 4 5 9) = true := by
  decide +kernel

theorem accepted04_05_10 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 5).erase 10)
      (certificate 4 5 10) = true := by
  decide +kernel

theorem accepted04_05_11 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 5).erase 11)
      (certificate 4 5 11) = true := by
  decide +kernel

theorem accepted04_05_12 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 5).erase 12)
      (certificate 4 5 12) = true := by
  decide +kernel

theorem accepted04_05_13 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 5).erase 13)
      (certificate 4 5 13) = true := by
  decide +kernel

theorem accepted04_05_14 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 5).erase 14)
      (certificate 4 5 14) = true := by
  decide +kernel

theorem accepted04_05_15 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 5).erase 15)
      (certificate 4 5 15) = true := by
  decide +kernel

theorem accepted04_05_16 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 5).erase 16)
      (certificate 4 5 16) = true := by
  decide +kernel

theorem accepted04_05_17 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 5).erase 17)
      (certificate 4 5 17) = true := by
  decide +kernel

theorem accepted04_05_18 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 5).erase 18)
      (certificate 4 5 18) = true := by
  decide +kernel

theorem accepted04_05_19 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 5).erase 19)
      (certificate 4 5 19) = true := by
  decide +kernel

theorem accepted04_06_07 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 6).erase 7)
      (certificate 4 6 7) = true := by
  decide +kernel

theorem accepted04_06_08 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 6).erase 8)
      (certificate 4 6 8) = true := by
  decide +kernel

theorem accepted04_06_09 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 6).erase 9)
      (certificate 4 6 9) = true := by
  decide +kernel

theorem accepted04_06_10 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 6).erase 10)
      (certificate 4 6 10) = true := by
  decide +kernel

theorem accepted04_06_11 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 6).erase 11)
      (certificate 4 6 11) = true := by
  decide +kernel

theorem accepted04_06_12 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 6).erase 12)
      (certificate 4 6 12) = true := by
  decide +kernel

theorem accepted04_06_13 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 6).erase 13)
      (certificate 4 6 13) = true := by
  decide +kernel

theorem accepted04_06_14 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 6).erase 14)
      (certificate 4 6 14) = true := by
  decide +kernel

theorem accepted04_06_15 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 6).erase 15)
      (certificate 4 6 15) = true := by
  decide +kernel

theorem accepted04_06_16 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 6).erase 16)
      (certificate 4 6 16) = true := by
  decide +kernel

theorem accepted04_06_17 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 6).erase 17)
      (certificate 4 6 17) = true := by
  decide +kernel

theorem accepted04_06_18 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 6).erase 18)
      (certificate 4 6 18) = true := by
  decide +kernel

theorem accepted04_06_19 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 6).erase 19)
      (certificate 4 6 19) = true := by
  decide +kernel

theorem accepted04_07_08 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 7).erase 8)
      (certificate 4 7 8) = true := by
  decide +kernel

theorem accepted04_07_09 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 7).erase 9)
      (certificate 4 7 9) = true := by
  decide +kernel

theorem accepted04_07_10 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 7).erase 10)
      (certificate 4 7 10) = true := by
  decide +kernel

theorem accepted04_07_11 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 7).erase 11)
      (certificate 4 7 11) = true := by
  decide +kernel

theorem accepted04_07_12 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 7).erase 12)
      (certificate 4 7 12) = true := by
  decide +kernel

theorem accepted04_07_13 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 7).erase 13)
      (certificate 4 7 13) = true := by
  decide +kernel

theorem accepted04_07_14 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 7).erase 14)
      (certificate 4 7 14) = true := by
  decide +kernel

theorem accepted04_07_15 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 7).erase 15)
      (certificate 4 7 15) = true := by
  decide +kernel

theorem accepted04_07_16 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 7).erase 16)
      (certificate 4 7 16) = true := by
  decide +kernel

theorem accepted04_07_17 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 7).erase 17)
      (certificate 4 7 17) = true := by
  decide +kernel

theorem accepted04_07_18 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 7).erase 18)
      (certificate 4 7 18) = true := by
  decide +kernel

theorem accepted04_07_19 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 7).erase 19)
      (certificate 4 7 19) = true := by
  decide +kernel

theorem accepted04_08_09 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 8).erase 9)
      (certificate 4 8 9) = true := by
  decide +kernel

theorem accepted04_08_10 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 8).erase 10)
      (certificate 4 8 10) = true := by
  decide +kernel

theorem accepted04_08_11 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 8).erase 11)
      (certificate 4 8 11) = true := by
  decide +kernel

theorem accepted04_08_12 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 8).erase 12)
      (certificate 4 8 12) = true := by
  decide +kernel

theorem accepted04_08_13 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 8).erase 13)
      (certificate 4 8 13) = true := by
  decide +kernel

theorem accepted04_08_14 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 8).erase 14)
      (certificate 4 8 14) = true := by
  decide +kernel

theorem accepted04_08_15 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 8).erase 15)
      (certificate 4 8 15) = true := by
  decide +kernel

theorem accepted04_08_16 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 8).erase 16)
      (certificate 4 8 16) = true := by
  decide +kernel

theorem accepted04_08_17 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 8).erase 17)
      (certificate 4 8 17) = true := by
  decide +kernel

theorem accepted04_08_18 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 8).erase 18)
      (certificate 4 8 18) = true := by
  decide +kernel

theorem accepted04_08_19 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 8).erase 19)
      (certificate 4 8 19) = true := by
  decide +kernel

theorem accepted04_09_10 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 9).erase 10)
      (certificate 4 9 10) = true := by
  decide +kernel

theorem accepted04_09_11 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 9).erase 11)
      (certificate 4 9 11) = true := by
  decide +kernel

theorem accepted04_09_12 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 9).erase 12)
      (certificate 4 9 12) = true := by
  decide +kernel

theorem accepted04_09_13 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 9).erase 13)
      (certificate 4 9 13) = true := by
  decide +kernel

theorem accepted04_09_14 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 9).erase 14)
      (certificate 4 9 14) = true := by
  decide +kernel

theorem accepted04_09_15 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 9).erase 15)
      (certificate 4 9 15) = true := by
  decide +kernel

theorem accepted04_09_16 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 9).erase 16)
      (certificate 4 9 16) = true := by
  decide +kernel

theorem accepted04_09_17 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 9).erase 17)
      (certificate 4 9 17) = true := by
  decide +kernel

theorem accepted04_09_18 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 9).erase 18)
      (certificate 4 9 18) = true := by
  decide +kernel

theorem accepted04_09_19 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 9).erase 19)
      (certificate 4 9 19) = true := by
  decide +kernel

theorem accepted04_10_11 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 10).erase 11)
      (certificate 4 10 11) = true := by
  decide +kernel

theorem accepted04_10_12 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 10).erase 12)
      (certificate 4 10 12) = true := by
  decide +kernel

theorem accepted04_10_13 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 10).erase 13)
      (certificate 4 10 13) = true := by
  decide +kernel

theorem accepted04_10_14 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 10).erase 14)
      (certificate 4 10 14) = true := by
  decide +kernel

theorem accepted04_10_15 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 10).erase 15)
      (certificate 4 10 15) = true := by
  decide +kernel

theorem accepted04_10_16 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 10).erase 16)
      (certificate 4 10 16) = true := by
  decide +kernel

theorem accepted04_10_17 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 10).erase 17)
      (certificate 4 10 17) = true := by
  decide +kernel

theorem accepted04_10_18 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 10).erase 18)
      (certificate 4 10 18) = true := by
  decide +kernel

theorem accepted04_10_19 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 10).erase 19)
      (certificate 4 10 19) = true := by
  decide +kernel

theorem accepted04_11_12 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 11).erase 12)
      (certificate 4 11 12) = true := by
  decide +kernel

theorem accepted04_11_13 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 11).erase 13)
      (certificate 4 11 13) = true := by
  decide +kernel

theorem accepted04_11_14 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 11).erase 14)
      (certificate 4 11 14) = true := by
  decide +kernel

theorem accepted04_11_15 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 11).erase 15)
      (certificate 4 11 15) = true := by
  decide +kernel

theorem accepted04_11_16 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 11).erase 16)
      (certificate 4 11 16) = true := by
  decide +kernel

theorem accepted04_11_17 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 11).erase 17)
      (certificate 4 11 17) = true := by
  decide +kernel

theorem accepted04_11_18 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 11).erase 18)
      (certificate 4 11 18) = true := by
  decide +kernel

theorem accepted04_11_19 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 11).erase 19)
      (certificate 4 11 19) = true := by
  decide +kernel

theorem accepted04_12_13 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 12).erase 13)
      (certificate 4 12 13) = true := by
  decide +kernel

theorem accepted04_12_14 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 12).erase 14)
      (certificate 4 12 14) = true := by
  decide +kernel

theorem accepted04_12_15 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 12).erase 15)
      (certificate 4 12 15) = true := by
  decide +kernel

theorem accepted04_12_16 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 12).erase 16)
      (certificate 4 12 16) = true := by
  decide +kernel

theorem accepted04_12_17 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 12).erase 17)
      (certificate 4 12 17) = true := by
  decide +kernel

theorem accepted04_12_18 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 12).erase 18)
      (certificate 4 12 18) = true := by
  decide +kernel

theorem accepted04_12_19 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 12).erase 19)
      (certificate 4 12 19) = true := by
  decide +kernel

theorem accepted04_13_14 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 13).erase 14)
      (certificate 4 13 14) = true := by
  decide +kernel

theorem accepted04_13_15 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 13).erase 15)
      (certificate 4 13 15) = true := by
  decide +kernel

theorem accepted04_13_16 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 13).erase 16)
      (certificate 4 13 16) = true := by
  decide +kernel

theorem accepted04_13_17 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 13).erase 17)
      (certificate 4 13 17) = true := by
  decide +kernel

theorem accepted04_13_18 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 13).erase 18)
      (certificate 4 13 18) = true := by
  decide +kernel

theorem accepted04_13_19 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 13).erase 19)
      (certificate 4 13 19) = true := by
  decide +kernel

theorem accepted04_14_15 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 14).erase 15)
      (certificate 4 14 15) = true := by
  decide +kernel

theorem accepted04_14_16 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 14).erase 16)
      (certificate 4 14 16) = true := by
  decide +kernel

theorem accepted04_14_17 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 14).erase 17)
      (certificate 4 14 17) = true := by
  decide +kernel

theorem accepted04_14_18 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 14).erase 18)
      (certificate 4 14 18) = true := by
  decide +kernel

theorem accepted04_14_19 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 14).erase 19)
      (certificate 4 14 19) = true := by
  decide +kernel

theorem accepted04_15_16 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 15).erase 16)
      (certificate 4 15 16) = true := by
  decide +kernel

theorem accepted04_15_17 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 15).erase 17)
      (certificate 4 15 17) = true := by
  decide +kernel

theorem accepted04_15_18 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 15).erase 18)
      (certificate 4 15 18) = true := by
  decide +kernel

theorem accepted04_15_19 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 15).erase 19)
      (certificate 4 15 19) = true := by
  decide +kernel

theorem accepted04_16_17 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 16).erase 17)
      (certificate 4 16 17) = true := by
  decide +kernel

theorem accepted04_16_18 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 16).erase 18)
      (certificate 4 16 18) = true := by
  decide +kernel

theorem accepted04_16_19 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 16).erase 19)
      (certificate 4 16 19) = true := by
  decide +kernel

theorem accepted04_17_18 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 17).erase 18)
      (certificate 4 17 18) = true := by
  decide +kernel

theorem accepted04_17_19 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 17).erase 19)
      (certificate 4 17 19) = true := by
  decide +kernel

theorem accepted04_18_19 :
    accepted spec (((Finset.univ.erase (4 : Label)).erase 18).erase 19)
      (certificate 4 18 19) = true := by
  decide +kernel

theorem accepted05_06_07 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 6).erase 7)
      (certificate 5 6 7) = true := by
  decide +kernel

theorem accepted05_06_08 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 6).erase 8)
      (certificate 5 6 8) = true := by
  decide +kernel

theorem accepted05_06_09 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 6).erase 9)
      (certificate 5 6 9) = true := by
  decide +kernel

theorem accepted05_06_10 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 6).erase 10)
      (certificate 5 6 10) = true := by
  decide +kernel

theorem accepted05_06_11 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 6).erase 11)
      (certificate 5 6 11) = true := by
  decide +kernel

theorem accepted05_06_12 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 6).erase 12)
      (certificate 5 6 12) = true := by
  decide +kernel

theorem accepted05_06_13 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 6).erase 13)
      (certificate 5 6 13) = true := by
  decide +kernel

theorem accepted05_06_14 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 6).erase 14)
      (certificate 5 6 14) = true := by
  decide +kernel

theorem accepted05_06_15 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 6).erase 15)
      (certificate 5 6 15) = true := by
  decide +kernel

theorem accepted05_06_16 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 6).erase 16)
      (certificate 5 6 16) = true := by
  decide +kernel

theorem accepted05_06_17 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 6).erase 17)
      (certificate 5 6 17) = true := by
  decide +kernel

theorem accepted05_06_18 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 6).erase 18)
      (certificate 5 6 18) = true := by
  decide +kernel

theorem accepted05_06_19 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 6).erase 19)
      (certificate 5 6 19) = true := by
  decide +kernel

theorem accepted05_07_08 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 7).erase 8)
      (certificate 5 7 8) = true := by
  decide +kernel

theorem accepted05_07_09 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 7).erase 9)
      (certificate 5 7 9) = true := by
  decide +kernel

theorem accepted05_07_10 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 7).erase 10)
      (certificate 5 7 10) = true := by
  decide +kernel

theorem accepted05_07_11 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 7).erase 11)
      (certificate 5 7 11) = true := by
  decide +kernel

theorem accepted05_07_12 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 7).erase 12)
      (certificate 5 7 12) = true := by
  decide +kernel

theorem accepted05_07_13 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 7).erase 13)
      (certificate 5 7 13) = true := by
  decide +kernel

theorem accepted05_07_14 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 7).erase 14)
      (certificate 5 7 14) = true := by
  decide +kernel

theorem accepted05_07_15 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 7).erase 15)
      (certificate 5 7 15) = true := by
  decide +kernel

theorem accepted05_07_16 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 7).erase 16)
      (certificate 5 7 16) = true := by
  decide +kernel

theorem accepted05_07_17 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 7).erase 17)
      (certificate 5 7 17) = true := by
  decide +kernel

theorem accepted05_07_18 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 7).erase 18)
      (certificate 5 7 18) = true := by
  decide +kernel

theorem accepted05_07_19 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 7).erase 19)
      (certificate 5 7 19) = true := by
  decide +kernel

theorem accepted05_08_09 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 8).erase 9)
      (certificate 5 8 9) = true := by
  decide +kernel

theorem accepted05_08_10 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 8).erase 10)
      (certificate 5 8 10) = true := by
  decide +kernel

theorem accepted05_08_11 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 8).erase 11)
      (certificate 5 8 11) = true := by
  decide +kernel

theorem accepted05_08_12 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 8).erase 12)
      (certificate 5 8 12) = true := by
  decide +kernel

theorem accepted05_08_13 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 8).erase 13)
      (certificate 5 8 13) = true := by
  decide +kernel

theorem accepted05_08_14 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 8).erase 14)
      (certificate 5 8 14) = true := by
  decide +kernel

theorem accepted05_08_15 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 8).erase 15)
      (certificate 5 8 15) = true := by
  decide +kernel

theorem accepted05_08_16 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 8).erase 16)
      (certificate 5 8 16) = true := by
  decide +kernel

theorem accepted05_08_17 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 8).erase 17)
      (certificate 5 8 17) = true := by
  decide +kernel

theorem accepted05_08_18 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 8).erase 18)
      (certificate 5 8 18) = true := by
  decide +kernel

theorem accepted05_08_19 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 8).erase 19)
      (certificate 5 8 19) = true := by
  decide +kernel

theorem accepted05_09_10 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 9).erase 10)
      (certificate 5 9 10) = true := by
  decide +kernel

theorem accepted05_09_11 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 9).erase 11)
      (certificate 5 9 11) = true := by
  decide +kernel

theorem accepted05_09_12 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 9).erase 12)
      (certificate 5 9 12) = true := by
  decide +kernel

theorem accepted05_09_13 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 9).erase 13)
      (certificate 5 9 13) = true := by
  decide +kernel

theorem accepted05_09_14 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 9).erase 14)
      (certificate 5 9 14) = true := by
  decide +kernel

theorem accepted05_09_15 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 9).erase 15)
      (certificate 5 9 15) = true := by
  decide +kernel

theorem accepted05_09_16 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 9).erase 16)
      (certificate 5 9 16) = true := by
  decide +kernel

theorem accepted05_09_17 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 9).erase 17)
      (certificate 5 9 17) = true := by
  decide +kernel

theorem accepted05_09_18 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 9).erase 18)
      (certificate 5 9 18) = true := by
  decide +kernel

theorem accepted05_09_19 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 9).erase 19)
      (certificate 5 9 19) = true := by
  decide +kernel

theorem accepted05_10_11 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 10).erase 11)
      (certificate 5 10 11) = true := by
  decide +kernel

theorem accepted05_10_12 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 10).erase 12)
      (certificate 5 10 12) = true := by
  decide +kernel

theorem accepted05_10_13 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 10).erase 13)
      (certificate 5 10 13) = true := by
  decide +kernel

theorem accepted05_10_14 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 10).erase 14)
      (certificate 5 10 14) = true := by
  decide +kernel

theorem accepted05_10_15 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 10).erase 15)
      (certificate 5 10 15) = true := by
  decide +kernel

theorem accepted05_10_16 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 10).erase 16)
      (certificate 5 10 16) = true := by
  decide +kernel

theorem accepted05_10_17 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 10).erase 17)
      (certificate 5 10 17) = true := by
  decide +kernel

theorem accepted05_10_18 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 10).erase 18)
      (certificate 5 10 18) = true := by
  decide +kernel

theorem accepted05_10_19 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 10).erase 19)
      (certificate 5 10 19) = true := by
  decide +kernel

theorem accepted05_11_12 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 11).erase 12)
      (certificate 5 11 12) = true := by
  decide +kernel

theorem accepted05_11_13 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 11).erase 13)
      (certificate 5 11 13) = true := by
  decide +kernel

theorem accepted05_11_14 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 11).erase 14)
      (certificate 5 11 14) = true := by
  decide +kernel

theorem accepted05_11_15 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 11).erase 15)
      (certificate 5 11 15) = true := by
  decide +kernel

theorem accepted05_11_16 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 11).erase 16)
      (certificate 5 11 16) = true := by
  decide +kernel

theorem accepted05_11_17 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 11).erase 17)
      (certificate 5 11 17) = true := by
  decide +kernel

theorem accepted05_11_18 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 11).erase 18)
      (certificate 5 11 18) = true := by
  decide +kernel

theorem accepted05_11_19 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 11).erase 19)
      (certificate 5 11 19) = true := by
  decide +kernel

theorem accepted05_12_13 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 12).erase 13)
      (certificate 5 12 13) = true := by
  decide +kernel

theorem accepted05_12_14 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 12).erase 14)
      (certificate 5 12 14) = true := by
  decide +kernel

theorem accepted05_12_15 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 12).erase 15)
      (certificate 5 12 15) = true := by
  decide +kernel

theorem accepted05_12_16 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 12).erase 16)
      (certificate 5 12 16) = true := by
  decide +kernel

theorem accepted05_12_17 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 12).erase 17)
      (certificate 5 12 17) = true := by
  decide +kernel

theorem accepted05_12_18 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 12).erase 18)
      (certificate 5 12 18) = true := by
  decide +kernel

theorem accepted05_12_19 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 12).erase 19)
      (certificate 5 12 19) = true := by
  decide +kernel

theorem accepted05_13_14 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 13).erase 14)
      (certificate 5 13 14) = true := by
  decide +kernel

theorem accepted05_13_15 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 13).erase 15)
      (certificate 5 13 15) = true := by
  decide +kernel

theorem accepted05_13_16 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 13).erase 16)
      (certificate 5 13 16) = true := by
  decide +kernel

theorem accepted05_13_17 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 13).erase 17)
      (certificate 5 13 17) = true := by
  decide +kernel

theorem accepted05_13_18 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 13).erase 18)
      (certificate 5 13 18) = true := by
  decide +kernel

theorem accepted05_13_19 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 13).erase 19)
      (certificate 5 13 19) = true := by
  decide +kernel

theorem accepted05_14_15 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 14).erase 15)
      (certificate 5 14 15) = true := by
  decide +kernel

theorem accepted05_14_16 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 14).erase 16)
      (certificate 5 14 16) = true := by
  decide +kernel

theorem accepted05_14_17 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 14).erase 17)
      (certificate 5 14 17) = true := by
  decide +kernel

theorem accepted05_14_18 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 14).erase 18)
      (certificate 5 14 18) = true := by
  decide +kernel

theorem accepted05_14_19 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 14).erase 19)
      (certificate 5 14 19) = true := by
  decide +kernel

theorem accepted05_15_16 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 15).erase 16)
      (certificate 5 15 16) = true := by
  decide +kernel

theorem accepted05_15_17 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 15).erase 17)
      (certificate 5 15 17) = true := by
  decide +kernel

theorem accepted05_15_18 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 15).erase 18)
      (certificate 5 15 18) = true := by
  decide +kernel

theorem accepted05_15_19 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 15).erase 19)
      (certificate 5 15 19) = true := by
  decide +kernel

theorem accepted05_16_17 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 16).erase 17)
      (certificate 5 16 17) = true := by
  decide +kernel

theorem accepted05_16_18 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 16).erase 18)
      (certificate 5 16 18) = true := by
  decide +kernel

theorem accepted05_16_19 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 16).erase 19)
      (certificate 5 16 19) = true := by
  decide +kernel

theorem accepted05_17_18 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 17).erase 18)
      (certificate 5 17 18) = true := by
  decide +kernel

theorem accepted05_17_19 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 17).erase 19)
      (certificate 5 17 19) = true := by
  decide +kernel

theorem accepted05_18_19 :
    accepted spec (((Finset.univ.erase (5 : Label)).erase 18).erase 19)
      (certificate 5 18 19) = true := by
  decide +kernel

theorem accepted06_07_08 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 7).erase 8)
      (certificate 6 7 8) = true := by
  decide +kernel

theorem accepted06_07_09 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 7).erase 9)
      (certificate 6 7 9) = true := by
  decide +kernel

theorem accepted06_07_10 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 7).erase 10)
      (certificate 6 7 10) = true := by
  decide +kernel

theorem accepted06_07_11 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 7).erase 11)
      (certificate 6 7 11) = true := by
  decide +kernel

theorem accepted06_07_12 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 7).erase 12)
      (certificate 6 7 12) = true := by
  decide +kernel

theorem accepted06_07_13 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 7).erase 13)
      (certificate 6 7 13) = true := by
  decide +kernel

theorem accepted06_07_14 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 7).erase 14)
      (certificate 6 7 14) = true := by
  decide +kernel

theorem accepted06_07_15 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 7).erase 15)
      (certificate 6 7 15) = true := by
  decide +kernel

theorem accepted06_07_16 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 7).erase 16)
      (certificate 6 7 16) = true := by
  decide +kernel

theorem accepted06_07_17 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 7).erase 17)
      (certificate 6 7 17) = true := by
  decide +kernel

theorem accepted06_07_18 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 7).erase 18)
      (certificate 6 7 18) = true := by
  decide +kernel

theorem accepted06_07_19 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 7).erase 19)
      (certificate 6 7 19) = true := by
  decide +kernel

theorem accepted06_08_09 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 8).erase 9)
      (certificate 6 8 9) = true := by
  decide +kernel

theorem accepted06_08_10 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 8).erase 10)
      (certificate 6 8 10) = true := by
  decide +kernel

theorem accepted06_08_11 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 8).erase 11)
      (certificate 6 8 11) = true := by
  decide +kernel

theorem accepted06_08_12 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 8).erase 12)
      (certificate 6 8 12) = true := by
  decide +kernel

theorem accepted06_08_13 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 8).erase 13)
      (certificate 6 8 13) = true := by
  decide +kernel

theorem accepted06_08_14 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 8).erase 14)
      (certificate 6 8 14) = true := by
  decide +kernel

theorem accepted06_08_15 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 8).erase 15)
      (certificate 6 8 15) = true := by
  decide +kernel

theorem accepted06_08_16 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 8).erase 16)
      (certificate 6 8 16) = true := by
  decide +kernel

theorem accepted06_08_17 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 8).erase 17)
      (certificate 6 8 17) = true := by
  decide +kernel

theorem accepted06_08_18 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 8).erase 18)
      (certificate 6 8 18) = true := by
  decide +kernel

theorem accepted06_08_19 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 8).erase 19)
      (certificate 6 8 19) = true := by
  decide +kernel

theorem accepted06_09_10 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 9).erase 10)
      (certificate 6 9 10) = true := by
  decide +kernel

theorem accepted06_09_11 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 9).erase 11)
      (certificate 6 9 11) = true := by
  decide +kernel

theorem accepted06_09_12 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 9).erase 12)
      (certificate 6 9 12) = true := by
  decide +kernel

theorem accepted06_09_13 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 9).erase 13)
      (certificate 6 9 13) = true := by
  decide +kernel

theorem accepted06_09_14 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 9).erase 14)
      (certificate 6 9 14) = true := by
  decide +kernel

theorem accepted06_09_15 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 9).erase 15)
      (certificate 6 9 15) = true := by
  decide +kernel

theorem accepted06_09_16 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 9).erase 16)
      (certificate 6 9 16) = true := by
  decide +kernel

theorem accepted06_09_17 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 9).erase 17)
      (certificate 6 9 17) = true := by
  decide +kernel

theorem accepted06_09_18 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 9).erase 18)
      (certificate 6 9 18) = true := by
  decide +kernel

theorem accepted06_09_19 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 9).erase 19)
      (certificate 6 9 19) = true := by
  decide +kernel

theorem accepted06_10_11 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 10).erase 11)
      (certificate 6 10 11) = true := by
  decide +kernel

theorem accepted06_10_12 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 10).erase 12)
      (certificate 6 10 12) = true := by
  decide +kernel

theorem accepted06_10_13 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 10).erase 13)
      (certificate 6 10 13) = true := by
  decide +kernel

theorem accepted06_10_14 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 10).erase 14)
      (certificate 6 10 14) = true := by
  decide +kernel

theorem accepted06_10_15 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 10).erase 15)
      (certificate 6 10 15) = true := by
  decide +kernel

theorem accepted06_10_16 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 10).erase 16)
      (certificate 6 10 16) = true := by
  decide +kernel

theorem accepted06_10_17 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 10).erase 17)
      (certificate 6 10 17) = true := by
  decide +kernel

theorem accepted06_10_18 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 10).erase 18)
      (certificate 6 10 18) = true := by
  decide +kernel

theorem accepted06_10_19 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 10).erase 19)
      (certificate 6 10 19) = true := by
  decide +kernel

theorem accepted06_11_12 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 11).erase 12)
      (certificate 6 11 12) = true := by
  decide +kernel

theorem accepted06_11_13 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 11).erase 13)
      (certificate 6 11 13) = true := by
  decide +kernel

theorem accepted06_11_14 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 11).erase 14)
      (certificate 6 11 14) = true := by
  decide +kernel

theorem accepted06_11_15 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 11).erase 15)
      (certificate 6 11 15) = true := by
  decide +kernel

theorem accepted06_11_16 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 11).erase 16)
      (certificate 6 11 16) = true := by
  decide +kernel

theorem accepted06_11_17 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 11).erase 17)
      (certificate 6 11 17) = true := by
  decide +kernel

theorem accepted06_11_18 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 11).erase 18)
      (certificate 6 11 18) = true := by
  decide +kernel

theorem accepted06_11_19 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 11).erase 19)
      (certificate 6 11 19) = true := by
  decide +kernel

theorem accepted06_12_13 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 12).erase 13)
      (certificate 6 12 13) = true := by
  decide +kernel

theorem accepted06_12_14 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 12).erase 14)
      (certificate 6 12 14) = true := by
  decide +kernel

theorem accepted06_12_15 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 12).erase 15)
      (certificate 6 12 15) = true := by
  decide +kernel

theorem accepted06_12_16 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 12).erase 16)
      (certificate 6 12 16) = true := by
  decide +kernel

theorem accepted06_12_17 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 12).erase 17)
      (certificate 6 12 17) = true := by
  decide +kernel

theorem accepted06_12_18 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 12).erase 18)
      (certificate 6 12 18) = true := by
  decide +kernel

theorem accepted06_12_19 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 12).erase 19)
      (certificate 6 12 19) = true := by
  decide +kernel

theorem accepted06_13_14 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 13).erase 14)
      (certificate 6 13 14) = true := by
  decide +kernel

theorem accepted06_13_15 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 13).erase 15)
      (certificate 6 13 15) = true := by
  decide +kernel

theorem accepted06_13_16 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 13).erase 16)
      (certificate 6 13 16) = true := by
  decide +kernel

theorem accepted06_13_17 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 13).erase 17)
      (certificate 6 13 17) = true := by
  decide +kernel

theorem accepted06_13_18 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 13).erase 18)
      (certificate 6 13 18) = true := by
  decide +kernel

theorem accepted06_13_19 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 13).erase 19)
      (certificate 6 13 19) = true := by
  decide +kernel

theorem accepted06_14_15 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 14).erase 15)
      (certificate 6 14 15) = true := by
  decide +kernel

theorem accepted06_14_16 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 14).erase 16)
      (certificate 6 14 16) = true := by
  decide +kernel

theorem accepted06_14_17 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 14).erase 17)
      (certificate 6 14 17) = true := by
  decide +kernel

theorem accepted06_14_18 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 14).erase 18)
      (certificate 6 14 18) = true := by
  decide +kernel

theorem accepted06_14_19 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 14).erase 19)
      (certificate 6 14 19) = true := by
  decide +kernel

theorem accepted06_15_16 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 15).erase 16)
      (certificate 6 15 16) = true := by
  decide +kernel

theorem accepted06_15_17 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 15).erase 17)
      (certificate 6 15 17) = true := by
  decide +kernel

theorem accepted06_15_18 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 15).erase 18)
      (certificate 6 15 18) = true := by
  decide +kernel

theorem accepted06_15_19 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 15).erase 19)
      (certificate 6 15 19) = true := by
  decide +kernel

theorem accepted06_16_17 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 16).erase 17)
      (certificate 6 16 17) = true := by
  decide +kernel

theorem accepted06_16_18 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 16).erase 18)
      (certificate 6 16 18) = true := by
  decide +kernel

theorem accepted06_16_19 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 16).erase 19)
      (certificate 6 16 19) = true := by
  decide +kernel

theorem accepted06_17_18 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 17).erase 18)
      (certificate 6 17 18) = true := by
  decide +kernel

theorem accepted06_17_19 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 17).erase 19)
      (certificate 6 17 19) = true := by
  decide +kernel

theorem accepted06_18_19 :
    accepted spec (((Finset.univ.erase (6 : Label)).erase 18).erase 19)
      (certificate 6 18 19) = true := by
  decide +kernel

theorem accepted07_08_09 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 8).erase 9)
      (certificate 7 8 9) = true := by
  decide +kernel

theorem accepted07_08_10 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 8).erase 10)
      (certificate 7 8 10) = true := by
  decide +kernel

theorem accepted07_08_11 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 8).erase 11)
      (certificate 7 8 11) = true := by
  decide +kernel

theorem accepted07_08_12 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 8).erase 12)
      (certificate 7 8 12) = true := by
  decide +kernel

theorem accepted07_08_13 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 8).erase 13)
      (certificate 7 8 13) = true := by
  decide +kernel

theorem accepted07_08_14 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 8).erase 14)
      (certificate 7 8 14) = true := by
  decide +kernel

theorem accepted07_08_15 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 8).erase 15)
      (certificate 7 8 15) = true := by
  decide +kernel

theorem accepted07_08_16 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 8).erase 16)
      (certificate 7 8 16) = true := by
  decide +kernel

theorem accepted07_08_17 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 8).erase 17)
      (certificate 7 8 17) = true := by
  decide +kernel

theorem accepted07_08_18 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 8).erase 18)
      (certificate 7 8 18) = true := by
  decide +kernel

theorem accepted07_08_19 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 8).erase 19)
      (certificate 7 8 19) = true := by
  decide +kernel

theorem accepted07_09_10 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 9).erase 10)
      (certificate 7 9 10) = true := by
  decide +kernel

theorem accepted07_09_11 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 9).erase 11)
      (certificate 7 9 11) = true := by
  decide +kernel

theorem accepted07_09_12 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 9).erase 12)
      (certificate 7 9 12) = true := by
  decide +kernel

theorem accepted07_09_13 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 9).erase 13)
      (certificate 7 9 13) = true := by
  decide +kernel

theorem accepted07_09_14 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 9).erase 14)
      (certificate 7 9 14) = true := by
  decide +kernel

theorem accepted07_09_15 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 9).erase 15)
      (certificate 7 9 15) = true := by
  decide +kernel

theorem accepted07_09_16 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 9).erase 16)
      (certificate 7 9 16) = true := by
  decide +kernel

theorem accepted07_09_17 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 9).erase 17)
      (certificate 7 9 17) = true := by
  decide +kernel

theorem accepted07_09_18 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 9).erase 18)
      (certificate 7 9 18) = true := by
  decide +kernel

theorem accepted07_09_19 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 9).erase 19)
      (certificate 7 9 19) = true := by
  decide +kernel

theorem accepted07_10_11 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 10).erase 11)
      (certificate 7 10 11) = true := by
  decide +kernel

theorem accepted07_10_12 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 10).erase 12)
      (certificate 7 10 12) = true := by
  decide +kernel

theorem accepted07_10_13 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 10).erase 13)
      (certificate 7 10 13) = true := by
  decide +kernel

theorem accepted07_10_14 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 10).erase 14)
      (certificate 7 10 14) = true := by
  decide +kernel

theorem accepted07_10_15 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 10).erase 15)
      (certificate 7 10 15) = true := by
  decide +kernel

theorem accepted07_10_16 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 10).erase 16)
      (certificate 7 10 16) = true := by
  decide +kernel

theorem accepted07_10_17 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 10).erase 17)
      (certificate 7 10 17) = true := by
  decide +kernel

theorem accepted07_10_18 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 10).erase 18)
      (certificate 7 10 18) = true := by
  decide +kernel

theorem accepted07_10_19 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 10).erase 19)
      (certificate 7 10 19) = true := by
  decide +kernel

theorem accepted07_11_12 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 11).erase 12)
      (certificate 7 11 12) = true := by
  decide +kernel

theorem accepted07_11_13 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 11).erase 13)
      (certificate 7 11 13) = true := by
  decide +kernel

theorem accepted07_11_14 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 11).erase 14)
      (certificate 7 11 14) = true := by
  decide +kernel

theorem accepted07_11_15 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 11).erase 15)
      (certificate 7 11 15) = true := by
  decide +kernel

theorem accepted07_11_16 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 11).erase 16)
      (certificate 7 11 16) = true := by
  decide +kernel

theorem accepted07_11_17 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 11).erase 17)
      (certificate 7 11 17) = true := by
  decide +kernel

theorem accepted07_11_18 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 11).erase 18)
      (certificate 7 11 18) = true := by
  decide +kernel

theorem accepted07_11_19 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 11).erase 19)
      (certificate 7 11 19) = true := by
  decide +kernel

theorem accepted07_12_13 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 12).erase 13)
      (certificate 7 12 13) = true := by
  decide +kernel

theorem accepted07_12_14 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 12).erase 14)
      (certificate 7 12 14) = true := by
  decide +kernel

theorem accepted07_12_15 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 12).erase 15)
      (certificate 7 12 15) = true := by
  decide +kernel

theorem accepted07_12_16 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 12).erase 16)
      (certificate 7 12 16) = true := by
  decide +kernel

theorem accepted07_12_17 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 12).erase 17)
      (certificate 7 12 17) = true := by
  decide +kernel

theorem accepted07_12_18 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 12).erase 18)
      (certificate 7 12 18) = true := by
  decide +kernel

theorem accepted07_12_19 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 12).erase 19)
      (certificate 7 12 19) = true := by
  decide +kernel

theorem accepted07_13_14 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 13).erase 14)
      (certificate 7 13 14) = true := by
  decide +kernel

theorem accepted07_13_15 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 13).erase 15)
      (certificate 7 13 15) = true := by
  decide +kernel

theorem accepted07_13_16 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 13).erase 16)
      (certificate 7 13 16) = true := by
  decide +kernel

theorem accepted07_13_17 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 13).erase 17)
      (certificate 7 13 17) = true := by
  decide +kernel

theorem accepted07_13_18 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 13).erase 18)
      (certificate 7 13 18) = true := by
  decide +kernel

theorem accepted07_13_19 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 13).erase 19)
      (certificate 7 13 19) = true := by
  decide +kernel

theorem accepted07_14_15 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 14).erase 15)
      (certificate 7 14 15) = true := by
  decide +kernel

theorem accepted07_14_16 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 14).erase 16)
      (certificate 7 14 16) = true := by
  decide +kernel

theorem accepted07_14_17 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 14).erase 17)
      (certificate 7 14 17) = true := by
  decide +kernel

theorem accepted07_14_18 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 14).erase 18)
      (certificate 7 14 18) = true := by
  decide +kernel

theorem accepted07_14_19 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 14).erase 19)
      (certificate 7 14 19) = true := by
  decide +kernel

theorem accepted07_15_16 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 15).erase 16)
      (certificate 7 15 16) = true := by
  decide +kernel

theorem accepted07_15_17 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 15).erase 17)
      (certificate 7 15 17) = true := by
  decide +kernel

theorem accepted07_15_18 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 15).erase 18)
      (certificate 7 15 18) = true := by
  decide +kernel

theorem accepted07_15_19 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 15).erase 19)
      (certificate 7 15 19) = true := by
  decide +kernel

theorem accepted07_16_17 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 16).erase 17)
      (certificate 7 16 17) = true := by
  decide +kernel

theorem accepted07_16_18 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 16).erase 18)
      (certificate 7 16 18) = true := by
  decide +kernel

theorem accepted07_16_19 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 16).erase 19)
      (certificate 7 16 19) = true := by
  decide +kernel

theorem accepted07_17_18 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 17).erase 18)
      (certificate 7 17 18) = true := by
  decide +kernel

theorem accepted07_17_19 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 17).erase 19)
      (certificate 7 17 19) = true := by
  decide +kernel

theorem accepted07_18_19 :
    accepted spec (((Finset.univ.erase (7 : Label)).erase 18).erase 19)
      (certificate 7 18 19) = true := by
  decide +kernel

theorem accepted08_09_10 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 9).erase 10)
      (certificate 8 9 10) = true := by
  decide +kernel

theorem accepted08_09_11 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 9).erase 11)
      (certificate 8 9 11) = true := by
  decide +kernel

theorem accepted08_09_12 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 9).erase 12)
      (certificate 8 9 12) = true := by
  decide +kernel

theorem accepted08_09_13 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 9).erase 13)
      (certificate 8 9 13) = true := by
  decide +kernel

theorem accepted08_09_14 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 9).erase 14)
      (certificate 8 9 14) = true := by
  decide +kernel

theorem accepted08_09_15 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 9).erase 15)
      (certificate 8 9 15) = true := by
  decide +kernel

theorem accepted08_09_16 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 9).erase 16)
      (certificate 8 9 16) = true := by
  decide +kernel

theorem accepted08_09_17 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 9).erase 17)
      (certificate 8 9 17) = true := by
  decide +kernel

theorem accepted08_09_18 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 9).erase 18)
      (certificate 8 9 18) = true := by
  decide +kernel

theorem accepted08_09_19 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 9).erase 19)
      (certificate 8 9 19) = true := by
  decide +kernel

theorem accepted08_10_11 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 10).erase 11)
      (certificate 8 10 11) = true := by
  decide +kernel

theorem accepted08_10_12 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 10).erase 12)
      (certificate 8 10 12) = true := by
  decide +kernel

theorem accepted08_10_13 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 10).erase 13)
      (certificate 8 10 13) = true := by
  decide +kernel

theorem accepted08_10_14 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 10).erase 14)
      (certificate 8 10 14) = true := by
  decide +kernel

theorem accepted08_10_15 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 10).erase 15)
      (certificate 8 10 15) = true := by
  decide +kernel

theorem accepted08_10_16 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 10).erase 16)
      (certificate 8 10 16) = true := by
  decide +kernel

theorem accepted08_10_17 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 10).erase 17)
      (certificate 8 10 17) = true := by
  decide +kernel

theorem accepted08_10_18 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 10).erase 18)
      (certificate 8 10 18) = true := by
  decide +kernel

theorem accepted08_10_19 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 10).erase 19)
      (certificate 8 10 19) = true := by
  decide +kernel

theorem accepted08_11_12 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 11).erase 12)
      (certificate 8 11 12) = true := by
  decide +kernel

theorem accepted08_11_13 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 11).erase 13)
      (certificate 8 11 13) = true := by
  decide +kernel

theorem accepted08_11_14 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 11).erase 14)
      (certificate 8 11 14) = true := by
  decide +kernel

theorem accepted08_11_15 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 11).erase 15)
      (certificate 8 11 15) = true := by
  decide +kernel

theorem accepted08_11_16 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 11).erase 16)
      (certificate 8 11 16) = true := by
  decide +kernel

theorem accepted08_11_17 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 11).erase 17)
      (certificate 8 11 17) = true := by
  decide +kernel

theorem accepted08_11_18 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 11).erase 18)
      (certificate 8 11 18) = true := by
  decide +kernel

theorem accepted08_11_19 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 11).erase 19)
      (certificate 8 11 19) = true := by
  decide +kernel

theorem accepted08_12_13 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 12).erase 13)
      (certificate 8 12 13) = true := by
  decide +kernel

theorem accepted08_12_14 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 12).erase 14)
      (certificate 8 12 14) = true := by
  decide +kernel

theorem accepted08_12_15 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 12).erase 15)
      (certificate 8 12 15) = true := by
  decide +kernel

theorem accepted08_12_16 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 12).erase 16)
      (certificate 8 12 16) = true := by
  decide +kernel

theorem accepted08_12_17 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 12).erase 17)
      (certificate 8 12 17) = true := by
  decide +kernel

theorem accepted08_12_18 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 12).erase 18)
      (certificate 8 12 18) = true := by
  decide +kernel

theorem accepted08_12_19 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 12).erase 19)
      (certificate 8 12 19) = true := by
  decide +kernel

theorem accepted08_13_14 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 13).erase 14)
      (certificate 8 13 14) = true := by
  decide +kernel

theorem accepted08_13_15 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 13).erase 15)
      (certificate 8 13 15) = true := by
  decide +kernel

theorem accepted08_13_16 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 13).erase 16)
      (certificate 8 13 16) = true := by
  decide +kernel

theorem accepted08_13_17 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 13).erase 17)
      (certificate 8 13 17) = true := by
  decide +kernel

theorem accepted08_13_18 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 13).erase 18)
      (certificate 8 13 18) = true := by
  decide +kernel

theorem accepted08_13_19 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 13).erase 19)
      (certificate 8 13 19) = true := by
  decide +kernel

theorem accepted08_14_15 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 14).erase 15)
      (certificate 8 14 15) = true := by
  decide +kernel

theorem accepted08_14_16 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 14).erase 16)
      (certificate 8 14 16) = true := by
  decide +kernel

theorem accepted08_14_17 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 14).erase 17)
      (certificate 8 14 17) = true := by
  decide +kernel

theorem accepted08_14_18 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 14).erase 18)
      (certificate 8 14 18) = true := by
  decide +kernel

theorem accepted08_14_19 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 14).erase 19)
      (certificate 8 14 19) = true := by
  decide +kernel

theorem accepted08_15_16 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 15).erase 16)
      (certificate 8 15 16) = true := by
  decide +kernel

theorem accepted08_15_17 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 15).erase 17)
      (certificate 8 15 17) = true := by
  decide +kernel

theorem accepted08_15_18 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 15).erase 18)
      (certificate 8 15 18) = true := by
  decide +kernel

theorem accepted08_15_19 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 15).erase 19)
      (certificate 8 15 19) = true := by
  decide +kernel

theorem accepted08_16_17 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 16).erase 17)
      (certificate 8 16 17) = true := by
  decide +kernel

theorem accepted08_16_18 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 16).erase 18)
      (certificate 8 16 18) = true := by
  decide +kernel

theorem accepted08_16_19 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 16).erase 19)
      (certificate 8 16 19) = true := by
  decide +kernel

theorem accepted08_17_18 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 17).erase 18)
      (certificate 8 17 18) = true := by
  decide +kernel

theorem accepted08_17_19 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 17).erase 19)
      (certificate 8 17 19) = true := by
  decide +kernel

theorem accepted08_18_19 :
    accepted spec (((Finset.univ.erase (8 : Label)).erase 18).erase 19)
      (certificate 8 18 19) = true := by
  decide +kernel

theorem accepted09_10_11 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 10).erase 11)
      (certificate 9 10 11) = true := by
  decide +kernel

theorem accepted09_10_12 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 10).erase 12)
      (certificate 9 10 12) = true := by
  decide +kernel

theorem accepted09_10_13 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 10).erase 13)
      (certificate 9 10 13) = true := by
  decide +kernel

theorem accepted09_10_14 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 10).erase 14)
      (certificate 9 10 14) = true := by
  decide +kernel

theorem accepted09_10_15 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 10).erase 15)
      (certificate 9 10 15) = true := by
  decide +kernel

theorem accepted09_10_16 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 10).erase 16)
      (certificate 9 10 16) = true := by
  decide +kernel

theorem accepted09_10_17 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 10).erase 17)
      (certificate 9 10 17) = true := by
  decide +kernel

theorem accepted09_10_18 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 10).erase 18)
      (certificate 9 10 18) = true := by
  decide +kernel

theorem accepted09_10_19 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 10).erase 19)
      (certificate 9 10 19) = true := by
  decide +kernel

theorem accepted09_11_12 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 11).erase 12)
      (certificate 9 11 12) = true := by
  decide +kernel

theorem accepted09_11_13 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 11).erase 13)
      (certificate 9 11 13) = true := by
  decide +kernel

theorem accepted09_11_14 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 11).erase 14)
      (certificate 9 11 14) = true := by
  decide +kernel

theorem accepted09_11_15 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 11).erase 15)
      (certificate 9 11 15) = true := by
  decide +kernel

theorem accepted09_11_16 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 11).erase 16)
      (certificate 9 11 16) = true := by
  decide +kernel

theorem accepted09_11_17 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 11).erase 17)
      (certificate 9 11 17) = true := by
  decide +kernel

theorem accepted09_11_18 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 11).erase 18)
      (certificate 9 11 18) = true := by
  decide +kernel

theorem accepted09_11_19 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 11).erase 19)
      (certificate 9 11 19) = true := by
  decide +kernel

theorem accepted09_12_13 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 12).erase 13)
      (certificate 9 12 13) = true := by
  decide +kernel

theorem accepted09_12_14 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 12).erase 14)
      (certificate 9 12 14) = true := by
  decide +kernel

theorem accepted09_12_15 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 12).erase 15)
      (certificate 9 12 15) = true := by
  decide +kernel

theorem accepted09_12_16 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 12).erase 16)
      (certificate 9 12 16) = true := by
  decide +kernel

theorem accepted09_12_17 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 12).erase 17)
      (certificate 9 12 17) = true := by
  decide +kernel

theorem accepted09_12_18 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 12).erase 18)
      (certificate 9 12 18) = true := by
  decide +kernel

theorem accepted09_12_19 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 12).erase 19)
      (certificate 9 12 19) = true := by
  decide +kernel

theorem accepted09_13_14 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 13).erase 14)
      (certificate 9 13 14) = true := by
  decide +kernel

theorem accepted09_13_15 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 13).erase 15)
      (certificate 9 13 15) = true := by
  decide +kernel

theorem accepted09_13_16 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 13).erase 16)
      (certificate 9 13 16) = true := by
  decide +kernel

theorem accepted09_13_17 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 13).erase 17)
      (certificate 9 13 17) = true := by
  decide +kernel

theorem accepted09_13_18 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 13).erase 18)
      (certificate 9 13 18) = true := by
  decide +kernel

theorem accepted09_13_19 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 13).erase 19)
      (certificate 9 13 19) = true := by
  decide +kernel

theorem accepted09_14_15 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 14).erase 15)
      (certificate 9 14 15) = true := by
  decide +kernel

theorem accepted09_14_16 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 14).erase 16)
      (certificate 9 14 16) = true := by
  decide +kernel

theorem accepted09_14_17 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 14).erase 17)
      (certificate 9 14 17) = true := by
  decide +kernel

theorem accepted09_14_18 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 14).erase 18)
      (certificate 9 14 18) = true := by
  decide +kernel

theorem accepted09_14_19 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 14).erase 19)
      (certificate 9 14 19) = true := by
  decide +kernel

theorem accepted09_15_16 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 15).erase 16)
      (certificate 9 15 16) = true := by
  decide +kernel

theorem accepted09_15_17 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 15).erase 17)
      (certificate 9 15 17) = true := by
  decide +kernel

theorem accepted09_15_18 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 15).erase 18)
      (certificate 9 15 18) = true := by
  decide +kernel

theorem accepted09_15_19 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 15).erase 19)
      (certificate 9 15 19) = true := by
  decide +kernel

theorem accepted09_16_17 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 16).erase 17)
      (certificate 9 16 17) = true := by
  decide +kernel

theorem accepted09_16_18 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 16).erase 18)
      (certificate 9 16 18) = true := by
  decide +kernel

theorem accepted09_16_19 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 16).erase 19)
      (certificate 9 16 19) = true := by
  decide +kernel

theorem accepted09_17_18 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 17).erase 18)
      (certificate 9 17 18) = true := by
  decide +kernel

theorem accepted09_17_19 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 17).erase 19)
      (certificate 9 17 19) = true := by
  decide +kernel

theorem accepted09_18_19 :
    accepted spec (((Finset.univ.erase (9 : Label)).erase 18).erase 19)
      (certificate 9 18 19) = true := by
  decide +kernel

theorem accepted10_11_12 :
    accepted spec (((Finset.univ.erase (10 : Label)).erase 11).erase 12)
      (certificate 10 11 12) = true := by
  decide +kernel

theorem accepted10_11_13 :
    accepted spec (((Finset.univ.erase (10 : Label)).erase 11).erase 13)
      (certificate 10 11 13) = true := by
  decide +kernel

theorem accepted10_11_14 :
    accepted spec (((Finset.univ.erase (10 : Label)).erase 11).erase 14)
      (certificate 10 11 14) = true := by
  decide +kernel

theorem accepted10_11_15 :
    accepted spec (((Finset.univ.erase (10 : Label)).erase 11).erase 15)
      (certificate 10 11 15) = true := by
  decide +kernel

theorem accepted10_11_16 :
    accepted spec (((Finset.univ.erase (10 : Label)).erase 11).erase 16)
      (certificate 10 11 16) = true := by
  decide +kernel

theorem accepted10_11_17 :
    accepted spec (((Finset.univ.erase (10 : Label)).erase 11).erase 17)
      (certificate 10 11 17) = true := by
  decide +kernel

theorem accepted10_11_18 :
    accepted spec (((Finset.univ.erase (10 : Label)).erase 11).erase 18)
      (certificate 10 11 18) = true := by
  decide +kernel

theorem accepted10_11_19 :
    accepted spec (((Finset.univ.erase (10 : Label)).erase 11).erase 19)
      (certificate 10 11 19) = true := by
  decide +kernel

theorem accepted10_12_13 :
    accepted spec (((Finset.univ.erase (10 : Label)).erase 12).erase 13)
      (certificate 10 12 13) = true := by
  decide +kernel

theorem accepted10_12_14 :
    accepted spec (((Finset.univ.erase (10 : Label)).erase 12).erase 14)
      (certificate 10 12 14) = true := by
  decide +kernel

theorem accepted10_12_15 :
    accepted spec (((Finset.univ.erase (10 : Label)).erase 12).erase 15)
      (certificate 10 12 15) = true := by
  decide +kernel

theorem accepted10_12_16 :
    accepted spec (((Finset.univ.erase (10 : Label)).erase 12).erase 16)
      (certificate 10 12 16) = true := by
  decide +kernel

theorem accepted10_12_17 :
    accepted spec (((Finset.univ.erase (10 : Label)).erase 12).erase 17)
      (certificate 10 12 17) = true := by
  decide +kernel

theorem accepted10_12_18 :
    accepted spec (((Finset.univ.erase (10 : Label)).erase 12).erase 18)
      (certificate 10 12 18) = true := by
  decide +kernel

theorem accepted10_12_19 :
    accepted spec (((Finset.univ.erase (10 : Label)).erase 12).erase 19)
      (certificate 10 12 19) = true := by
  decide +kernel

theorem accepted10_13_14 :
    accepted spec (((Finset.univ.erase (10 : Label)).erase 13).erase 14)
      (certificate 10 13 14) = true := by
  decide +kernel

theorem accepted10_13_15 :
    accepted spec (((Finset.univ.erase (10 : Label)).erase 13).erase 15)
      (certificate 10 13 15) = true := by
  decide +kernel

theorem accepted10_13_16 :
    accepted spec (((Finset.univ.erase (10 : Label)).erase 13).erase 16)
      (certificate 10 13 16) = true := by
  decide +kernel

theorem accepted10_13_17 :
    accepted spec (((Finset.univ.erase (10 : Label)).erase 13).erase 17)
      (certificate 10 13 17) = true := by
  decide +kernel

theorem accepted10_13_18 :
    accepted spec (((Finset.univ.erase (10 : Label)).erase 13).erase 18)
      (certificate 10 13 18) = true := by
  decide +kernel

theorem accepted10_13_19 :
    accepted spec (((Finset.univ.erase (10 : Label)).erase 13).erase 19)
      (certificate 10 13 19) = true := by
  decide +kernel

theorem accepted10_14_15 :
    accepted spec (((Finset.univ.erase (10 : Label)).erase 14).erase 15)
      (certificate 10 14 15) = true := by
  decide +kernel

theorem accepted10_14_16 :
    accepted spec (((Finset.univ.erase (10 : Label)).erase 14).erase 16)
      (certificate 10 14 16) = true := by
  decide +kernel

theorem accepted10_14_17 :
    accepted spec (((Finset.univ.erase (10 : Label)).erase 14).erase 17)
      (certificate 10 14 17) = true := by
  decide +kernel

theorem accepted10_14_18 :
    accepted spec (((Finset.univ.erase (10 : Label)).erase 14).erase 18)
      (certificate 10 14 18) = true := by
  decide +kernel

theorem accepted10_14_19 :
    accepted spec (((Finset.univ.erase (10 : Label)).erase 14).erase 19)
      (certificate 10 14 19) = true := by
  decide +kernel

theorem accepted10_15_16 :
    accepted spec (((Finset.univ.erase (10 : Label)).erase 15).erase 16)
      (certificate 10 15 16) = true := by
  decide +kernel

theorem accepted10_15_17 :
    accepted spec (((Finset.univ.erase (10 : Label)).erase 15).erase 17)
      (certificate 10 15 17) = true := by
  decide +kernel

theorem accepted10_15_18 :
    accepted spec (((Finset.univ.erase (10 : Label)).erase 15).erase 18)
      (certificate 10 15 18) = true := by
  decide +kernel

theorem accepted10_15_19 :
    accepted spec (((Finset.univ.erase (10 : Label)).erase 15).erase 19)
      (certificate 10 15 19) = true := by
  decide +kernel

theorem accepted10_16_17 :
    accepted spec (((Finset.univ.erase (10 : Label)).erase 16).erase 17)
      (certificate 10 16 17) = true := by
  decide +kernel

theorem accepted10_16_18 :
    accepted spec (((Finset.univ.erase (10 : Label)).erase 16).erase 18)
      (certificate 10 16 18) = true := by
  decide +kernel

theorem accepted10_16_19 :
    accepted spec (((Finset.univ.erase (10 : Label)).erase 16).erase 19)
      (certificate 10 16 19) = true := by
  decide +kernel

theorem accepted10_17_18 :
    accepted spec (((Finset.univ.erase (10 : Label)).erase 17).erase 18)
      (certificate 10 17 18) = true := by
  decide +kernel

theorem accepted10_17_19 :
    accepted spec (((Finset.univ.erase (10 : Label)).erase 17).erase 19)
      (certificate 10 17 19) = true := by
  decide +kernel

theorem accepted10_18_19 :
    accepted spec (((Finset.univ.erase (10 : Label)).erase 18).erase 19)
      (certificate 10 18 19) = true := by
  decide +kernel

theorem accepted11_12_13 :
    accepted spec (((Finset.univ.erase (11 : Label)).erase 12).erase 13)
      (certificate 11 12 13) = true := by
  decide +kernel

theorem accepted11_12_14 :
    accepted spec (((Finset.univ.erase (11 : Label)).erase 12).erase 14)
      (certificate 11 12 14) = true := by
  decide +kernel

theorem accepted11_12_15 :
    accepted spec (((Finset.univ.erase (11 : Label)).erase 12).erase 15)
      (certificate 11 12 15) = true := by
  decide +kernel

theorem accepted11_12_16 :
    accepted spec (((Finset.univ.erase (11 : Label)).erase 12).erase 16)
      (certificate 11 12 16) = true := by
  decide +kernel

theorem accepted11_12_17 :
    accepted spec (((Finset.univ.erase (11 : Label)).erase 12).erase 17)
      (certificate 11 12 17) = true := by
  decide +kernel

theorem accepted11_12_18 :
    accepted spec (((Finset.univ.erase (11 : Label)).erase 12).erase 18)
      (certificate 11 12 18) = true := by
  decide +kernel

theorem accepted11_12_19 :
    accepted spec (((Finset.univ.erase (11 : Label)).erase 12).erase 19)
      (certificate 11 12 19) = true := by
  decide +kernel

theorem accepted11_13_14 :
    accepted spec (((Finset.univ.erase (11 : Label)).erase 13).erase 14)
      (certificate 11 13 14) = true := by
  decide +kernel

theorem accepted11_13_15 :
    accepted spec (((Finset.univ.erase (11 : Label)).erase 13).erase 15)
      (certificate 11 13 15) = true := by
  decide +kernel

theorem accepted11_13_16 :
    accepted spec (((Finset.univ.erase (11 : Label)).erase 13).erase 16)
      (certificate 11 13 16) = true := by
  decide +kernel

theorem accepted11_13_17 :
    accepted spec (((Finset.univ.erase (11 : Label)).erase 13).erase 17)
      (certificate 11 13 17) = true := by
  decide +kernel

theorem accepted11_13_18 :
    accepted spec (((Finset.univ.erase (11 : Label)).erase 13).erase 18)
      (certificate 11 13 18) = true := by
  decide +kernel

theorem accepted11_13_19 :
    accepted spec (((Finset.univ.erase (11 : Label)).erase 13).erase 19)
      (certificate 11 13 19) = true := by
  decide +kernel

theorem accepted11_14_15 :
    accepted spec (((Finset.univ.erase (11 : Label)).erase 14).erase 15)
      (certificate 11 14 15) = true := by
  decide +kernel

theorem accepted11_14_16 :
    accepted spec (((Finset.univ.erase (11 : Label)).erase 14).erase 16)
      (certificate 11 14 16) = true := by
  decide +kernel

theorem accepted11_14_17 :
    accepted spec (((Finset.univ.erase (11 : Label)).erase 14).erase 17)
      (certificate 11 14 17) = true := by
  decide +kernel

theorem accepted11_14_18 :
    accepted spec (((Finset.univ.erase (11 : Label)).erase 14).erase 18)
      (certificate 11 14 18) = true := by
  decide +kernel

theorem accepted11_14_19 :
    accepted spec (((Finset.univ.erase (11 : Label)).erase 14).erase 19)
      (certificate 11 14 19) = true := by
  decide +kernel

theorem accepted11_15_16 :
    accepted spec (((Finset.univ.erase (11 : Label)).erase 15).erase 16)
      (certificate 11 15 16) = true := by
  decide +kernel

theorem accepted11_15_17 :
    accepted spec (((Finset.univ.erase (11 : Label)).erase 15).erase 17)
      (certificate 11 15 17) = true := by
  decide +kernel

theorem accepted11_15_18 :
    accepted spec (((Finset.univ.erase (11 : Label)).erase 15).erase 18)
      (certificate 11 15 18) = true := by
  decide +kernel

theorem accepted11_15_19 :
    accepted spec (((Finset.univ.erase (11 : Label)).erase 15).erase 19)
      (certificate 11 15 19) = true := by
  decide +kernel

theorem accepted11_16_17 :
    accepted spec (((Finset.univ.erase (11 : Label)).erase 16).erase 17)
      (certificate 11 16 17) = true := by
  decide +kernel

theorem accepted11_16_18 :
    accepted spec (((Finset.univ.erase (11 : Label)).erase 16).erase 18)
      (certificate 11 16 18) = true := by
  decide +kernel

theorem accepted11_16_19 :
    accepted spec (((Finset.univ.erase (11 : Label)).erase 16).erase 19)
      (certificate 11 16 19) = true := by
  decide +kernel

theorem accepted11_17_18 :
    accepted spec (((Finset.univ.erase (11 : Label)).erase 17).erase 18)
      (certificate 11 17 18) = true := by
  decide +kernel

theorem accepted11_17_19 :
    accepted spec (((Finset.univ.erase (11 : Label)).erase 17).erase 19)
      (certificate 11 17 19) = true := by
  decide +kernel

theorem accepted11_18_19 :
    accepted spec (((Finset.univ.erase (11 : Label)).erase 18).erase 19)
      (certificate 11 18 19) = true := by
  decide +kernel

theorem accepted12_13_14 :
    accepted spec (((Finset.univ.erase (12 : Label)).erase 13).erase 14)
      (certificate 12 13 14) = true := by
  decide +kernel

theorem accepted12_13_15 :
    accepted spec (((Finset.univ.erase (12 : Label)).erase 13).erase 15)
      (certificate 12 13 15) = true := by
  decide +kernel

theorem accepted12_13_16 :
    accepted spec (((Finset.univ.erase (12 : Label)).erase 13).erase 16)
      (certificate 12 13 16) = true := by
  decide +kernel

theorem accepted12_13_17 :
    accepted spec (((Finset.univ.erase (12 : Label)).erase 13).erase 17)
      (certificate 12 13 17) = true := by
  decide +kernel

theorem accepted12_13_18 :
    accepted spec (((Finset.univ.erase (12 : Label)).erase 13).erase 18)
      (certificate 12 13 18) = true := by
  decide +kernel

theorem accepted12_13_19 :
    accepted spec (((Finset.univ.erase (12 : Label)).erase 13).erase 19)
      (certificate 12 13 19) = true := by
  decide +kernel

theorem accepted12_14_15 :
    accepted spec (((Finset.univ.erase (12 : Label)).erase 14).erase 15)
      (certificate 12 14 15) = true := by
  decide +kernel

theorem accepted12_14_16 :
    accepted spec (((Finset.univ.erase (12 : Label)).erase 14).erase 16)
      (certificate 12 14 16) = true := by
  decide +kernel

theorem accepted12_14_17 :
    accepted spec (((Finset.univ.erase (12 : Label)).erase 14).erase 17)
      (certificate 12 14 17) = true := by
  decide +kernel

theorem accepted12_14_18 :
    accepted spec (((Finset.univ.erase (12 : Label)).erase 14).erase 18)
      (certificate 12 14 18) = true := by
  decide +kernel

theorem accepted12_14_19 :
    accepted spec (((Finset.univ.erase (12 : Label)).erase 14).erase 19)
      (certificate 12 14 19) = true := by
  decide +kernel

theorem accepted12_15_16 :
    accepted spec (((Finset.univ.erase (12 : Label)).erase 15).erase 16)
      (certificate 12 15 16) = true := by
  decide +kernel

theorem accepted12_15_17 :
    accepted spec (((Finset.univ.erase (12 : Label)).erase 15).erase 17)
      (certificate 12 15 17) = true := by
  decide +kernel

theorem accepted12_15_18 :
    accepted spec (((Finset.univ.erase (12 : Label)).erase 15).erase 18)
      (certificate 12 15 18) = true := by
  decide +kernel

theorem accepted12_15_19 :
    accepted spec (((Finset.univ.erase (12 : Label)).erase 15).erase 19)
      (certificate 12 15 19) = true := by
  decide +kernel

theorem accepted12_16_17 :
    accepted spec (((Finset.univ.erase (12 : Label)).erase 16).erase 17)
      (certificate 12 16 17) = true := by
  decide +kernel

theorem accepted12_16_18 :
    accepted spec (((Finset.univ.erase (12 : Label)).erase 16).erase 18)
      (certificate 12 16 18) = true := by
  decide +kernel

theorem accepted12_16_19 :
    accepted spec (((Finset.univ.erase (12 : Label)).erase 16).erase 19)
      (certificate 12 16 19) = true := by
  decide +kernel

theorem accepted12_17_18 :
    accepted spec (((Finset.univ.erase (12 : Label)).erase 17).erase 18)
      (certificate 12 17 18) = true := by
  decide +kernel

theorem accepted12_17_19 :
    accepted spec (((Finset.univ.erase (12 : Label)).erase 17).erase 19)
      (certificate 12 17 19) = true := by
  decide +kernel

theorem accepted12_18_19 :
    accepted spec (((Finset.univ.erase (12 : Label)).erase 18).erase 19)
      (certificate 12 18 19) = true := by
  decide +kernel

theorem accepted13_14_15 :
    accepted spec (((Finset.univ.erase (13 : Label)).erase 14).erase 15)
      (certificate 13 14 15) = true := by
  decide +kernel

theorem accepted13_14_16 :
    accepted spec (((Finset.univ.erase (13 : Label)).erase 14).erase 16)
      (certificate 13 14 16) = true := by
  decide +kernel

theorem accepted13_14_17 :
    accepted spec (((Finset.univ.erase (13 : Label)).erase 14).erase 17)
      (certificate 13 14 17) = true := by
  decide +kernel

theorem accepted13_14_18 :
    accepted spec (((Finset.univ.erase (13 : Label)).erase 14).erase 18)
      (certificate 13 14 18) = true := by
  decide +kernel

theorem accepted13_14_19 :
    accepted spec (((Finset.univ.erase (13 : Label)).erase 14).erase 19)
      (certificate 13 14 19) = true := by
  decide +kernel

theorem accepted13_15_16 :
    accepted spec (((Finset.univ.erase (13 : Label)).erase 15).erase 16)
      (certificate 13 15 16) = true := by
  decide +kernel

theorem accepted13_15_17 :
    accepted spec (((Finset.univ.erase (13 : Label)).erase 15).erase 17)
      (certificate 13 15 17) = true := by
  decide +kernel

theorem accepted13_15_18 :
    accepted spec (((Finset.univ.erase (13 : Label)).erase 15).erase 18)
      (certificate 13 15 18) = true := by
  decide +kernel

theorem accepted13_15_19 :
    accepted spec (((Finset.univ.erase (13 : Label)).erase 15).erase 19)
      (certificate 13 15 19) = true := by
  decide +kernel

theorem accepted13_16_17 :
    accepted spec (((Finset.univ.erase (13 : Label)).erase 16).erase 17)
      (certificate 13 16 17) = true := by
  decide +kernel

theorem accepted13_16_18 :
    accepted spec (((Finset.univ.erase (13 : Label)).erase 16).erase 18)
      (certificate 13 16 18) = true := by
  decide +kernel

theorem accepted13_16_19 :
    accepted spec (((Finset.univ.erase (13 : Label)).erase 16).erase 19)
      (certificate 13 16 19) = true := by
  decide +kernel

theorem accepted13_17_18 :
    accepted spec (((Finset.univ.erase (13 : Label)).erase 17).erase 18)
      (certificate 13 17 18) = true := by
  decide +kernel

theorem accepted13_17_19 :
    accepted spec (((Finset.univ.erase (13 : Label)).erase 17).erase 19)
      (certificate 13 17 19) = true := by
  decide +kernel

theorem accepted13_18_19 :
    accepted spec (((Finset.univ.erase (13 : Label)).erase 18).erase 19)
      (certificate 13 18 19) = true := by
  decide +kernel

theorem accepted14_15_16 :
    accepted spec (((Finset.univ.erase (14 : Label)).erase 15).erase 16)
      (certificate 14 15 16) = true := by
  decide +kernel

theorem accepted14_15_17 :
    accepted spec (((Finset.univ.erase (14 : Label)).erase 15).erase 17)
      (certificate 14 15 17) = true := by
  decide +kernel

theorem accepted14_15_18 :
    accepted spec (((Finset.univ.erase (14 : Label)).erase 15).erase 18)
      (certificate 14 15 18) = true := by
  decide +kernel

theorem accepted14_15_19 :
    accepted spec (((Finset.univ.erase (14 : Label)).erase 15).erase 19)
      (certificate 14 15 19) = true := by
  decide +kernel

theorem accepted14_16_17 :
    accepted spec (((Finset.univ.erase (14 : Label)).erase 16).erase 17)
      (certificate 14 16 17) = true := by
  decide +kernel

theorem accepted14_16_18 :
    accepted spec (((Finset.univ.erase (14 : Label)).erase 16).erase 18)
      (certificate 14 16 18) = true := by
  decide +kernel

theorem accepted14_16_19 :
    accepted spec (((Finset.univ.erase (14 : Label)).erase 16).erase 19)
      (certificate 14 16 19) = true := by
  decide +kernel

theorem accepted14_17_18 :
    accepted spec (((Finset.univ.erase (14 : Label)).erase 17).erase 18)
      (certificate 14 17 18) = true := by
  decide +kernel

theorem accepted14_17_19 :
    accepted spec (((Finset.univ.erase (14 : Label)).erase 17).erase 19)
      (certificate 14 17 19) = true := by
  decide +kernel

theorem accepted14_18_19 :
    accepted spec (((Finset.univ.erase (14 : Label)).erase 18).erase 19)
      (certificate 14 18 19) = true := by
  decide +kernel

theorem accepted15_16_17 :
    accepted spec (((Finset.univ.erase (15 : Label)).erase 16).erase 17)
      (certificate 15 16 17) = true := by
  decide +kernel

theorem accepted15_16_18 :
    accepted spec (((Finset.univ.erase (15 : Label)).erase 16).erase 18)
      (certificate 15 16 18) = true := by
  decide +kernel

theorem accepted15_16_19 :
    accepted spec (((Finset.univ.erase (15 : Label)).erase 16).erase 19)
      (certificate 15 16 19) = true := by
  decide +kernel

theorem accepted15_17_18 :
    accepted spec (((Finset.univ.erase (15 : Label)).erase 17).erase 18)
      (certificate 15 17 18) = true := by
  decide +kernel

theorem accepted15_17_19 :
    accepted spec (((Finset.univ.erase (15 : Label)).erase 17).erase 19)
      (certificate 15 17 19) = true := by
  decide +kernel

theorem accepted15_18_19 :
    accepted spec (((Finset.univ.erase (15 : Label)).erase 18).erase 19)
      (certificate 15 18 19) = true := by
  decide +kernel

theorem accepted16_17_18 :
    accepted spec (((Finset.univ.erase (16 : Label)).erase 17).erase 18)
      (certificate 16 17 18) = true := by
  decide +kernel

theorem accepted16_17_19 :
    accepted spec (((Finset.univ.erase (16 : Label)).erase 17).erase 19)
      (certificate 16 17 19) = true := by
  decide +kernel

theorem accepted16_18_19 :
    accepted spec (((Finset.univ.erase (16 : Label)).erase 18).erase 19)
      (certificate 16 18 19) = true := by
  decide +kernel

theorem accepted17_18_19 :
    accepted spec (((Finset.univ.erase (17 : Label)).erase 18).erase 19)
      (certificate 17 18 19) = true := by
  decide +kernel

set_option maxHeartbeats 1000000 in
theorem row00_accepted : ∀ b c : Label, (0 : Label) < b → b < c →
    accepted spec (((Finset.univ.erase (0 : Label)).erase b).erase c)
      (certificate 0 b c) = true := by
  intro b c hab hbc
  fin_cases b
  · norm_num at hab
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted00_01_02
    · exact accepted00_01_03
    · exact accepted00_01_04
    · exact accepted00_01_05
    · exact accepted00_01_06
    · exact accepted00_01_07
    · exact accepted00_01_08
    · exact accepted00_01_09
    · exact accepted00_01_10
    · exact accepted00_01_11
    · exact accepted00_01_12
    · exact accepted00_01_13
    · exact accepted00_01_14
    · exact accepted00_01_15
    · exact accepted00_01_16
    · exact accepted00_01_17
    · exact accepted00_01_18
    · exact accepted00_01_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted00_02_03
    · exact accepted00_02_04
    · exact accepted00_02_05
    · exact accepted00_02_06
    · exact accepted00_02_07
    · exact accepted00_02_08
    · exact accepted00_02_09
    · exact accepted00_02_10
    · exact accepted00_02_11
    · exact accepted00_02_12
    · exact accepted00_02_13
    · exact accepted00_02_14
    · exact accepted00_02_15
    · exact accepted00_02_16
    · exact accepted00_02_17
    · exact accepted00_02_18
    · exact accepted00_02_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted00_03_04
    · exact accepted00_03_05
    · exact accepted00_03_06
    · exact accepted00_03_07
    · exact accepted00_03_08
    · exact accepted00_03_09
    · exact accepted00_03_10
    · exact accepted00_03_11
    · exact accepted00_03_12
    · exact accepted00_03_13
    · exact accepted00_03_14
    · exact accepted00_03_15
    · exact accepted00_03_16
    · exact accepted00_03_17
    · exact accepted00_03_18
    · exact accepted00_03_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted00_04_05
    · exact accepted00_04_06
    · exact accepted00_04_07
    · exact accepted00_04_08
    · exact accepted00_04_09
    · exact accepted00_04_10
    · exact accepted00_04_11
    · exact accepted00_04_12
    · exact accepted00_04_13
    · exact accepted00_04_14
    · exact accepted00_04_15
    · exact accepted00_04_16
    · exact accepted00_04_17
    · exact accepted00_04_18
    · exact accepted00_04_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted00_05_06
    · exact accepted00_05_07
    · exact accepted00_05_08
    · exact accepted00_05_09
    · exact accepted00_05_10
    · exact accepted00_05_11
    · exact accepted00_05_12
    · exact accepted00_05_13
    · exact accepted00_05_14
    · exact accepted00_05_15
    · exact accepted00_05_16
    · exact accepted00_05_17
    · exact accepted00_05_18
    · exact accepted00_05_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted00_06_07
    · exact accepted00_06_08
    · exact accepted00_06_09
    · exact accepted00_06_10
    · exact accepted00_06_11
    · exact accepted00_06_12
    · exact accepted00_06_13
    · exact accepted00_06_14
    · exact accepted00_06_15
    · exact accepted00_06_16
    · exact accepted00_06_17
    · exact accepted00_06_18
    · exact accepted00_06_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted00_07_08
    · exact accepted00_07_09
    · exact accepted00_07_10
    · exact accepted00_07_11
    · exact accepted00_07_12
    · exact accepted00_07_13
    · exact accepted00_07_14
    · exact accepted00_07_15
    · exact accepted00_07_16
    · exact accepted00_07_17
    · exact accepted00_07_18
    · exact accepted00_07_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted00_08_09
    · exact accepted00_08_10
    · exact accepted00_08_11
    · exact accepted00_08_12
    · exact accepted00_08_13
    · exact accepted00_08_14
    · exact accepted00_08_15
    · exact accepted00_08_16
    · exact accepted00_08_17
    · exact accepted00_08_18
    · exact accepted00_08_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted00_09_10
    · exact accepted00_09_11
    · exact accepted00_09_12
    · exact accepted00_09_13
    · exact accepted00_09_14
    · exact accepted00_09_15
    · exact accepted00_09_16
    · exact accepted00_09_17
    · exact accepted00_09_18
    · exact accepted00_09_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted00_10_11
    · exact accepted00_10_12
    · exact accepted00_10_13
    · exact accepted00_10_14
    · exact accepted00_10_15
    · exact accepted00_10_16
    · exact accepted00_10_17
    · exact accepted00_10_18
    · exact accepted00_10_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted00_11_12
    · exact accepted00_11_13
    · exact accepted00_11_14
    · exact accepted00_11_15
    · exact accepted00_11_16
    · exact accepted00_11_17
    · exact accepted00_11_18
    · exact accepted00_11_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted00_12_13
    · exact accepted00_12_14
    · exact accepted00_12_15
    · exact accepted00_12_16
    · exact accepted00_12_17
    · exact accepted00_12_18
    · exact accepted00_12_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted00_13_14
    · exact accepted00_13_15
    · exact accepted00_13_16
    · exact accepted00_13_17
    · exact accepted00_13_18
    · exact accepted00_13_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted00_14_15
    · exact accepted00_14_16
    · exact accepted00_14_17
    · exact accepted00_14_18
    · exact accepted00_14_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted00_15_16
    · exact accepted00_15_17
    · exact accepted00_15_18
    · exact accepted00_15_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted00_16_17
    · exact accepted00_16_18
    · exact accepted00_16_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted00_17_18
    · exact accepted00_17_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted00_18_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc

set_option maxHeartbeats 1000000 in
theorem row01_accepted : ∀ b c : Label, (1 : Label) < b → b < c →
    accepted spec (((Finset.univ.erase (1 : Label)).erase b).erase c)
      (certificate 1 b c) = true := by
  intro b c hab hbc
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted01_02_03
    · exact accepted01_02_04
    · exact accepted01_02_05
    · exact accepted01_02_06
    · exact accepted01_02_07
    · exact accepted01_02_08
    · exact accepted01_02_09
    · exact accepted01_02_10
    · exact accepted01_02_11
    · exact accepted01_02_12
    · exact accepted01_02_13
    · exact accepted01_02_14
    · exact accepted01_02_15
    · exact accepted01_02_16
    · exact accepted01_02_17
    · exact accepted01_02_18
    · exact accepted01_02_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted01_03_04
    · exact accepted01_03_05
    · exact accepted01_03_06
    · exact accepted01_03_07
    · exact accepted01_03_08
    · exact accepted01_03_09
    · exact accepted01_03_10
    · exact accepted01_03_11
    · exact accepted01_03_12
    · exact accepted01_03_13
    · exact accepted01_03_14
    · exact accepted01_03_15
    · exact accepted01_03_16
    · exact accepted01_03_17
    · exact accepted01_03_18
    · exact accepted01_03_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted01_04_05
    · exact accepted01_04_06
    · exact accepted01_04_07
    · exact accepted01_04_08
    · exact accepted01_04_09
    · exact accepted01_04_10
    · exact accepted01_04_11
    · exact accepted01_04_12
    · exact accepted01_04_13
    · exact accepted01_04_14
    · exact accepted01_04_15
    · exact accepted01_04_16
    · exact accepted01_04_17
    · exact accepted01_04_18
    · exact accepted01_04_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted01_05_06
    · exact accepted01_05_07
    · exact accepted01_05_08
    · exact accepted01_05_09
    · exact accepted01_05_10
    · exact accepted01_05_11
    · exact accepted01_05_12
    · exact accepted01_05_13
    · exact accepted01_05_14
    · exact accepted01_05_15
    · exact accepted01_05_16
    · exact accepted01_05_17
    · exact accepted01_05_18
    · exact accepted01_05_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted01_06_07
    · exact accepted01_06_08
    · exact accepted01_06_09
    · exact accepted01_06_10
    · exact accepted01_06_11
    · exact accepted01_06_12
    · exact accepted01_06_13
    · exact accepted01_06_14
    · exact accepted01_06_15
    · exact accepted01_06_16
    · exact accepted01_06_17
    · exact accepted01_06_18
    · exact accepted01_06_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted01_07_08
    · exact accepted01_07_09
    · exact accepted01_07_10
    · exact accepted01_07_11
    · exact accepted01_07_12
    · exact accepted01_07_13
    · exact accepted01_07_14
    · exact accepted01_07_15
    · exact accepted01_07_16
    · exact accepted01_07_17
    · exact accepted01_07_18
    · exact accepted01_07_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted01_08_09
    · exact accepted01_08_10
    · exact accepted01_08_11
    · exact accepted01_08_12
    · exact accepted01_08_13
    · exact accepted01_08_14
    · exact accepted01_08_15
    · exact accepted01_08_16
    · exact accepted01_08_17
    · exact accepted01_08_18
    · exact accepted01_08_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted01_09_10
    · exact accepted01_09_11
    · exact accepted01_09_12
    · exact accepted01_09_13
    · exact accepted01_09_14
    · exact accepted01_09_15
    · exact accepted01_09_16
    · exact accepted01_09_17
    · exact accepted01_09_18
    · exact accepted01_09_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted01_10_11
    · exact accepted01_10_12
    · exact accepted01_10_13
    · exact accepted01_10_14
    · exact accepted01_10_15
    · exact accepted01_10_16
    · exact accepted01_10_17
    · exact accepted01_10_18
    · exact accepted01_10_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted01_11_12
    · exact accepted01_11_13
    · exact accepted01_11_14
    · exact accepted01_11_15
    · exact accepted01_11_16
    · exact accepted01_11_17
    · exact accepted01_11_18
    · exact accepted01_11_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted01_12_13
    · exact accepted01_12_14
    · exact accepted01_12_15
    · exact accepted01_12_16
    · exact accepted01_12_17
    · exact accepted01_12_18
    · exact accepted01_12_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted01_13_14
    · exact accepted01_13_15
    · exact accepted01_13_16
    · exact accepted01_13_17
    · exact accepted01_13_18
    · exact accepted01_13_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted01_14_15
    · exact accepted01_14_16
    · exact accepted01_14_17
    · exact accepted01_14_18
    · exact accepted01_14_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted01_15_16
    · exact accepted01_15_17
    · exact accepted01_15_18
    · exact accepted01_15_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted01_16_17
    · exact accepted01_16_18
    · exact accepted01_16_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted01_17_18
    · exact accepted01_17_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted01_18_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc

set_option maxHeartbeats 1000000 in
theorem row02_accepted : ∀ b c : Label, (2 : Label) < b → b < c →
    accepted spec (((Finset.univ.erase (2 : Label)).erase b).erase c)
      (certificate 2 b c) = true := by
  intro b c hab hbc
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted02_03_04
    · exact accepted02_03_05
    · exact accepted02_03_06
    · exact accepted02_03_07
    · exact accepted02_03_08
    · exact accepted02_03_09
    · exact accepted02_03_10
    · exact accepted02_03_11
    · exact accepted02_03_12
    · exact accepted02_03_13
    · exact accepted02_03_14
    · exact accepted02_03_15
    · exact accepted02_03_16
    · exact accepted02_03_17
    · exact accepted02_03_18
    · exact accepted02_03_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted02_04_05
    · exact accepted02_04_06
    · exact accepted02_04_07
    · exact accepted02_04_08
    · exact accepted02_04_09
    · exact accepted02_04_10
    · exact accepted02_04_11
    · exact accepted02_04_12
    · exact accepted02_04_13
    · exact accepted02_04_14
    · exact accepted02_04_15
    · exact accepted02_04_16
    · exact accepted02_04_17
    · exact accepted02_04_18
    · exact accepted02_04_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted02_05_06
    · exact accepted02_05_07
    · exact accepted02_05_08
    · exact accepted02_05_09
    · exact accepted02_05_10
    · exact accepted02_05_11
    · exact accepted02_05_12
    · exact accepted02_05_13
    · exact accepted02_05_14
    · exact accepted02_05_15
    · exact accepted02_05_16
    · exact accepted02_05_17
    · exact accepted02_05_18
    · exact accepted02_05_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted02_06_07
    · exact accepted02_06_08
    · exact accepted02_06_09
    · exact accepted02_06_10
    · exact accepted02_06_11
    · exact accepted02_06_12
    · exact accepted02_06_13
    · exact accepted02_06_14
    · exact accepted02_06_15
    · exact accepted02_06_16
    · exact accepted02_06_17
    · exact accepted02_06_18
    · exact accepted02_06_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted02_07_08
    · exact accepted02_07_09
    · exact accepted02_07_10
    · exact accepted02_07_11
    · exact accepted02_07_12
    · exact accepted02_07_13
    · exact accepted02_07_14
    · exact accepted02_07_15
    · exact accepted02_07_16
    · exact accepted02_07_17
    · exact accepted02_07_18
    · exact accepted02_07_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted02_08_09
    · exact accepted02_08_10
    · exact accepted02_08_11
    · exact accepted02_08_12
    · exact accepted02_08_13
    · exact accepted02_08_14
    · exact accepted02_08_15
    · exact accepted02_08_16
    · exact accepted02_08_17
    · exact accepted02_08_18
    · exact accepted02_08_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted02_09_10
    · exact accepted02_09_11
    · exact accepted02_09_12
    · exact accepted02_09_13
    · exact accepted02_09_14
    · exact accepted02_09_15
    · exact accepted02_09_16
    · exact accepted02_09_17
    · exact accepted02_09_18
    · exact accepted02_09_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted02_10_11
    · exact accepted02_10_12
    · exact accepted02_10_13
    · exact accepted02_10_14
    · exact accepted02_10_15
    · exact accepted02_10_16
    · exact accepted02_10_17
    · exact accepted02_10_18
    · exact accepted02_10_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted02_11_12
    · exact accepted02_11_13
    · exact accepted02_11_14
    · exact accepted02_11_15
    · exact accepted02_11_16
    · exact accepted02_11_17
    · exact accepted02_11_18
    · exact accepted02_11_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted02_12_13
    · exact accepted02_12_14
    · exact accepted02_12_15
    · exact accepted02_12_16
    · exact accepted02_12_17
    · exact accepted02_12_18
    · exact accepted02_12_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted02_13_14
    · exact accepted02_13_15
    · exact accepted02_13_16
    · exact accepted02_13_17
    · exact accepted02_13_18
    · exact accepted02_13_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted02_14_15
    · exact accepted02_14_16
    · exact accepted02_14_17
    · exact accepted02_14_18
    · exact accepted02_14_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted02_15_16
    · exact accepted02_15_17
    · exact accepted02_15_18
    · exact accepted02_15_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted02_16_17
    · exact accepted02_16_18
    · exact accepted02_16_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted02_17_18
    · exact accepted02_17_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted02_18_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc

set_option maxHeartbeats 1000000 in
theorem row03_accepted : ∀ b c : Label, (3 : Label) < b → b < c →
    accepted spec (((Finset.univ.erase (3 : Label)).erase b).erase c)
      (certificate 3 b c) = true := by
  intro b c hab hbc
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted03_04_05
    · exact accepted03_04_06
    · exact accepted03_04_07
    · exact accepted03_04_08
    · exact accepted03_04_09
    · exact accepted03_04_10
    · exact accepted03_04_11
    · exact accepted03_04_12
    · exact accepted03_04_13
    · exact accepted03_04_14
    · exact accepted03_04_15
    · exact accepted03_04_16
    · exact accepted03_04_17
    · exact accepted03_04_18
    · exact accepted03_04_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted03_05_06
    · exact accepted03_05_07
    · exact accepted03_05_08
    · exact accepted03_05_09
    · exact accepted03_05_10
    · exact accepted03_05_11
    · exact accepted03_05_12
    · exact accepted03_05_13
    · exact accepted03_05_14
    · exact accepted03_05_15
    · exact accepted03_05_16
    · exact accepted03_05_17
    · exact accepted03_05_18
    · exact accepted03_05_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted03_06_07
    · exact accepted03_06_08
    · exact accepted03_06_09
    · exact accepted03_06_10
    · exact accepted03_06_11
    · exact accepted03_06_12
    · exact accepted03_06_13
    · exact accepted03_06_14
    · exact accepted03_06_15
    · exact accepted03_06_16
    · exact accepted03_06_17
    · exact accepted03_06_18
    · exact accepted03_06_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted03_07_08
    · exact accepted03_07_09
    · exact accepted03_07_10
    · exact accepted03_07_11
    · exact accepted03_07_12
    · exact accepted03_07_13
    · exact accepted03_07_14
    · exact accepted03_07_15
    · exact accepted03_07_16
    · exact accepted03_07_17
    · exact accepted03_07_18
    · exact accepted03_07_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted03_08_09
    · exact accepted03_08_10
    · exact accepted03_08_11
    · exact accepted03_08_12
    · exact accepted03_08_13
    · exact accepted03_08_14
    · exact accepted03_08_15
    · exact accepted03_08_16
    · exact accepted03_08_17
    · exact accepted03_08_18
    · exact accepted03_08_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted03_09_10
    · exact accepted03_09_11
    · exact accepted03_09_12
    · exact accepted03_09_13
    · exact accepted03_09_14
    · exact accepted03_09_15
    · exact accepted03_09_16
    · exact accepted03_09_17
    · exact accepted03_09_18
    · exact accepted03_09_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted03_10_11
    · exact accepted03_10_12
    · exact accepted03_10_13
    · exact accepted03_10_14
    · exact accepted03_10_15
    · exact accepted03_10_16
    · exact accepted03_10_17
    · exact accepted03_10_18
    · exact accepted03_10_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted03_11_12
    · exact accepted03_11_13
    · exact accepted03_11_14
    · exact accepted03_11_15
    · exact accepted03_11_16
    · exact accepted03_11_17
    · exact accepted03_11_18
    · exact accepted03_11_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted03_12_13
    · exact accepted03_12_14
    · exact accepted03_12_15
    · exact accepted03_12_16
    · exact accepted03_12_17
    · exact accepted03_12_18
    · exact accepted03_12_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted03_13_14
    · exact accepted03_13_15
    · exact accepted03_13_16
    · exact accepted03_13_17
    · exact accepted03_13_18
    · exact accepted03_13_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted03_14_15
    · exact accepted03_14_16
    · exact accepted03_14_17
    · exact accepted03_14_18
    · exact accepted03_14_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted03_15_16
    · exact accepted03_15_17
    · exact accepted03_15_18
    · exact accepted03_15_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted03_16_17
    · exact accepted03_16_18
    · exact accepted03_16_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted03_17_18
    · exact accepted03_17_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted03_18_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc

set_option maxHeartbeats 1000000 in
theorem row04_accepted : ∀ b c : Label, (4 : Label) < b → b < c →
    accepted spec (((Finset.univ.erase (4 : Label)).erase b).erase c)
      (certificate 4 b c) = true := by
  intro b c hab hbc
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted04_05_06
    · exact accepted04_05_07
    · exact accepted04_05_08
    · exact accepted04_05_09
    · exact accepted04_05_10
    · exact accepted04_05_11
    · exact accepted04_05_12
    · exact accepted04_05_13
    · exact accepted04_05_14
    · exact accepted04_05_15
    · exact accepted04_05_16
    · exact accepted04_05_17
    · exact accepted04_05_18
    · exact accepted04_05_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted04_06_07
    · exact accepted04_06_08
    · exact accepted04_06_09
    · exact accepted04_06_10
    · exact accepted04_06_11
    · exact accepted04_06_12
    · exact accepted04_06_13
    · exact accepted04_06_14
    · exact accepted04_06_15
    · exact accepted04_06_16
    · exact accepted04_06_17
    · exact accepted04_06_18
    · exact accepted04_06_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted04_07_08
    · exact accepted04_07_09
    · exact accepted04_07_10
    · exact accepted04_07_11
    · exact accepted04_07_12
    · exact accepted04_07_13
    · exact accepted04_07_14
    · exact accepted04_07_15
    · exact accepted04_07_16
    · exact accepted04_07_17
    · exact accepted04_07_18
    · exact accepted04_07_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted04_08_09
    · exact accepted04_08_10
    · exact accepted04_08_11
    · exact accepted04_08_12
    · exact accepted04_08_13
    · exact accepted04_08_14
    · exact accepted04_08_15
    · exact accepted04_08_16
    · exact accepted04_08_17
    · exact accepted04_08_18
    · exact accepted04_08_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted04_09_10
    · exact accepted04_09_11
    · exact accepted04_09_12
    · exact accepted04_09_13
    · exact accepted04_09_14
    · exact accepted04_09_15
    · exact accepted04_09_16
    · exact accepted04_09_17
    · exact accepted04_09_18
    · exact accepted04_09_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted04_10_11
    · exact accepted04_10_12
    · exact accepted04_10_13
    · exact accepted04_10_14
    · exact accepted04_10_15
    · exact accepted04_10_16
    · exact accepted04_10_17
    · exact accepted04_10_18
    · exact accepted04_10_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted04_11_12
    · exact accepted04_11_13
    · exact accepted04_11_14
    · exact accepted04_11_15
    · exact accepted04_11_16
    · exact accepted04_11_17
    · exact accepted04_11_18
    · exact accepted04_11_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted04_12_13
    · exact accepted04_12_14
    · exact accepted04_12_15
    · exact accepted04_12_16
    · exact accepted04_12_17
    · exact accepted04_12_18
    · exact accepted04_12_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted04_13_14
    · exact accepted04_13_15
    · exact accepted04_13_16
    · exact accepted04_13_17
    · exact accepted04_13_18
    · exact accepted04_13_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted04_14_15
    · exact accepted04_14_16
    · exact accepted04_14_17
    · exact accepted04_14_18
    · exact accepted04_14_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted04_15_16
    · exact accepted04_15_17
    · exact accepted04_15_18
    · exact accepted04_15_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted04_16_17
    · exact accepted04_16_18
    · exact accepted04_16_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted04_17_18
    · exact accepted04_17_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted04_18_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc

set_option maxHeartbeats 1000000 in
theorem row05_accepted : ∀ b c : Label, (5 : Label) < b → b < c →
    accepted spec (((Finset.univ.erase (5 : Label)).erase b).erase c)
      (certificate 5 b c) = true := by
  intro b c hab hbc
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted05_06_07
    · exact accepted05_06_08
    · exact accepted05_06_09
    · exact accepted05_06_10
    · exact accepted05_06_11
    · exact accepted05_06_12
    · exact accepted05_06_13
    · exact accepted05_06_14
    · exact accepted05_06_15
    · exact accepted05_06_16
    · exact accepted05_06_17
    · exact accepted05_06_18
    · exact accepted05_06_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted05_07_08
    · exact accepted05_07_09
    · exact accepted05_07_10
    · exact accepted05_07_11
    · exact accepted05_07_12
    · exact accepted05_07_13
    · exact accepted05_07_14
    · exact accepted05_07_15
    · exact accepted05_07_16
    · exact accepted05_07_17
    · exact accepted05_07_18
    · exact accepted05_07_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted05_08_09
    · exact accepted05_08_10
    · exact accepted05_08_11
    · exact accepted05_08_12
    · exact accepted05_08_13
    · exact accepted05_08_14
    · exact accepted05_08_15
    · exact accepted05_08_16
    · exact accepted05_08_17
    · exact accepted05_08_18
    · exact accepted05_08_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted05_09_10
    · exact accepted05_09_11
    · exact accepted05_09_12
    · exact accepted05_09_13
    · exact accepted05_09_14
    · exact accepted05_09_15
    · exact accepted05_09_16
    · exact accepted05_09_17
    · exact accepted05_09_18
    · exact accepted05_09_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted05_10_11
    · exact accepted05_10_12
    · exact accepted05_10_13
    · exact accepted05_10_14
    · exact accepted05_10_15
    · exact accepted05_10_16
    · exact accepted05_10_17
    · exact accepted05_10_18
    · exact accepted05_10_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted05_11_12
    · exact accepted05_11_13
    · exact accepted05_11_14
    · exact accepted05_11_15
    · exact accepted05_11_16
    · exact accepted05_11_17
    · exact accepted05_11_18
    · exact accepted05_11_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted05_12_13
    · exact accepted05_12_14
    · exact accepted05_12_15
    · exact accepted05_12_16
    · exact accepted05_12_17
    · exact accepted05_12_18
    · exact accepted05_12_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted05_13_14
    · exact accepted05_13_15
    · exact accepted05_13_16
    · exact accepted05_13_17
    · exact accepted05_13_18
    · exact accepted05_13_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted05_14_15
    · exact accepted05_14_16
    · exact accepted05_14_17
    · exact accepted05_14_18
    · exact accepted05_14_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted05_15_16
    · exact accepted05_15_17
    · exact accepted05_15_18
    · exact accepted05_15_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted05_16_17
    · exact accepted05_16_18
    · exact accepted05_16_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted05_17_18
    · exact accepted05_17_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted05_18_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc

set_option maxHeartbeats 1000000 in
theorem row06_accepted : ∀ b c : Label, (6 : Label) < b → b < c →
    accepted spec (((Finset.univ.erase (6 : Label)).erase b).erase c)
      (certificate 6 b c) = true := by
  intro b c hab hbc
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted06_07_08
    · exact accepted06_07_09
    · exact accepted06_07_10
    · exact accepted06_07_11
    · exact accepted06_07_12
    · exact accepted06_07_13
    · exact accepted06_07_14
    · exact accepted06_07_15
    · exact accepted06_07_16
    · exact accepted06_07_17
    · exact accepted06_07_18
    · exact accepted06_07_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted06_08_09
    · exact accepted06_08_10
    · exact accepted06_08_11
    · exact accepted06_08_12
    · exact accepted06_08_13
    · exact accepted06_08_14
    · exact accepted06_08_15
    · exact accepted06_08_16
    · exact accepted06_08_17
    · exact accepted06_08_18
    · exact accepted06_08_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted06_09_10
    · exact accepted06_09_11
    · exact accepted06_09_12
    · exact accepted06_09_13
    · exact accepted06_09_14
    · exact accepted06_09_15
    · exact accepted06_09_16
    · exact accepted06_09_17
    · exact accepted06_09_18
    · exact accepted06_09_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted06_10_11
    · exact accepted06_10_12
    · exact accepted06_10_13
    · exact accepted06_10_14
    · exact accepted06_10_15
    · exact accepted06_10_16
    · exact accepted06_10_17
    · exact accepted06_10_18
    · exact accepted06_10_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted06_11_12
    · exact accepted06_11_13
    · exact accepted06_11_14
    · exact accepted06_11_15
    · exact accepted06_11_16
    · exact accepted06_11_17
    · exact accepted06_11_18
    · exact accepted06_11_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted06_12_13
    · exact accepted06_12_14
    · exact accepted06_12_15
    · exact accepted06_12_16
    · exact accepted06_12_17
    · exact accepted06_12_18
    · exact accepted06_12_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted06_13_14
    · exact accepted06_13_15
    · exact accepted06_13_16
    · exact accepted06_13_17
    · exact accepted06_13_18
    · exact accepted06_13_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted06_14_15
    · exact accepted06_14_16
    · exact accepted06_14_17
    · exact accepted06_14_18
    · exact accepted06_14_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted06_15_16
    · exact accepted06_15_17
    · exact accepted06_15_18
    · exact accepted06_15_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted06_16_17
    · exact accepted06_16_18
    · exact accepted06_16_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted06_17_18
    · exact accepted06_17_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted06_18_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc

set_option maxHeartbeats 1000000 in
theorem row07_accepted : ∀ b c : Label, (7 : Label) < b → b < c →
    accepted spec (((Finset.univ.erase (7 : Label)).erase b).erase c)
      (certificate 7 b c) = true := by
  intro b c hab hbc
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted07_08_09
    · exact accepted07_08_10
    · exact accepted07_08_11
    · exact accepted07_08_12
    · exact accepted07_08_13
    · exact accepted07_08_14
    · exact accepted07_08_15
    · exact accepted07_08_16
    · exact accepted07_08_17
    · exact accepted07_08_18
    · exact accepted07_08_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted07_09_10
    · exact accepted07_09_11
    · exact accepted07_09_12
    · exact accepted07_09_13
    · exact accepted07_09_14
    · exact accepted07_09_15
    · exact accepted07_09_16
    · exact accepted07_09_17
    · exact accepted07_09_18
    · exact accepted07_09_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted07_10_11
    · exact accepted07_10_12
    · exact accepted07_10_13
    · exact accepted07_10_14
    · exact accepted07_10_15
    · exact accepted07_10_16
    · exact accepted07_10_17
    · exact accepted07_10_18
    · exact accepted07_10_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted07_11_12
    · exact accepted07_11_13
    · exact accepted07_11_14
    · exact accepted07_11_15
    · exact accepted07_11_16
    · exact accepted07_11_17
    · exact accepted07_11_18
    · exact accepted07_11_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted07_12_13
    · exact accepted07_12_14
    · exact accepted07_12_15
    · exact accepted07_12_16
    · exact accepted07_12_17
    · exact accepted07_12_18
    · exact accepted07_12_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted07_13_14
    · exact accepted07_13_15
    · exact accepted07_13_16
    · exact accepted07_13_17
    · exact accepted07_13_18
    · exact accepted07_13_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted07_14_15
    · exact accepted07_14_16
    · exact accepted07_14_17
    · exact accepted07_14_18
    · exact accepted07_14_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted07_15_16
    · exact accepted07_15_17
    · exact accepted07_15_18
    · exact accepted07_15_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted07_16_17
    · exact accepted07_16_18
    · exact accepted07_16_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted07_17_18
    · exact accepted07_17_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted07_18_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc

set_option maxHeartbeats 1000000 in
theorem row08_accepted : ∀ b c : Label, (8 : Label) < b → b < c →
    accepted spec (((Finset.univ.erase (8 : Label)).erase b).erase c)
      (certificate 8 b c) = true := by
  intro b c hab hbc
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted08_09_10
    · exact accepted08_09_11
    · exact accepted08_09_12
    · exact accepted08_09_13
    · exact accepted08_09_14
    · exact accepted08_09_15
    · exact accepted08_09_16
    · exact accepted08_09_17
    · exact accepted08_09_18
    · exact accepted08_09_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted08_10_11
    · exact accepted08_10_12
    · exact accepted08_10_13
    · exact accepted08_10_14
    · exact accepted08_10_15
    · exact accepted08_10_16
    · exact accepted08_10_17
    · exact accepted08_10_18
    · exact accepted08_10_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted08_11_12
    · exact accepted08_11_13
    · exact accepted08_11_14
    · exact accepted08_11_15
    · exact accepted08_11_16
    · exact accepted08_11_17
    · exact accepted08_11_18
    · exact accepted08_11_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted08_12_13
    · exact accepted08_12_14
    · exact accepted08_12_15
    · exact accepted08_12_16
    · exact accepted08_12_17
    · exact accepted08_12_18
    · exact accepted08_12_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted08_13_14
    · exact accepted08_13_15
    · exact accepted08_13_16
    · exact accepted08_13_17
    · exact accepted08_13_18
    · exact accepted08_13_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted08_14_15
    · exact accepted08_14_16
    · exact accepted08_14_17
    · exact accepted08_14_18
    · exact accepted08_14_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted08_15_16
    · exact accepted08_15_17
    · exact accepted08_15_18
    · exact accepted08_15_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted08_16_17
    · exact accepted08_16_18
    · exact accepted08_16_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted08_17_18
    · exact accepted08_17_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted08_18_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc

set_option maxHeartbeats 1000000 in
theorem row09_accepted : ∀ b c : Label, (9 : Label) < b → b < c →
    accepted spec (((Finset.univ.erase (9 : Label)).erase b).erase c)
      (certificate 9 b c) = true := by
  intro b c hab hbc
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted09_10_11
    · exact accepted09_10_12
    · exact accepted09_10_13
    · exact accepted09_10_14
    · exact accepted09_10_15
    · exact accepted09_10_16
    · exact accepted09_10_17
    · exact accepted09_10_18
    · exact accepted09_10_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted09_11_12
    · exact accepted09_11_13
    · exact accepted09_11_14
    · exact accepted09_11_15
    · exact accepted09_11_16
    · exact accepted09_11_17
    · exact accepted09_11_18
    · exact accepted09_11_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted09_12_13
    · exact accepted09_12_14
    · exact accepted09_12_15
    · exact accepted09_12_16
    · exact accepted09_12_17
    · exact accepted09_12_18
    · exact accepted09_12_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted09_13_14
    · exact accepted09_13_15
    · exact accepted09_13_16
    · exact accepted09_13_17
    · exact accepted09_13_18
    · exact accepted09_13_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted09_14_15
    · exact accepted09_14_16
    · exact accepted09_14_17
    · exact accepted09_14_18
    · exact accepted09_14_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted09_15_16
    · exact accepted09_15_17
    · exact accepted09_15_18
    · exact accepted09_15_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted09_16_17
    · exact accepted09_16_18
    · exact accepted09_16_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted09_17_18
    · exact accepted09_17_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted09_18_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc

set_option maxHeartbeats 1000000 in
theorem row10_accepted : ∀ b c : Label, (10 : Label) < b → b < c →
    accepted spec (((Finset.univ.erase (10 : Label)).erase b).erase c)
      (certificate 10 b c) = true := by
  intro b c hab hbc
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted10_11_12
    · exact accepted10_11_13
    · exact accepted10_11_14
    · exact accepted10_11_15
    · exact accepted10_11_16
    · exact accepted10_11_17
    · exact accepted10_11_18
    · exact accepted10_11_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted10_12_13
    · exact accepted10_12_14
    · exact accepted10_12_15
    · exact accepted10_12_16
    · exact accepted10_12_17
    · exact accepted10_12_18
    · exact accepted10_12_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted10_13_14
    · exact accepted10_13_15
    · exact accepted10_13_16
    · exact accepted10_13_17
    · exact accepted10_13_18
    · exact accepted10_13_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted10_14_15
    · exact accepted10_14_16
    · exact accepted10_14_17
    · exact accepted10_14_18
    · exact accepted10_14_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted10_15_16
    · exact accepted10_15_17
    · exact accepted10_15_18
    · exact accepted10_15_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted10_16_17
    · exact accepted10_16_18
    · exact accepted10_16_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted10_17_18
    · exact accepted10_17_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted10_18_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc

set_option maxHeartbeats 1000000 in
theorem row11_accepted : ∀ b c : Label, (11 : Label) < b → b < c →
    accepted spec (((Finset.univ.erase (11 : Label)).erase b).erase c)
      (certificate 11 b c) = true := by
  intro b c hab hbc
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted11_12_13
    · exact accepted11_12_14
    · exact accepted11_12_15
    · exact accepted11_12_16
    · exact accepted11_12_17
    · exact accepted11_12_18
    · exact accepted11_12_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted11_13_14
    · exact accepted11_13_15
    · exact accepted11_13_16
    · exact accepted11_13_17
    · exact accepted11_13_18
    · exact accepted11_13_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted11_14_15
    · exact accepted11_14_16
    · exact accepted11_14_17
    · exact accepted11_14_18
    · exact accepted11_14_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted11_15_16
    · exact accepted11_15_17
    · exact accepted11_15_18
    · exact accepted11_15_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted11_16_17
    · exact accepted11_16_18
    · exact accepted11_16_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted11_17_18
    · exact accepted11_17_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted11_18_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc

set_option maxHeartbeats 1000000 in
theorem row12_accepted : ∀ b c : Label, (12 : Label) < b → b < c →
    accepted spec (((Finset.univ.erase (12 : Label)).erase b).erase c)
      (certificate 12 b c) = true := by
  intro b c hab hbc
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted12_13_14
    · exact accepted12_13_15
    · exact accepted12_13_16
    · exact accepted12_13_17
    · exact accepted12_13_18
    · exact accepted12_13_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted12_14_15
    · exact accepted12_14_16
    · exact accepted12_14_17
    · exact accepted12_14_18
    · exact accepted12_14_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted12_15_16
    · exact accepted12_15_17
    · exact accepted12_15_18
    · exact accepted12_15_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted12_16_17
    · exact accepted12_16_18
    · exact accepted12_16_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted12_17_18
    · exact accepted12_17_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted12_18_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc

set_option maxHeartbeats 1000000 in
theorem row13_accepted : ∀ b c : Label, (13 : Label) < b → b < c →
    accepted spec (((Finset.univ.erase (13 : Label)).erase b).erase c)
      (certificate 13 b c) = true := by
  intro b c hab hbc
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted13_14_15
    · exact accepted13_14_16
    · exact accepted13_14_17
    · exact accepted13_14_18
    · exact accepted13_14_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted13_15_16
    · exact accepted13_15_17
    · exact accepted13_15_18
    · exact accepted13_15_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted13_16_17
    · exact accepted13_16_18
    · exact accepted13_16_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted13_17_18
    · exact accepted13_17_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted13_18_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc

set_option maxHeartbeats 1000000 in
theorem row14_accepted : ∀ b c : Label, (14 : Label) < b → b < c →
    accepted spec (((Finset.univ.erase (14 : Label)).erase b).erase c)
      (certificate 14 b c) = true := by
  intro b c hab hbc
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted14_15_16
    · exact accepted14_15_17
    · exact accepted14_15_18
    · exact accepted14_15_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted14_16_17
    · exact accepted14_16_18
    · exact accepted14_16_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted14_17_18
    · exact accepted14_17_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted14_18_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc

set_option maxHeartbeats 1000000 in
theorem row15_accepted : ∀ b c : Label, (15 : Label) < b → b < c →
    accepted spec (((Finset.univ.erase (15 : Label)).erase b).erase c)
      (certificate 15 b c) = true := by
  intro b c hab hbc
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted15_16_17
    · exact accepted15_16_18
    · exact accepted15_16_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted15_17_18
    · exact accepted15_17_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted15_18_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc

set_option maxHeartbeats 1000000 in
theorem row16_accepted : ∀ b c : Label, (16 : Label) < b → b < c →
    accepted spec (((Finset.univ.erase (16 : Label)).erase b).erase c)
      (certificate 16 b c) = true := by
  intro b c hab hbc
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted16_17_18
    · exact accepted16_17_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted16_18_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc

set_option maxHeartbeats 1000000 in
theorem row17_accepted : ∀ b c : Label, (17 : Label) < b → b < c →
    accepted spec (((Finset.univ.erase (17 : Label)).erase b).erase c)
      (certificate 17 b c) = true := by
  intro b c hab hbc
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · exact accepted17_18_19
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc

set_option maxHeartbeats 1000000 in
theorem row18_accepted : ∀ b c : Label, (18 : Label) < b → b < c →
    accepted spec (((Finset.univ.erase (18 : Label)).erase b).erase c)
      (certificate 18 b c) = true := by
  intro b c hab hbc
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · fin_cases c
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc
    · norm_num at hbc

set_option maxHeartbeats 1000000 in
theorem row19_accepted : ∀ b c : Label, (19 : Label) < b → b < c →
    accepted spec (((Finset.univ.erase (19 : Label)).erase b).erase c)
      (certificate 19 b c) = true := by
  intro b c hab hbc
  fin_cases b
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab
  · norm_num at hab

theorem all_accepted : ∀ a b c : Label, a < b → b < c →
    accepted spec (((Finset.univ.erase a).erase b).erase c)
      (certificate a b c) = true := by
  intro a b c hab hbc
  fin_cases a
  · exact row00_accepted b c hab hbc
  · exact row01_accepted b c hab hbc
  · exact row02_accepted b c hab hbc
  · exact row03_accepted b c hab hbc
  · exact row04_accepted b c hab hbc
  · exact row05_accepted b c hab hbc
  · exact row06_accepted b c hab hbc
  · exact row07_accepted b c hab hbc
  · exact row08_accepted b c hab hbc
  · exact row09_accepted b c hab hbc
  · exact row10_accepted b c hab hbc
  · exact row11_accepted b c hab hbc
  · exact row12_accepted b c hab hbc
  · exact row13_accepted b c hab hbc
  · exact row14_accepted b c hab hbc
  · exact row15_accepted b c hab hbc
  · exact row16_accepted b c hab hbc
  · exact row17_accepted b c hab hbc
  · exact row18_accepted b c hab hbc
  · exact row19_accepted b c hab hbc

end Prize.JSP404.ThreeArcOrder17Data
