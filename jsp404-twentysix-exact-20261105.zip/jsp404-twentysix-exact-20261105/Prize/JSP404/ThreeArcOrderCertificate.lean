import Mathlib.Data.List.FinRange
import Mathlib.Data.Finset.Basic
import Mathlib.Basic.Real.Basic

/-! A small checked proof language for strict-order contradictions.
The certificate data is untrusted: accepted leaves must close an actual
strict cycle, and every alternative at a branch must be checked. -/
namespace Prize.JSP404.ThreeArcOrderCertificate

abbrev Label := Fin 20
abbrev Var := Fin 60
abbrev Edge := Var × Var
abbrev Choice := List Edge

structure Spec where
  width : Label → List Edge
  options : Label → Label → List Choice

def Holds (x : Var → ℝ) (edges : List Edge) : Prop :=
  ∀ e ∈ edges, x e.1 < x e.2

def Model (S : Spec) (active : Finset Label) (x : Var → ℝ) : Prop :=
  (∀ i ∈ active, Holds x (S.width i)) ∧
    ∀ i ∈ active, ∀ j ∈ active, i < j → ∃ alt ∈ S.options i j, Holds x alt

inductive Node where
  | cycle (path : List Var)
  | branch (i j : Label) (children : List (Choice × ℕ))

def closePath (edges : List Edge) (first : Var) : Var → List Var → Bool
  | current, [] => decide (current = first)
  | current, next :: rest =>
      decide ((current, next) ∈ edges) && closePath edges first next rest

def cycleCheck (edges : List Edge) : List Var → Bool
  | first :: next :: rest =>
      decide ((first, next) ∈ edges) && closePath edges first next rest
  | _ => false

def check (S : Spec) (active : Finset Label) (nodes : Array Node) :
    ℕ → List Edge → ℕ → Bool
  | 0, _, _ => false
  | fuel + 1, edges, index =>
      match nodes[index]? with
      | none => false
      | some (.cycle path) => cycleCheck edges path
      | some (.branch i j children) =>
          decide (i ∈ active ∧ j ∈ active ∧ i < j) &&
            (S.options i j).all (fun alt => children.any (fun child =>
              decide (child.1 = alt) && check S active nodes fuel (edges ++ alt) child.2))

def initialEdges (S : Spec) (active : Finset Label) : List Edge :=
  (List.finRange 20).flatMap fun i => if i ∈ active then S.width i else []

def accepted (S : Spec) (active : Finset Label) (nodes : Array Node) : Bool :=
  check S active nodes (nodes.size + 1) (initialEdges S active) (nodes.size - 1)

theorem holds_append {x : Var → ℝ} {a b : List Edge}
    (ha : Holds x a) (hb : Holds x b) : Holds x (a ++ b) := by
  intro e he
  rcases List.mem_append.mp he with he | he
  · exact ha e he
  · exact hb e he

theorem closePath_le (x : Var → ℝ) (edges : List Edge) (h : Holds x edges)
    (first current : Var) (rest : List Var)
    (hc : closePath edges first current rest = true) : x current ≤ x first := by
  induction rest generalizing current with
  | nil =>
    have he : current = first := of_decide_eq_true hc
    rw [he]
  | cons next rest ih =>
    change (decide ((current, next) ∈ edges) && closePath edges first next rest) = true at hc
    obtain ⟨he, hr⟩ := Bool.and_eq_true_iff.mp hc
    exact (le_of_lt (h _ (of_decide_eq_true he))).trans (ih next hr)

theorem cycleCheck_false (x : Var → ℝ) (edges : List Edge) (h : Holds x edges)
    (path : List Var) (hc : cycleCheck edges path = true) : False := by
  cases path with
  | nil => simp [cycleCheck] at hc
  | cons first rest =>
    cases rest with
    | nil => simp [cycleCheck] at hc
    | cons next rest =>
      obtain ⟨he, hr⟩ := Bool.and_eq_true_iff.mp hc
      have hlt := h (first, next) (of_decide_eq_true he)
      have hle := closePath_le x edges h first next rest hr
      exact (not_lt_of_ge hle) hlt

theorem check_false (S : Spec) (active : Finset Label) (nodes : Array Node)
    (x : Var → ℝ) (hm : Model S active x) (fuel : ℕ)
    (edges : List Edge) (index : ℕ) (he : Holds x edges)
    (hc : check S active nodes fuel edges index = true) : False := by
  induction fuel generalizing edges index with
  | zero => simp [check] at hc
  | succ fuel ih =>
    cases hn : nodes[index]? with
    | none => simp [check, hn] at hc
    | some node =>
      cases node with
      | cycle path =>
        exact cycleCheck_false x edges he path (by simpa only [check, hn] using hc)
      | branch i j children =>
        have hb : (decide (i ∈ active ∧ j ∈ active ∧ i < j) &&
            (S.options i j).all (fun alt => children.any (fun child =>
              decide (child.1 = alt) && check S active nodes fuel (edges ++ alt) child.2))) = true := by
          simpa only [check, hn] using hc
        obtain ⟨ha, hall⟩ := Bool.and_eq_true_iff.mp hb
        have ha' : i ∈ active ∧ j ∈ active ∧ i < j := of_decide_eq_true ha
        obtain ⟨alt, halt, hat⟩ := hm.2 i ha'.1 j ha'.2.1 ha'.2.2
        have hcandidates := List.all_eq_true.mp hall alt halt
        obtain ⟨child, _, hchild⟩ := List.any_eq_true.mp hcandidates
        have hnext := (Bool.and_eq_true_iff.mp hchild).2
        exact ih (edges ++ alt) child.2 (holds_append he hat) hnext

theorem initialEdges_hold (S : Spec) (active : Finset Label) (x : Var → ℝ)
    (hm : Model S active x) : Holds x (initialEdges S active) := by
  intro e he
  obtain ⟨i, _, hi⟩ := List.mem_flatMap.mp he
  by_cases ha : i ∈ active
  · exact hm.1 i ha e (by simpa [ha] using hi)
  · simp [ha] at hi

theorem accepted_false (S : Spec) (active : Finset Label) (nodes : Array Node)
    (h : accepted S active nodes = true) : ¬ ∃ x, Model S active x := by
  rintro ⟨x, hx⟩
  exact check_false S active nodes x hx _ _ _ (initialEdges_hold S active x hx) h

end Prize.JSP404.ThreeArcOrderCertificate
