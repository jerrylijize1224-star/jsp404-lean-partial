import Prize.JSP404.ThreeArcMaskSteps

/-! Strict integer difference bounds reduce to strict orders of fractional
parts. These lemmas do not assume canonicalization of the original rows. -/
namespace Prize.JSP404.ThreeArcFractionOrder
open ContinuousDirection

def Gap (a b K : ℤ) (u v : ℝ) : Prop :=
  a - b < K ∨ (a - b = K ∧ u < v)

theorem gap_le {a b K : ℤ} {u v : ℝ} (h : Gap a b K u v) : a - b ≤ K := by
  rcases h with h | ⟨h, _⟩ <;> omega

theorem gap_boundary {a b K : ℤ} {u v : ℝ} (h : Gap a b K u v)
    (he : a - b = K) : u < v := by
  rcases h with h | ⟨_, h⟩
  · omega
  · exact h

theorem gap_iff_le_boundary (a b K : ℤ) (u v : ℝ) :
    Gap a b K u v ↔ a - b ≤ K ∧ (a - b = K → u < v) := by
  constructor
  · intro h
    exact ⟨gap_le h, gap_boundary h⟩
  · rintro ⟨h, hb⟩
    by_cases he : a - b = K
    · exact Or.inr ⟨he, hb he⟩
    · exact Or.inl (by omega)

theorem strict_gap_iff (a b K : ℤ) (u v : ℝ)
    (hu0 : 0 ≤ u) (hu1 : u < 1) (hv0 : 0 ≤ v) (hv1 : v < 1) :
    ((a : ℝ) + u) - ((b : ℝ) + v) < K ↔ Gap a b K u v := by
  constructor
  · intro h
    have hzR : ((a - b : ℤ) : ℝ) < (K : ℝ) + 1 := by
      push_cast
      linarith
    have hz : a - b < K + 1 := by exact_mod_cast hzR
    by_cases he : a - b = K
    · right
      refine ⟨he, ?_⟩
      have heR : (a : ℝ) - b = K := by exact_mod_cast he
      linarith
    · left
      omega
  · intro h
    rcases h with h | ⟨he, huv⟩
    · have hz : a - b ≤ K - 1 := by omega
      have hzR : (a : ℝ) - b ≤ (K : ℝ) - 1 := by exact_mod_cast hz
      linarith
    · have heR : (a : ℝ) - b = K := by exact_mod_cast he
      linarith

def offset (k : Fin 3) : ℤ := if k = 0 then 10 else 0

theorem offset_nonneg (k : Fin 3) : 0 ≤ offset k := by
  unfold offset
  split_ifs <;> omega

theorem offset_scaled (k : Fin 3) :
    (9 : ℝ) / 5 * offset k = ContinuousThreeArc.periodOffset k := by
  fin_cases k <;> norm_num [offset, ContinuousThreeArc.periodOffset]

theorem start_width {d : ℝ} (R : ThreeArcRow d) (k : Fin 3) :
    R.start k ≤ R.start (ContinuousThreeArc.previous k) + d -
      ContinuousThreeArc.periodOffset k := by
  fin_cases k
  · simpa [ThreeArcRow.start, ContinuousThreeArc.previous,
      ContinuousThreeArc.periodOffset] using R.width0
  · simpa [ThreeArcRow.start, ContinuousThreeArc.previous,
      ContinuousThreeArc.periodOffset] using R.width1
  · simpa [ThreeArcRow.start, ContinuousThreeArc.previous,
      ContinuousThreeArc.periodOffset] using R.width2

def RowOrder (a : Fin 3 → ℤ) (f : Fin 3 → ℝ) : Prop :=
  ∀ k, Gap (a k) (a (ContinuousThreeArc.previous k)) (4 - offset k)
    (f k) (f (ContinuousThreeArc.previous k))

def PairOrder (a b : Fin 3 → ℤ) (f g : Fin 3 → ℝ) : Prop :=
  ∃ k l : Fin 3, ∃ z : ℤ,
    Gap (a k) (b (ContinuousThreeArc.previous l)) (9 - offset l + 10 * z)
      (f k) (g (ContinuousThreeArc.previous l)) ∧
    Gap (b l) (a (ContinuousThreeArc.previous k)) (-1 - offset k - 10 * z)
      (g l) (f (ContinuousThreeArc.previous k))

def PairOrderBounded (a b : Fin 3 → ℤ) (f g : Fin 3 → ℝ) : Prop :=
  ∃ k l : Fin 3, ∃ z : ℤ, (z = -1 ∨ z = 0) ∧
    Gap (a k) (b (ContinuousThreeArc.previous l)) (9 - offset l + 10 * z)
      (f k) (g (ContinuousThreeArc.previous l)) ∧
    Gap (b l) (a (ContinuousThreeArc.previous k)) (-1 - offset k - 10 * z)
      (g l) (f (ContinuousThreeArc.previous k))

theorem row_order {d : ℝ} (R : ThreeArcRow d) (hd : d < 36 / 5)
    (a : Fin 3 → ℤ) (f : Fin 3 → ℝ)
    (hf : ∀ k, 0 ≤ f k ∧ f k < 1)
    (hdecomp : ∀ k, 5 * R.start k / 9 = (a k : ℝ) + f k) : RowOrder a f := by
  intro k
  have hw := start_width R k
  have ho := offset_scaled k
  have hg : 5 * R.start k / 9 - 5 * R.start (ContinuousThreeArc.previous k) / 9 <
      ((4 - offset k : ℤ) : ℝ) := by
    push_cast
    linarith
  rw [hdecomp k, hdecomp (ContinuousThreeArc.previous k)] at hg
  exact (strict_gap_iff _ _ _ _ _ (hf k).1 (hf k).2
    (hf (ContinuousThreeArc.previous k)).1 (hf (ContinuousThreeArc.previous k)).2).mp hg

theorem pair_order {d : ℝ} (R S : ThreeArcRow d) (hd : d < 36 / 5)
    (a b : Fin 3 → ℤ) (f g : Fin 3 → ℝ)
    (hf : ∀ k, 0 ≤ f k ∧ f k < 1) (hg : ∀ k, 0 ≤ g k ∧ g k < 1)
    (hR : ∀ k, 5 * R.start k / 9 = (a k : ℝ) + f k)
    (hS : ∀ k, 5 * S.start k / 9 = (b k : ℝ) + g k)
    (hpair : ∃ x y : ℝ, ∃ z : ℤ, R.Mem x ∧ S.Mem y ∧ y = x + 9 + 18 * z) :
    PairOrder a b f g := by
  obtain ⟨x, y, z, hx, hy, hxy⟩ := hpair
  obtain ⟨k, hk⟩ := R.mem_start hx
  obtain ⟨l, hl⟩ := S.mem_start hy
  have hok := offset_scaled k
  have hol := offset_scaled l
  refine ⟨k, l, -z - 1, ?_, ?_⟩
  · have h : 5 * R.start k / 9 - 5 * S.start (ContinuousThreeArc.previous l) / 9 <
        ((9 - offset l + 10 * (-z - 1) : ℤ) : ℝ) := by
      push_cast
      linarith [hk.1, hl.2]
    rw [hR k, hS (ContinuousThreeArc.previous l)] at h
    exact (strict_gap_iff _ _ _ _ _ (hf k).1 (hf k).2
      (hg (ContinuousThreeArc.previous l)).1 (hg (ContinuousThreeArc.previous l)).2).mp h
  · have h : 5 * S.start l / 9 - 5 * R.start (ContinuousThreeArc.previous k) / 9 <
        ((-1 - offset k - 10 * (-z - 1) : ℤ) : ℝ) := by
      push_cast
      linarith [hl.1, hk.2]
    rw [hS l, hR (ContinuousThreeArc.previous k)] at h
    exact (strict_gap_iff _ _ _ _ _ (hg l).1 (hg l).2
      (hf (ContinuousThreeArc.previous k)).1 (hf (ContinuousThreeArc.previous k)).2).mp h

theorem pair_order_bounded {a b : Fin 3 → ℤ} {f g : Fin 3 → ℝ}
    (ha : ∀ k, 0 ≤ a k ∧ a k ≤ 9) (hb : ∀ k, 0 ≤ b k ∧ b k ≤ 9)
    (h : PairOrder a b f g) : PairOrderBounded a b f g := by
  obtain ⟨k, l, z, hk, hl⟩ := h
  have hki := gap_le hk
  have hli := gap_le hl
  have hka := ha k
  have hkb := hb l
  have hpa := ha (ContinuousThreeArc.previous k)
  have hpb := hb (ContinuousThreeArc.previous l)
  have hok := offset_nonneg k
  have hol := offset_nonneg l
  refine ⟨k, l, z, ?_, hk, hl⟩
  omega

noncomputable def fraction {d : ℝ} (R : ThreeArcRow d) (k : Fin 3) : ℝ :=
  Int.fract (5 * R.start k / 9)

theorem fraction_bounds {d : ℝ} (R : ThreeArcRow d) (k : Fin 3) :
    0 ≤ fraction R k ∧ fraction R k < 1 :=
  ⟨Int.fract_nonneg _, Int.fract_lt_one _⟩

theorem decomposition_of_floor {d : ℝ} (R : ThreeArcRow d) (a : Fin 3 → ℤ)
    (h : ∀ k, ⌊5 * R.start k / 9⌋ = a k) (k : Fin 3) :
    5 * R.start k / 9 = (a k : ℝ) + fraction R k := by
  rw [← h k]
  exact (Int.floor_add_fract _).symm

theorem row_order_of_floor {d : ℝ} (R : ThreeArcRow d) (hd : d < 36 / 5)
    (a : Fin 3 → ℤ) (h : ∀ k, ⌊5 * R.start k / 9⌋ = a k) :
    RowOrder a (fraction R) :=
  row_order R hd a (fraction R) (fraction_bounds R) (decomposition_of_floor R a h)

theorem pair_order_of_floor {d : ℝ} (R S : ThreeArcRow d) (hd : d < 36 / 5)
    (a b : Fin 3 → ℤ) (hR : ∀ k, ⌊5 * R.start k / 9⌋ = a k)
    (hS : ∀ k, ⌊5 * S.start k / 9⌋ = b k)
    (hpair : ∃ x y : ℝ, ∃ z : ℤ, R.Mem x ∧ S.Mem y ∧ y = x + 9 + 18 * z) :
    PairOrder a b (fraction R) (fraction S) :=
  pair_order R S hd a b (fraction R) (fraction S) (fraction_bounds R) (fraction_bounds S)
    (decomposition_of_floor R a hR) (decomposition_of_floor S b hS) hpair

theorem pair_order_bounded_of_floor {d : ℝ} (R S : ThreeArcRow d) (hd : d < 36 / 5)
    (a b : Fin 3 → ℤ) (ha : ∀ k, 0 ≤ a k ∧ a k ≤ 9)
    (hb : ∀ k, 0 ≤ b k ∧ b k ≤ 9)
    (hR : ∀ k, ⌊5 * R.start k / 9⌋ = a k)
    (hS : ∀ k, ⌊5 * S.start k / 9⌋ = b k)
    (hpair : ∃ x y : ℝ, ∃ z : ℤ, R.Mem x ∧ S.Mem y ∧ y = x + 9 + 18 * z) :
    PairOrderBounded a b (fraction R) (fraction S) :=
  pair_order_bounded ha hb (pair_order_of_floor R S hd a b hR hS hpair)

end Prize.JSP404.ThreeArcFractionOrder
