# 26 点精确值：144°

日期：2026-11-05。`alpha 26 = 4*Real.pi/5` 与 26～32 点完整尖锐性已通过 Lean。完整构建 3285 项、公理审计 3885 项全部成功，其中 4 项不依赖公理。
此前已验证并发布 `alpha 27 = 4*Real.pi/5`。完整 `SendovClaim` 尚未完成。

## 原题连接

`ThreeArcSixteen.lean` 把连续三弧容量从 17 降至 16。
结合已经证明的单弧容量 9，可得所有角严格小于 144° 的平面配置至多 25 点。
`TwentysixExact.lean` 把这一结论接回原题的任意有限平面点集，并沿用既有二进制构造的尖锐上界，证明
`alpha 26 = 4*Real.pi/5` 和 26≤N≤32 的完整 `IsSharpBound`。
原题没有增加凸性、一般位置、实现性或极值达到假设。

## 全部 1140 种缺失三元组

复用 27 点证明中已经验证的规范化：每行连续三弧对应 20 种明确编号之一，不同行的编号不同。
17 行占据其中 17 个编号，恰好缺少 3 个。把缺失编号排序为 a<b<c，共有 C(20,3)=1140 种情况。
`ThreeArcOrderModelGeneral.lean` 把此前的连续模型连接推广到非空 `Fin n`，并证明 17 行的缺失集恰好是三次删除。
非空条件仅用于构造逆映射，在 n=17 时自动满足，不是原题附加的数学假设。

`ThreeArcOrder17Data.lean` 直接复用原来的 `ThreeArcOrderData.spec`；宽度表、交点选项表、严格序比较和规范化证明均沿用已有结果。
生成器给每个缺失三元组导出一份证明树。移除冗余分支后，共 19498 个节点、5051 个循环叶子；单例最多 87 个节点，最大深度 26。
移除分支只是缩小待核验的数据，不改变检查器；所有导出分支和叶子仍由原来的检查器重新检查。
`ThreeArcOrder17Checks.lean` 对 1140 份证书分别使用 `decide +kernel`，再用 20 个行汇总定理及统一 `all_accepted` 连接全部情况。
这些分别检查同一排除任务的有限情况，不是 1140 个独立数学发现。

## 可信边界与复现

搜索器只使用 Python 标准库，搜索结果不作为公理或外部判定结论。
已有 `ThreeArcOrderCertificate.lean` 证明检查器可靠：每次分支必须覆盖该行对的所有允许选项，每个循环叶子的每条严格比较都必须在路径上下文内。
有限表与连续模型的覆盖性分别已有证明。因此只有所有证书通过 Lean 内核、三弧排除接回原题并完成公理审计后，才报告精确数值。
没有引入 `sorry`、`admit`、新公理或 `native_decide`。

`scripts/export_three_arc_order17_certificate.py` 可独立重建数据与检查源码：

```sh
python3 scripts/export_three_arc_order17_certificate.py --out /tmp/jsp404-order17-reproduced
```

本轮独立复现耗时约 32.53 秒 CPU，数据 976266 字节、检查源码 288280 字节均与项目源码逐字节一致。
复现统计见 `logs/jsp404-order-certificate-17-reproduction-20261104.json`；这种复现记录与 Lean 内核证明相互区分。

## 来源和范围

数值目标来自 Sendov 的经典论文：*Minimax of the angles in a plane configuration of points*, Acta Mathematica Hungarica 69 (1995), 27–46，[DOI](https://doi.org/10.1007/BF01874605)，[公开馆藏](https://real-j.mtak.hu/7467/)。
来源核对与计数重建限制见 `jsp404-english-source.md` 与 `jsp404-proof-map.md`。
本轮没有做新的文献或全球仓库检索，不声称数学新发现、首次形式化或优先权。
本路线的贡献是有限证书核验与既有几何约化之间的形式化连接；任意点数总命题仍未证明。

5 个新模块的 1174 个定理均已列入审计；其中 1140 项逐例检查、21 项汇总检查。
本轮完成后，21～25 点仍为 [140°,144°]，任意点数总命题仍未证明。
