# JSP-000404 阶段成果发布记录

2026-09-18 09:25（Asia/Shanghai），依据用户明确授权，使用用户已登录的
GitHub 账号 `jerrylijize1224-star` 发布阶段成果。

- 公开仓库：https://github.com/jerrylijize1224-star/jsp404-lean-partial
- 固定提交：https://github.com/jerrylijize1224-star/jsp404-lean-partial/commit/317441dd29d7a4975be4a89dc7802be2567f86cb
- 发布文件：README.md、jsp404-partial-20260918.zip、对应 SHA-256 文件。
- 压缩包 SHA-256：`d620eb4b1a9e6044c7971ae2dad3362bbe0abc1e52f74f7331e31ede2b5bb4e0`。
- 已从公开固定提交重新下载，SHA-256 与本地阶段成果包完全一致。

README 明确列出部分成果、剩余缺口、已有公开工作、AI 辅助归属及复现说明。
此操作没有提交整题完成声明，没有向孙奖仓库提交 PR 或奖金申请。
封存包里的“尚未发布”是打包当时的状态；仓库根 README 已说明这一点。
公开提交记录不能替代原创性或奖金优先权审查。

## 2026-09-19：统一四中心角度表达式

- 固定提交：https://github.com/jerrylijize1224-star/jsp404-lean-partial/commit/5341064411741a6a9903eb7d6251c1b1b3309193
- 新包：`jsp404-four-centre-20260919.zip`（45 个文件，82715 字节）。
- SHA-256：`ece15485e0b950a8992ce54839f961b9a152fa80f9ae3799497517dece742205`。
- 已回下载确认 SHA-256 一致；旧包保留不变，根 README 更新到新版本。
- 新增：完整四点几何分类、共同对称局部指数、不依赖编号的四点集合表达式及两段容量界。
- 完整构建和公理检查已通过；循环投影方向间隔的等价与广义点簇大小连接仍未完成。

## 2026-09-20：实际投影方向间隔

- 固定提交：https://github.com/jerrylijize1224-star/jsp404-lean-partial/commit/f36dffb7f6281b4d17c67dc0325296548b951f09
- 新包：`jsp404-projective-gaps-20260920.zip`（50 个文件，94939 字节）。
- SHA-256：`ef1b8f29c24103a006da3875924be117f5f03d686e746564d73f409bab47e037`。
- 已从固定公开提交回下载，校验值与本地一致；之前的两个发布包保留。
- 新增：实际方向的排序投影坐标、三个正间隔之和等于 π、局部指数与坐标选择无关，以及四中心容量与实际间隔表达式的等价。
- 整项目构建与公理检查通过。原题仍未证完，广义点簇计数与一般中心数论证继续开发。

## 2026-09-20：条件性点簇计数

- 固定提交：https://github.com/jerrylijize1224-star/jsp404-lean-partial/commit/78697a4e22416a0091631310f3da18a1cd2506b8
- 新包：`jsp404-cluster-counting-20260920.zip`（54 个文件，103561 字节）。
- SHA-256：`1d47247be2a447716d98fd2fe39c84caeaff782307bc9c64f80a420965d7eb84`。
- 已从固定公开提交回下载，SHA-256 与本地封存包一致；旧包全部保留。
- 新增：广义方向覆盖计数、跨簇方向的角度排除、闭区间的严格窄覆盖，
  以及在允许间隔坐标条件下构造真实方向扇区并推出点数界。
- 整项目构建成功（2542 项含依赖），公理检查退出码为 0，仅标准三项基础。
- 从实际中心推导内部方向的允许坐标仍未证明；没有声称完整点簇约化或原题完成。

## 2026-09-21：四点簇的实际点数界

- 固定提交：https://github.com/jerrylijize1224-star/jsp404-lean-partial/commit/17f9adeeda6a54f7a3f2d63c2ed99cbc3b93cfcd
- 新包：`jsp404-four-clusters-20260921.zip`（57 个文件，111278 字节）。
- SHA-256：`1dabdb6d4ec158fca3f2fdd38e0d4d50970d59211d59a5de1f8cc01df1de5f98`。
- 11:28（Asia/Shanghai）公开提交后，从固定提交回下载，校验值与已审计本地包一致。
- 新增：由三个实际锚点推导允许间隔，覆盖半圈循环边界；将四个非空点簇
  的总标签数连接到四中心容量，并证明两段点数上界。没有额外假设扇区覆盖存在。
- 整项目构建成功（2544 项含依赖），完整公理检查退出码为 0，仅标准三项基础。
- 一层四簇模型的假设显式保留。任意配置的约化、五中心及以上以及原题仍未证明。
- 此前一次上传被自动审批以账户额度用尽为由拦截，未发布成功。用户继续后，
  只读检查确认额度恢复，再通过同一网页上传流程成功发布；没有绕过拦截。

## 2026-09-21：任意有限中心数的局部计数

- 固定提交：https://github.com/jerrylijize1224-star/jsp404-lean-partial/commit/a6a363f96cf617fa6227c7300a4a318fde86244a
- 新包：`jsp404-finite-clusters-20260921.zip`（61 个文件，121607 字节）。
- SHA-256：`de958e3cb79ed86376330bc6e8cfd4693ee13246d123ec95811c6484c9bcbd48`。
- 11:55（Asia/Shanghai）已生成公开提交。回下载校验当时被自动审批因额度用尽拦截；
  2026-09-22 只读检查确认额度恢复后，经原流程回下载，SHA-256 与本地包一致。
- 新增任意非空有限方向的排序坐标、正循环间隔、总和 π、允许区间及坐标选择无关性。
  任意不少于两个中心的一层模型中，每簇点数受局部容量限制，总点数受容量和限制。
- 整项目构建成功（2547 项含依赖），公理检查退出码为 0，仅标准三项基础。
- 尚未证明五中心以上的容量和满足两段尖锐界，也未完成原题。

## 2026-09-22：实际间隔约化与最大指数

- 固定提交：https://github.com/jerrylijize1224-star/jsp404-lean-partial/commit/9d331c9c3ce776055c2f9eb45016e5ff03aa1c30
- 新包：`jsp404-gap-restriction-20260922.zip`（64 个文件，129365 字节）。
- SHA-256：`ef51d31c5bab1a0292b2de62dff8499339e2032b7071fdf712c651a5d3cdfc3d`。
- 已从固定公开提交回下载，与通过 Lean 检查的本地封存包逐字节一致。
- 新增：实际循环间隔的两段求和、保留两个方向时局部容量不减、实际三角形
  约化、每个局部指数的上界及达到最大指数的中心数量限制。
- 整项目构建成功（2549 项含依赖），随后完整公理检查退出码为 0；
  新增声明仅依赖 `propext`、`Classical.choice`、`Quot.sound`。
- 五中心以上的尖锐总容量界、普通配置约化和完整尖锐构造仍未证明。
  旧包全部保留；没有向官方奖题仓库提交完成声明。

## 2026-09-22：小角度凸位置及条件性外角连接

- 固定提交：https://github.com/jerrylijize1224-star/jsp404-lean-partial/commit/4fa56d7c17a628d3f899215b9a889449c972fe9f
- 新包：`jsp404-convex-position-20260922.zip`（68 个文件，138494 字节）。
- SHA-256：`bccd4cb51edabe89baecf5773f8e6a93d4c295c3ad06275aae2c5d29f8ac299f`。
- 已从固定公开提交回下载，和本地封存包逐字节一致。
- 新增：0<t<3 时实际有限点集及中心族的凸独立性；显式外角预算条件下
  的取整权重界；同侧射线排序坐标下的局部外角容量恒等式。
- 完整构建成功（2555 项含依赖），完整公理检查退出码为 0；九个新增声明
  均仅依赖标准三项基础，没有未完成证明占位或新增数学公理。
- 旋转坐标的构造与容量不变性、外角总和连接、一般尖锐总容量界仍未完成。
  该快照不是原题完整解答，旧包全部保留。

## 2026-09-22：直接外角上界与五中心几何接口

- 固定提交：https://github.com/jerrylijize1224-star/jsp404-lean-partial/commit/17bf1574dabb19b47f1026e745dcc0b4bace9cef
- 新包：`jsp404-exterior-five-20260922.zip`（71 个文件，146510 字节）。
- SHA-256：`fa3a859de3ea3f22c298fbc1ddaa91cb123183c9841b1b89cc3d816e44b32db7`。
- 固定公开提交已回下载，与本地已审计封存包逐字节一致。
- 新增：无需旋转或同侧射线条件的局部外角容量上界；显式外角预算下
  的实际总点数界；五中心三组严格对角线交叉推出的内外角和及点簇计数。
- 完整构建成功（2557 项含依赖），公理检查退出码为 0；十二个新增声明
  仅依赖标准三项基础，没有未完成证明占位或新增数学公理。
- 任意凸独立五点集的交叉标号存在性、任意中心数的外角预算与一般尖锐界
  均未完成。没有提交原题完成声明，旧快照全部保留。


## 2026-09-23：五点排列存在性与五中心首段计数

- 固定提交：https://github.com/jerrylijize1224-star/jsp404-lean-partial/commit/f6c7c3f8c2dbdd3c6e90af6deb7e350a57170e31
- 新包：`jsp404-pentagon-order-20260923.zip`（76 个文件，157550 字节）。
- SHA-256：`2e6f2a5841715daac126fda2444ce441f637c52aac9e0398c616cae700e02243`。
- 固定公开提交已回下载，与本地已审计封存包逐字节一致。
- 新增：严格分离后的正射线坐标、四点 Radon 交叉分类、有序射线的严格交叉、
  任意凸独立五点集的交叉标号存在性，以及重新编号后的实际五中心计数。
- 对 1≤t<3 的五个非空中心簇模型，总标签数恰为 5；1≤t<5/2 时模型不可能。
  这两个结果不再要求额外的顶点顺序、对角线交叉或外角预算假设。
- 完整构建成功（2568 项含依赖），随后完整公理检查退出码为 0；十五项新增
  定理检查仅依赖标准三项基础，没有未完成证明占位或新增数学公理。
- 更高参数的五中心问题、六中心及以上、一般尖锐总容量与原题仍未完成。
  旧快照全部保留，没有提交原题完成声明或奖金申请。


## 2026-09-25：普通点集的 108° 与 120° 普遍下界

- 固定提交：https://github.com/jerrylijize1224-star/jsp404-lean-partial/commit/e4a122f1691ec8f9c0bbaed019d67b185a3bd2f4
- 新包：`jsp404-first-band-lower-20260925.zip`（80 个文件，166624 字节）。
- SHA-256：`6f98e312b0cfd56526a48e8e3cfedf692871e6ec5cd71f5578b170b424b56d6f`。
- 固定公开提交已回下载，与本地已审计封存包逐字节一致。
- 新增：任意有限凸独立点族的交叉排序、六边形内角和、0<t<3 时普通点集
  至多五点，以及对应实际点簇模型至多五个非空中心簇。
- 原题连接：n≥5 时 alpha n≥3π/5，n≥6 时 alpha n≥2π/3；不要求一般位置、
  预给定顺序或普通点集到广义模型的约化，包含阈值端点。
- 完整构建成功（2571 项含依赖），随后完整公理检查退出码为 0；十二项新增
  定理只依赖标准三项基础，没有未完成证明占位或新增数学公理。
- 匹配的尖锐构造、更高参数下的一般容量界及原题完整证明仍未完成。
  旧快照全部保留，没有向官方题库提交完成声明或奖金申请。


## 2026-09-25：六点精确值 α(6)=120°

- 固定提交：https://github.com/jerrylijize1224-star/jsp404-lean-partial/commit/4771034b2e183d7750b055c5b42becfb7bf56620
- 新包：`jsp404-six-points-20260925.zip`（82 个文件，170037 字节）。
- SHA-256：`eb2583376f630c929e20bf4152ab02752dd83b91a461df2795d8f47c8e4b3815`。
- 固定公开提交已回下载，与本地已审计封存包逐字节一致。
- 新增显式正六边形的互异性、所有夹角≤120° 的精确内积证书，以及
  `sixPoints_sharp` 和 `alpha_six`。上下界均直接针对原题普通六点集合。
- 完整构建成功（2572 项含依赖），随后公理检查退出码为 0；七项新增定理
  仅依赖标准三项基础，没有未完成证明占位、新增数学公理或 `native_decide`。
- 五、七、八点的匹配构造以及任意点数完整主定理仍未完成。
  旧快照全部保留；不主张新数学发现、首次形式化或奖金资格。


## 2026-09-26：五点精确值 α(5)=108°

- 固定提交：https://github.com/jerrylijize1224-star/jsp404-lean-partial/commit/4acde6aa51286ee3cb8d5f698f40fb46d7421dc4
- 新包：`jsp404-five-points-20260926.zip`（84 个文件，175623 字节）。
- SHA-256：`4693671fdda938509d46e9dc7d395d72687ea67b49ce2ac9cfa250f7f0ee8c65`。
- 固定公开提交已回下载，与本地已审计封存包逐字节一致。
- 新增黄金比例五点坐标构造、互异性、精确内积证书、108° 余弦公式，以及
  `fivePoints_sharp` 和 `alpha_five`。上下界均直接针对原题普通五点集合。
- 完整构建成功（2573 项含依赖），随后完整公理检查退出码为 0；十三项新增
  定理仅依赖标准三项基础，无未完成证明占位、新增数学公理或 `native_decide`。
- 当前已证明本项目 n=3、4、5、6 的精确值；七、八点匹配构造与一般主定理
  仍未完成。旧快照全部保留，不主张新数学发现、首次形式化或奖金资格。


## 2026-09-26：七、八点精确值 α(7)=α(8)=120°

- 固定提交：https://github.com/jerrylijize1224-star/jsp404-lean-partial/commit/5c7440a5d04c4e20326cba4b8d8e4f1dde55753c
- 新包：`jsp404-binary-eight-20260926.zip`（87 个文件，182974 字节）。
- SHA-256：`621e82741a96f1328d8f08cc300519aeb2904acab072650dfdf5bdc250cf750e`。
- 固定公开提交已回下载，与本地已审计封存包逐字节一致。
- 新增有限同时逼近接口和三层二进制八点坐标构造；每个正误差下都有八个
  互异普通点满足严格角度上界。结合已有下界得到七、八点精确值，未假定极值配置存在。
- 完整构建成功（2575 项含依赖），随后完整公理检查退出码为 0；全部 217 项
  检查覆盖当前审计清单，十二项新增定理均仅依赖标准三项基础。
- 本项目已证明 n=3 到 n=8 的精确值；一般尖锐计数界、任意层数构造和
  完整 `SendovClaim` 仍未完成。旧快照保留，不主张新发现、首次形式化或奖金资格。


## 2026-09-26：任意有限二进制层与十六点上界

- 固定提交：https://github.com/jerrylijize1224-star/jsp404-lean-partial/commit/3a79b282f00dfa892f6c75f05fec5dc5504264ec
- 新包：`jsp404-binary-scales-20260926.zip`（90 个文件，191073 字节）。
- SHA-256：`26126edce45a0476d26eddd0690d829eef0ef284fbecd1bebfb4e3f2f13dae41`。
- 固定公开提交已回下载，与本地已审计封存包逐字节一致。
- 任意有限层数的首差分解和普通点逼近已证明，但轴角度条件明确保留。
  四个显式轴给出十六点的 135° 上界；未证明十六点的精确值。
- 完整构建成功（2577 项含依赖），随后全部 236 项公理检查通过；十九项新增
  定理仅依赖标准三项基础，无未完成证明占位、新增数学公理或 `native_decide`。
- n=3 到 n=8 的精确值保持成立。一般尖锐轴族、一般普遍下界和完整主定理
  仍未完成；旧快照保留，不主张新发现、首次形式化或奖金资格。


## 2026-09-26：全部二进制阈值及第二分段的一般上界

- 固定提交：https://github.com/jerrylijize1224-star/jsp404-lean-partial/commit/fdb37c713d45bafc24943081958c990cb5512c06
- 新包：`jsp404-dyadic-upper-20260926.zip`（92 个文件，196422 字节）。
- SHA-256：`6cda8f3a3f36d8872d2dcc896cd5a245ba0ef2043a3d8eac6cef74e15b7816d5`。
- 固定公开提交已回下载，与本地已审计封存包逐字节一致。
- 对任意 n≥2 验证半圆等分轴，得到恰好 2ⁿ 个普通点的逼近反例，
  以及 3≤m≤2ⁿ 时 alpha m≤(1−1/n)π。原题第二分段的一般上界已连接，
  但未证明匹配的一般下界或第一分段的更精细构造。
- 完整构建成功（2578 项含依赖），随后全部 248 项公理检查通过；十二项
  新增定理仅依赖标准三项基础，无未完成证明占位或新增数学公理。
- 已证明的精确值仍为 n=3 到 n=8，完整主定理未完成。
  旧快照保留，不主张新发现、首次形式化或奖金资格。


## 2026-09-27：第一分段一般上界——本地封存，上传待完成

- 本地包：`jsp404-first-band-upper-20260927.zip`（97 个文件，208521 字节）。
- SHA-256：`3470ee261661c35fb4d0a3633646717108e50554e3da8a7de0c41f906c06a87d`。
- 完整构建成功（2582 项含依赖），随后全部 278 项公理检查通过；三十项新增
  定理仅依赖标准三项基础。两个分段的一般上界均已证明，一般下界仍未完成。
- GitHub 文件选择器多次超时；改用网页文件输入控件、刷新上传页及尝试检查
  系统文件窗口后仍未恢复，最后浏览器工具会话被超时错误重置。
- 此版本尚未得到上传成功或新提交的确认，不得称为已公开发布。
  已准备根目录 README、ZIP 和 SHA-256 文件；上一公开版本仍为
  `fdb37c713d45bafc24943081958c990cb5512c06`。


## 2026-09-27：第一分段一般上界——上传恢复并完成

- 浏览器文件选择器在后续尝试中恢复，已上传 README、封存 ZIP 和校验文件。
- 固定提交：https://github.com/jerrylijize1224-star/jsp404-lean-partial/commit/13c5499f7c90ca0cec5b2bbb49ec1b9c241d5bfa
- 固定提交的公开 ZIP 已回下载，与上一条记录的 208521 字节本地包逐字节一致，
  SHA-256 保持 `3470ee261661c35fb4d0a3633646717108e50554e3da8a7de0c41f906c06a87d`。
- 上一条“上传待完成”记录为当时状态，现已解除；封存包未改写。


## 2026-09-27：一般下界与极限——验证完成，准备封存

- 新增半开方向分区、普通配置的一般非尖锐下界，以及 alpha N→π。
- 两个分段的上下界区间已连接，例子为 135°≤alpha 17≤140°。
- 完整构建成功（2584 项含依赖），随后 290 项公理检查全部通过；十二项新增
  定理仅依赖标准三项基础。精确值范围仍为 n=3 到 n=8，原题尚未完成。
- 本条为封存前记录；本轮新包的公开提交和哈希需以后续发布记录为准。


## 2026-09-27：一般下界与极限——已发布并回下载核对

- 固定提交：https://github.com/jerrylijize1224-star/jsp404-lean-partial/commit/770cdbcfee72e05bc2a6d33f468709b008c9f266
- 新包：`jsp404-uniform-lower-20260927.zip`（100 个文件，215904 字节）。
- SHA-256：`49dcfedc92784a7357599d7cff0016d123b8e46f847eeafd7e1b906e1e694e52`。
- 固定提交的公开 ZIP 已回下载，与通过 2584 项构建及 290 项公理检查的
  本地封存包逐字节一致。十二项新增定理只依赖标准三项基础。
- 本轮证明一般非尖锐下界、alpha N→π 和两个分段的上下界区间；
  十七点为 135° 至 140°，没有证明其精确值。原题及匹配的一般下界仍未完成。
- 已保留以前的公开快照，包括本轮先补发的第一分段一般上界包。


## 2026-09-27：严格一般下界——验证完成，准备封存

- 紧致单位方向空间给出 N>2ᵏ 时 alpha N>(1−1/k)π；对每个 k 存在
  对全部 N>2ᵏ 适用的统一正余量，未算出其具体数值。
- 十七点区间加强为 135°<alpha 17≤140°，未证明其精确值。
- 完整构建成功（2586 项含依赖），随后全部 308 项公理检查通过。十八项
  新增定理只依赖标准三项基础；完整主定理及匹配一般下界仍未完成。
- 此为封存前记录；新包是否公开及其提交哈希，以后续记录为准。


## 2026-09-27：严格一般下界——已发布并回下载核对

- 固定提交：https://github.com/jerrylijize1224-star/jsp404-lean-partial/commit/c3ad1d7bfc185a9e85999c6c3f1835e9db668f32
- 新包：`jsp404-strict-lower-20260927.zip`（103 个文件，224822 字节）。
- SHA-256：`23c297a247bc1227eeadfed5286513836ae5bb6fc3d749cde4a3a16ef90aeb65`。
- 固定公开提交的 ZIP 已回下载，与通过 2586 项构建和 308 项公理检查的
  本地封存包逐字节一致。十八项新增定理只依赖标准三项基础。
- 新结论为 N>2ᵏ 时的严格一般下界及每个 k 对应的统一正余量；
  未给出余量数值，未证明匹配尖锐下界，完整 SendovClaim 仍未完成。
- 本项目当前十七点区间为 135°<alpha 17≤140°；精确值仍为 n=3 到 n=8。
  保留此前快照，不作数学新发现、首次形式化或奖金完成声明。


## 2026-09-28：显式正余量——验证完成，准备封存

- 新下界为 N>2ᵏ 时 alpha N≥(1−1/k)π+π/[k(N²+1)]；
  用单调性还可把 N 固定为 2ᵏ+1，得到统一显式余量。
- 十七点为 (135+9/58)°≤alpha 17≤140°，仍未证明其精确值。
- 完整构建成功（2589 项含依赖），随后全部 320 项公理检查通过。
  十二项新增定理仅依赖 propext、Classical.choice、Quot.sound。
- 此为封存前记录，公开提交和回下载核对结果以后续记录为准。
  原题及匹配一般下界仍未完成，不作数学新发现或首次形式化声明。


## 2026-09-28：显式正余量——已发布并回下载核对

- 固定提交：https://github.com/jerrylijize1224-star/jsp404-lean-partial/commit/ad96b5e65b87d305ea7606d6ac97675aacda61e1
- 新包：`jsp404-quantitative-lower-20260928.zip`（107 个文件，235371 字节）。
- SHA-256：`1b0bb80c01fa2667de37759726aa8cf4a2a148c3d5f655ea66fbd0d62a31ac43`。
- 固定公开提交的 ZIP 已回下载，与通过 2589 项构建和 320 项公理检查的
  本地封存包逐字节一致。十二项新增定理仅依赖标准三项基础。
- 新结论为显式非尖锐一般下界及可计算的统一正余量；十七点为
  (135+9/58)°≤alpha 17≤140°。精确值仍仅为 n=3 到 n=8。
- 完整 SendovClaim 和匹配尖锐一般下界仍未完成；保留此前快照，
  不作数学新发现、首次形式化或奖金完成声明。


## 2026-09-29：无序点对改进——验证完成，准备封存

- 下界改进为 N>2ᵏ 时 alpha N≥(1−1/k)π+π/[k(choose(N,2)+1)]，
  并证明严格强于上一轮有序点对估计。可用单调性取得统一显式余量。
- 十七点为 (135+45/137)°≤alpha 17≤140°，精确值尚未证明。
- 完整构建成功（2590 项含依赖），随后全部 332 项公理检查通过。
  十二项新增定理仅依赖 propext、Classical.choice、Quot.sound。
- 原目标题文件与上轮公开版本完全一致。此为封存前记录；
  公开提交和回下载核对结果以后续记录为准。不作新发现或完整解题声明。


## 2026-09-29：无序点对改进——已发布并回下载核对

- 固定提交：https://github.com/jerrylijize1224-star/jsp404-lean-partial/commit/d7f1b623e2b763d0dbce1ba63ed65d112c32d952
- 新包：`jsp404-edge-lower-20260929.zip`（109 个文件，239583 字节）。
- SHA-256：`a4859354a4eed7afdea8280a6cded8fed33b94709cd0461605e93dba1833a265`。
- 固定公开提交的 ZIP 已回下载，与通过 2590 项构建和 332 项公理检查的
  本地封存包逐字节一致。十二项新增定理仅依赖标准三项基础。
- 无序点对去重给出严格强于上一轮的显式一般下界；十七点为
  (135+45/137)°≤alpha 17≤140°。这仍是非尖锐的小幅定量改进。
- 完整 SendovClaim 及匹配一般下界仍未证明；精确值仍为 n=3 到 n=8。
  保留旧快照，不作新发现、首次形式化或奖金完成声明。


## 2026-09-30：所有二进制点数精确值——验证完成，准备封存

- 用二进制计数等号结构、连通性和实际开扇区的半圈旋转，证明严格角帽下
  点数严格少于 2ᵏ。接回普通点集并合并已有上界，得到所有 k≥2 的
  alpha(2ᵏ)=(1−1/k)π 和对应 IsSharpBound。
- 例如 alpha 16=135°、alpha 32=144°；17 点精确值及一般非二进制情况仍未完成。
- 完整构建成功（2595 项含依赖），随后全部 347 项公理检查通过。
  十五项新增定理仅依赖 propext、Classical.choice、Quot.sound。
- 经典数学结论归原作者；不作新发现或首次形式化声明。原目标题文件未改变。
  此为封存前记录；公开提交和回下载核对结果以后续记录为准。


## 2026-09-30：所有二进制点数精确值——已发布并回下载核对

- 固定提交：https://github.com/jerrylijize1224-star/jsp404-lean-partial/commit/9e3c4a3e98f1700553b3624b9aa4c58f1cc1925c
- 新包：`jsp404-dyadic-sharp-20260930.zip`（113 个文件，250371 字节）。
- SHA-256：`4dd48b2e63aa373bbfba945e608867fb6d07d6a301d2deb018600bd90d60eae6`。
- 固定公开提交的 ZIP 已回下载，与通过 2595 项构建和 347 项公理检查的
  本地封存包逐字节一致。十五项新增定理仅依赖标准三项基础。
- 本轮完成经典无限子族 alpha(2ᵏ)=(1−1/k)π（k≥2）及 IsSharpBound。
  例如 alpha 16=135°、alpha 32=144°。此前 n=3 到 n=8 的精确值保留。
- 一般非二进制点数的匹配尖锐下界及完整 SendovClaim 仍未证明。
  不作数学新发现、首次形式化或奖金完成声明，保留全部旧快照。

## 2026-09-30：加权容量与旋转空缺（封包后、上传前）

- 新增 `WeightedDirectionCover.lean` 和 `RotatingCoverDeficit.lean`，共十二个定理。
- 加权容量 Σᵥ2^f(v)≤2ᵏ 及固定方向类的空缺点数界已验证，并接入实际旋转开扇区。
- 每个指定点和关系都存在空缺位置，但尚未证明同一位置出现足够多空缺。
- 没有改进 alpha 的数值下界；一般非二进制尖锐下界和完整主定理仍未完成。
- 完整构建成功（2597 项含依赖），随后全部 359 项公理检查通过。
  新增十二个定理仅依赖 `propext`、`Classical.choice`、`Quot.sound`。
- 新包：`jsp404-weighted-cover-20260930.zip`（116 个文件，259605 字节）。
- SHA-256：`81fe766cddf4e8fe4e7fdd9357a1792526e191fbcbba706475e0c7324040752e`。
- 包内构建、公理日志与源码一并封存；本段为封包后的记录，不重写封存 ZIP。
- 新工具是本地形式化扩展，不声称数学新颖性、首次形式化或获奖资格。
  本轮没有全面重查外部提交，也没有独立重建其他作者的证明包。
- 按用户既有授权上传原公开仓库；固定提交和远端字节核验随后记录。

## 2026-09-30：加权容量快照公开核验

- 已发布提交：[bef171bd1c3db1eee55c9e357087899a0966fe64](https://github.com/jerrylijize1224-star/jsp404-lean-partial/commit/bef171bd1c3db1eee55c9e357087899a0966fe64)。
- 仓库首页、`jsp404-weighted-cover-20260930.zip` 及其 SHA-256 文件一并更新。
- 从固定公开提交下载 ZIP，确认与本地通过构建及 359 项公理检查的封包逐字节相同。
  文件大小 259605 字节，SHA-256 为 `81fe766cddf4e8fe4e7fdd9357a1792526e191fbcbba706475e0c7324040752e`。
- 既有快照保留，新封存包未重写。没有向奖项仓库提交完整证明或奖金申请。

## 2026-09-30：总空缺预算与实际反例（封包前）

- 新增 `CoverDeficitBudget.lean`、`RotatingDeficitObstruction.lean`，并从已有三点构造导出公开等角三角形存在性，共七个新定理。
- 验证 |V|+Σᵥf(v)≤2ᵏ，及 |V|+1=2ᵏ 时空缺对的全局唯一性。
- 实际等边三角形每个点和方向类都有某个未使用位置，但任意位置至多出现一个空缺对。
- 这排除过强的通用量词交换，不否定 Sendov 公式，也不排除利用更大点数得到额外重叠估计。
- 完整构建成功（2599 项含依赖），全部 366 项公理审计通过；新增七个定理仅依赖标准 `propext`、`Classical.choice`、`Quot.sound`。
- 没有改变 alpha 数值界；一般非二进制尖锐下界和完整主定理仍未完成。
- 无新颖性或首次形式化主张，本轮未做新的全面文献检索。按用户既有授权发布原公开仓库。

## 2026-09-30：总空缺预算快照公开核验

- 固定提交：[3182c9b1d2b4e3f1ab2a98a64cfaabba2d72cda7](https://github.com/jerrylijize1224-star/jsp404-lean-partial/commit/3182c9b1d2b4e3f1ab2a98a64cfaabba2d72cda7)。
- 新包：`jsp404-deficit-obstruction-20260930.zip`，119 个文件，268382 字节。
- SHA-256：`98fa7d896e55cbeaf9385c593bc8d909344b3d211bdb08a75305c1d6b8237ef9`。
- 固定公开提交中的 ZIP 已下载，并与本地通过 2599 项构建和 366 项公理审计的封存包逐字节核验一致。
- 已保留旧快照，新 ZIP 未重写；未向奖项仓库提交完整解答或奖金申请。

## 2026-10-04：九点与十点精确值（封包前）

- alpha 9 = alpha 10 = 5π/7 及对应完整 IsSharpBound 已验证。
- 九点下界和几何转移来自 zilan520 的 PR #100，固定提交 d869ab901722fab0b2d980b38b7bd958cf52c128；59 个未改写模块逐文件锁定 SHA-256，并在本地以 --trust=0 重新编译。
- 本项目的连接使用自己的原始点集目标与既有上界；不声称独立生成证书、数学新发现或首次形式化。
- 完整构建通过（2768 项含依赖）；373 项公理检查全部通过。新增五个本地定理及两个外部入口定理实际依赖仅为 propext、Classical.choice、Quot.sound。
- 快照包含来源锁、准备/顺序构建脚本及 59 份本地模块日志，不包含第三方源码或预编译文件。不声称已在全新机器复现，也未运行 Nanoda。
- 精确值已覆盖 3–10 点及所有 2ᵏ 点（k≥2）。11–15 点仍是本地缺口，17 点上下界不变，完整 SendovClaim 未证明。
- 按用户既有授权上传原公开仓库，保留旧快照；固定公开提交与字节核验另行记录。

## 2026-10-04：九点与十点精确值已公开核验

- 固定提交：[f5af83dfc6d68846f2a967389435f15a98f1f3d0](https://github.com/jerrylijize1224-star/jsp404-lean-partial/commit/f5af83dfc6d68846f2a967389435f15a98f1f3d0)。
- 新包：`jsp404-nine-ten-exact-20261004.zip`，183 个文件，323967 字节。
- SHA-256：`da99e8c6ff84b728b30e010f8f2664ee6b04bc69ae28b26534f699c6fba9ccd4`。
- 固定公开提交的 ZIP 已回下载，与通过完整构建和 373 项公理审计的本地封包逐字节相同。包内全部清单哈希也已核对。
- 保留全部旧快照；新封包没有重写。发布说明明确引用 zilan520 的九点下界证书，不作完整解答或首次形式化声明。

## 2026-10-05：奇数指数减一点精确值（封包前）

- 新增本地奇偶性证明：奇数 k≥3 时 alpha(2ᵏ−1)=(1−1/k)π，且为完整 IsSharpBound。
- 具体 alpha 31=144°、alpha 127=1080/7°。这些是经典数学结论，不声称新发现或首次形式化。
- 奇偶性结果的递归导入仅包含 27 个本地模块及 mathlib，不包含九点、十一点外部证书。
- 同轮独立完成注明来源的 PR #647 证书整合，证明本项目原始定义下 11–16 点精确值 135°；所选 368 个外部模块以 --trust=0 逐个重新编译，未修改其字节，来源与每文件哈希均锁定。
- 完整构建通过（3140 项含依赖），397 项公理检查全部通过，仅使用标准三项 Lean 基础。
- 未使用证明占位、新公理或 native_decide；未改变主目标。完整分类和 17 点尖锐值仍未证明。
- 保留旧快照，按用户既有授权上传个人仓库；本记录在封包前写入，固定公开提交与下载核验另行追加。

## 2026-10-05：奇数指数减一点快照公开核验

- 固定提交：[e90b674f468802aa70efea9b3f02f68f26835ad1](https://github.com/jerrylijize1224-star/jsp404-lean-partial/commit/e90b674f468802aa70efea9b3f02f68f26835ad1)。
- 新包：`jsp404-odd-near-dyadic-20261005.zip`，559 个文件，881349 字节。
- SHA-256：`d7d23da4e50e8fb01b55c294fbdd17b4e46ff88f7844fbd14fbec81fa3fa4a74`。
- 固定公开提交中的 ZIP 已下载，和通过 3140 项构建及 397 项公理检查的本地封包逐字节相同；全部包内清单哈希也已核验。
- 旧快照保留，新封包未改写。未向奖项仓库提交完整解答或奖金申请。

## 2026-10-05：所有二进制点数减一（封包前）

- 已去除上一阶段的奇数指数限制：所有 k≥3 时 alpha(2ᵏ−1)=(1−1/k)π，并有完整 IsSharpBound。
- 新增具体精确值 alpha 63=150°、alpha 255=157.5°；经典数学结论，不作数学新发现或首次形式化声明。
- 新增短旋转证明依赖闭包为 28 个本地模块及 mathlib，不导入九点、十一点外部证书。
- 完整构建成功（3142 项含依赖），随后 412 项公理检查全部通过。所有新增定理都列入审计，依赖仅为 propext、Classical.choice、Quot.sound。
- 原始普通有限点集定义、IsSharpBound 及 SendovClaim 未改写；完整分类与 17 点精确值仍未证明。
- 按用户既有授权上传个人仓库，保留旧快照。此记录在封包前写入，固定公开提交和字节核验另行记录。

## 2026-10-05：全部二进制点数减一快照公开核验

- 固定提交：[23c6b07887bc8d6fc59c8f4e568e943bfdd06890](https://github.com/jerrylijize1224-star/jsp404-lean-partial/commit/23c6b07887bc8d6fc59c8f4e568e943bfdd06890)。
- 新包：`jsp404-all-near-dyadic-20261005.zip`，562 个文件，889896 字节。
- SHA-256：`c27e2c3a333afbba8a3e17da308e08e3f0fc520fa98e1afdc92647ccb36bdad6`。
- 固定公开提交的 ZIP 已回下载，与通过完整构建及 412 项公理检查的本地封包逐字节一致。561 项包内清单哈希及 ZIP CRC 已核对。
- 旧快照保留，新封包未改写。公开说明明确给出 63/255 点精确值、所有 k≥3 的一般族，以及整题和 17 点仍未完成的边界。

## 2026-10-07：26 扇区提高 17 点下界（封包前）

- 新增原始点集结论：N≥17 时 GuaranteedAngle N (10π/13)，且 alpha N≥(10/13)π。
- 17 点区间由约 [135.328467°,140°] 收紧为 [138.461538°,140°]；精确剩余间隔 20/13°。
- 任意点集适用，没有增加凸性或一般位置假设；17 点精确值与完整 SendovClaim 仍未证明。
- 覆盖证书穷尽 156 个扇区类型；两族各至多容纳 8 个相容类型。检查器可靠性、类型覆盖、取整边界、复平面到原题转移全部经过 Lean 核验。
- 八个新增模块的 46 个定理全部审计；完整构建通过（3150 项含依赖），随后 458 项公理检查成功，其中一项无公理，其余依赖均包含于 propext、Classical.choice、Quot.sound。
- Python 只用于发现和导出有限数据，具体 Lean 检查使用内核归约，不使用 native_decide。
- 新证明依赖闭包为 33 个本地模块及 mathlib，不导入九点或十一点证书。完整项目保留其他注明来源的整合结果。
- 无数学新颖性、优先权、全新机器复现或外部独立审查声明。
- 按用户已有授权上传个人仓库，保留旧快照。本记录在封包前写入，固定提交与公开字节核验随后追加。

## 2026-10-07：26 扇区下界快照公开核验

- 固定提交：[739b3b6312baf45b75c9029d1e437a38e3491351](https://github.com/jerrylijize1224-star/jsp404-lean-partial/commit/739b3b6312baf45b75c9029d1e437a38e3491351)。
- 新包：`jsp404-sector26-lower-20261007.zip`，586 个文件，977694 字节。
- SHA-256：`fb18a12d8e4af78b08e948e362af2461cba5bd44ed934b940130cd4df531826e`。
- 固定公开提交中的 ZIP 已回下载，与通过 3150 项完整构建及 458 项公理审计的本地封包逐字节相同。585 项清单哈希及 ZIP CRC 全部核对。
- 保留旧快照，新封包未改写。公开说明明确给出 17 点新下界 10π/13、剩余间隔 20/13°，且没有声称精确值或整题完成。
- 发布截图保存于本地 `releases/publish/sector26-lower-published.jpg`；本条发布后记录没有倒填进已封存归档。

## 2026-10-14：44 扇区进一步提高 17 点下界（封包前）

- 已证明 N≥17 时 GuaranteedAngle N (17π/22)，且 alpha N≥(17/22)π。17 点下界为 1530/11°≈139.090909°，与上界 140° 相差 10/11°。
- 新增支配约简的通用可靠性证明，压缩 572 类型的有限证书；约简、覆盖、容量与原题几何转移全部由 Lean 核验，没有额外几何假设。
- 完整构建通过（3183 项含依赖），随后 540 项公理审计通过，包含新增 82 个定理。两项无公理，其余只依赖标准 Lean 基础的子集。
- 新下界的导入闭包为 60 个本地模块和 mathlib，不导入九点、十一点外部有限证书；完整项目仍保留其他注明来源的结果。
- 17 点精确值和完整 SendovClaim 仍未证明。本轮未进行新的外部优先权检索，不作首次或新颖性声明。
- 按用户已有授权上传个人仓库并保留旧快照。固定提交与公开字节核验在发布后另行记录。

### 2026-10-14 发布完成与下载核验

- 固定提交：[9e15220194b61549ff465010119132ba7ebc23c5](https://github.com/jerrylijize1224-star/jsp404-lean-partial/commit/9e15220194b61549ff465010119132ba7ebc23c5)。上传 README、证明归档及 SHA-256 文件，保留之前的快照。
- 归档：`jsp404-sector44-lower-20261014.zip`，625 个文件，1384178 字节。
- SHA-256：`d215bffce6511661d307fbc0cce929985f906a01f8bcaef14d8972ba167b4ed5`。
- 从固定提交重新下载公开归档，与本地封存文件逐字节相同；ZIP CRC 和 624 项清单哈希全部通过。
- 本地完整构建 3183 项成功，540 项公理审计通过；新增 82 个定理全部包含在审计中。上下界为 139.090909…°≤alpha 17≤140°，差 10/11°。
- 本段为封包后的发布记录，不回写已封存归档。没有独立第三方审查、新机器重建或优先权认证；精确值 140° 与完整 SendovClaim 仍未证明。

## 2026-10-21：62 扇区提高 17 点下界（封包前）

- 已证明所有 N≥17 的 GuaranteedAngle N (24π/31)，任意普通平面点集适用。
- 17 点区间为 [4320/31°, 140°]，剩余 20/31°；较前一快照的区间宽度缩小 9/31。
- 1426 类型覆盖、22 个非弧型代表、弧型容量、支配约简、准确量化和原题转移均已核验。
- 完整构建 3246 项成功，随后 2286 项公理审计成功；59 个新模块的 1746 个定理全部纳入审计。大部分是有限证书的分段核验。
- 4 项无公理依赖，其余仅依赖标准 Lean 基础的子集。新下界闭包为 87 个本地模块及 mathlib，不导入九点、十一点外部证书。
- 精确 140° 和完整 SendovClaim 仍未证明。没有新的优先权检索、独立第三方审查或新机器重建声明。
- 根据用户此前授权上传个人仓库，保留已封存旧快照。固定提交及公开字节核验在发布后另行记录。

### 2026-10-21 发布完成与下载核验

- 固定提交：[210c9c163c41a05254a1a53c6efc2116e2e4af95](https://github.com/jerrylijize1224-star/jsp404-lean-partial/commit/210c9c163c41a05254a1a53c6efc2116e2e4af95)。更新 README，新增证明归档及 SHA-256 文件，保留旧快照。
- 归档：`jsp404-sector62-lower-20261021.zip`，690 个文件，5085920 字节。
- SHA-256：`c622e2addd7bcd6fdb23cba7e5bff32a99ab3e68e9812809a3cc771ee76236e2`。
- 从固定提交重新下载公开 ZIP，与本地封存归档逐字节一致；689 项清单哈希及 ZIP CRC 全部通过。公开 README 也与本地发布文件逐字节一致。
- 完整构建 3246 项成功，2286 项公理审计成功。原题定义、Target、Lean/mathlib 锁定文件与上一封存快照逐字节一致。
- 本地发布凭证：`releases/publish/sector62-lower-published.png`。
- 本段是封包后的记录，不回写已封存归档。新结果是 24π/31 下界；精确值 140° 与完整 SendovClaim 仍未证明。

## 2026-10-21：连续三弧统一排除（封包前，尚未上传）

- 证明任意 d<7 的九组三弧模型不存在；单位为 20°，严格阈值为 140°。
- 27 个角度参数经小数部分秩压缩到 d*=188/27，再由已有 62 扇区非弧型容量 8 排除。
- 四个新模块、25 个定理及压缩定义均纳入验证：完整构建 3250 项成功，公理审计 2312 项成功。
- 新定理仅依赖标准 Lean 基础；导入闭包为 65 个本地模块及 mathlib，不依赖外部九点/十一点证书。
- 原题定义、Target、Lean/mathlib 固定文件与上一封存快照逐字节一致。
- 原题普通方向集分类、单弧统一计数与最终连接仍未完成。原题数值区间保持 139.354838709677…°≤alpha 17≤140°。
- 尚未上传本轮成果。当前工具没有浏览器上传入口，GitHub 插件尚未连接；可验证的快照先在本地封存。
- 本轮未进行新的优先权检索，不作新颖性、独立第三方审查或完整解题声明。

### 连续三弧快照已在本地封存，等待发布连接

- 归档：`jsp404-three-arc-exclusion-20261021.zip`，700 个文件，5111748 字节；ZIP CRC 检查通过。
- SHA-256：`0fb64354856bad5a710971e417eeefcf2d3c3dbc447061fad414181af249b638`。
- 上传所需 README、归档、校验文件与提交说明均已准备，尚未上传；没有新公开提交号。
- 已提供 GitHub 插件入口；最后确认状态为未安装，须用户完成安装/连接后才能使用。
- 本段为封包后的本地记录，不改写封存归档。旧公开提交 210c9c1 仍对应此前的 62 扇区下界。


## 2026-10-22: continuous three-arc snapshot published

Published via the authenticated GitHub web upload interface after the connected GitHub integration rejected create-blob with HTTP 403 (Resource not accessible by integration). Account identity was confirmed as jerrylijize1224-star.

- Commit: [0119e3e5c34c13212182a77d3a5919055aad7ad4](https://github.com/jerrylijize1224-star/jsp404-lean-partial/commit/0119e3e5c34c13212182a77d3a5919055aad7ad4).
- Uploaded README.md, jsp404-three-arc-exclusion-20261021.zip and its .sha256 sidecar.
- Sealed archive: 5,111,748 bytes; SHA-256 0fb64354856bad5a710971e417eeefcf2d3c3dbc447061fad414181af249b638.
- API tree verification: all three blob SHA-1 values and sizes exactly matched the local bytes. All earlier files except the intentionally updated README retain their previous blob IDs. A direct raw download using Node fetch failed; no downloaded-byte comparison is claimed for this publication.
- Visible commit page confirms title, scope, and three changed files. Screenshot: releases/publish/three-arc-exclusion-published.png.
- This is the continuous-model exclusion only; the ordinary 17-point interval remains [4320/31, 140] degrees. Exact 140 degrees and full SendovClaim are still unproved.
- This post-publication note does not modify the sealed ZIP.


## 2026-10-22: exact 17–20-point snapshot prepared locally

The original planar 140-degree value and full sharpness for 17 through 20 points
have passed the full 3254-job build and 2338-declaration axiom audit. All 26 new
theorems are checked; the final declarations use only the three allowed standard
foundations. Original definitions and dependency pins are unchanged.
The new sealed snapshot is prepared as `jsp404-seventeen-twenty-exact-20261022`.
At this pre-seal stage it has not yet been uploaded; publication must be verified
at a new fixed commit. The complete arbitrary-cardinality SendovClaim is still
unproved. Earlier sealed archives remain unchanged.


## 2026-10-22: exact 17–20-point snapshot published

- Fixed commit: [fbac2c5d66b80de9ad55fb47b36e8c19c9958eac](https://github.com/jerrylijize1224-star/jsp404-lean-partial/commit/fbac2c5d66b80de9ad55fb47b36e8c19c9958eac).
- Uploaded README.md, jsp404-seventeen-twenty-exact-20261022.zip, and its SHA-256 sidecar.
- Archive: 705 files, 5,110,556 bytes; SHA-256 0d949be263134859b041c0ec1fdea57c744f0830a05adde65c547fda3c6f415a.
- Verification: all three Git blob identifiers and byte sizes match local files; all earlier snapshot blobs remain unchanged. Visible commit page confirms scope and three changed files. Screenshot: releases/publish/seventeen-twenty-exact-published.png.
- Exact original-plane values and full sharpness for N=17–20 are verified, with 3254 build jobs and 2338 axiom checks. Full SendovClaim remains unproved.
- This post-publication record does not alter the sealed ZIP. Subsequent 144-degree exploratory work is outside this snapshot.


## 2026-10-23: triangle-constraint snapshot prepared locally

The new triangle direction interface and fixed rows 7,9,10 exclusion passed
the complete 3256-job build and 2357-declaration axiom audit, including all
19 new theorems. No solver output is trusted by the Lean proofs.
This snapshot is named `jsp404-triangle-obstruction-20261023`. At this pre-seal
stage it is not yet uploaded. The original targets, dependency pins, and prior
sealed ZIPs are unchanged. For N=21 through 30 the proved interval stays
[140,144] degrees; the variable 9+12 arc search timed out, and no general
144-degree lower bound or full SendovClaim is claimed.
