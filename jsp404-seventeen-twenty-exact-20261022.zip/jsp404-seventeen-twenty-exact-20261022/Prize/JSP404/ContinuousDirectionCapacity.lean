import Prize.JSP404.ContinuousDirectionClassification
import Prize.JSP404.ContinuousOneArc
import Prize.JSP404.ThreeArcExclusion
import Mathlib.Data.Fintype.EquivFin

/-! Capacity sixteen for antipodally consistent continuous direction covers.
This module combines the geometric classification with both family bounds. -/

namespace Prize.JSP404.ContinuousDirection

def ThreeArcRow.start {d : ℝ} (R : ThreeArcRow d) (k : Fin 3) : ℝ :=
  if k = 0 then R.a else if k = 1 then R.b else R.c

theorem ThreeArcRow.mem_start {d : ℝ} (R : ThreeArcRow d) {x : ℝ} (hx : R.Mem x) :
    ∃ k : Fin 3, R.start k ≤ x ∧
      x ≤ R.start (ContinuousThreeArc.previous k) + d - ContinuousThreeArc.periodOffset k := by
  rcases hx with hx | hx | hx
  · exact ⟨0, by simpa [start, ContinuousThreeArc.previous, ContinuousThreeArc.periodOffset] using hx⟩
  · exact ⟨1, by simpa [start, ContinuousThreeArc.previous, ContinuousThreeArc.periodOffset] using hx⟩
  · exact ⟨2, by simpa [start, ContinuousThreeArc.previous, ContinuousThreeArc.periodOffset] using hx⟩

theorem one_arc_family_bound {n : ℕ} {d : ℝ} (hd0 : 0 ≤ d) (hd : d < 7)
    (a : Fin n → ℝ)
    (hpair : ∀ i j, i ≠ j → ∃ x y : ℝ, ∃ z : ℤ,
      (a i ≤ x ∧ x ≤ a i + d) ∧ (a j ≤ y ∧ y ≤ a j + d) ∧ y = x + 9 + 18 * z) :
    n ≤ 8 := by
  let M : ContinuousOneArc.Model n d := {
    start := a
    nonneg := hd0
    overlap := by
      intro i j hij
      obtain ⟨x, y, z, hx, hy, he⟩ := hpair i j hij
      refine ⟨-z - 1, ?_, ?_⟩ <;> push_cast <;> linarith [hx.1, hx.2, hy.1, hy.2] }
  exact M.card_le_eight hd

theorem three_arc_family_bound {n : ℕ} {d : ℝ} (hd : d < 7)
    (R : Fin n → ThreeArcRow d)
    (hpair : ∀ i j, i ≠ j → ∃ x y : ℝ, ∃ z : ℤ,
      (R i).Mem x ∧ (R j).Mem y ∧ y = x + 9 + 18 * z) : n ≤ 8 := by
  by_contra hn
  have h9 : 9 ≤ n := by omega
  let e : Fin 9 → Fin n := Fin.castLE h9
  have hei : Function.Injective e := by
    intro i j h
    have hv := congrArg (fun v : Fin n => v.val) h
    exact Fin.ext hv
  let M : ContinuousThreeArc.Model 9 d := {
    start := fun p => (R (e p.1)).start p.2
    order01 := by intro i; simpa [ThreeArcRow.start] using (R (e i)).ab
    order12 := by intro i; simpa [ThreeArcRow.start] using (R (e i)).bc
    period := by intro i; simpa [ThreeArcRow.start] using (R (e i)).ca
    width := by
      intro i k
      fin_cases k
      · simpa [ThreeArcRow.start, ContinuousThreeArc.previous, ContinuousThreeArc.periodOffset] using (R (e i)).width0
      · simpa [ThreeArcRow.start, ContinuousThreeArc.previous, ContinuousThreeArc.periodOffset] using (R (e i)).width1
      · simpa [ThreeArcRow.start, ContinuousThreeArc.previous, ContinuousThreeArc.periodOffset] using (R (e i)).width2
    overlap := by
      intro i j hij
      obtain ⟨x, y, z, hx, hy, he⟩ := hpair (e i) (e j) (hei.ne hij)
      obtain ⟨k, hk⟩ := (R (e i)).mem_start hx
      obtain ⟨l, hl⟩ := (R (e j)).mem_start hy
      refine ⟨k, l, -z - 1, ?_, ?_⟩ <;> push_cast <;> linarith [hk.1, hk.2, hl.1, hl.2] }
  exact ContinuousThreeArc.no_nine_model_below_seven hd ⟨M⟩

abbrev Cover (d : ℝ) := ℝ ⊕ ThreeArcRow d

def Cover.Mem {d : ℝ} (C : Cover d) (x : ℝ) : Prop :=
  match C with
  | .inl a => a ≤ x ∧ x ≤ a + d
  | .inr R => R.Mem x

theorem card_le_sixteen_of_covers {V : Type*} [Fintype V] {d : ℝ}
    (hd0 : 0 ≤ d) (hd : d < 7) (C : V → Cover d)
    (hpair : ∀ i j, i ≠ j → ∃ x y : ℝ, ∃ z : ℤ,
      (C i).Mem x ∧ (C j).Mem y ∧ y = x + 9 + 18 * z) : Fintype.card V ≤ 16 := by
  classical
  let P (v : V) := ∃ a, C v = Sum.inl a
  let s0 := Finset.univ.filter P
  let s1 := Finset.univ.filter (fun v => ¬ P v)
  let e0 (i : Fin s0.card) : V := (s0.equivFin.symm i).val
  let e1 (i : Fin s1.card) : V := (s1.equivFin.symm i).val
  have hi0 : Function.Injective e0 := by
    intro i j h; apply s0.equivFin.symm.injective; exact Subtype.ext h
  have hi1 : Function.Injective e1 := by
    intro i j h; apply s1.equivFin.symm.injective; exact Subtype.ext h
  have hex0 (i : Fin s0.card) : ∃ a, C (e0 i) = Sum.inl a :=
    (Finset.mem_filter.mp (s0.equivFin.symm i).property).2
  have hex1 (i : Fin s1.card) : ∃ R, C (e1 i) = Sum.inr R := by
    have hp : ¬ P (e1 i) := (Finset.mem_filter.mp (s1.equivFin.symm i).property).2
    cases he : C (e1 i) with
    | inl a => exact (hp ⟨a, he⟩).elim
    | inr R => exact ⟨R, rfl⟩
  let a (i : Fin s0.card) := Classical.choose (hex0 i)
  let R (i : Fin s1.card) := Classical.choose (hex1 i)
  have h0 : s0.card ≤ 8 := by
    apply one_arc_family_bound hd0 hd a
    intro i j hij
    obtain ⟨x, y, z, hx, hy, he⟩ := hpair (e0 i) (e0 j) (hi0.ne hij)
    rw [Classical.choose_spec (hex0 i)] at hx
    rw [Classical.choose_spec (hex0 j)] at hy
    exact ⟨x, y, z, hx, hy, he⟩
  have h1 : s1.card ≤ 8 := by
    apply three_arc_family_bound hd R
    intro i j hij
    obtain ⟨x, y, z, hx, hy, he⟩ := hpair (e1 i) (e1 j) (hi1.ne hij)
    rw [Classical.choose_spec (hex1 i)] at hx
    rw [Classical.choose_spec (hex1 j)] at hy
    exact ⟨x, y, z, hx, hy, he⟩
  have hc := Finset.card_filter_add_card_filter_not (s := (Finset.univ : Finset V)) P
  change s0.card + s1.card = Fintype.card V at hc
  omega

/-- Continuous antipodal direction assignments of diameter at most `d < 7`
have at most sixteen vertices. No geometric classification is assumed here. -/
theorem card_le_sixteen_of_assignment {V : Type*} [Fintype V] {d : ℝ}
    (hd0 : 6 ≤ d) (hd : d < 7) (q : V → V → ℝ)
    (hrev : ∀ u v, u ≠ v → ∃ z : ℤ, q v u = q u v + 9 + 18 * z)
    (hsmall : ∀ v u w, v ≠ u → v ≠ w → Close d (q v u) (q v w)) :
    Fintype.card V ≤ 16 := by
  classical
  let outgoing (v : V) := (Finset.univ.erase v).image (q v)
  have hc (v : V) : OneArcCover d (outgoing v) ∨ ThreeArcCover d (outgoing v) := by
    apply classification _ hd0 hd
    intro x hx y hy
    obtain ⟨u, hu, rfl⟩ := Finset.mem_image.mp hx
    obtain ⟨w, hw, rfl⟩ := Finset.mem_image.mp hy
    exact hsmall v u w (Finset.mem_erase.mp hu).1.symm (Finset.mem_erase.mp hw).1.symm
  have hex (v : V) : ∃ C : Cover d, ∀ w, v ≠ w → ∃ z : ℤ, C.Mem (q v w + 18 * z) := by
    rcases hc v with ⟨a, ha⟩ | ⟨R, hR⟩
    · refine ⟨Sum.inl a, ?_⟩
      intro w hvw
      exact ha _ (Finset.mem_image.mpr ⟨w, by simp [hvw.symm], rfl⟩)
    · refine ⟨Sum.inr R, ?_⟩
      intro w hvw
      exact hR _ (Finset.mem_image.mpr ⟨w, by simp [hvw.symm], rfl⟩)
  let C (v : V) := Classical.choose (hex v)
  apply card_le_sixteen_of_covers (by linarith) hd C
  intro u v huv
  obtain ⟨k, hk⟩ := Classical.choose_spec (hex u) v huv
  obtain ⟨l, hl⟩ := Classical.choose_spec (hex v) u huv.symm
  obtain ⟨z, hz⟩ := hrev u v huv
  refine ⟨q u v + 18 * k, q v u + 18 * l, z + l - k, hk, hl, ?_⟩
  push_cast
  linarith

end Prize.JSP404.ContinuousDirection
