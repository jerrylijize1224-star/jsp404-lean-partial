import Prize.JSP404.ContinuousThreeArcModel
import Mathlib.Data.Finset.Max

/-!
# Finite direction sets: continuous one-arc / three-arc classification

Angles are measured on a circle of period 18. The classification below is
about finite real direction sets and retains periodic representatives explicitly.
Connecting these covers to ordinary planar configurations is a separate step.
-/

namespace Prize.JSP404.ContinuousDirection

def Close (d x y : ℝ) : Prop := ∃ z : ℤ, |x - y + 18 * z| ≤ d

def OneArcCover (d : ℝ) (s : Finset ℝ) : Prop :=
  ∃ a : ℝ, ∀ x ∈ s, ∃ z : ℤ, a ≤ x + 18 * z ∧ x + 18 * z ≤ a + d

structure ThreeArcRow (d : ℝ) where
  a : ℝ
  b : ℝ
  c : ℝ
  ab : a < b
  bc : b < c
  ca : c < a + 18
  width0 : a ≤ c + d - 18
  width1 : b ≤ a + d
  width2 : c ≤ b + d

def ThreeArcRow.Mem {d : ℝ} (R : ThreeArcRow d) (x : ℝ) : Prop :=
  (R.a ≤ x ∧ x ≤ R.c + d - 18) ∨
  (R.b ≤ x ∧ x ≤ R.a + d) ∨ (R.c ≤ x ∧ x ≤ R.b + d)

def ThreeArcCover (d : ℝ) (s : Finset ℝ) : Prop :=
  ∃ R : ThreeArcRow d, ∀ x ∈ s, ∃ z : ℤ, R.Mem (x + 18 * z)

theorem close_cases {d x y : ℝ} (h : Close d x y) :
    (x - y ≤ d ∧ y - x ≤ d) ∨ 18 - d ≤ x - y ∨ 18 - d ≤ y - x := by
  obtain ⟨z, hz⟩ := h
  have ha := abs_le.mp hz
  by_cases he : z = 0
  · subst z; norm_num at ha; left; constructor <;> linarith
  · by_cases hp : 0 < z
    · have hp' : (1 : ℝ) ≤ z := by exact_mod_cast (show 1 ≤ z by omega)
      right; right; linarith
    · have hn' : (z : ℝ) ≤ -1 := by exact_mod_cast (show z ≤ -1 by omega)
      right; left; linarith

theorem close_translate {d x y : ℝ} (h : Close d x y) (k l : ℤ) :
    Close d (x + 18 * k) (y + 18 * l) := by
  obtain ⟨z, hz⟩ := h
  refine ⟨z - k + l, ?_⟩
  have he : x + 18 * k - (y + 18 * l) + 18 * ((z - k + l : ℤ) : ℝ) =
      x - y + 18 * z := by push_cast; ring
  rwa [he]

theorem forward_close {d x y : ℝ} (hd : d < 18) (h : Close d x y)
    (hlo : 0 ≤ y - x) (hhi : y - x < 18 - d) : y - x ≤ d := by
  rcases close_cases h with h | h | h
  · exact h.2
  · linarith
  · linarith

/-- Three compatible anchors divide all other directions into three narrow
regions, with the region across zero lifted by minus one period. -/
theorem anchor_regions {d b c x : ℝ} (_hd0 : 6 ≤ d) (hd : d < 7)
    (_hb : 0 ≤ b) (hbd : b ≤ d) (hc : 18 - d ≤ c) (_hcd : c - b ≤ d)
    (hx0 : 0 ≤ x) (hx18 : x < 18)
    (h0 : Close d x 0) (hB : Close d x b) (hC : Close d x c) :
    (b - d ≤ x ∧ x ≤ c + d - 18) ∨
    (c - d ≤ x ∧ x ≤ d) ∨
    (18 - d ≤ x ∧ x ≤ b + d) ∨
    (b - d ≤ x - 18 ∧ x - 18 ≤ c + d - 18) := by
  rcases close_cases h0 with h0 | h0 | h0
  · rcases close_cases hC with hC | hC | hC
    · right; left; constructor <;> linarith
    · exfalso; linarith
    · left; constructor <;> linarith
  · rcases close_cases hB with hB | hB | hB
    · right; right; left; constructor <;> linarith
    · right; right; right; constructor <;> linarith
    · exfalso; linarith
  · exfalso; linarith

/-- A finite set with three non-single-arc anchors admits the exact three-arc
cover, obtained by taking the least direction in each lifted region. -/
theorem three_arc_of_anchors (s : Finset ℝ) {d b c : ℝ}
    (hd0 : 6 ≤ d) (hd : d < 7)
    (h0 : 0 ∈ s) (hbmem : b ∈ s) (hcmem : c ∈ s)
    (hb : 0 ≤ b) (hbd : b ≤ d) (hc : 18 - d ≤ c) (hcd : c - b ≤ d)
    (hs : ∀ x ∈ s, 0 ≤ x ∧ x < 18)
    (hclose : ∀ x ∈ s, ∀ y ∈ s, Close d x y) : ThreeArcCover d s := by
  classical
  let t := s ∪ s.image (fun x => x - 18)
  let t0 := t.filter (fun x => b - d ≤ x ∧ x ≤ c + d - 18)
  let t1 := t.filter (fun x => c - d ≤ x ∧ x ≤ d)
  let t2 := t.filter (fun x => 18 - d ≤ x ∧ x ≤ b + d)
  have ht (x : ℝ) (hx : x ∈ t) : ∃ y ∈ s, ∃ k : ℤ, x = y + 18 * k := by
    rcases Finset.mem_union.mp hx with hx | hx
    · exact ⟨x, hx, 0, by simp⟩
    · obtain ⟨y, hy, rfl⟩ := Finset.mem_image.mp hx
      exact ⟨y, hy, -1, by norm_num; ring⟩
  have htc (x : ℝ) (hx : x ∈ t) (y : ℝ) (hy : y ∈ t) : Close d x y := by
    obtain ⟨u, hu, k, rfl⟩ := ht x hx
    obtain ⟨v, hv, l, rfl⟩ := ht y hy
    exact close_translate (hclose u hu v hv) k l
  have hne0 : t0.Nonempty := ⟨0, Finset.mem_filter.mpr
    ⟨Finset.mem_union_left _ h0, by constructor <;> linarith⟩⟩
  have hne1 : t1.Nonempty := ⟨b, Finset.mem_filter.mpr
    ⟨Finset.mem_union_left _ hbmem, by constructor <;> linarith⟩⟩
  have hne2 : t2.Nonempty := ⟨c, Finset.mem_filter.mpr
    ⟨Finset.mem_union_left _ hcmem, by constructor <;> linarith⟩⟩
  let a0 := t0.min' hne0
  let a1 := t1.min' hne1
  let a2 := t2.min' hne2
  have ha0 := Finset.mem_filter.mp (Finset.min'_mem t0 hne0)
  have ha1 := Finset.mem_filter.mp (Finset.min'_mem t1 hne1)
  have ha2 := Finset.mem_filter.mp (Finset.min'_mem t2 hne2)
  change a0 ∈ t ∧ (b - d ≤ a0 ∧ a0 ≤ c + d - 18) at ha0
  change a1 ∈ t ∧ (c - d ≤ a1 ∧ a1 ≤ d) at ha1
  change a2 ∈ t ∧ (18 - d ≤ a2 ∧ a2 ≤ b + d) at ha2
  have h01 (x : ℝ) (hx : x ∈ t0) (y : ℝ) (hy : y ∈ t1) : y - x ≤ d := by
    obtain ⟨hxt, hx⟩ := Finset.mem_filter.mp hx
    obtain ⟨hyt, hy⟩ := Finset.mem_filter.mp hy
    exact forward_close (by linarith) (htc x hxt y hyt) (by linarith) (by linarith)
  have h12 (x : ℝ) (hx : x ∈ t1) (y : ℝ) (hy : y ∈ t2) : y - x ≤ d := by
    obtain ⟨hxt, hx⟩ := Finset.mem_filter.mp hx
    obtain ⟨hyt, hy⟩ := Finset.mem_filter.mp hy
    exact forward_close (by linarith) (htc x hxt y hyt) (by linarith) (by linarith)
  have h20 (x : ℝ) (hx : x ∈ t2) (y : ℝ) (hy : y ∈ t0) : y + 18 - x ≤ d := by
    obtain ⟨hxt, hx⟩ := Finset.mem_filter.mp hx
    obtain ⟨hyt, hy⟩ := Finset.mem_filter.mp hy
    have hxy : Close d x (y + 18) := by
      simpa using close_translate (htc x hxt y hyt) 0 1
    exact forward_close (by linarith) hxy (by linarith) (by linarith)
  have hm0 : a0 ∈ t0 := Finset.min'_mem _ _
  have hm1 : a1 ∈ t1 := Finset.min'_mem _ _
  have hm2 : a2 ∈ t2 := Finset.min'_mem _ _
  let R : ThreeArcRow d := {
    a := a0, b := a1, c := a2
    ab := by linarith [ha0.2.2, ha1.2.1]
    bc := by linarith [ha1.2.2, ha2.2.1]
    ca := by linarith [ha2.2.2, ha0.2.1]
    width0 := by linarith [h20 a2 hm2 a0 hm0]
    width1 := by linarith [h01 a0 hm0 a1 hm1]
    width2 := by linarith [h12 a1 hm1 a2 hm2] }
  have hcover (x : ℝ) (hx : x ∈ t0 ∨ x ∈ t1 ∨ x ∈ t2) : R.Mem x := by
    rcases hx with hx | hx | hx
    · left
      exact ⟨Finset.min'_le _ _ hx, by dsimp [R]; linarith [h20 a2 hm2 x hx]⟩
    · right; left
      exact ⟨Finset.min'_le _ _ hx, by dsimp [R]; linarith [h01 a0 hm0 x hx]⟩
    · right; right
      exact ⟨Finset.min'_le _ _ hx, by dsimp [R]; linarith [h12 a1 hm1 x hx]⟩
  refine ⟨R, ?_⟩
  intro x hx
  have hxt : x ∈ t := Finset.mem_union_left _ hx
  have hxt' : x - 18 ∈ t := Finset.mem_union_right _ (Finset.mem_image.mpr ⟨x, hx, rfl⟩)
  rcases anchor_regions hd0 hd hb hbd hc hcd (hs x hx).1 (hs x hx).2
    (hclose x hx 0 h0) (hclose x hx b hbmem) (hclose x hx c hcmem) with h | h | h | h
  · exact ⟨0, by simpa using hcover x (Or.inl (Finset.mem_filter.mpr ⟨hxt, h⟩))⟩
  · exact ⟨0, by simpa using hcover x (Or.inr (Or.inl (Finset.mem_filter.mpr ⟨hxt, h⟩)))⟩
  · exact ⟨0, by simpa using hcover x (Or.inr (Or.inr (Finset.mem_filter.mpr ⟨hxt, h⟩)))⟩
  · refine ⟨-1, ?_⟩
    simpa [sub_eq_add_neg] using hcover (x - 18) (Or.inl (Finset.mem_filter.mpr ⟨hxt', h⟩))

/-- Complete classification for a normalized finite direction set. There is
no general-position or nondegeneracy assumption on the set. -/
theorem normalized_classification (s : Finset ℝ) {d : ℝ}
    (hd0 : 6 ≤ d) (hd : d < 7) (h0 : 0 ∈ s)
    (hs : ∀ x ∈ s, 0 ≤ x ∧ x < 18)
    (hclose : ∀ x ∈ s, ∀ y ∈ s, Close d x y) :
    OneArcCover d s ∨ ThreeArcCover d s := by
  classical
  have hsplit (x : ℝ) (hx : x ∈ s) : x ≤ d ∨ 18 - d ≤ x := by
    rcases close_cases (hclose x hx 0 h0) with h | h | h
    · left; linarith
    · right; linarith
    · have := (hs x hx).1; exfalso; linarith
  let lo := s.filter (fun x => x ≤ d)
  let hi := s.filter (fun x => 18 - d ≤ x)
  have hlo : lo.Nonempty := ⟨0, Finset.mem_filter.mpr ⟨h0, by linarith⟩⟩
  by_cases hhi : hi.Nonempty
  · let b := lo.max' hlo
    let c := hi.min' hhi
    have hb := Finset.mem_filter.mp (Finset.max'_mem lo hlo)
    have hc := Finset.mem_filter.mp (Finset.min'_mem hi hhi)
    change b ∈ s ∧ b ≤ d at hb
    change c ∈ s ∧ 18 - d ≤ c at hc
    have hb0 := (hs b hb.1).1
    have hc18 := (hs c hc.1).2
    by_cases hwrap : 18 - c + b ≤ d
    · left; refine ⟨c, ?_⟩
      intro x hx
      rcases hsplit x hx with hl | hh
      · have hxb : x ≤ b := Finset.le_max' lo x (Finset.mem_filter.mpr ⟨hx, hl⟩)
        refine ⟨1, ?_, ?_⟩ <;> norm_num
        · linarith [(hs x hx).1]
        · linarith
      · have hcx : c ≤ x := Finset.min'_le hi x (Finset.mem_filter.mpr ⟨hx, hh⟩)
        refine ⟨0, ?_, ?_⟩ <;> norm_num
        · exact hcx
        · linarith [(hs x hx).2]
    · have hcb : c - b ≤ d := by
        rcases close_cases (hclose b hb.1 c hc.1) with h | h | h
        · exact h.2
        · linarith [hb.2, hc.2]
        · linarith
      right
      exact three_arc_of_anchors s hd0 hd h0 hb.1 hc.1 hb0 hb.2 hc.2 hcb hs hclose
  · left; refine ⟨0, ?_⟩
    intro x hx
    have hxd : x ≤ d := (hsplit x hx).resolve_right (fun hh =>
      hhi ⟨x, Finset.mem_filter.mpr ⟨hx, hh⟩⟩)
    exact ⟨0, by simpa using (hs x hx).1, by simpa using hxd⟩

/-- Every finite real direction set with the stated circular diameter has a
one-arc or three-arc cover. No choice of representatives is assumed. -/
theorem classification (s : Finset ℝ) {d : ℝ} (hd0 : 6 ≤ d) (hd : d < 7)
    (hclose : ∀ x ∈ s, ∀ y ∈ s, Close d x y) :
    OneArcCover d s ∨ ThreeArcCover d s := by
  classical
  by_cases hne : s.Nonempty
  · obtain ⟨a, ha⟩ := hne
    let q (x : ℝ) : ℤ := ⌊(x - a) / 18⌋
    let r (x : ℝ) : ℝ := x - a - 18 * q x
    let t := s.image r
    have hr (x : ℝ) : 0 ≤ r x ∧ r x < 18 := by
      have h₁ := Int.floor_le ((x - a) / 18)
      have h₂ := Int.lt_floor_add_one ((x - a) / 18)
      dsimp [r, q]
      constructor <;> linarith
    have h0 : 0 ∈ t := Finset.mem_image.mpr ⟨a, ha, by simp [r, q]⟩
    have ht (x : ℝ) (hx : x ∈ t) : 0 ≤ x ∧ x < 18 := by
      obtain ⟨y, _, rfl⟩ := Finset.mem_image.mp hx
      exact hr y
    have hct (x : ℝ) (hx : x ∈ t) (y : ℝ) (hy : y ∈ t) : Close d x y := by
      obtain ⟨u, hu, rfl⟩ := Finset.mem_image.mp hx
      obtain ⟨v, hv, rfl⟩ := Finset.mem_image.mp hy
      obtain ⟨z, hz⟩ := hclose u hu v hv
      refine ⟨z + q u - q v, ?_⟩
      have he : r u - r v + 18 * ((z + q u - q v : ℤ) : ℝ) =
          u - v + 18 * z := by dsimp [r]; push_cast; ring
      rwa [he]
    have he (x : ℝ) (z : ℤ) : x + 18 * ((z - q x : ℤ) : ℝ) =
        (r x + 18 * z) + a := by dsimp [r]; push_cast; ring
    rcases normalized_classification t hd0 hd h0 ht hct with h | h
    · obtain ⟨b, hb⟩ := h
      left; refine ⟨b + a, ?_⟩
      intro x hx
      obtain ⟨z, hlo, hhi⟩ := hb (r x) (Finset.mem_image.mpr ⟨x, hx, rfl⟩)
      refine ⟨z - q x, ?_, ?_⟩ <;> rw [he] <;> linarith
    · obtain ⟨R, hR⟩ := h
      let R' : ThreeArcRow d := {
        a := R.a + a, b := R.b + a, c := R.c + a
        ab := by linarith [R.ab]
        bc := by linarith [R.bc]
        ca := by linarith [R.ca]
        width0 := by linarith [R.width0]
        width1 := by linarith [R.width1]
        width2 := by linarith [R.width2] }
      have hshift (x : ℝ) (hx : R.Mem x) : R'.Mem (x + a) := by
        rcases hx with hx | hx | hx
        · left; dsimp [R']; constructor <;> linarith [hx.1, hx.2]
        · right; left; dsimp [R']; constructor <;> linarith [hx.1, hx.2]
        · right; right; dsimp [R']; constructor <;> linarith [hx.1, hx.2]
      right; refine ⟨R', ?_⟩
      intro x hx
      obtain ⟨z, hz⟩ := hR (r x) (Finset.mem_image.mpr ⟨x, hx, rfl⟩)
      exact ⟨z - q x, by rw [he]; exact hshift _ hz⟩
  · left; refine ⟨0, ?_⟩
    intro x hx
    exact (hne ⟨x, hx⟩).elim

end Prize.JSP404.ContinuousDirection
