# JSP-000404 当前状态

2026-09-16：用户选定 JSP-000404 / Erdős 504（Blumenthal 最大角问题）。

## 原始论文

Sendov, *Minimax of the angles in a plane configuration of points*, Acta Mathematica Hungarica 69 (1995), 27–46，DOI [10.1007/BF01874605](https://doi.org/10.1007/BF01874605)。Crossref 元数据与出版商页面一致。

2026-09-17：已从 [REAL-J 公开馆藏](https://real-j.mtak.hu/7467/) 免费取得英文原论文
第 27–46 页，核对了标题、页码及关键证明。无需购买；详见 [英文来源核对](jsp404-english-source.md)。
此前出版商 PDF 地址返回 HTML 的访问限制不再阻止阅读。
现已从 [Math-Net 官方入口](https://www.mathnet.ru/eng/fpm81) 取得作者另一篇
《Compulsory configurations of points in the plane》的 **26 页俄文全文**，
§4 包含本题公式和证明。先前 403 来自旧 PDF 链接，已通过入口取得有效链接。
没有购买、登录或联络作者。

已按页面图像核对第 514 页定理 4.4 的分段公式。当前不需要购买英文版。
俄文版将极值存在性引用到英文论文，计数引理 4.12 的归纳还需要重建。
进一步发现：s=4 子情形声称的最大值 9 与一个给出 10 的分层方向模型不符；
10 仍符合主引理上界。精确算术已由 Lean 检查，全部模型三点角已用有理数枚举；
几何实现尚未形式化，不能声称 Lean 已证明论文有误。
详见 [四中心复核](jsp404-lemma412-check.md) 和 [证明路线](jsp404-proof-map.md)。
英文版第 39–40 页沿用了相同计数归纳，没有补上该缺口；其 §5 提供了极值存在性证明。
当前需继续独立修补数学论证。

## Lean 工作范围

`Prize/JSP404/Basic.lean` 使用欧氏平面、有限点集和 mathlib 的无向角：

- 明确三点互异，允许共线，不偷偷增加一般位置假设。
- `GuaranteedAngle n a` 表达任意恰有 n 个点的集合都含有至少 a 的角。
- `alpha n` 是 [0, π] 内所有保证角的上确界。
- `IsSharpBound` 同时要求普遍下界及任意更大值的失败；`FullSolution` 是待证明目标的规格，不是定理。
- 基础证明包括集合扩大与点数增加的单调性、n≥3 时的 π/3 下界、上确界的界和单调性，以及尖锐界与上确界的连接。

`Prize/JSP404/ThreePoints.lean` 用坐标 (0,0)、(2,0)、(1,√3) 的等边三角形
证明 `threePoints_sharp`，从而得到 `alpha_three : alpha 3 = π/3`。
`Prize/JSP404/FourPoints.lean` 用凸包分割及内积论证证明任意四点含至少 π/2 的角，
再用显式正方形证明尖锐性，得到 `alpha_four : alpha 4 = π/2`。
详见 [四点精确值证明](jsp404-four-points.md)；它不是四个广义中心的容量界。
`Prize/JSP404/Target.lean` 定义 `SendovClaim : Prop`，记录核对后的完整分段答案；
它只是目标规格。

`Prize/JSP404/Counting.lean` 证明三个组合接口：

- k 个二分图覆盖所有不同顶点对，则顶点数 ≤ 2^k；不要求边不重叠。
- 以所有闭游走长度为偶数为前提的版本，通过 mathlib 连接到二染色。
- 定向关系覆盖所有顶点对，且不存在连续两条同类箭头时，同样得到 ≤ 2^k。
  该版本供扇区几何使用，但扇区满足这些前提的证明尚未完成。

`CountingCheck.lean` 只验证四中心复核中的有理数算术，独立于主定理证明。

本轮继续新增：

- `GeneralPosition.lean`：正式消除论文的无三点共线限制，证明对 a≤π 的普遍下界与原题等价。
- `Sharpness.lean`：固定有限点集的最大角、下界阈值闭合、至少 n 点反例取子集，
  以及任意精度近似足以给出尖锐值；不依赖全局最优配置实际存在。
- `SectorCapacity.lean`：相邻角度间隔合并时，局部容量不减；在明确条件下至少增加 1。
- `DirectionCover.lean`：通过实际欧氏向量夹角，将满足窄方向覆盖条件的点集连接到 ≤2^k 的计数界。
- `ThreeCentreCapacity.lean`：两中心精确容量、三中心在两个区间的容量上界，
  以及从实际欧氏三角形角度条件到这些上界的连接；另有上半区间等号角度数据。
  推导直接使用取整约束，不依赖原文的最大化序列断言。
  详见 [三中心独立证明及边界](jsp404-three-centres.md)。
- `MaximalCentres.lean`：有限间隔分组的容量界，以及任意多个中心中最大指数的数量限制。
  早期几何接口显式要求三角形约化条件；2026-09-22 已对下述有限点簇模型
  从实际循环间隔证明该条件，普通配置到模型的约化仍未完成。
  这不是任意多中心的总容量界，见 [推广的前提与缺口](jsp404-maximal-centres.md)。

主计数修补尚未完成。精确正五边形方向模型排除了最直接的容量不减删点归纳；
这并未排除移动点簇或其他归纳方式。详见 [修补尝试与接口结果](jsp404-repair-route.md)。
三中心结论还需连接广义配置的点簇大小。
四中心的凸四边形与三角形内点两类，已分别完成数值容量界及真实几何连接；
后续已补全一般四点分类接口，并建立两类容量共同的、不依赖编号的角度表达式；
后续进一步补充四中心与实际循环方向间隔的正式连接；五中心及以上尚未证明。
详见 [四中心计数修补及边界](jsp404-four-centres.md)。
分类和统一表达式见 [2026-09-18 后续证明](jsp404-four-centre-unified.md)。
实际向量、排序方向与间隔指数的连接见 [2026-09-19 后续证明](jsp404-projective-gap-connection.md)。
2026-09-20 后续增加广义方向的覆盖计数、外部方向角度排除条件、
允许闭区间的严格窄覆盖，以及给定允许间隔坐标后的实际扇区计数。
其中条件接口见 [点簇计数](jsp404-cluster-counting.md)。2026-09-21 已补全
三个实际锚点的允许坐标存在性，并将四中心容量连接到四个非空点簇的
总标签数，见 [四点簇连接](jsp404-four-cluster-link.md)。
普通配置到所需模型的约化、任意中心数的计数仍未完成。
2026-09-21 后续推广：任意有限中心数的方向坐标存在性、循环间隔及局部
点簇计数现接入同一框架；未完成的是容量和的尖锐总量界。
详见 [一般有限点簇的连接](jsp404-finite-cluster-link.md)。

2026-09-22：`FiniteGapRestriction.lean` 构造两段实际循环间隔并证明合并后的
容量不减；`FiniteMaximalCentres.lean` 据此去掉有限点簇模型中三角形约化的
额外前提。在至少三个中心、n≥2、n≤t<n+1 时，每个局部指数≤n−1；
下半区间达到 n−1 的中心至多一个，整个区间至多两个。
这些限制没有控制全部较小指数的总权重，见
[实际间隔约化与最大指数](jsp404-gap-restriction.md)。

2026-09-22 后续：`SmallAngleConvexPosition.lean` 证明在 0<t<3 时，实际
角度上界迫使点集凸独立（任何点不在其余点的凸包中）；通过 Carathéodory
定理把任意有限支撑化为至多三点，排除线段及三角形内点。
该结论也接入任意有限点簇模型的中心族。尚未证明凸多边形的中心数或
尖锐总容量界，见 [小角度下的凸位置](jsp404-small-angle-convex-position.md)。
同轮补充条件性外角预算算术，以及同侧射线坐标下局部指数等于外角容量的
接口；从凸位置构造旋转坐标、旋转不变性与外角总和的连接仍未完成。
2026-09-22 再推进：`FiniteExteriorBound.lean` 从已有三角形约化直接推出
不依赖旋转或射线符号的局部外角上界，并在显式外角预算下接通实际点簇
总点数的 4/5 界。上界路线不再需要先完成旋转；剩余几何步骤集中到从
凸独立性构造邻接关系并证明外角和。详见 [直接外角连接](jsp404-finite-exterior-bound.md)。
同轮 `PentagonExterior.lean` 从五中心三组明确的严格对角线交叉推导实际
内角和 3π、外角和 2π，从而得到该几何接口下的五簇点数界。任意凸独立
五点集的交叉标号存在性仍未证明，不能称为所有五中心情形已经完成。

没有证明 Sendov 的分段公式，也没有宣称完成任何奖题。

本轮验证：`./scripts/lake.sh build` 成功，随后
`./scripts/lake.sh env lean Prize/Audit.lean` 退出码为 0。
本轮检查的新增定理公理依赖均只有标准基础 `propext`、`Classical.choice`、`Quot.sound`，
没有使用 `sorry` 或新增数学公理。
输出见 `research/logs/jsp404-build.log` 和 `research/logs/jsp404-audit.log`；
以命令退出状态和日志为准，构建任务数包含依赖，不能理解为新增定理数。

## 2026-09-18 发布准备及重合检查

完整构建与包含四中心新增定理的公理检查均已成功；只依赖三项标准基础。
待发布的准确范围、复现步骤、来源及剩余缺口见
[阶段成果说明](jsp404-release-20260918.md)。现已发布到用户自己的
[公开仓库](https://github.com/jerrylijize1224-star/jsp404-lean-partial)，
固定提交及回下载校验见 [发布记录](jsp404-publication.md)。

公开 PR #42、#100、#300、#647 已有重合的部分形式化，不能宣称本项目的小规模
精确值是首次完成；完整源码尚未独立复核。当前拟发布重点是三、四中心的容量论证，
其新增贡献也仍需对照审查。官方最新规则不接收部分证明作为整题提交，
因此先准备独立研究仓库，不提交完成声明或奖金申请。

## 早期公开说明草稿（已被上面的阶段成果说明取代）

> I am working on a Lean 4 formalization of the known solution to Erdős Problem 504 / JSP-000404 (Blumenthal's maximum-angle problem). The project is currently at the source-review and elementary-lemma stage; no complete formalization is claimed. I would welcome pointers to existing work or coordination to avoid duplication.

可以在 Erdős 504 标记 “I am working on formalising the results on this problem”。标记有助于协调，但本次查阅未发现它授予独占、优先权或奖金保证的规则。孙奖题库的 `Claimed` 是成果申领状态，不应作为研究题目的占位按钮使用。参考[题库说明](https://github.com/TheJustinSunPrize/awards/blob/f4e7173d89dfe91022a185427d63452c8ffbf6ae/problems/README.md#reading-conventions)。
