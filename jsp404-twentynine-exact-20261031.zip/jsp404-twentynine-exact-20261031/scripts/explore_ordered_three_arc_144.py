"""Search all-three-arc ordered submodels; results are not Lean proofs.

A SAT result refutes exclusion of this relaxed class only, not the planar
21-point target. The optional support-edge normalization has no Lean bridge.
"""
import argparse, json, time
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
import z3

p=argparse.ArgumentParser()
p.add_argument('--points',type=int,default=12)
p.add_argument('--seconds',type=int,default=60)
p.add_argument('--output',type=Path,required=True)
p.add_argument('--support-edge',action='store_true')
a=p.parse_args();n=a.points
assert n>=3 and a.seconds>0
if a.output.exists():raise SystemExit('Output exists')
D=F(36,5);Q=lambda x:z3.RealVal(str(x))
s=z3.SolverFor('QF_RDL');s.set(timeout=a.seconds*1000,random_seed=0)
x={ij:z3.Real('q_%s_%s'%ij) for ij in combinations(range(n),2)}
b=[[z3.Real(f'b_{i}_{k}') for k in range(3)] for i in range(n)]
rows=[]
for u,v,w in b:
 s.add(0<=u,u<v,v<w,w<18,u<w+Q(D)-18,v<u+Q(D),w<v+Q(D))
 rows.append([(u,w+Q(D)-18),(v,u+Q(D)),(w,v+Q(D))])
def mem(z,row):
 return z3.Or([z3.And(lo<=z+sh,z+sh<hi) for lo,hi in row for sh in [-18,0,18]])
for (i,j),q in x.items():s.add(0<=q,q<9,mem(q,rows[i]),mem(q+9,rows[j]))
for i,j,k in combinations(range(n),3):
 u,v,w=x[i,j],x[i,k],x[j,k]
 s.add(z3.Or(z3.And(u<v,v<w,v-u<Q(D),w-v<Q(D),Q(9-D)<w-u),
             z3.And(w<v,v<u,u-v<Q(D),v-w<Q(D),Q(9-D)<u-w)))
if a.support_edge:s.add(x[0,1]==0)
start=time.monotonic();r=s.check()
out={'scope':'Exploratory all-three-arc ordered model, not a proof or planar construction',
     'points':n,'support_edge':a.support_edge,'result':str(r),'seconds':time.monotonic()-start,
     'solver':z3.get_version_string()}
if r==z3.unknown:out['reason']=s.reason_unknown()
if r==z3.sat:
 m=s.model();val=lambda z:m.eval(z).as_fraction()
 ev={ij:val(z) for ij,z in x.items()};bv=[[val(z) for z in row] for row in b]
 margins=[D-6]
 for u,v,w in bv:margins.extend([w+D-18-u,u+D-v,v+D-w])
 for (i,j),q in ev.items():
  for v,row in [(q,bv[i]),(q+9,bv[j])]:
   u,w,z=row
   rr=[(u,z+D-18),(w,u+D),(z,w+D)]
   margins.append(max(hi-v-sh for lo,hi in rr for sh in [-18,0,18] if lo<=v+sh<hi))
 for i,j,k in combinations(range(n),3):
  u,v,w=ev[i,j],ev[i,k],ev[j,k]
  assert u<v<w or w<v<u
  margins.extend([D-abs(u-v),D-abs(v-w),D-(9-abs(u-w))])
 assert min(margins)>0
 d=D-min(margins)/2
 def member(v,row):
  u,w,z=row
  return any(lo<=v+sh<=hi for lo,hi in [(u,z+d-18),(w,u+d),(z,w+d)] for sh in [-18,0,18])
 assert 6<=d<D
 for u,v,w in bv:assert 0<=u<v<w<18 and u<=w+d-18 and v<=u+d and w<=v+d
 for (i,j),q in ev.items():assert 0<=q<9 and member(q,bv[i]) and member(q+9,bv[j])
 for i,j,k in combinations(range(n),3):
  u,v,w=ev[i,j],ev[i,k],ev[j,k]
  assert (u<v<w or w<v<u) and max(abs(u-v),abs(v-w),9-abs(u-w))<=d
 out.update(diameter=str(d),degrees=str(20*d),independent_fraction_check=True,
            starts_three=[[str(z) for z in row] for row in bv],
            edge_directions={str(ij):str(z) for ij,z in ev.items()})
a.output.write_text(json.dumps(out,indent=2)+'\n')
print({k:v for k,v in out.items() if k not in ('starts_three','edge_directions')})
