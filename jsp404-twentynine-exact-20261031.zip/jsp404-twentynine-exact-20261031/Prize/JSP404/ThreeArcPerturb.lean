import Prize.JSP404.ThreeArcTwenty

/-! Widening and independently translating three-arc rows preserves pairwise
antipodal intersection when the translations differ by at most the widening. -/
namespace Prize.JSP404.ContinuousDirection

def ThreeArcRow.widenTranslate {d d' : ℝ} (R : ThreeArcRow d)
    (hdd : d ≤ d') (t : ℝ) : ThreeArcRow d' where
  a := R.a + t
  b := R.b + t
  c := R.c + t
  ab := by linarith [R.ab]
  bc := by linarith [R.bc]
  ca := by linarith [R.ca]
  width0 := by linarith [R.width0]
  width1 := by linarith [R.width1]
  width2 := by linarith [R.width2]

theorem ThreeArcRow.mem_widenTranslate {d d' : ℝ} (R : ThreeArcRow d)
    (hdd : d ≤ d') {x t u : ℝ} (hx : R.Mem x)
    (htu : t ≤ u) (hut : u ≤ t + (d' - d)) :
    (R.widenTranslate hdd t).Mem (x + u) := by
  rcases hx with hx | hx | hx
  · left
    change R.a + t ≤ x + u ∧ x + u ≤ R.c + t + d' - 18
    constructor <;> linarith [hx.1, hx.2]
  · right; left
    change R.b + t ≤ x + u ∧ x + u ≤ R.a + t + d'
    constructor <;> linarith [hx.1, hx.2]
  · right; right
    change R.c + t ≤ x + u ∧ x + u ≤ R.b + t + d'
    constructor <;> linarith [hx.1, hx.2]

theorem family_pair_widenTranslate {V : Type*} {d d' : ℝ}
    (R : V → ThreeArcRow d) (hdd : d ≤ d') (t : V → ℝ)
    (hdiff : ∀ i j, |t i - t j| ≤ d' - d)
    (hpair : ∀ i j, i ≠ j → ∃ x y : ℝ, ∃ z : ℤ,
      (R i).Mem x ∧ (R j).Mem y ∧ y = x + 9 + 18 * z) :
    ∀ i j, i ≠ j → ∃ x y : ℝ, ∃ z : ℤ,
      ((R i).widenTranslate hdd (t i)).Mem x ∧
      ((R j).widenTranslate hdd (t j)).Mem y ∧ y = x + 9 + 18 * z := by
  intro i j hij
  obtain ⟨x, y, z, hx, hy, hxy⟩ := hpair i j hij
  have hti : max (t i) (t j) ≤ t i + (d' - d) := by
    apply max_le
    · linarith
    · have h := (abs_le.mp (hdiff j i)).2
      linarith
  have htj : max (t i) (t j) ≤ t j + (d' - d) := by
    apply max_le
    · have h := (abs_le.mp (hdiff i j)).2
      linarith
    · linarith
  refine ⟨x + max (t i) (t j), y + max (t i) (t j), z,
    (R i).mem_widenTranslate hdd hx (le_max_left _ _) hti,
    (R j).mem_widenTranslate hdd hy (le_max_right _ _) htj, ?_⟩
  linarith

end Prize.JSP404.ContinuousDirection
