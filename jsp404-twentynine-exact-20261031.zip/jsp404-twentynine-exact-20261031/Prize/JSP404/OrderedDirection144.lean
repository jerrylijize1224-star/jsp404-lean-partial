import Prize.JSP404.TriangleDirection
import Prize.JSP404.ThreeDirectionChart

/-!
# Ordered forward directions for the 144-degree problem

A generic projection orders every finite configuration without changing angles.
All forward directions then lie in one half-circle. Triangle constraints become
strict betweenness and linear difference bounds. These are necessary conditions,
not an assertion of realizability or an exclusion of twenty-one vertices.
-/

namespace Prize.JSP404

open ContinuousDirection

/-- A finite injective complex configuration admits a similarity whose imaginary
coordinates are injective. No general-position hypothesis is needed. -/
theorem exists_injective_im_mul {n : ℕ} (p : Fin n → ℂ)
    (hp : Function.Injective p) :
    ∃ c : ℂ, c ≠ 0 ∧ Function.Injective (fun i => (c * p i).im) := by
  classical
  let bad : Finset ℝ := Finset.univ.image (fun ij : Fin n × Fin n =>
    ((p ij.2).im - (p ij.1).im) / ((p ij.1).re - (p ij.2).re))
  obtain ⟨t, ht⟩ := bad.exists_notMem
  let c : ℂ := ⟨1, t⟩
  have hc : c ≠ 0 := by
    intro h
    have := congrArg Complex.re h
    norm_num [c] at this
  refine ⟨c, hc, ?_⟩
  intro i j hij
  have he : (p i).im + t * (p i).re = (p j).im + t * (p j).re := by
    simpa [c, Complex.mul_im] using hij
  by_cases hr : (p i).re = (p j).re
  · apply hp
    apply Complex.ext hr
    rw [hr] at he
    linarith
  · have hden : (p i).re - (p j).re ≠ 0 := sub_ne_zero.mpr hr
    have ht' : t = ((p j).im - (p i).im) / ((p i).re - (p j).re) := by
      apply (eq_div_iff hden).mpr
      nlinarith
    exact (ht (Finset.mem_image.mpr ⟨(i, j), Finset.mem_univ _, ht'.symm⟩)).elim

theorem exists_sorted_similarity {n : ℕ} (p : Fin n → ℂ)
    (hp : Function.Injective p) :
    ∃ c : ℂ, ∃ e : Equiv.Perm (Fin n),
      c ≠ 0 ∧ StrictMono (fun i => (c * p (e i)).im) := by
  obtain ⟨c, hc, hi⟩ := exists_injective_im_mul p hp
  obtain ⟨e, he⟩ := exists_strictMono_reindex (fun i => (c * p i).im) hi
  exact ⟨c, e, hc, he⟩

theorem scaledArg_bounds_of_im_pos {z : ℂ} (h : 0 < z.im) :
    0 < scaledArg z ∧ scaledArg z < 9 := by
  have ha : 0 < z.arg := by
    have hn := Complex.arg_nonneg_iff.mpr h.le
    have he : z.arg ≠ 0 := by
      intro he
      exact (ne_of_gt h) (Complex.arg_eq_zero_iff.mp he).2
    exact lt_of_le_of_ne hn (Ne.symm he)
  have hb : z.arg < Real.pi := Complex.arg_lt_pi_iff.mpr (Or.inr (ne_of_gt h))
  unfold scaledArg
  constructor
  · exact div_pos (mul_pos (by norm_num) ha) Real.pi_pos
  · apply (div_lt_iff₀ Real.pi_pos).mpr
    linarith

namespace ContinuousDirection

theorem positiveTurn_iff_lt_of_half {x y : ℝ}
    (hx : 0 < x ∧ x < 9) (hy : 0 < y ∧ y < 9) :
    PositiveTurn x y ↔ x < y := by
  rw [positiveTurn_iff_of_normalized ⟨hx.1.le, by linarith [hx.2]⟩
    ⟨hy.1.le, by linarith [hy.2]⟩]
  constructor
  · rintro (h | h) <;> linarith [hx.1, hx.2, hy.1, hy.2]
  · intro h
    exact Or.inl ⟨by linarith, by linarith [hx.1, hy.2]⟩

theorem triangleCompatible_iff_between_of_half {u v w : ℝ}
    (hu : 0 < u ∧ u < 9) (hv : 0 < v ∧ v < 9) (hw : 0 < w ∧ w < 9) :
    TriangleCompatible u v w ↔ (u < v ∧ v < w) ∨ (w < v ∧ v < u) := by
  simp only [TriangleCompatible, positiveTurn_iff_lt_of_half hu hv,
    positiveTurn_iff_lt_of_half hu hw, positiveTurn_iff_lt_of_half hv hw,
    positiveTurn_iff_lt_of_half hv hu, positiveTurn_iff_lt_of_half hw hu,
    positiveTurn_iff_lt_of_half hw hv]
  constructor
  · rintro (h | h)
    · exact Or.inl ⟨h.1, h.2.2⟩
    · exact Or.inr ⟨h.2.2, h.1⟩
  · rintro (h | h)
    · exact Or.inl ⟨h.1, h.1.trans h.2, h.2⟩
    · exact Or.inr ⟨h.2, h.1.trans h.2, h.1⟩

theorem close_half_abs_le {d x y : ℝ} (hd : d < 9)
    (hx : 0 < x ∧ x < 9) (hy : 0 < y ∧ y < 9) (h : Close d x y) :
    |x - y| ≤ d := by
  rcases close_cases h with h | h | h
  · exact abs_le.mpr ⟨by linarith [h.2], h.1⟩
  · linarith [hx.2, hy.1]
  · linarith [hx.1, hy.2]

theorem close_reverse_half_separated {d x y : ℝ} (hd : d < 9)
    (hx : 0 < x ∧ x < 9) (hy : 0 < y ∧ y < 9) (h : Close d (x + 9) y) :
    9 - d ≤ |x - y| := by
  rcases close_cases h with h | h | h
  · have : 9 - d ≤ y - x := by linarith [h.1]
    exact this.trans (le_abs_self _ |>.trans_eq (abs_sub_comm y x))
  · exact (show 9 - d ≤ x - y by linarith).trans (le_abs_self _)
  · linarith [hx.1, hy.2]

/-- A search model on forward edges only. Weak bounds use a single d strictly
below 36/5; strict order comes from noncollinear triangles. -/
structure OrderedModel (n : ℕ) (d : ℝ) where
  direction : Fin n → Fin n → ℝ
  half : ∀ i j, i < j → 0 < direction i j ∧ direction i j < 9
  between : ∀ i j k, i < j → j < k →
    (direction i j < direction i k ∧ direction i k < direction j k) ∨
    (direction j k < direction i k ∧ direction i k < direction i j)
  left_bound : ∀ i j k, i < j → j < k → |direction i j - direction i k| ≤ d
  right_bound : ∀ i j k, i < j → j < k → |direction i k - direction j k| ≤ d
  middle_bound : ∀ i j k, i < j → j < k → 9 - d ≤ |direction i j - direction j k|

/-- The exact strict disjunction used by the exploratory search, with no
rounding or solver assumptions. -/
theorem OrderedModel.strict_triangle {n : ℕ} {d : ℝ} (M : OrderedModel n d)
    (hd : d < 36 / 5) (i j k : Fin n) (hij : i < j) (hjk : j < k) :
    (M.direction i j < M.direction i k ∧ M.direction i k < M.direction j k ∧
      M.direction i k - M.direction i j < 36 / 5 ∧
      M.direction j k - M.direction i k < 36 / 5 ∧
      9 / 5 < M.direction j k - M.direction i j) ∨
    (M.direction j k < M.direction i k ∧ M.direction i k < M.direction i j ∧
      M.direction i j - M.direction i k < 36 / 5 ∧
      M.direction i k - M.direction j k < 36 / 5 ∧
      9 / 5 < M.direction i j - M.direction j k) := by
  have hl := M.left_bound i j k hij hjk
  have hr := M.right_bound i j k hij hjk
  have hm := M.middle_bound i j k hij hjk
  rcases M.between i j k hij hjk with h | h
  · rw [abs_of_neg (sub_neg.mpr h.1)] at hl
    rw [abs_of_neg (sub_neg.mpr h.2)] at hr
    rw [abs_of_neg (sub_neg.mpr (h.1.trans h.2))] at hm
    left
    exact ⟨h.1, h.2, by linarith, by linarith, by linarith⟩
  · rw [abs_of_pos (sub_pos.mpr h.2)] at hl
    rw [abs_of_pos (sub_pos.mpr h.1)] at hr
    rw [abs_of_pos (sub_pos.mpr (h.1.trans h.2))] at hm
    right
    exact ⟨h.1, h.2, by linarith, by linarith, by linarith⟩

end ContinuousDirection

/-- Every ordinary complex configuration below 144 degrees gives an ordered
linear-inequality model. The sorting similarity adds no geometric assumption. -/
theorem exists_orderedModel_of_complex_angles_lt_four_pi_fifths
    {n : ℕ} (p : Fin n → ℂ) (hp : Function.Injective p)
    (hangle : ∀ u v w, u ≠ v → u ≠ w → v ≠ w →
      EuclideanGeometry.angle (p u) (p v) (p w) < 4 * Real.pi / 5) :
    ∃ d : ℝ, 6 ≤ d ∧ d < 36 / 5 ∧ Nonempty (OrderedModel n d) := by
  obtain ⟨c, e, hc, hsort⟩ := exists_sorted_similarity p hp
  let r : Fin n → ℂ := fun i => c * p (e i)
  have hr : Function.Injective r := (mul_right_injective₀ hc).comp (hp.comp e.injective)
  have hang : ∀ u v w, u ≠ v → u ≠ w → v ≠ w →
      EuclideanGeometry.angle (r u) (r v) (r w) < 4 * Real.pi / 5 := by
    intro u v w huv huw hvw
    have h := hangle (e u) (e v) (e w) (e.injective.ne huv)
      (e.injective.ne huw) (e.injective.ne hvw)
    change InnerProductGeometry.angle (r u - r v) (r w - r v) < _
    dsimp [r]
    rw [← mul_sub, ← mul_sub, Complex.angle_mul_left hc]
    exact h
  let q (i j : Fin n) : ℝ := scaledArg (r j - r i)
  have hhalf (i j : Fin n) (hij : i < j) : 0 < q i j ∧ q i j < 9 :=
    scaledArg_bounds_of_im_pos (by
      change 0 < (r j).im - (r i).im
      exact sub_pos.mpr (hsort hij))
  -- Take one finite maximum to obtain a common strict margin below 144°.
  let angles := Finset.univ.image (fun t : Fin n × Fin n × Fin n =>
    if t.1 ≠ t.2.1 ∧ t.1 ≠ t.2.2 ∧ t.2.1 ≠ t.2.2 then
      EuclideanGeometry.angle (r t.1) (r t.2.1) (r t.2.2) else 0)
  let s := insert (2 * Real.pi / 3) angles
  have hs : s.Nonempty := ⟨_, Finset.mem_insert_self _ _⟩
  let A := s.max' hs
  have hA0 : 2 * Real.pi / 3 ≤ A := Finset.le_max' _ _ (Finset.mem_insert_self _ _)
  have hA : A < 4 * Real.pi / 5 := by
    rcases Finset.mem_insert.mp (s.max'_mem hs) with h | h
    · change A = _ at h
      rw [h]; linarith [Real.pi_pos]
    · obtain ⟨⟨u, v, w⟩, _, he⟩ := Finset.mem_image.mp h
      change _ = A at he
      rw [← he]
      split_ifs with h
      · exact hang u v w h.1 h.2.1 h.2.2
      · positivity
  have hle (u v w : Fin n) (huv : u ≠ v) (huw : u ≠ w) (hvw : v ≠ w) :
      EuclideanGeometry.angle (r u) (r v) (r w) ≤ A := by
    apply Finset.le_max' s _
    apply Finset.mem_insert_of_mem
    exact Finset.mem_image.mpr ⟨(u,v,w), Finset.mem_univ _, by simp [huv,huw,hvw]⟩
  let D := 9 * A / Real.pi
  have hD0 : 6 ≤ D := (le_div_iff₀ Real.pi_pos).mpr (by linarith)
  have hD : D < 36 / 5 := (div_lt_iff₀ Real.pi_pos).mpr (by linarith)
  have hsmall (v u w : Fin n) (hvu : v ≠ u) (hvw : v ≠ w) (huw : u ≠ w) :
      Close D (q v u) (q v w) :=
    scaledArg_close (sub_ne_zero.mpr (hr.ne hvu.symm))
      (sub_ne_zero.mpr (hr.ne hvw.symm)) (hle u v w hvu.symm huw hvw)
  refine ⟨D, hD0, hD, ⟨{
    direction := q, half := hhalf, between := ?_, left_bound := ?_,
    right_bound := ?_, middle_bound := ?_ }⟩⟩
  · intro i j k hij hjk
    apply (triangleCompatible_iff_between_of_half (hhalf i j hij)
      (hhalf i k (hij.trans hjk)) (hhalf j k hjk)).mp
    apply triangleCompatible_of_complex_angles_lt_pi (hr.ne hij.ne)
      (hr.ne (hij.trans hjk).ne) (hr.ne hjk.ne)
    all_goals
      first
      | exact lt_trans (hang j i k hij.ne.symm hjk.ne (hij.trans hjk).ne)
          (by linarith [Real.pi_pos])
      | exact lt_trans (hang i j k hij.ne (hij.trans hjk).ne hjk.ne)
          (by linarith [Real.pi_pos])
      | exact lt_trans (hang i k j (hij.trans hjk).ne hij.ne hjk.ne.symm)
          (by linarith [Real.pi_pos])
  · intro i j k hij hjk
    exact close_half_abs_le (by linarith) (hhalf i j hij) (hhalf i k (hij.trans hjk))
      (hsmall i j k hij.ne (hij.trans hjk).ne hjk.ne)
  · intro i j k hij hjk
    have h := hsmall k i j (hij.trans hjk).ne.symm hjk.ne.symm hij.ne
    obtain ⟨a, ha⟩ := scaledArg_neg (sub_ne_zero.mpr (hr.ne (hij.trans hjk).ne.symm))
    obtain ⟨b, hb⟩ := scaledArg_neg (sub_ne_zero.mpr (hr.ne hjk.ne.symm))
    have hki : q k i = q i k + 9 + 18 * a := by
      dsimp [q]; rwa [show r i - r k = -(r k - r i) by abel]
    have hkj : q k j = q j k + 9 + 18 * b := by
      dsimp [q]; rwa [show r j - r k = -(r k - r j) by abel]
    rw [hki, hkj] at h
    obtain ⟨z, hz⟩ := h
    apply close_half_abs_le (by linarith) (hhalf i k (hij.trans hjk)) (hhalf j k hjk)
    refine ⟨z + a - b, ?_⟩
    convert hz using 1; congr 1; push_cast; ring
  · intro i j k hij hjk
    have h := hsmall j i k hij.ne.symm hjk.ne (hij.trans hjk).ne
    obtain ⟨a, ha⟩ := scaledArg_neg (sub_ne_zero.mpr (hr.ne hij.ne.symm))
    have hji : q j i = q i j + 9 + 18 * a := by
      dsimp [q]; rwa [show r i - r j = -(r j - r i) by abel]
    rw [hji] at h
    obtain ⟨z, hz⟩ := h
    apply close_reverse_half_separated (by linarith) (hhalf i j hij) (hhalf j k hjk)
    refine ⟨z + a, ?_⟩
    convert hz using 1; congr 1; push_cast; ring

theorem exists_orderedModel_of_plane_angles_lt_four_pi_fifths
    {n : ℕ} (p : Fin n → Plane) (hp : Function.Injective p)
    (hangle : ∀ u v w, u ≠ v → u ≠ w → v ≠ w →
      EuclideanGeometry.angle (p u) (p v) (p w) < 4 * Real.pi / 5) :
    ∃ d : ℝ, 6 ≤ d ∧ d < 36 / 5 ∧ Nonempty (OrderedModel n d) := by
  let e := Complex.orthonormalBasisOneI.repr.symm
  apply exists_orderedModel_of_complex_angles_lt_four_pi_fifths
    (fun v => e (p v)) (e.injective.comp hp)
  intro u v w huv huw hvw
  change InnerProductGeometry.angle (e (p u) - e (p v)) (e (p w) - e (p v)) < _
  rw [← map_sub, ← map_sub]
  change InnerProductGeometry.angle (e.toLinearIsometry (p u - p v))
    (e.toLinearIsometry (p w - p v)) < _
  rw [e.toLinearIsometry.angle_map]
  exact hangle u v w huv huw hvw

/-- Necessary ordered inequalities for an arbitrary ordinary counterexample. -/
theorem orderedModel_of_plane_counterexample {s : Finset Plane}
    (h : ¬ HasLargeAngle s (4 * Real.pi / 5)) :
    ∃ d : ℝ, 6 ≤ d ∧ d < 36 / 5 ∧ Nonempty (OrderedModel s.card d) := by
  classical
  let e := s.equivFin.symm
  let p : Fin s.card → Plane := fun i => (e i).val
  have hp : Function.Injective p := Subtype.val_injective.comp e.injective
  apply exists_orderedModel_of_plane_angles_lt_four_pi_fifths p hp
  intro u v w huv huw hvw
  apply lt_of_not_ge
  intro ha
  apply h
  exact ⟨p u, (e u).property, p v, (e v).property, p w, (e w).property,
    hp.ne huv, hp.ne huw, hp.ne hvw, ha⟩

end Prize.JSP404
