import Prize.JSP404.ThreeArcTwenty

/-! A downward crossing of a first-start sector boundary changes the row mask.
The other two starts may cross boundaries at the same time. -/
namespace Prize.JSP404.ThreeArcTwenty
open ContinuousDirection

theorem rowShape_start_mem {d : ℝ} (R : ThreeArcRow d) (hd : d < 36 / 5) :
    intSector ⌊5 * R.a / 9⌋ ∈ rowShape R := by
  exact mem_rowShape R hd (Or.inl ⟨le_refl _, R.width0⟩)

theorem rowShape_end_mem {d : ℝ} (R : ThreeArcRow d) (hd : d < 36 / 5) :
    intSector (⌊5 * R.a / 9⌋ + 4) ∈ rowShape R := by
  have h := floor_gap_le_four hd R.width1
  let A : ℤ := ⌊5 * R.a / 9⌋
  change intSector (A + 4) ∈ shape A
    (⌊5 * R.b / 9⌋ - A) (⌊5 * R.c / 9⌋ - A)
  simp only [shape, Finset.mem_filter, Finset.mem_univ, true_and]
  have hm : (((intSector (A + 4)).val : ℤ) - A) % 10 = 4 := by
    dsimp [intSector]; omega
  rw [hm]
  exact Or.inr (Or.inl ⟨h, le_refl _⟩)

theorem rowShape_ne_of_floor_predecessor {d d' : ℝ} (R : ThreeArcRow d)
    (S : ThreeArcRow d') (hd : d < 36 / 5) (hd' : d' < 36 / 5)
    (ha : ⌊5 * S.a / 9⌋ = ⌊5 * R.a / 9⌋ - 1) : rowShape R ≠ rowShape S := by
  intro heq
  have hR := rowShape_end_mem R hd
  have hS := rowShape_start_mem S hd'
  have he : intSector (⌊5 * R.a / 9⌋ - 1) =
      antipode (intSector (⌊5 * R.a / 9⌋ + 4)) := by
    apply Fin.ext
    dsimp [intSector, antipode]
    omega
  rw [ha, he, ← heq] at hS
  exact types_no_antipodes _ (rowShape_mem R hd) _ hR hS

end Prize.JSP404.ThreeArcTwenty
