import Prize.JSP404.ThreeArcMaskEvent
import Prize.JSP404.ThreeArcPerturb

/-! Strictness below 144 degrees excludes saturation of all twenty masks.
Widen slightly, translate just one row across a sector boundary, and use
the nineteen fixed rows to force the changing row's mask to stay fixed. -/
namespace Prize.JSP404.ThreeArcTwenty
open ContinuousDirection

theorem family_masks_injective {V : Type*} {d : ℝ} (hd : d < 36 / 5)
    (R : V → ThreeArcRow d)
    (hpair : ∀ i j, i ≠ j → ∃ x y : ℝ, ∃ z : ℤ,
      (R i).Mem x ∧ (R j).Mem y ∧ y = x + 9 + 18 * z) :
    Function.Injective (fun i => rowShape (R i)) := by
  intro i j heq
  change rowShape (R i) = rowShape (R j) at heq
  by_contra hij
  obtain ⟨x, y, z, hx, hy, hxy⟩ := hpair i j hij
  have hX := mem_rowShape (R i) hd hx
  have hY := mem_rowShape (R j) hd hy
  rw [← heq, hxy, sector_antipodal] at hY
  exact types_no_antipodes _ (rowShape_mem (R i) hd) _ hX hY

theorem no_twenty_family {d : ℝ} (hd : d < 36 / 5)
    (R : Fin 20 → ThreeArcRow d)
    (hpair : ∀ i j, i ≠ j → ∃ x y : ℝ, ∃ z : ℤ,
      (R i).Mem x ∧ (R j).Mem y ∧ y = x + 9 + 18 * z) : False := by
  classical
  let d' : ℝ := (d + 36 / 5) / 2
  have hdd : d ≤ d' := by dsimp [d']; linarith
  have hdd' : d < d' := by dsimp [d']; linarith
  have hd' : d' < 36 / 5 := by dsimp [d']; linarith
  let ε : ℝ := min (1 / 2) ((d' - d) / 2)
  have hε : 0 < ε := lt_min (by norm_num) (by linarith)
  have hε1 : ε ≤ 1 / 2 := min_le_left _ _
  have hεδ : ε ≤ d' - d := (min_le_right _ _).trans (by linarith)
  let t : ℝ := -(R 0).a
  let A (i : Fin 20) := (R i).widenTranslate hdd t
  let u (i : Fin 20) : ℝ := t - if i = 0 then ε else 0
  let B (i : Fin 20) := (R i).widenTranslate hdd (u i)
  have hpA := family_pair_widenTranslate R hdd (fun _ => t)
    (by intro i j; simp; linarith) hpair
  have hpB := family_pair_widenTranslate R hdd u (by
    intro i j
    dsimp [u]
    split_ifs <;> rw [abs_le] <;> constructor <;> linarith) hpair
  have hiA : Function.Injective (fun i => rowShape (A i)) := family_masks_injective hd' A hpA
  have hiB : Function.Injective (fun i => rowShape (B i)) := family_masks_injective hd' B hpB
  let f : Fin 20 → types := fun i => ⟨rowShape (A i), rowShape_mem (A i) hd'⟩
  have hf : Function.Injective f := by
    intro i j h
    exact hiA (congrArg Subtype.val h)
  have hsur : Function.Surjective f :=
    (Fintype.bijective_iff_injective_and_card f).mpr
      ⟨hf, by simp only [Fintype.card_fin, Fintype.card_coe, types_card]⟩ |>.2
  obtain ⟨j, hj⟩ := hsur ⟨rowShape (B 0), rowShape_mem (B 0) hd'⟩
  have heq : rowShape (A j) = rowShape (B 0) := congrArg Subtype.val hj
  have hj0 : j = 0 := by
    by_contra hn
    have hBA : B j = A j := by simp [A, B, u, hn]
    rw [← hBA] at heq
    exact hn (hiB heq)
  subst j
  apply rowShape_ne_of_floor_predecessor (A 0) (B 0) hd' hd' _ heq
  have ha : (A 0).a = 0 := by dsimp [A, ThreeArcRow.widenTranslate, t]; ring
  have hb : (B 0).a = -ε := by
    simp [B, u, ThreeArcRow.widenTranslate, t] <;> ring
  rw [ha, hb]
  norm_num
  apply Int.floor_eq_iff.mpr
  constructor <;> push_cast <;> linarith

theorem family_card_le_nineteen {V : Type*} [Fintype V] {d : ℝ}
    (hd : d < 36 / 5) (R : V → ThreeArcRow d)
    (hpair : ∀ i j, i ≠ j → ∃ x y : ℝ, ∃ z : ℤ,
      (R i).Mem x ∧ (R j).Mem y ∧ y = x + 9 + 18 * z) :
    Fintype.card V ≤ 19 := by
  by_contra hn
  have h20 : 20 ≤ Fintype.card V := by omega
  let e : Fin 20 → V := fun i => (Fintype.equivFin V).symm (Fin.castLE h20 i)
  have he : Function.Injective e := by
    intro i j h
    apply Fin.ext
    have := congrArg Fin.val ((Fintype.equivFin V).symm.injective h)
    exact this
  exact no_twenty_family hd (fun i => R (e i))
    (fun i j hij => hpair (e i) (e j) (he.ne hij))

end Prize.JSP404.ThreeArcTwenty
