import Prize.JSP404.PlanarReduction144

/-! Twenty possible ten-sector shapes bound every antipodally compatible
three-arc family below 144 degrees. All finite checks use the Lean kernel. -/
namespace Prize.JSP404.ThreeArcTwenty
open ContinuousDirection

abbrev Sector := Fin 10

def intSector (z : ℤ) : Sector := ⟨(z % 10).toNat, by omega⟩
def antipode (i : Sector) : Sector := ⟨(i.val + 5) % 10, by omega⟩
noncomputable def sector (x : ℝ) : Sector := intSector ⌊5 * x / 9⌋

def shape (a u v : ℤ) : Finset Sector := Finset.univ.filter fun i =>
  let r := ((i.val : ℤ) - a) % 10
  r ≤ v - 6 ∨ (u ≤ r ∧ r ≤ 4) ∨ (v ≤ r ∧ r ≤ u + 4)

def types : Finset (Finset Sector) := {
    {0, 1, 2, 4, 8}, {0, 1, 3, 4, 7}, {0, 1, 3, 7, 9},
    {0, 1, 4, 7, 8}, {0, 2, 3, 4, 6}, {0, 2, 3, 6, 9},
    {0, 2, 6, 8, 9}, {0, 3, 4, 6, 7}, {0, 3, 6, 7, 9},
    {0, 4, 6, 7, 8}, {1, 2, 3, 5, 9}, {1, 2, 4, 5, 8},
    {1, 2, 5, 8, 9}, {1, 3, 4, 5, 7}, {1, 4, 5, 7, 8},
    {1, 5, 7, 8, 9}, {2, 3, 5, 6, 9}, {2, 4, 5, 6, 8},
    {2, 5, 6, 8, 9}, {3, 5, 6, 7, 9} }

theorem types_card : types.card = 20 := by decide +kernel

theorem types_no_antipodes : ∀ T ∈ types, ∀ i : Sector,
    i ∈ T → antipode i ∉ T := by decide +kernel

theorem shape_mem_types (a u v : ℤ) (hu0 : 0 ≤ u) (hu : u ≤ 4)
    (hv : 6 ≤ v) (hvu : v - u ≤ 4) : shape a u v ∈ types := by
  have hfinite : ∀ a : Fin 10, ∀ u : Fin 5, ∀ v : Fin 9,
      6 ≤ v.val → (v.val : ℤ) - u.val ≤ 4 →
      shape a.val u.val v.val ∈ types := by decide +kernel
  let A : Fin 10 := intSector a
  let U : Fin 5 := ⟨u.toNat, by omega⟩
  let V : Fin 9 := ⟨v.toNat, by omega⟩
  have hU : (U.val : ℤ) = u := by dsimp [U]; omega
  have hV : (V.val : ℤ) = v := by dsimp [V]; omega
  have hA : (A.val : ℤ) = a % 10 := by dsimp [A, intSector]; omega
  have h := hfinite A U V (by omega) (by omega)
  rw [hU, hV, hA] at h
  have he : shape (a % 10) u v = shape a u v := by
    ext i
    simp only [shape, Finset.mem_filter, Finset.mem_univ, true_and]
    have : ((i.val : ℤ) - a % 10) % 10 = ((i.val : ℤ) - a) % 10 := by omega
    rw [this]
  rwa [he] at h

theorem sector_antipodal (x : ℝ) (z : ℤ) :
    sector (x + 9 + 18 * z) = antipode (sector x) := by
  have he : 5 * (x + 9 + 18 * z) / 9 = 5 * x / 9 + ((5 + 10 * z : ℤ) : ℝ) := by
    push_cast; ring
  unfold sector
  rw [he, Int.floor_add_intCast]
  apply Fin.ext
  simp only [intSector, antipode]
  omega

theorem floor_gap_le_four {d x y : ℝ} (hd : d < 36 / 5) (h : x ≤ y + d) :
    ⌊5 * x / 9⌋ - ⌊5 * y / 9⌋ ≤ 4 := by
  have hx := Int.floor_le (5 * x / 9)
  have hy := Int.lt_floor_add_one (5 * y / 9)
  have hlt : (⌊5 * x / 9⌋ : ℝ) - ⌊5 * y / 9⌋ < 5 := by linarith
  have : ⌊5 * x / 9⌋ - ⌊5 * y / 9⌋ < 5 := by exact_mod_cast hlt
  omega

noncomputable def rowShape {d : ℝ} (R : ThreeArcRow d) : Finset Sector :=
  shape ⌊5 * R.a / 9⌋ (⌊5 * R.b / 9⌋ - ⌊5 * R.a / 9⌋)
    (⌊5 * R.c / 9⌋ - ⌊5 * R.a / 9⌋)

theorem rowShape_mem {d : ℝ} (R : ThreeArcRow d) (hd : d < 36 / 5) :
    rowShape R ∈ types := by
  have h1 := floor_gap_le_four hd R.width1
  have h2 := floor_gap_le_four hd R.width2
  have h3 := floor_gap_le_four hd (show R.a + 18 ≤ R.c + d by linarith [R.width0])
  have he : 5 * (R.a + 18) / 9 = 5 * R.a / 9 + (10 : ℤ) := by push_cast; ring
  rw [he, Int.floor_add_intCast] at h3
  apply shape_mem_types
  · have hm := Int.floor_mono (show 5 * R.a / 9 ≤ 5 * R.b / 9 by linarith [R.ab])
    omega
  · exact h1
  · omega
  · omega

theorem mem_rowShape {d : ℝ} (R : ThreeArcRow d) (hd : d < 36 / 5)
    {x : ℝ} (hx : R.Mem x) : sector x ∈ rowShape R := by
  let A : ℤ := ⌊5 * R.a / 9⌋
  let B : ℤ := ⌊5 * R.b / 9⌋
  let C : ℤ := ⌊5 * R.c / 9⌋
  let X : ℤ := ⌊5 * x / 9⌋
  have h1 : B - A ≤ 4 := floor_gap_le_four hd R.width1
  have h2 : C - B ≤ 4 := floor_gap_le_four hd R.width2
  have h3 : 6 ≤ C - A := by
    have h := floor_gap_le_four hd (show R.a + 18 ≤ R.c + d by linarith [R.width0])
    have he : 5 * (R.a + 18) / 9 = 5 * R.a / 9 + (10 : ℤ) := by push_cast; ring
    rw [he, Int.floor_add_intCast] at h
    change A + 10 - C ≤ 4 at h
    omega
  have hsector : ((sector x).val : ℤ) = X % 10 := by
    dsimp [sector, intSector, X]; omega
  have hmod : (((sector x).val : ℤ) - A) % 10 = (X - A) % 10 := by
    rw [hsector]; omega
  change sector x ∈ shape A (B - A) (C - A)
  simp only [shape, Finset.mem_filter, Finset.mem_univ, true_and]
  rw [hmod]
  rcases hx with hx | hx | hx
  · have hlo : A ≤ X := Int.floor_mono (by linarith [hx.1])
    have hhi : X + 10 - C ≤ 4 := by
      have h := floor_gap_le_four hd (show x + 18 ≤ R.c + d by linarith [hx.2])
      have he : 5 * (x + 18) / 9 = 5 * x / 9 + (10 : ℤ) := by push_cast; ring
      rw [he, Int.floor_add_intCast] at h
      exact h
    left; omega
  · have hlo : B ≤ X := Int.floor_mono (by linarith [hx.1])
    have hhi : X - A ≤ 4 := floor_gap_le_four hd hx.2
    right; left; omega
  · have hlo : C ≤ X := Int.floor_mono (by linarith [hx.1])
    have hhi : X - B ≤ 4 := floor_gap_le_four hd hx.2
    right; right; omega

theorem family_card_le_twenty {V : Type*} [Fintype V] {d : ℝ}
    (hd : d < 36 / 5) (R : V → ThreeArcRow d)
    (hpair : ∀ i j, i ≠ j → ∃ x y : ℝ, ∃ z : ℤ,
      (R i).Mem x ∧ (R j).Mem y ∧ y = x + 9 + 18 * z) :
    Fintype.card V ≤ 20 := by
  let f : V → types := fun i => ⟨rowShape (R i), rowShape_mem (R i) hd⟩
  have hf : Function.Injective f := by
    intro i j he
    by_contra hij
    obtain ⟨x, y, z, hx, hy, hxy⟩ := hpair i j hij
    have heq : rowShape (R i) = rowShape (R j) := congrArg Subtype.val he
    have hX := mem_rowShape (R i) hd hx
    have hY := mem_rowShape (R j) hd hy
    rw [← heq, hxy, sector_antipodal] at hY
    exact types_no_antipodes _ (rowShape_mem (R i) hd) _ hX hY
  have h := Fintype.card_le_of_injective f hf
  simpa only [Fintype.card_coe, types_card] using h

end Prize.JSP404.ThreeArcTwenty
