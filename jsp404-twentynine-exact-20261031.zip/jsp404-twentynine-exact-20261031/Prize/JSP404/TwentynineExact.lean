import Prize.JSP404.ThreeArcNineteen
import Prize.JSP404.EquallySpacedBinaryAxes

/-! The ordinary twenty-nine-point value is 144 degrees. The lower bound counts
at most nine one-arc covers and nineteen three-arc covers strictly below 144.
The upper bound reuses the existing binary planar construction. -/
namespace Prize.JSP404.ContinuousDirection

theorem TriangleCoverModel.three_card_le_nineteen {V : Type*} [Fintype V] {d : ℝ}
    (M : TriangleCoverModel V d) (hd : d < 36 / 5) :
    M.threeVertices.card ≤ 19 := by
  classical
  let S := M.threeVertices
  have hex (i : S) : ∃ R : ThreeArcRow d, M.cover i.val = Sum.inr R := by
    have hi : ¬ M.IsOne i.val := (Finset.mem_filter.mp i.property).2
    cases he : M.cover i.val with
    | inl a => exact False.elim (hi ⟨a, he⟩)
    | inr R => exact ⟨R, rfl⟩
  let R (i : S) := Classical.choose (hex i)
  have hR (i : S) : M.cover i.val = Sum.inr (R i) := Classical.choose_spec (hex i)
  have hc := ThreeArcTwenty.family_card_le_nineteen hd R (by
    intro i j hij
    have hne : i.val ≠ j.val := fun h => hij (Subtype.ext h)
    obtain ⟨k, hk⟩ := M.covered i.val j.val hne
    obtain ⟨l, hl⟩ := M.covered j.val i.val hne.symm
    obtain ⟨z, hz⟩ := M.reverse i.val j.val hne
    rw [hR i] at hk
    rw [hR j] at hl
    refine ⟨M.direction i.val j.val + 18 * k,
      M.direction j.val i.val + 18 * l, z + l - k, hk, hl, ?_⟩
    push_cast
    linarith)
  simpa only [Fintype.card_coe] using hc

theorem TriangleCoverModel.card_le_twenty_eight {V : Type*} [Fintype V] {d : ℝ}
    (M : TriangleCoverModel V d) (hd0 : 0 ≤ d) (hd : d < 36 / 5) :
    Fintype.card V ≤ 28 := by
  have := M.card_le_nine_add_three hd0 hd
  have := M.three_card_le_nineteen hd
  omega

end Prize.JSP404.ContinuousDirection

namespace Prize.JSP404
open ContinuousDirection

theorem card_le_twenty_eight_of_plane_angles_four_pi_fifths
    {V : Type*} [Fintype V] (p : V → Plane) (hp : Function.Injective p)
    (hangle : ∀ u v w, u ≠ v → u ≠ w → v ≠ w →
      EuclideanGeometry.angle (p u) (p v) (p w) < 4 * Real.pi / 5) :
    Fintype.card V ≤ 28 := by
  obtain ⟨d, hd0, hd, ⟨M⟩⟩ :=
    exists_triangleCoverModel_of_plane_angles_lt_four_pi_fifths p hp hangle
  exact M.card_le_twenty_eight (by linarith) hd

theorem guaranteedAngle_four_pi_fifths_of_twenty_nine {N : ℕ} (hN : 29 ≤ N) :
    GuaranteedAngle N (4 * Real.pi / 5) := by
  intro s hs
  classical
  by_contra hn
  have hb : ∀ u v w : s, u ≠ v → u ≠ w → v ≠ w →
      EuclideanGeometry.angle (u : Plane) (v : Plane) (w : Plane) < 4 * Real.pi / 5 := by
    intro u v w huv huw hvw
    apply lt_of_not_ge
    intro ha
    apply hn
    exact ⟨u, u.property, v, v.property, w, w.property,
      (fun h => huv (Subtype.ext h)), (fun h => huw (Subtype.ext h)),
      (fun h => hvw (Subtype.ext h)), ha⟩
  have hc := card_le_twenty_eight_of_plane_angles_four_pi_fifths
    (fun u : s => (u : Plane)) Subtype.val_injective hb
  simp only [Fintype.card_coe] at hc
  omega

theorem twentynine_thirtytwo_isSharpBound {N : ℕ} (hlo : 29 ≤ N) (hhi : N ≤ 32) :
    IsSharpBound N (4 * Real.pi / 5) := by
  refine ⟨by positivity, by linarith [Real.pi_pos],
    guaranteedAngle_four_pi_fifths_of_twenty_nine hlo, ?_⟩
  intro b hb
  apply dyadic_not_guaranteed (n := 5) (by decide) (by norm_num; omega)
  norm_num
  linarith

theorem alpha_twentynine : alpha 29 = 4 * Real.pi / 5 :=
  (twentynine_thirtytwo_isSharpBound (by decide) (by decide)).alpha_eq

end Prize.JSP404
